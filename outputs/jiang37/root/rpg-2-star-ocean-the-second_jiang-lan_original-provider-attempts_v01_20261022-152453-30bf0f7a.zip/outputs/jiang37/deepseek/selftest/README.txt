SYNTHETIC CHECKER SELF-TEST — not asset evidence, not creator approval.

The canonical source `game/assets/characters/jiang-lan-native-south-v01/*manifest*.json`
was absent at run time, so the canonical check is explicitly pending. To prove the
checker and its negative control execute without SCRIPT_ERROR, a tiny 80x112 fixture
(8 role layers + hidden guide, ORA/merged image, source portrait) was generated here
and checked:

  root/    synthetic source fixture (NOT a project asset)
  run/     checker report (status pass, 17/17) plus same-output-root control:
           run/control/manifest.copy.json          clean manifest, accepted
           run/control/manifest.bad-png-hash.json  PNG hash flipped, rejected

The real canonical run must be performed by root against the produced source bank.
Art remains UNAPPROVED; GUI-clean and PXO roundtrip were not inferred.
