extends SceneTree
# sdef35 scene-default boundary/parity/capture probe (support evidence only; root owns integration/status).
# Direct deterministic scene setup, NOT physical game input: fixed 640x360, frozen nodes, isolated profile.
# Modes:
#   --mode=baseline : capture ordinary default-off frames before the prepared policy exists (policy optional).
#   --mode=parity   : capture again after the policy copy; require policy all-false, no preview flags,
#                     then pixel-equal the baseline and check scene scripts/actor transforms.
#   --mode=preview  : --scene=city|ruins|room2|loop; turn on only that existing reversible switch,
#                     prove the other three targets and accepted controls stay equal, then roll back.
# No runtime/art/default/source/ledger/index edits. No new assets. Technical only, no art/human approval.

const POLICY_PATH := "res://scripts/sdef35/rpg-2-star-ocean-the-second_mvp-scene-defaults_policy_prepared-v01_20261021-231349-a83c4bae.gd"
const LOOP_SCENE := "res://scenes/rpg-2-star-ocean-the-second_chicago-loop_district-placeholder-scene_m2-v02_20261015-185645-a7d62ba0.tscn"
const V05_SELECTOR_PATH := "res://scripts/rpg-2-star-ocean-the-second_chicago-loop_state-lake-scene-opt-in-selector_unapproved-v05_20261017-234337-84862412.gd"
const V05_SCENE := "res://scenes/rpg-2-star-ocean-the-second_chicago-loop_state-lake-block-scene_unapproved-v05_20261017-234337-84862412.tscn"
const V13_SELECTOR_PATH := "res://scripts/rpg-2-star-ocean-the-second_wdc-capitol-west_exploration-opt-in-selector_unapproved-v13_20261018-135539-63201688.gd"
const CITY_V06_PATH := "res://scripts/city_hall_park_v06_scene.gd"
const ROOM2_FLAG := "--wdc-records-chamber-v01"
const TARGET_IDS := ["scifi.city", "scifi.ruins", "scifi.ruins-survey-inner", "scifi.loop"]
const TARGETS := [
	{"id": "city", "destination": "scifi.city", "scene": "res://scenes/scifi_exploration_area.tscn", "room": 1},
	{"id": "ruins", "destination": "scifi.ruins", "scene": "res://scenes/scifi_exploration_area.tscn", "room": 1},
	{"id": "room2", "destination": "scifi.ruins", "scene": "res://scenes/survey_annex.tscn", "room": 2},
	{"id": "loop", "destination": "scifi.loop", "scene": LOOP_SCENE, "room": 1},
]
const CONTROLS := [
	{"id": "annex-room1", "destination": "scifi.ruins", "scene": "res://scenes/survey_annex.tscn", "room": 1},
	{"id": "city-room2-accepted", "destination": "scifi.city", "scene": "res://scenes/survey_annex.tscn", "room": 2},
]
const PREVIEW_FLAGS := ["--city-hall-park-v06", "--wdc-capitol-west-v13", "--wdc-capitol-west-v12r2", "--wdc-capitol-west-v12r1", "--wdc-capitol-west-v12", ROOM2_FLAG, "--chicago-state-lake-v05", "--chicago-state-lake-v04", "--chicago-state-lake-v03r1", "--chicago-state-lake-v03"]
const SOURCES := ["res://scripts/scifi_exploration_area.gd", "res://scripts/survey_annex.gd", CITY_V06_PATH, V13_SELECTOR_PATH, V05_SELECTOR_PATH, "res://scripts/rpg-2-star-ocean-the-second_chicago-loop_state-lake-block-scene_unapproved-v02_20261017-160959-55667f46.gd", "res://scripts/app_state.gd"]

var checks := 0
var failures: Array[String] = []
var out_dir := ""
var tag := ""
var mode := ""
var revision := ""
var baseline: Dictionary = {}
var cases: Array = []
var policy: Dictionary = {}
var source_before: Dictionary = {}
var scene_overrides := {}
var actual_game_input := false


func ck(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures.append(label)
		print("SDEF35_FAIL ", label)


func _initialize() -> void:
	call_deferred("run")
	create_timer(180.0).timeout.connect(func(): print("SDEF35_TIMEOUT"); quit(2))


func arg(name: String, fallback: String = "") -> String:
	var args := OS.get_cmdline_user_args()
	for i in args.size():
		if args[i] == name and i + 1 < args.size():
			return args[i + 1]
		if String(args[i]).begins_with(name + "="):
			return String(args[i]).substr(name.length() + 1)
	return fallback


func sha(path: String) -> String:
	return FileAccess.get_sha256(path) if FileAccess.file_exists(path) else ""


func image_sha(image: Image) -> String:
	if image == null:
		return ""
	var ctx := HashingContext.new()
	ctx.start(HashingContext.HASH_SHA256)
	image.convert(Image.FORMAT_RGBA8)
	ctx.update(image.get_data())
	return ctx.finish().hex_encode()


func diff_pixels(a: Image, b: Image) -> int:
	if a == null or b == null or a.get_size() != b.get_size():
		return -1
	a.convert(Image.FORMAT_RGBA8)
	b.convert(Image.FORMAT_RGBA8)
	var x := a.get_data()
	var y := b.get_data()
	var total := 0
	for i in range(0, x.size(), 4):
		if x[i] != y[i] or x[i + 1] != y[i + 1] or x[i + 2] != y[i + 2] or x[i + 3] != y[i + 3]:
			total += 1
	return total


func freeze(node: Node) -> void:
	node.process_mode = Node.PROCESS_MODE_DISABLED
	node.set_process(false)
	node.set_physics_process(false)
	node.set_process_input(false)
	node.set_process_unhandled_input(false)
	if node is AnimationPlayer:
		node.stop()
	if node is AnimatedSprite2D:
		node.stop()
	if node is Timer:
		node.stop()
	for child in node.get_children():
		freeze(child)


func detach_audio(node: Node) -> void:
	for child in node.get_children():
		if child is AudioStreamPlayer or child is AudioStreamPlayer2D or child is AudioStreamPlayer3D:
			child.stop()
			child.stream = null
		detach_audio(child)


func kill_tweens() -> void:
	for tween in get_processed_tweens():
		tween.kill()


func make_image(c: Dictionary, language: String) -> Dictionary:
	begin_state(c, language)
	var node = load(c.scene).instantiate()
	root.add_child(node)
	# room2 direct preview: the real _build_wdc_room_two() path, only when this run did not carry the flag.
	var room2_direct := false
	if c.id == "room2" and scene_overrides.get("room2", false) and not OS.get_cmdline_user_args().has(ROOM2_FLAG):
		node._build_wdc_room_two()
		room2_direct = true
	freeze(node)
	node._refresh_text()
	kill_tweens()
	for i in 3:
		await process_frame
	await RenderingServer.frame_post_draw
	var image: Image = root.get_texture().get_image()
	image.convert(Image.FORMAT_RGBA8)
	var hero = node.get("hero")
	var has_hero := hero != null
	var info := {
		"id": c.id, "language": language, "scene": c.scene, "room": c.room,
		"sceneScript": node.get_script().resource_path,
		"heroPosition": var_to_str(hero.position) if has_hero else "",
		"heroScale": var_to_str(hero.scale) if has_hero else "",
		"heroOffset": var_to_str(hero.offset) if has_hero else "",
		"heroFlipH": hero.flip_h if has_hero else false,
		"heroTextureSha256": image_sha(hero.texture.get_image()) if has_hero and hero.texture != null else "",
		"room2DirectSetup": room2_direct,
		"native640": image.get_size() == Vector2i(640, 360),
	}
	detach_audio(node)
	root.remove_child(node)
	node.free()
	await process_frame
	info["image"] = image
	info["rgbaSha256"] = image_sha(image)
	return info


func begin_state(c: Dictionary, language: String) -> void:
	var app: Node = root.get_node("AppState")
	app.begin_new_run()
	app.hero_appearance = "female"
	app.language = language
	app.current_destination_id = c.destination
	app.current_annex_room = c.room
	app.show_initial_guide = false
	app.returning_from_battle = false
	app.resume_area_pending = false
	app.resume_annex_pending = false
	app.play_time_seconds = 84.0
	app.run_active = false
	app.set_process(false)


func save_case(c: Dictionary, language: String, label: String) -> Dictionary:
	var first: Dictionary = await make_image(c, language)
	var second: Dictionary = await make_image(c, language)
	var image: Image = first.image
	var row: Dictionary = first.duplicate()
	row.erase("image")
	row["label"] = label
	row["repeatDiffPixels"] = diff_pixels(image, second.image)
	row["file"] = "rpg-2-star-ocean-the-second_scene-defaults_%s_%s_%s_640_sdef35-v01_%s.png" % [c.id, language, label, tag]
	ck(image.save_png(out_dir.path_join(row.file)) == OK, "save png " + row.file)
	row["pngSha256"] = sha(out_dir.path_join(row.file))
	row["baselineDiffPixels"] = -2
	if not baseline.is_empty():
		var found := 0
		for item in baseline.get("cases", []):
			if String(item.get("id", "")) == c.id and String(item.get("language", "")) == language:
				found += 1
				var src := Image.load_from_file(String(baseline["outDir"]).path_join(String(item["file"])))
				ck(src != null, "baseline image loads " + c.id + " " + language)
				row["baselineDiffPixels"] = diff_pixels(src, image)
		ck(found == 1, "one baseline row " + c.id + " " + language)
	return row


func case_by_id(id: String) -> Dictionary:
	for c in TARGETS:
		if c.id == id:
			return c
	for c in CONTROLS:
		if c.id == id:
			return c
	return {}


func collect_policy_pairs(value: Variant, depth: int, out: Dictionary) -> void:
	if depth > 4:
		return
	if typeof(value) == TYPE_DICTIONARY:
		for key in value:
			var k := String(key)
			var v = value[key]
			if TARGET_IDS.has(k) and typeof(v) == TYPE_BOOL:
				out[k] = v
			else:
				collect_policy_pairs(v, depth + 1, out)
	elif typeof(value) == TYPE_ARRAY:
		for item in value:
			collect_policy_pairs(item, depth + 1, out)


func probe_policy() -> Dictionary:
	var result := {"present": false, "loaded": false, "defaults": {}, "allFourFalse": false, "constants": []}
	if not ResourceLoader.exists(POLICY_PATH):
		return result
	result["present"] = true
	var script = load(POLICY_PATH)
	if script == null:
		return result
	result["loaded"] = true
	var constants: Dictionary = script.get_script_constant_map()
	result["constants"] = constants.keys()
	var defaults := {}
	for key in constants:
		collect_policy_pairs(constants[key], 0, defaults)
	result["defaults"] = defaults
	var all_false := defaults.size() == 4
	for key in defaults:
		if typeof(defaults[key]) != TYPE_BOOL or defaults[key] != false:
			all_false = false
	result["allFourFalse"] = all_false
	return result


func preview_flags() -> Array:
	var found := []
	for a in OS.get_cmdline_user_args():
		if PREVIEW_FLAGS.has(a):
			found.append(a)
	return found


func switch_state() -> Dictionary:
	var city = load(CITY_V06_PATH)
	var v13 = load(V13_SELECTOR_PATH)
	var v05 = load(V05_SELECTOR_PATH)
	return {
		"cityV06Enabled": city.enabled(),
		"ruinsV13Enabled": v13.v13_enabled(),
		"loopV05Enabled": v05.v05_enabled(),
		"room2Flag": OS.get_cmdline_user_args().has(ROOM2_FLAG),
		"cityOverride": city.enabled_override,
		"ruinsOverride": v13.v13_override,
		"loopOverride": v05.v05_override,
	}


func reset_overrides() -> void:
	load(CITY_V06_PATH).enabled_override = -1
	load(V13_SELECTOR_PATH).v13_override = -1
	load(V05_SELECTOR_PATH).v05_override = -1
	scene_overrides.clear()


func apply_preview(scene_id: String) -> Dictionary:
	reset_overrides()
	var detail := {"scene": scene_id, "kind": "existing reversible selector switch", "applied": false}
	if scene_id == "city":
		load(CITY_V06_PATH).enabled_override = 1
		scene_overrides["city"] = true
		detail["applied"] = true
	elif scene_id == "ruins":
		load(V13_SELECTOR_PATH).v13_override = 1
		scene_overrides["ruins"] = true
		detail["applied"] = true
	elif scene_id == "room2":
		scene_overrides["room2"] = true
		detail["flag"] = OS.get_cmdline_user_args().has(ROOM2_FLAG)
		detail["kind"] = "existing room2 flag" if detail["flag"] else "direct _build_wdc_room_two() setup (flag absent)"
		detail["applied"] = true
	elif scene_id == "loop":
		var v05 = load(V05_SELECTOR_PATH)
		v05.v05_override = 1
		scene_overrides["loop"] = true
		detail["applied"] = true
		detail["newestSelectorFlagRecognized"] = v05.v05_enabled()
	return detail


func selector_handoff() -> Dictionary:
	# Test the newest Chicago selector's real handoff with its documented override, from a selector root.
	var v05 = load(V05_SELECTOR_PATH)
	v05.v05_override = 1
	var host := Node2D.new()
	host.set_script(v05)
	root.add_child(host)
	var reached := false
	for i in 60:
		await process_frame
		if current_scene != null and String(current_scene.get_script().resource_path) == String(load(V05_SCENE).get_script().resource_path):
			reached = true
			break
	var script_path := String(current_scene.get_script().resource_path) if current_scene != null else ""
	var result := {"flagRecognized": v05.v05_enabled(), "expectedSceneScript": String(load(V05_SCENE).get_script().resource_path), "handoffSceneScript": script_path, "reachedNewestScene": reached}
	if current_scene != null:
		current_scene.queue_free()
		current_scene = null
	host.queue_free()
	await process_frame
	return result


func loop_root_script() -> String:
	var node: Node = load(LOOP_SCENE).instantiate()
	var path := String(node.get_script().resource_path)
	node.free()
	return path


func write_report(result: String) -> void:
	var after := {}
	for path in SOURCES:
		after[path] = sha(path)
	var report := {
		"mode": mode, "result": result, "failed": failures, "checkCount": checks,
		"testedRevision": revision, "policyPath": POLICY_PATH, "policy": policy,
		"policyPresent": policy.get("present", false), "policyAllFourFalse": policy.get("allFourFalse", false),
		"previewFlags": preview_flags(), "switchState": switch_state(),
		"loopNormalSceneRootScript": loop_root_script(),
		"sourceRawSha256Before": source_before, "sourceRawSha256After": after,
		"probePath": get_script().resource_path, "probeRawSha256": sha(get_script().resource_path),
		"tag": tag, "outDir": out_dir, "baselinePath": String(baseline.get("path", "")),
		"cases": cases, "inputKind": "direct deterministic scene setup", "actualGameInput": actual_game_input,
		"directSetup": true, "motionOrArtApproval": false, "humanPlaytest": false,
		"scope": "sdef35 boundary/parity/capture support only; root owns integration comparison and final gate",
		"completedAt": Time.get_datetime_string_from_system(true),
	}
	var f := FileAccess.open(out_dir.path_join("rpg-2-star-ocean-the-second_scene-defaults_%s_proof_sdef35-v01_%s.json" % [mode, tag]), FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(report, "  ") + "\n")
		f.close()
	else:
		failures.append("report writable")


func finish() -> void:
	var ok := failures.is_empty()
	write_report("PASS" if ok else "FAIL")
	print("SDEF35_RESULT ", "PASS" if ok else "FAIL", " mode=", mode, " checks=", checks, " failures=", failures.size())
	if ok:
		print("SDEF35_PASS mode=", mode, " checks=", checks)
		quit(0)
	else:
		print("SDEF35_FAILURES ", JSON.stringify(failures))
		quit(1)


func run() -> void:
	mode = arg("--mode")
	out_dir = arg("--out")
	tag = arg("--tag")
	revision = arg("--revision", "unknown")
	var baseline_path := arg("--baseline")
	var scene_id := arg("--scene")
	ck(mode in ["baseline", "parity", "preview"], "mode baseline|parity|preview")
	ck(out_dir != "", "out dir")
	ck(tag != "", "tag")
	ck(scene_id == "" or scene_id in ["city", "ruins", "room2", "loop"], "scene id")
	DirAccess.make_dir_recursive_absolute(out_dir)
	root.size = Vector2i(640, 360)
	root.gui_disable_input = true
	SaveStore.root_path = "user://test-saves/sdef35-" + tag
	for path in SOURCES:
		source_before[path] = sha(path)
	policy = probe_policy()
	if baseline_path != "" and FileAccess.file_exists(baseline_path):
		baseline = JSON.parse_string(FileAccess.get_file_as_string(baseline_path))
		if typeof(baseline) != TYPE_DICTIONARY:
			baseline = {}
		else:
			baseline["path"] = baseline_path
	if mode == "baseline":
		# Baseline must work with or without the prepared policy; policy presence is recorded, not required.
		if policy.get("present", false):
			print("SDEF35_NOTE baseline run sees policy; pixels are still captured default-off")
	elif mode in ["parity", "preview"]:
		ck(not baseline.is_empty(), "baseline json present")
		ck(policy.get("present", false), "prepared policy present")
		ck(policy.get("loaded", false), "prepared policy loads")
		ck(policy.get("allFourFalse", false), "policy exposes four bool scene defaults, all false")
		if mode == "parity":
			ck(preview_flags().is_empty(), "parity run has no preview flag")
		if mode == "preview":
			ck(scene_id != "", "preview scene id")
	if mode == "preview" and scene_id == "loop":
		actual_game_input = false

	var langs := ["en", "zh"]
	for language in langs:
		if mode == "preview":
			var live := {}
			for c in TARGETS:
				live[c.id] = await save_case(c, language, "default")
			for c in CONTROLS:
				live[c.id] = await save_case(c, language, "default")
			if language == langs[0]:
				ck(live["city"].baselineDiffPixels == 0, "preview live default city equals baseline")
				reset_overrides()
				var detail := apply_preview(scene_id)
				ck(detail.get("applied", false), "preview switch applied " + scene_id)
				var target_case: Dictionary = case_by_id(scene_id).duplicate()
				if scene_id == "loop":
					# The normal Loop tscn still names the code-drawn placeholder; capture the newest v05 scene
					# directly and prove the v05 selector handoff separately below. This is direct setup, not input.
					target_case["scene"] = V05_SCENE
				var target: Dictionary = await save_case(target_case, language, "preview")
				for c in TARGETS:
					if c.id != scene_id:
						var other: Dictionary = await save_case(c, language, "preview-control")
						ck(other.baselineDiffPixels == 0, "preview leaves other target equal: " + c.id)
						other["controlRole"] = "other target unchanged"
						cases.append(other)
				for c in CONTROLS:
					var control: Dictionary = await save_case(c, language, "preview-control")
					ck(control.baselineDiffPixels == 0, "preview leaves accepted control equal: " + c.id)
					control["controlRole"] = "accepted annex control unchanged"
					cases.append(control)
				if scene_id == "loop":
					var handoff: Dictionary = await selector_handoff()
					handoff["normalLoopRootScript"] = loop_root_script()
					handoff["normalLoopUsesV05Selector"] = String(handoff["normalLoopRootScript"]).contains("chicago-loop_state-lake-scene-opt-in-selector")
					target["newestSelectorHandoff"] = handoff
					ck(handoff["reachedNewestScene"], "Chicago newest v05 selector actually reaches v05 scene")
					ck(handoff["flagRecognized"], "Chicago newest v05 selector flag recognized")
				ck(target.repeatDiffPixels == 0, "preview capture deterministic " + scene_id)
				ck(target.baselineDiffPixels != 0, "preview target differs from default " + scene_id)
				target["previewControl"] = detail
				cases.append(target)
				# Exact rollback: restore the existing switch and recapture the target.
				reset_overrides()
				scene_overrides.clear()
				if scene_id == "room2" and OS.get_cmdline_user_args().has(ROOM2_FLAG):
					# The room2 flag is process-level; rollback is the separate no-flag parity run.
					var pending := {"id": "room2", "language": language, "controlRole": "rollback pending separate no-flag parity run", "baselineDiffPixels": -2}
					cases.append(pending)
					print("SDEF35_NOTE room2 rollback requires the separate no-flag parity invocation")
				else:
					var rolled: Dictionary = await save_case(case_by_id(scene_id), language, "rollback")
					ck(rolled.baselineDiffPixels == 0, "exact rollback target equals baseline " + scene_id)
					rolled["controlRole"] = "exact rollback"
					cases.append(rolled)
			else:
				# Bilingual preview capture only (no repeated switch assertions); zh target + rollback.
				reset_overrides()
				apply_preview(scene_id)
				var target_case_zh: Dictionary = case_by_id(scene_id).duplicate()
				if scene_id == "loop":
					target_case_zh["scene"] = V05_SCENE
				var target_zh: Dictionary = await save_case(target_case_zh, language, "preview")
				reset_overrides()
				ck(target_zh.baselineDiffPixels != 0, "zh preview target differs " + scene_id)
				cases.append(target_zh)
				if scene_id == "room2" and OS.get_cmdline_user_args().has(ROOM2_FLAG):
					cases.append({"id": "room2", "language": language, "controlRole": "rollback pending separate no-flag parity run", "baselineDiffPixels": -2})
				else:
					var rollback_zh: Dictionary = await save_case(case_by_id(scene_id), language, "rollback")
					ck(rollback_zh.baselineDiffPixels == 0, "zh rollback target equals baseline " + scene_id)
					cases.append(rollback_zh)
		else:
			for c in TARGETS:
				var row: Dictionary = await save_case(c, language, "default")
				cases.append(row)
				ck(row.repeatDiffPixels == 0, "repeat deterministic " + c.id + " " + language)
				ck(row.native640, "native 640 " + c.id)
				if mode == "parity":
					ck(row.baselineDiffPixels == 0, "default-off pixel equality " + c.id + " " + language)
					var base_row := {}
					for item in baseline.get("cases", []):
						if String(item.get("id", "")) == c.id and String(item.get("language", "")) == language:
							base_row = item
					ck(not base_row.is_empty(), "baseline row present " + c.id + " " + language)
					ck(row.sceneScript == String(base_row.get("sceneScript", "")), "scene script parity " + c.id)
					ck(row.heroTextureSha256 == String(base_row.get("heroTextureSha256", "")), "actor texture parity " + c.id)
					ck(row.heroPosition == String(base_row.get("heroPosition", "")), "actor position parity " + c.id)
			for c in CONTROLS:
				var row: Dictionary = await save_case(c, language, "control")
				cases.append(row)
				ck(row.repeatDiffPixels == 0, "control deterministic " + c.id + " " + language)
				if mode == "parity":
					ck(row.baselineDiffPixels == 0, "accepted control pixel equality " + c.id + " " + language)
	reset_overrides()
	finish()
