# One-shot, byte-exact hook application for sdef35 (keeps each file's own line endings).
import pathlib, sys
ROOT = pathlib.Path(sys.argv[1])
P = 'const SceneDefaults35 := preload("res://scripts/sdef35/rpg-2-star-ocean-the-second_mvp-scene-defaults_policy_prepared-v01_20261021-231349-a83c4bae.gd")'
S = "game/scripts/"
EDITS = [
 (S + "city_hall_park_v06_scene.gd", [
  ('const CLI_FLAG := "--city-hall-park-v06"', 'const CLI_FLAG := "--city-hall-park-v06"\n' + P),
  ("\treturn OS.get_cmdline_user_args().has(CLI_FLAG)\n",
   "\tif OS.get_cmdline_user_args().has(CLI_FLAG):\n\t\treturn true\n\t# MVP default fallback (sdef35 policy; false until the creator authorizes it).\n\treturn SceneDefaults35.default_on(SceneDefaults35.CITY)\n")]),
 (S + "rpg-2-star-ocean-the-second_wdc-capitol-west_exploration-opt-in-selector_unapproved-v13_20261018-135539-63201688.gd", [
  ('const V13_FLAG := "--wdc-capitol-west-v13"', 'const V13_FLAG := "--wdc-capitol-west-v13"\n' + P),
  ("\treturn OS.get_cmdline_user_args().has(V13_FLAG)\n",
   "\tvar args := OS.get_cmdline_user_args()\n\tif args.has(V13_FLAG):\n\t\treturn true\n"
   "\t# MVP default fallback (sdef35 policy; false until the creator authorizes it). Any explicit older\n"
   "\t# v12/v12r1/v12r2 override or flag keeps its own behaviour.\n"
   "\tif v12_override >= 0 or r1_override >= 0 or r2_override >= 0:\n\t\treturn false\n"
   "\tif args.has(V12_FLAG) or args.has(R1_FLAG) or args.has(R2_FLAG):\n\t\treturn false\n"
   "\treturn SceneDefaults35.default_on(SceneDefaults35.RUINS)\n")]),
 (S + "survey_annex.gd", [
  ('const WDC_ROOM_TWO_FLAG := "--wdc-records-chamber-v01"', 'const WDC_ROOM_TWO_FLAG := "--wdc-records-chamber-v01"\n' + P),
  ("\tif wdc_room_two_walls and OS.get_cmdline_user_args().has(WDC_ROOM_TWO_FLAG):\n",
   "\t# Flag first, then the MVP default fallback (sdef35 policy; false until the creator authorizes it).\n"
   "\tif wdc_room_two_walls and (OS.get_cmdline_user_args().has(WDC_ROOM_TWO_FLAG) or SceneDefaults35.default_on(SceneDefaults35.RECORDS)):\n")]),
 (S + "rpg-2-star-ocean-the-second_chicago-loop_state-lake-scene-opt-in-selector_unapproved-v05_20261017-234337-84862412.gd", [
  ("# not accepted). NOT WIRED: in this pass the runtime Loop .tscn still names the v04 selector, because\n"
   "# another session may be editing that shared file. The v05 Godot capture check proves this selector by\n"
   "# handing the Loop scene path a test-only in-memory copy of the Loop scene whose root uses this script\n"
   "# (exactly what a one-line `path=` change in the Loop .tscn would do), then flying in from the world map.\n",
   "# not accepted). WIRED (sdef35, 2026-10-21): the runtime Loop .tscn names this selector. It was previously\n"
   "# proven through a test-only in-memory copy of the Loop scene (v05 Godot capture check); that check's\n"
   "# 'still names v04' source pin is now historical.\n"),
  ('const V05_FLAG := "--chicago-state-lake-v05"', 'const V05_FLAG := "--chicago-state-lake-v05"\n' + P),
  ("\t\ttarget = V04Selector.V03R1Selector.V03Selector.V03_SCENE\n",
   "\t\ttarget = V04Selector.V03R1Selector.V03Selector.V03_SCENE\n"
   "\telif v05_override != 0 and SceneDefaults35.default_on(SceneDefaults35.CHICAGO):\n"
   "\t\t# MVP default fallback after every explicit flag (sdef35 policy; false until the creator authorizes it).\n"
   "\t\ttarget = V05_SCENE\n")]),
 ("game/scenes/rpg-2-star-ocean-the-second_chicago-loop_district-placeholder-scene_m2-v02_20261015-185645-a7d62ba0.tscn", [
  ("state-lake-scene-opt-in-selector_unapproved-v04_20261017-230650-c0d4b7f0.gd", "state-lake-scene-opt-in-selector_unapproved-v05_20261017-234337-84862412.gd")]),
]
for rel, reps in EDITS:
    p = ROOT / rel
    raw = p.read_bytes()
    crlf = b"\r\n" in raw
    text = raw.decode("utf-8")
    if crlf:
        text = text.replace("\r\n", "\n")
    for old, new in reps:
        n = text.count(old)
        if n != 1:
            sys.exit(f"FAIL {rel}: {n} matches for {old[:60]!r}")
        text = text.replace(old, new)
    if crlf:
        text = text.replace("\n", "\r\n")
    p.write_bytes(text.encode("utf-8"))
    print("EDITED", rel, "crlf" if crlf else "lf")
