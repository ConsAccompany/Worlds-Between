extends SceneTree

# TEST-ONLY runtime set check for the ordinary male mpath24 hero and the ordinary Liang lpath30 City Hall field NPC
# (qa.char.protagonist-male.runtime-set-check, qa.char.liang-xu.runtime-set-check). Changes no runtime, default, asset,
# mechanic or save schema; sets no pilot flag or override. Art/motion remain UNAPPROVED.
#
#   godot --path game [--headless] -s <abs>/tools/<this file> -- <out_dir> <tag> [en|zh] [30|60|mixed] [--capture]
#
# out_dir and tag are positional and required; language (default en) and fps mode (default 60) are optional positional.
# --capture saves viewport PNGs (needs a real renderer; refused under the headless display server).
# Male: the normal exploration scene at scifi.outskirts with no pilot flags; the hero is driven only by Input actions
# through the host's own _process (140 px/s, its collision clamp). Liang: the normal scene at scifi.city; the recruit
# NPC keeps its City Hall placement and its ordinary static presentation is checked first. Liang's four-direction
# idle/walk/stop drive afterwards is a labelled TEST-ONLY FIXTURE calling the driver's face()/walk()/idle() directly:
# the NPC never moves, is never recruited and is never a follower.
# Shared clock: host and driver processing are disabled and every tick calls driver.advance(dt) then the host
# (engine order: the driver has process_priority -1). Expected frames come from the source JSON durations, not frame_at.
# Foot slip oracle: floor-row (pivot.y - 1) opaque runs in the raw source PNGs. A pair passes only if some contact run
# stays within LOCK_TEXELS in world space; that is a best-case lower bound because foot identity is not authored in
# the runtime package, so a passing lower bound is reported UNRESOLVED, never PASS.
# Markers: MLX36_FAIL <check>, MLX36_TIMEOUT, then MLX36_TECHNICAL_PASS / MLX36_UNRESOLVED / MLX36_FAILED.
# Exit 0 = every group PASS, 1 = any FAIL, 2 = bad args/timeout, 3 = no FAIL but slip UNRESOLVED.

const Pilot := preload("res://scripts/exploration_sprite_set_pilot.gd")
const MALE_DRIVER := "res://scripts/mpath24/rpg-2-star-ocean-the-second_male-playable-path_explore-driver_opt-in-v01_20261021-170200-5e1c24a7.gd"
const MALE_CONFIG := "res://scripts/mpath24/rpg-2-star-ocean-the-second_male-playable-path_config_opt-in-v01_20261021-170200-5e1c24a7.gd"
const LIANG_DRIVER := "res://scripts/lpath30/rpg-2-star-ocean-the-second_liang-playable-path_npc-driver_opt-in-v01_20261021-202247-ca439d91.gd"
const LIANG_CONFIG := "res://scripts/lpath30/rpg-2-star-ocean-the-second_liang-playable-path_config_opt-in-v01_20261021-202247-ca439d91.gd"
const ZHAO_DRIVER := "res://scripts/zpath27/rpg-2-star-ocean-the-second_zhao-playable-path_npc-driver_opt-in-v01_20261021-223218-3246d731.gd"
const PILOT_PATH := "res://scripts/exploration_sprite_set_pilot.gd"
const HOST_SCRIPT := "res://scripts/scifi_exploration_area.gd"
const SCENE := "res://scenes/scifi_exploration_area.tscn"
const SAVE_ROOT := "user://test-saves/xcheck36-male-liang"
const DIRS := ["south", "west", "north", "east"]
const OPPOSITE := {"south": "north", "north": "south", "west": "east", "east": "west"}
const INPUT := {"south": "move_down", "north": "move_up", "west": "move_left", "east": "move_right"}
const UNIT := {"south": Vector2(0, 1), "north": Vector2(0, -1), "west": Vector2(-1, 0), "east": Vector2(1, 0)}
const MOVE_SPEED := 140.0
const LOCK_TEXELS := 1.0
const MIXED_DT := [1.0 / 60.0, 1.0 / 30.0, 1.0 / 144.0, 0.025, 1.0 / 60.0, 0.05]
# Outskirts starts: 3 walk cycles (201 px) stay inside the clamp, > 23 px from the patrol and out of the bypass zone.
const MALE_STARTS := {"south": Vector2(100, 80), "north": Vector2(100, 300), "west": Vector2(520, 290), "east": Vector2(40, 290)}
const DEADLINE_S := 240.0

var out := ""
var tag := ""
var language := "en"
var fps_mode := "60"
var capture := false
var dt_index := 0
var failed := false
var groups := {}
var failures: Array = []
var captures: Array = []
var trials: Array = []
var slip := {}
var hashes_start := {}
var notes: Array = []


func _initialize() -> void:
	create_timer(DEADLINE_S).timeout.connect(func():
		print("MLX36_TIMEOUT")
		quit(2))
	_run.call_deferred()


func ck(ok: bool, group: String, label: String, detail: Variant = null) -> bool:
	if not groups.has(group):
		groups[group] = {"passed": 0, "failed": 0}
	groups[group]["passed" if ok else "failed"] += 1
	if not ok:
		failed = true
		if failures.size() < 300:
			failures.append({"group": group, "check": label, "detail": detail})
		print("MLX36_FAIL ", group, " ", label, " ", detail)
	return ok


func next_dt() -> float:
	if fps_mode == "30":
		return 1.0 / 30.0
	if fps_mode == "60":
		return 1.0 / 60.0
	var dt: float = MIXED_DT[dt_index % MIXED_DT.size()]
	dt_index += 1
	return dt


# ---------- independent source reading ----------

func read_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK:
		return null
	return json.data


func resolve(base_dir: String, file: String) -> String:
	return file if file.contains("://") else base_dir.path_join(file).simplify_path()


func read_source(actor: String, registry: String, supplement: String) -> Dictionary:
	var src := {"ok": false, "actor": actor, "registry": registry, "supplement": supplement}
	var reg = read_json(registry)
	if not ck(reg is Dictionary and reg.get("actors") is Dictionary and reg["actors"].has(actor), "package", actor + " registry lists actor"):
		return src
	var set_path := resolve(registry.get_base_dir(), String(reg["actors"][actor]))
	var data = read_json(set_path)
	var sup = read_json(supplement)
	if not ck(data is Dictionary and sup is Dictionary, "package", actor + " set and supplement JSON readable", [set_path, supplement]):
		return src
	src["set_path"] = set_path
	src["density"] = int(data["density"])
	src["frame_size"] = Vector2(float(data["frame_size"][0]), float(data["frame_size"][1]))
	src["pivot"] = Vector2(float(data["pivot"][0]), float(data["pivot"][1]))
	src["frame_ms"] = int(sup["frame_ms"])
	src["settle_ms"] = int(sup["settle_ms_inclusive"])
	ck(Vector2(float(sup["pivot"][0]), float(sup["pivot"][1])) == src["pivot"], "anchors", actor + " supplement pivot equals set pivot")
	var clips := {}
	for action in ["idle", "walk"]:
		clips[action] = {}
		for d in DIRS:
			var files: Array = []
			var durs: Array = []
			for entry in data["actions"][action][d]:
				files.append(resolve(set_path.get_base_dir(), String(entry["file"])))
				durs.append(int(entry["duration_ms"]))
			clips[action][d] = {"files": files, "durs": durs}
	src["clips"] = clips
	var bridges := {}
	for d in DIRS:
		bridges[d] = []
		var walk_n: int = clips["walk"][d]["files"].size()
		ck(sup["phase_bridges"][d].size() == walk_n, "frames", "%s %s one stop bridge per walk phase" % [actor, d], [sup["phase_bridges"][d].size(), walk_n])
		for p in walk_n:
			var entries: Array = sup["phase_bridges"][d].get("phase%d" % p, [])
			var files: Array = []
			if ck(entries.size() == 4, "frames", "%s %s/phase%d bridge has 4 entries" % [actor, d, p]):
				ck(entries[0].get("ref") == "walk" and int(entries[0].get("index", -1)) == p, "frames", "%s %s/phase%d starts on walk p" % [actor, d, p])
				ck(entries[3].get("ref") == "idle" and int(entries[3].get("index", -1)) == 0, "frames", "%s %s/phase%d ends on idle f00" % [actor, d, p])
				files.append(clips["walk"][d]["files"][p])
				for i in [1, 2]:
					var path := resolve(supplement.get_base_dir(), String(entries[i]["file"]))
					ck(FileAccess.get_sha256(path) == String(entries[i]["sha256"]).to_lower(), "frames", "%s %s/phase%d s%d sha256" % [actor, d, p, i], path)
					files.append(path)
				files.append(clips["idle"][d]["files"][0])
			bridges[d].append(files)
	src["bridges"] = bridges
	src["ok"] = true
	return src


func source_files(src: Dictionary) -> Array:
	var files: Array = [src["registry"], src["set_path"], src["supplement"]]
	for action in ["idle", "walk"]:
		for d in DIRS:
			files.append_array(src["clips"][action][d]["files"])
	for d in DIRS:
		for chain in src["bridges"][d]:
			for f in [chain[1], chain[2]]:
				if not files.has(f):
					files.append(f)
	return files


func expected_frame(durs: Array, t_us: int) -> int:
	var cycle := 0
	for d in durs:
		cycle += int(d) * 1000
	var t := t_us % cycle
	var acc := 0
	for i in durs.size():
		acc += int(durs[i]) * 1000
		if t < acc:
			return i
	return durs.size() - 1


func raw_image(path: String) -> Image:
	var image := Image.new()
	if image.load_png_from_buffer(FileAccess.get_file_as_bytes(path)) != OK:
		return null
	image.convert(Image.FORMAT_RGBA8)
	return image


func floor_runs(image: Image, row: int) -> Array:
	var runs: Array = []
	var start := -1
	for x in image.get_width() + 1:
		var on := x < image.get_width() and image.get_pixel(x, row).a > 0.5
		if on and start < 0:
			start = x
		elif not on and start >= 0:
			runs.append([start, x - 1])
			start = -1
	return runs


# ---------- package, anchors, pivot/scale ----------

func check_package(src: Dictionary, prepared: Dictionary, label: String) -> void:
	var actor: String = src["actor"]
	ck(prepared.get("ok", false), "package", label + " runtime package prepared whole", prepared.get("errors", []))
	if not prepared.get("ok", false):
		return
	var pset: Dictionary = prepared["set"]
	ck(int(pset["density"]) == src["density"] and Vector2(pset["frame_size"]) == src["frame_size"] and Vector2(pset["pivot"]) == src["pivot"], "anchors", actor + " runtime density/frame/pivot equal source JSON")
	ck(int(prepared["frame_ms"]) == src["frame_ms"] and src["settle_ms"] == src["frame_ms"] * 3, "frames", actor + " stop frame_ms and settle from supplement", [prepared["frame_ms"], src["settle_ms"]])
	var pivot_y := int(src["pivot"].y)
	for action in ["idle", "walk"]:
		for d in DIRS:
			var clip: Dictionary = pset["clips"][action][d]
			var files: Array = src["clips"][action][d]["files"]
			ck(clip["paths"] == files, "directions", "%s %s/%s runtime paths equal source order" % [actor, action, d])
			ck(files.size() == (4 if action == "idle" else 12), "frames", "%s %s/%s frame count" % [actor, action, d], files.size())
			for i in files.size():
				var image := raw_image(files[i])
				if not ck(image != null and Vector2(image.get_size()) == src["frame_size"], "anchors", "%s %s/%s/%d raw PNG size" % [actor, action, d, i]):
					continue
				var imported: Image = clip["textures"][i].get_image()
				imported.convert(Image.FORMAT_RGBA8)
				ck(imported.get_data() == image.get_data(), "anchors", "%s %s/%s/%d imported texels equal source PNG" % [actor, action, d, i])
				var used := image.get_used_rect()
				if action == "idle":
					ck(used.end.y == pivot_y, "anchors", "%s idle/%s/%d soles on floor line" % [actor, d, i], used.end.y)
				else:
					ck(used.end.y <= pivot_y and used.size.y > 0, "anchors", "%s walk/%s/%d nothing below floor line" % [actor, d, i], used.end.y)
	for d in DIRS:
		for p in src["bridges"][d].size():
			var chain: Array = src["bridges"][d][p]
			var ptex: Array = prepared["bridges"][d][p]
			ck(ptex[0] == pset["clips"]["walk"][d]["textures"][p] and ptex[3] == pset["clips"]["idle"][d]["textures"][0], "frames", "%s %s/phase%d runtime bridge ends are walk p / idle f00" % [actor, d, p])
			for i in [1, 2]:
				ck(ptex[i] != null and ptex[i].resource_path == chain[i], "frames", "%s %s/phase%d s%d runtime texture path" % [actor, d, p, i])
				var image := raw_image(chain[i])
				ck(image != null and image.get_used_rect().end.y <= pivot_y, "anchors", "%s %s/phase%d s%d nothing below floor line" % [actor, d, p, i])


func check_pivot(src: Dictionary, sprite: Sprite2D, anchor: Vector2, label: String) -> void:
	var density: int = src["density"]
	ck(sprite.scale == Vector2.ONE / float(density), "anchors", label + " display scale 1/density", sprite.scale)
	var offset: Vector2 = src["frame_size"] * 0.5 - src["pivot"] + Vector2(0.0, Pilot.FLOOR_DROP_LOGICAL * density)
	ck(sprite.offset == offset, "anchors", label + " offset pins source pivot", [sprite.offset, offset])
	var local: Vector2 = src["pivot"] - src["frame_size"] * 0.5 + sprite.offset
	var floor_point := sprite.to_global(local)
	var expected := anchor + Vector2(0.0, Pilot.FLOOR_DROP_LOGICAL)
	ck(floor_point.distance_to(expected) < 0.001, "anchors", label + " source pivot lands on host floor row", [floor_point, expected])


# ---------- foot slip oracle (raw source PNGs, authored contacts on the floor row) ----------

func best_drift(a_runs: Array, b_runs: Array, density: int, host_step: Vector2) -> float:
	var best := INF
	for a in a_runs:
		for b in b_runs:
			var sx := (float(b[0] + b[1]) - float(a[0] + a[1])) * 0.5 / float(density)
			best = minf(best, (Vector2(sx, 0.0) + host_step).length())
	return best


func slip_analysis(src: Dictionary, hypothetical: bool) -> Dictionary:
	var density: int = src["density"]
	var row := int(src["pivot"].y) - 1
	var tol := LOCK_TEXELS / float(density)
	var rep := {"toleranceLogical": tol, "floorRow": row, "hostSpeedLogicalPerS": MOVE_SPEED,
		"hostSpeedIsHypothetical": hypothetical, "walk": {}, "stop": {}}
	var walk_fail := 0
	var stop_fail := 0
	var gaps := 0
	for d in DIRS:
		var files: Array = src["clips"]["walk"][d]["files"]
		var durs: Array = src["clips"]["walk"][d]["durs"]
		var rows: Array = []
		for p in files.size():
			var q := (p + 1) % files.size()
			var a := floor_runs(raw_image(files[p]), row)
			var b := floor_runs(raw_image(files[q]), row)
			var step: Vector2 = UNIT[d] * MOVE_SPEED * float(durs[p]) / 1000.0
			if a.is_empty() or b.is_empty():
				gaps += 1
				rows.append({"from": p, "to": q, "gap": "no floor-row contact", "runsFrom": a, "runsTo": b})
				continue
			var drift := best_drift(a, b, density, step)
			if drift > tol:
				walk_fail += 1
			rows.append({"from": p, "to": q, "hostStepLogical": step.length(), "bestCaseDriftLogical": snappedf(drift, 0.001),
				"holdDriftLogical": step.length(), "runsFrom": a, "runsTo": b})
		rep["walk"][d] = rows
		var stops: Array = []
		for p in src["bridges"][d].size():
			var chain: Array = src["bridges"][d][p]
			var steps: Array = []
			for i in 3:
				var a := floor_runs(raw_image(chain[i]), row)
				var b := floor_runs(raw_image(chain[i + 1]), row)
				if a.is_empty() or b.is_empty():
					gaps += 1
					steps.append({"step": i, "gap": "no floor-row contact"})
					continue
				var drift := best_drift(a, b, density, Vector2.ZERO)
				if drift > tol:
					stop_fail += 1
				steps.append({"step": i, "bestCaseDriftLogical": snappedf(drift, 0.001)})
			stops.append({"phase": p, "steps": steps})
		rep["stop"][d] = stops
	rep["walkPairsOverTolerance"] = walk_fail
	rep["stopStepsOverTolerance"] = stop_fail
	rep["contactGaps"] = gaps
	rep["status"] = "FAIL" if walk_fail + stop_fail + gaps > 0 else "UNRESOLVED"
	rep["unresolvedReason"] = "best-case floor-row matching only; per-foot contact identity is not authored in the runtime package"
	return rep


# ---------- shared clock ticks ----------

func tick(ctx: Dictionary, dt: float, press: String) -> void:
	var driver = ctx["driver"]
	if ctx["mode"] == "input":
		for d in DIRS:
			if d == press:
				Input.action_press(INPUT[d])
			else:
				Input.action_release(INPUT[d])
		driver.advance(dt)
		ctx["host"]._process(dt)
	else:
		driver.advance(dt)
		if press != "":
			if press != driver.facing:
				driver.face(press)
			driver.walk()
		else:
			driver.idle()


func position(ctx: Dictionary) -> Vector2:
	return ctx["host"].hero.position if ctx["mode"] == "input" else ctx["sprite"].position


func host_ok(ctx: Dictionary, label: String) -> void:
	var host = ctx["host"]
	ck(host.is_inside_tree() and not host.dialogue_open, "input", label + " host still exploring (no dialogue/encounter)")


func expect_move(ctx: Dictionary, before: Vector2, dir: String, dt: float, label: String) -> void:
	var expected: Vector2 = before + (UNIT[dir] * MOVE_SPEED * dt if ctx["mode"] == "input" and dir != "" else Vector2.ZERO)
	ck(position(ctx).distance_to(expected) < 0.001, "input", label + " position", [position(ctx), expected])


func tex_path(ctx: Dictionary) -> String:
	var texture: Texture2D = ctx["sprite"].texture
	return texture.resource_path if texture != null else ""


func settle(ctx: Dictionary, dir: String) -> void:
	for i in 40:
		tick(ctx, 0.02, "")
	if ctx["mode"] == "input":
		ctx["host"].hero.position = MALE_STARTS[dir]


func shot(ctx: Dictionary, label: String) -> void:
	if not capture:
		return
	await process_frame
	await RenderingServer.frame_post_draw
	var image: Image = root.get_texture().get_image()
	var path := out.path_join("rpg-2-star-ocean-the-second_%s_%s-%s-%s_runtime-check-v01_%s.png" % [ctx["subject"], language, fps_mode, label, tag])
	if ck(image != null and image.save_png(path) == OK, "capture", label + " saved"):
		captures.append({"label": label, "path": path, "sha256": FileAccess.get_sha256(path)})


# Walk from settled idle and release when the bridge would start at phase p; follow the bridge past settle.
func trial(ctx: Dictionary, dir: String, p: int) -> void:
	var src: Dictionary = ctx["src"]
	var walk: Dictionary = src["clips"]["walk"][dir]
	var idle: Dictionary = src["clips"]["idle"][dir]
	var frame_us: int = src["frame_ms"] * 1000
	var settle_us: int = src["settle_ms"] * 1000
	var label := "%s %s/p%02d" % [ctx["subject"], dir, p]
	settle(ctx, dir)
	var row := {"actor": ctx["subject"], "direction": dir, "phase": p, "walkTicks": 0, "bridgeTicks": 0}
	var before := position(ctx)
	var dt := next_dt()
	tick(ctx, dt, dir)
	var st: Dictionary = ctx["driver"].state()
	ck(st["action"] == "walk" and st["facing"] == dir and st["frame"] == 0 and st["clock_us"] == 0, "frames", label + " press starts walk f0", st)
	expect_move(ctx, before, dir, dt, label + " press")
	var exp_us := 0.0
	var cap_us: int = 3 * expected_cycle(walk["durs"])
	var reached := false
	var shot_walk := false
	while exp_us <= cap_us:
		dt = next_dt()
		if expected_frame(walk["durs"], int(round(exp_us + dt * 1000000.0))) == p:
			reached = true
			break
		before = position(ctx)
		tick(ctx, dt, dir)
		exp_us += dt * 1000000.0
		row["walkTicks"] += 1
		st = ctx["driver"].state()
		var f := expected_frame(walk["durs"], int(round(exp_us)))
		ck(st["action"] == "walk" and st["frame"] == f and st["clock_us"] == int(round(exp_us)), "frames", label + " walk frame from source durations", [st, f, exp_us])
		ck(tex_path(ctx) == walk["files"][f], "directions", label + " walk texture", tex_path(ctx))
		expect_move(ctx, before, dir, dt, label + " walk")
		if ctx["mode"] == "input":
			host_ok(ctx, label)
		if p == 6 and not shot_walk:
			shot_walk = true
			await shot(ctx, "%s-walk" % dir)
	if not ck(reached, "frames", label + " phase reachable within 3 cycles at this dt sequence", fps_mode):
		trials.append(row)
		return
	var stop_at := position(ctx)
	tick(ctx, dt, "")
	st = ctx["driver"].state()
	ck(st["action"] == "stop" and st.get("phase", -1) == p and st["frame"] == 0, "stop", label + " release starts bridge at phase p", st)
	ck(tex_path(ctx) == src["bridges"][dir][p][0], "stop", label + " bridge entry 0 is walk p", tex_path(ctx))
	ck(position(ctx) == stop_at, "stop", label + " immediate physical stop on release tick")
	var bt := 0.0
	var settled_ms := -1.0
	var shot_s1 := false
	while bt < float(settle_us) + 300000.0:
		dt = next_dt()
		tick(ctx, dt, "")
		bt += dt * 1000000.0
		row["bridgeTicks"] += 1
		var t := int(round(bt))
		st = ctx["driver"].state()
		if t < settle_us:
			var index := t / frame_us
			ck(st["action"] == "stop" and st["frame"] == index and st.get("phase", -1) == p, "stop", label + " bridge index at %d us" % t, st)
			ck(tex_path(ctx) == src["bridges"][dir][p][index], "stop", label + " bridge texture at %d us" % t, tex_path(ctx))
			if p == 6 and index == 1 and not shot_s1:
				shot_s1 = true
				await shot(ctx, "%s-stop-s1" % dir)
		else:
			var f := expected_frame(idle["durs"], t - settle_us)
			if settled_ms < 0.0:
				settled_ms = t / 1000.0
				ck(tex_path(ctx) == idle["files"][0] and f == 0, "stop", label + " settle endpoint is idle f00", [t, tex_path(ctx)])
				if p == 6:
					await shot(ctx, "%s-settled" % dir)
			ck(st["action"] == "idle" and st["frame"] == f and st["clock_us"] == t - settle_us, "stop", label + " idle after settle at %d us" % t, st)
			ck(tex_path(ctx) == idle["files"][f], "stop", label + " idle texture after settle", tex_path(ctx))
		ck(position(ctx) == stop_at, "stop", label + " no physical drift during bridge/idle")
	row["settleObservedMs"] = settled_ms
	row["visualSettleMs"] = src["settle_ms"]
	row["physicalStopMs"] = 0
	trials.append(row)


func expected_cycle(durs: Array) -> int:
	var total := 0
	for d in durs:
		total += int(d) * 1000
	return total


# Exact microsecond boundaries: every walk frame end, release, every bridge index, settle and the first idle frame end.
func boundary_probe(ctx: Dictionary, dir: String) -> void:
	var src: Dictionary = ctx["src"]
	var walk: Dictionary = src["clips"]["walk"][dir]
	var idle_durs: Array = src["clips"]["idle"][dir]["durs"]
	var label := "%s %s boundary" % [ctx["subject"], dir]
	settle(ctx, dir)
	tick(ctx, 1.0 / 60.0, dir)
	var now := 0
	var acc := 0
	for i in walk["durs"].size():
		acc += int(walk["durs"][i]) * 1000
		tick(ctx, float(acc - 1 - now) / 1000000.0, dir)
		now = acc - 1
		ck(ctx["driver"].state()["frame"] == i and ctx["driver"].state()["clock_us"] == now, "frames", label + " walk %d at end-1us" % i, ctx["driver"].state())
		tick(ctx, 0.000001, dir)
		now = acc
		var nf := (i + 1) % walk["durs"].size()
		ck(ctx["driver"].state()["frame"] == nf and tex_path(ctx) == walk["files"][nf], "frames", label + " walk %d at boundary" % nf, ctx["driver"].state())
	tick(ctx, 0.000001, "")
	ck(ctx["driver"].state().get("phase", -1) == 0 and ctx["driver"].state()["action"] == "stop", "stop", label + " release after wrap bridges phase 0", ctx["driver"].state())
	var frame_us: int = src["frame_ms"] * 1000
	var settle_us: int = src["settle_ms"] * 1000
	now = 0
	for index in range(1, 3):
		tick(ctx, float(index * frame_us - 1 - now) / 1000000.0, "")
		ck(ctx["driver"].state()["frame"] == index - 1 and ctx["driver"].state()["action"] == "stop", "stop", label + " bridge %d at end-1us" % (index - 1), ctx["driver"].state())
		tick(ctx, 0.000001, "")
		now = index * frame_us
		ck(ctx["driver"].state()["frame"] == index and tex_path(ctx) == src["bridges"][dir][0][index], "stop", label + " bridge %d at boundary" % index, ctx["driver"].state())
	tick(ctx, float(settle_us - 1 - now) / 1000000.0, "")
	ck(ctx["driver"].state()["action"] == "stop" and ctx["driver"].state()["frame"] == 2, "stop", label + " still s2 at settle-1us", ctx["driver"].state())
	tick(ctx, 0.000001, "")
	ck(ctx["driver"].state()["action"] == "idle" and ctx["driver"].state()["frame"] == 0 and ctx["driver"].state()["clock_us"] == 0 and tex_path(ctx) == src["clips"]["idle"][dir]["files"][0], "stop", label + " settles to idle f00 exactly at settle", ctx["driver"].state())
	var idle_end := int(idle_durs[0]) * 1000
	tick(ctx, float(idle_end - 1) / 1000000.0, "")
	ck(ctx["driver"].state()["frame"] == 0, "frames", label + " idle f00 at end-1us", ctx["driver"].state())
	tick(ctx, 0.000001, "")
	ck(ctx["driver"].state()["frame"] == 1 and tex_path(ctx) == src["clips"]["idle"][dir]["files"][1], "frames", label + " idle f01 at boundary", ctx["driver"].state())


# Re-press and reversal during a bridge, and a same-tick reversal while walking.
func repress_reversal(ctx: Dictionary, dir: String) -> void:
	var label := "%s %s" % [ctx["subject"], dir]
	for mode in ["repress", "reverse"]:
		settle(ctx, dir)
		tick(ctx, 0.02, dir)
		tick(ctx, 0.05, dir)
		tick(ctx, 0.02, "")
		ck(ctx["driver"].state()["action"] == "stop", "stop", label + " %s: bridge active before press" % mode, ctx["driver"].state())
		var next_dir: String = dir if mode == "repress" else OPPOSITE[dir]
		var before := position(ctx)
		var dt := next_dt()
		tick(ctx, dt, next_dir)
		var st: Dictionary = ctx["driver"].state()
		ck(st["action"] == "walk" and st["facing"] == next_dir and st["frame"] == 0 and st["clock_us"] == 0 and not st.has("phase"), "stop", label + " %s cancels bridge and restarts walk f0" % mode, st)
		ck(tex_path(ctx) == ctx["src"]["clips"]["walk"][next_dir]["files"][0], "stop", label + " %s texture walk f0" % mode, tex_path(ctx))
		expect_move(ctx, before, next_dir, dt, label + " " + mode)
	settle(ctx, dir)
	tick(ctx, 0.02, dir)
	tick(ctx, 0.05, dir)
	var opposite: String = OPPOSITE[dir]
	var before2 := position(ctx)
	tick(ctx, 0.02, opposite)
	var st2: Dictionary = ctx["driver"].state()
	ck(st2["action"] == "walk" and st2["facing"] == opposite and st2["frame"] == 0 and not st2.has("phase"), "stop", label + " same-tick reversal walks f0 with no bridge", st2)
	expect_move(ctx, before2, opposite, 0.02, label + " same-tick reversal")


func run_actor(ctx: Dictionary) -> void:
	for dir in DIRS:
		await boundary_probe(ctx, dir)
		repress_reversal(ctx, dir)
		for p in ctx["src"]["clips"]["walk"][dir]["files"].size():
			await trial(ctx, dir, p)
	for d in DIRS:
		Input.action_release(INPUT[d])


# ---------- main ----------

func snapshot(files: Array) -> Dictionary:
	var result := {}
	for f in files:
		result[f] = FileAccess.get_sha256(f)
	return result


func list_saves() -> Array:
	var names: Array = []
	var dir := DirAccess.open("user://saves")
	if dir != null:
		for name in dir.get_files():
			names.append([name, FileAccess.get_sha256("user://saves".path_join(name))])
	return names


func open_scene(destination: String) -> Node:
	var app := root.get_node("AppState")
	app.begin_new_run()
	app.hero_appearance = "male"
	app.show_initial_guide = false
	if app.language != language:
		app.toggle_language()
	ck(app.select_destination(destination), "defaults", destination + " selected by the normal destination rule")
	var host: Node = load(SCENE).instantiate()
	root.add_child(host)
	await process_frame
	await process_frame
	return host


func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var positional: Array = []
	for a in args:
		if a == "--capture":
			capture = true
		elif not a.begins_with("--"):
			positional.append(a)
	if positional.size() < 2 or (positional.size() > 2 and not positional[2] in ["en", "zh"]) or (positional.size() > 3 and not positional[3] in ["30", "60", "mixed"]):
		print("MLX36_BAD_ARGS usage: -- <out_dir> <tag> [en|zh] [30|60|mixed] [--capture]")
		quit(2)
		return
	out = positional[0]
	tag = positional[1]
	if positional.size() > 2:
		language = positional[2]
	if positional.size() > 3:
		fps_mode = positional[3]
	if capture and DisplayServer.get_name() == "headless":
		print("MLX36_BAD_ARGS --capture needs a real renderer")
		quit(2)
		return
	DirAccess.make_dir_recursive_absolute(out)
	SaveStore.root_path = SAVE_ROOT
	var saves_before := list_saves()
	var male_driver = load(MALE_DRIVER)
	var liang_driver = load(LIANG_DRIVER)
	var liang_config = load(LIANG_CONFIG)
	# Ordinary defaults: no generic pilot flag/override, no male/Liang override, creator-authorized defaults on.
	var user_flags: Array = []
	for a in args:
		if a == Pilot.FLAG or a.begins_with(Pilot.REGISTRY_ARG) or a.begins_with("--mpath24") or a.begins_with("--lpath30"):
			user_flags.append(a)
	ck(user_flags.is_empty() and Pilot.enabled_override == -1 and Pilot.registry_override == "" and not Pilot.enabled(), "defaults", "no generic exploration pilot flag or override", user_flags)
	ck(male_driver.male_enabled_override == -1 and male_driver.registry_path_override == "" and male_driver.supplement_path_override == "" and male_driver.DEFAULT_ADOPTED and male_driver.male_enabled(), "defaults", "male mpath24 is the ordinary default with no override")
	ck(liang_config.enabled_override == -1 and liang_config.registry_path_override == "" and liang_config.supplement_path_override == "" and liang_config.DEFAULT_ADOPTED and liang_config.enabled(), "defaults", "Liang lpath30 is the ordinary default with no override")
	ck(load(HOST_SCRIPT).MOVE_SPEED == MOVE_SPEED, "input", "host MOVE_SPEED is 140 logical px/s")
	var male_src := read_source("protagonist-male", male_driver.REGISTRY_PATH, male_driver.SUPPLEMENT_PATH)
	var liang_src := read_source("liang-xu", liang_driver.LIANG_REGISTRY_PATH, liang_driver.LIANG_SUPPLEMENT_PATH)
	if not male_src["ok"] or not liang_src["ok"]:
		finish({}, {})
		return
	var hashed: Array = [get_script().resource_path, MALE_DRIVER, MALE_CONFIG, LIANG_DRIVER, LIANG_CONFIG, ZHAO_DRIVER, PILOT_PATH, HOST_SCRIPT, SCENE]
	hashed.append_array(source_files(male_src))
	hashed.append_array(source_files(liang_src))
	hashes_start = snapshot(hashed)
	check_package(male_src, male_driver.prepare_package(male_driver.REGISTRY_PATH, male_driver.SUPPLEMENT_PATH), "male")
	check_package(liang_src, liang_driver.prepare_liang_package(liang_driver.LIANG_REGISTRY_PATH, liang_driver.LIANG_SUPPLEMENT_PATH), "liang")
	slip["protagonist-male"] = slip_analysis(male_src, false)
	slip["liang-xu"] = slip_analysis(liang_src, true)

	# Male: ordinary hero, host input only.
	var host: Node = await open_scene("scifi.outskirts")
	var pilot = host.sprite_pilot
	ck(pilot != null and pilot.get_script().resource_path == MALE_DRIVER and pilot.actor_id == "protagonist-male", "defaults", "ordinary male hero drawn by mpath24 driver", str(pilot))
	if pilot != null and pilot.get_script().resource_path == MALE_DRIVER:
		check_pivot(male_src, host.hero, host.hero.global_position, "male hero")
		await shot({"subject": "male"}, "attached")
		host.set_process(false)
		pilot.set_process(false)
		await run_actor({"subject": "male", "mode": "input", "host": host, "driver": pilot, "sprite": host.hero, "src": male_src})
	host.queue_free()
	await process_frame

	# Liang: ordinary City Hall field NPC; then a TEST-ONLY fixture drive of the same driver in place.
	host = await open_scene("scifi.city")
	var app := root.get_node("AppState")
	var npc: Sprite2D = host.city_npc
	var npc_driver = host.field_npc_driver
	var placement: Vector2 = load(HOST_SCRIPT).AREA_CONFIG["scifi.city"]["npc"]
	ck(host.recruit_id == "liang-xu" and npc != null and npc.position == placement and npc.visible, "defaults", "Liang recruit NPC at the City Hall placement", [npc.position if npc != null else null, placement])
	ck(liang_config.npc_attached(host) and host.field_npc_presenter_override == "", "defaults", "ordinary lpath30 driver draws the Liang field NPC (no presenter override)")
	ck(host.sprite_pilot != null and host.sprite_pilot.get_script().resource_path == MALE_DRIVER, "defaults", "hero remains the ordinary male in the Liang scene")
	ck(not app.recruited_members.has("liang-xu"), "defaults", "Liang not recruited, not a party member or follower")
	if npc_driver != null and npc != null:
		for i in 10:
			await process_frame
		var st: Dictionary = npc_driver.state()
		ck(st["action"] == "idle" and st["facing"] == "south" and npc.texture.resource_path == liang_src["clips"]["idle"]["south"]["files"][0], "defaults", "ordinary Liang NPC shows static south idle f00", [st, npc.texture.resource_path])
		check_pivot(liang_src, npc, npc.global_position, "Liang NPC")
		await shot({"subject": "liang-xu"}, "ordinary-npc")
		var sprites_before := 0
		for child in host.get_children():
			if child is Sprite2D:
				sprites_before += 1
		host.set_process(false)
		npc_driver.set_process(false)
		var hero_at: Vector2 = host.hero.position
		await run_actor({"subject": "liang-xu", "mode": "fixture", "host": host, "driver": npc_driver, "sprite": npc, "src": liang_src})
		var sprites_after := 0
		for child in host.get_children():
			if child is Sprite2D:
				sprites_after += 1
		ck(npc.position == placement and host.hero.position == hero_at, "defaults", "TEST-ONLY fixture never moved the NPC or hero")
		ck(sprites_after == sprites_before and not app.recruited_members.has("liang-xu"), "defaults", "no follower node or recruitment created by the fixture")
	host.queue_free()
	await process_frame
	ck(list_saves() == saves_before, "defaults", "ordinary user://saves untouched")
	finish(snapshot(hashes_start.keys()), {})


func finish(hashes_end: Dictionary, _unused: Dictionary) -> void:
	ck(not hashes_start.is_empty() and hashes_end == hashes_start, "hashes", "driver/config/host/source hashes unchanged during run")
	var status := {}
	for g in groups:
		status[g] = "PASS" if groups[g]["failed"] == 0 else "FAIL"
	var slip_status := {}
	for actor in slip:
		slip_status[actor] = slip[actor]["status"]
	var criteria := {}
	for actor in ["protagonist-male", "liang-xu"]:
		var subject := "male" if actor == "protagonist-male" else "liang-xu"
		var actor_fail := {"frames": false, "anchors": false, "directions": false}
		for f in failures:
			var check := String(f["check"])
			if check.begins_with(subject + " ") or check.begins_with(actor + " ") or (subject == "male" and check.begins_with("male")) or (subject == "liang-xu" and check.begins_with("liang")):
				for key in ["frames", "stop", "anchors", "directions", "input"]:
					if f["group"] == key:
						actor_fail["frames" if key in ["frames", "stop", "input"] else key] = true
		criteria[actor] = {"frames": "FAIL" if actor_fail["frames"] or failures.size() >= 300 else "PASS",
			"anchors": "FAIL" if actor_fail["anchors"] or failures.size() >= 300 else "PASS",
			"directions": "FAIL" if actor_fail["directions"] or failures.size() >= 300 else "PASS",
			"slip": slip_status.get(actor, "FAIL")}
	var any_unresolved := false
	for actor in criteria:
		if criteria[actor]["slip"] != "PASS":
			any_unresolved = true
		for key in criteria[actor]:
			if criteria[actor][key] == "FAIL":
				failed = true
	var report := {"schema": "worlds-between.male-liang-explore-runtime-check/1", "tag": tag, "language": language,
		"fpsMode": fps_mode, "mixedDtSequence": MIXED_DT if fps_mode == "mixed" else [],
		"display": DisplayServer.get_name(), "captureRequested": capture,
		"scope": "TEST-ONLY harness; ordinary male mpath24 via host Input; ordinary Liang lpath30 field NPC at City Hall plus TEST-ONLY fixture drive in place; no runtime/default/save/asset change; art/motion UNAPPROVED",
		"hashNormalization": "sha256-bytes (no text normalization)", "harness": get_script().resource_path,
		"hashesStart": hashes_start, "hashesEnd": hashes_end, "groups": groups, "groupStatus": status,
		"criteria": criteria, "slip": slip, "trials": trials, "failures": failures, "failuresTruncated": failures.size() >= 300,
		"captures": captures, "saveRoot": SAVE_ROOT,
		"knownGaps": ["Foot identity per phase is not in the runtime package; slip can at best be UNRESOLVED by this oracle.",
			"Runtime walk is time-driven (40 ms frames at 140 px/s = 5.6 logical px per frame); any per-frame lock also holds each frame for that host travel.",
			"Liang never moves in ordinary play; its walk/slip numbers use the host speed as a hypothetical TEST-ONLY reference."]}
	var path := out.path_join("rpg-2-star-ocean-the-second_male-liang_explore-runtime-check_%s-%s_%s.json" % [language, fps_mode, tag])
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		print("MLX36_FAIL report not writable ", path)
		quit(1)
		return
	file.store_string(JSON.stringify(report, "  ") + "\n")
	file.close()
	print("MLX36_REPORT ", path, " ", FileAccess.get_sha256(path))
	if failed:
		print("MLX36_FAILED")
		quit(1)
	elif any_unresolved:
		print("MLX36_UNRESOLVED")
		quit(3)
	else:
		print("MLX36_TECHNICAL_PASS")
		quit(0)
