#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent Python-only source/package contact check for mexplore23 / lexplore28.

Reads the game/data registries, runtime sprite sets, stop supplements, the source
manifests under outputs/<set>/, the source authors and the current mpath24/lpath30
drivers.  It parses the exact JSON and every referenced PNG itself; it never loads
Godot, never imports the project, and never calls the runtime package_ok oracle.

What is checked (source/package boundary only)
  * exact generated paths, frame counts, dimensions, set density/pivot,
  * raw sha256 bytes for every source PNG and every package copy,
  * all four directions: static + 4-frame idle + 12-phase walk + 12 stop bridges,
  * bridge[start] == walk p exact, bridge[end] == idle f00 exact == static,
  * declared sole rows / heel columns are present in the PNG alpha, and the
    declared stop/contact anchor sequences reproduce from those alpha anchors,
  * driver source implication that the ordinary stationary field NPC is never
    moved (presentation only), without claiming a runtime movement test.

What is deliberately NOT claimed
  * actual stance-foot lock or foot slip during runtime playback (unmeasured),
  * world-position drift during runtime (unmeasured),
  * cosmetic/artistic quality (not assessed),
  * the Godot runtime checks required to close the QA tasks (not run here).

Expected-corruption self-test copies a temporary mirror under the output subtree,
mutates one frame and the stop manifest, expects rejection, and removes the mirror.
No game asset is ever mutated.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
import zipfile
from datetime import datetime, timezone

try:
    from PIL import Image
except Exception as exc:  # pragma: no cover - explicit environment failure
    Image = None
    _PIL_IMPORT_ERROR = exc
else:
    _PIL_IMPORT_ERROR = None


PROJECT = "rpg-2-star-ocean-the-second"
SCHEMA = "worlds-between.male-liang.source-contact-check.v1"
DIRECTIONS = ("south", "west", "north", "east")
IDLE_MS = (700, 200, 400, 200)
WALK_MS = 40
FRAME_MS = 40
FRAME_SIZE = (80, 112)
PIVOT = (40, 104)
DENSITY = 2
SOLE_ROW = 103
LOGICAL_HEIGHT = 48
BODY_TEXELS = 96
STOP_SCHEMA = "worlds-between.exploration-stop-transition.supplemental.v1"
SET_SCHEMA = "worlds-between.exploration-sprite-set.v1"
REGISTRY_SCHEMA = "worlds-between.exploration-sprite-set-registry.v1"

ACTORS = (
    {"key": "protagonist-male", "set_dir": "mexplore23", "out_dir": "outputs/mexplore23"},
    {"key": "liang-xu", "set_dir": "lexplore28", "out_dir": "outputs/lexplore28"},
)


# --------------------------------------------------------------------------- windows paths
def wp(path: str) -> str:
    """Absolute extended-length path for Windows (>MAX_PATH source filenames exist)."""
    text = os.path.abspath(str(path))
    if os.name != "nt":
        return text
    if text.startswith("\\\\?\\"):
        return text
    if text.startswith("\\\\"):
        return "\\\\?\\UNC\\" + text[2:]
    return "\\\\?\\" + text


def read_bytes(path: str) -> bytes:
    with open(wp(path), "rb") as handle:
        return handle.read()


def write_bytes(path: str, payload: bytes) -> None:
    parent = os.path.dirname(os.path.abspath(str(path)))
    os.makedirs(wp(parent), exist_ok=True)
    with open(wp(path), "wb") as handle:
        handle.write(payload)


def write_text(path: str, text: str) -> None:
    write_bytes(path, text.encode("utf-8"))


def path_exists(path: str) -> bool:
    return os.path.exists(wp(path))


def is_dir(path: str) -> bool:
    return os.path.isdir(wp(path))


def list_dir(path: str) -> list:
    return sorted(os.listdir(wp(path)))


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: str) -> str:
    return sha256_bytes(read_bytes(path))


def sha256_text_lf(path: str) -> str:
    return sha256_bytes(read_bytes(path).replace(b"\r\n", b"\n"))


def safe_rel(rel: str) -> bool:
    if not isinstance(rel, str) or not rel:
        return False
    if rel.startswith(("/", "\\")) or ":" in rel:
        return False
    parts = rel.replace("\\", "/").split("/")
    return all(part not in ("", ".", "..") for part in parts)


def join_rel(root: str, rel: str) -> str:
    return os.path.normpath(os.path.join(str(root), rel.replace("/", os.sep)))


def base_name(rel: str) -> str:
    return rel.replace("\\", "/").rsplit("/", 1)[-1]


def res_rel(set_dir: str, filename: str) -> str:
    return "res://data/%s/%s" % (set_dir, filename)


# --------------------------------------------------------------------------- assertions
class Recorder:
    def __init__(self) -> None:
        self.assertions = []
        self.failures = []
        self.counts = {}

    def add(self, cid: str, ok: bool, category: str, detail=None) -> bool:
        self.counts[category] = self.counts.get(category, 0) + 1
        item = {"id": cid, "category": category, "ok": bool(ok)}
        if detail not in (None, "", []):
            item["detail"] = detail
        self.assertions.append(item)
        if not ok:
            self.failures.append({"id": cid, "category": category, "detail": detail})
        return bool(ok)

    def frame_fail(self, cid: str, detail) -> None:
        self.counts["frame"] = self.counts.get("frame", 0) + 1
        self.failures.append({"id": cid, "category": "frame", "detail": detail})

    def cat_ok(self, category: str) -> bool:
        return not any(item["category"] == category for item in self.failures)


# --------------------------------------------------------------------------- png inspection
def inspect_png(payload: bytes, frame_size=FRAME_SIZE):
    """Return measured fields or raise ValueError with a concrete reason."""
    image = Image.open(io.BytesIO(payload))
    image.load()
    if image.format != "PNG":
        raise ValueError("format is %r, not PNG" % (image.format,))
    rgba = image.convert("RGBA")
    if rgba.size != tuple(frame_size):
        raise ValueError("size is %s, not %s" % (rgba.size, tuple(frame_size)))
    alpha = rgba.getchannel("A")
    histogram = alpha.histogram()
    partial = sum(histogram[1:255])
    bbox = alpha.getbbox()
    if bbox is None:
        raise ValueError("frame is empty")
    width, height = rgba.size
    border = 0
    for box in ((0, 0, width, 1), (0, height - 1, width, height),
                (0, 0, 1, height), (width - 1, 0, width, height)):
        if alpha.crop(box).getbbox() is not None:
            border += 1
    return {
        "image": rgba,
        "alpha": alpha,
        "size": list(rgba.size),
        "bbox": list(bbox),
        "bottom": bbox[3] - 1,
        "body_height": bbox[3] - bbox[1],
        "partial_alpha": partial,
        "opaque_border_edges": border,
    }


def half_feet(alpha, width=80, height=112):
    """South/north L (x<40) and R (x>=40) bottom rows and L x_min at its bottom row."""
    left = alpha.crop((0, 0, width // 2, height)).getbbox()
    right = alpha.crop((width // 2, 0, width, height)).getbbox()
    if left is None or right is None:
        return None
    bottom_l = left[3] - 1
    bottom_r = right[3] - 1
    pixels = alpha.load()
    xs_l = [x for x in range(0, width // 2) if pixels[x, bottom_l] > 0]
    xs_r = [x for x in range(width // 2, width) if pixels[x, bottom_r] > 0]
    if not xs_l or not xs_r:
        return None
    return {
        "L": {"bottom": bottom_l, "x_min": min(xs_l), "x_max": max(xs_l)},
        "R": {"bottom": bottom_r, "x_min": min(xs_r), "x_max": max(xs_r)},
    }


def side_heel(alpha, direction: str, row: int = SOLE_ROW):
    """Composite planted heel: west = max opaque x on the sole row, east = min."""
    pixels = alpha.load()
    xs = [x for x in range(alpha.size[0]) if pixels[x, row] > 0]
    if not xs:
        return None
    return max(xs) if direction == "west" else min(xs)


def load_ora_leg_heels(root: str, manifest: dict, direction: str, actor_key: str, rec: Recorder):
    """Idle f00 native layer heels; the merged idle has both feet overlapping on row 103."""
    info = manifest.get("directions", {}).get(direction, {}).get("ora", {})
    rel = info.get("file", "")
    if not safe_rel(rel):
        rec.add("%s.anchor.%s.ora_layer_source" % (actor_key, direction), False, "anchor", rel)
        return None
    path = join_rel(root, rel)
    if not path_exists(path):
        rec.add("%s.anchor.%s.ora_layer_source" % (actor_key, direction), False, "anchor",
                {"missing": rel})
        return None
    actual = sha256_file(path)
    rec.add("%s.anchor.%s.ora_sha256" % (actor_key, direction), actual == info.get("sha256"),
            "hash", {"file": rel, "declared": info.get("sha256"), "actual": actual})
    heels = {}
    try:
        with open(wp(path), "rb") as handle:
            archive = zipfile.ZipFile(handle)
            for layer in ("leg-near", "leg-far"):
                payload = archive.read("data/%s.png" % layer)
                measured = inspect_png(payload)
                heels[layer] = side_heel(measured["alpha"], direction)
    except Exception as exc:
        rec.add("%s.anchor.%s.ora_layer_source" % (actor_key, direction), False, "anchor",
                {"file": rel, "error": "%s: %s" % (type(exc).__name__, exc)})
        return None
    rec.add("%s.anchor.%s.ora_layer_source" % (actor_key, direction),
            all(isinstance(v, int) for v in heels.values()), "anchor",
            {"file": rel, "leg_heels": heels})
    return heels


# --------------------------------------------------------------------------- discovery
def discover(root: str, actor: dict):
    set_dir = join_rel(root, "game/data/" + actor["set_dir"])
    out_dir = join_rel(root, actor["out_dir"])

    def one(directory, contains, suffix):
        names = [n for n in list_dir(directory)
                 if n.endswith(suffix) and all(token in n for token in contains)]
        return names

    registries = one(set_dir, ("registry",), ".json")
    sets = one(set_dir, ("sprite-set", "runtime"), ".json")
    stops = one(set_dir, ("stop-transition", "supplemental"), ".json")
    manifests = one(out_dir, ("source-manifest",), ".json")
    drivers = {}

    def one_paths(directory, contains, suffix):
        return [os.path.join(directory, name) for name in one(directory, contains, suffix)]

    drivers["male_driver"] = one_paths(join_rel(root, "game/scripts/mpath24"), ("explore-driver",), ".gd")
    drivers["male_config"] = one_paths(join_rel(root, "game/scripts/mpath24"), ("config",), ".gd")
    drivers["liang_driver"] = one_paths(join_rel(root, "game/scripts/lpath30"), ("npc-driver",), ".gd")
    drivers["liang_config"] = one_paths(join_rel(root, "game/scripts/lpath30"), ("config",), ".gd")
    drivers["zhao_driver"] = one_paths(join_rel(root, "game/scripts/zpath27"), ("npc-driver",), ".gd")
    return {
        "root": root,
        "actor": actor,
        "set_dir": set_dir,
        "out_dir": out_dir,
        "registry": os.path.join(set_dir, registries[0]) if len(registries) == 1 else None,
        "registry_candidates": registries,
        "set": os.path.join(set_dir, sets[0]) if len(sets) == 1 else None,
        "set_candidates": sets,
        "stop": os.path.join(set_dir, stops[0]) if len(stops) == 1 else None,
        "stop_candidates": stops,
        "manifest": os.path.join(out_dir, manifests[0]) if len(manifests) == 1 else None,
        "manifest_candidates": manifests,
        "drivers": {k: (v[0] if len(v) == 1 else None) for k, v in drivers.items()},
        "driver_candidates": drivers,
    }


def read_json(path: str):
    return json.loads(read_bytes(path).decode("utf-8-sig"))


# --------------------------------------------------------------------------- source analysis
def driver_stationary_analysis(root: str, found: dict, rec: Recorder, set_dir: str, registry_name: str,
                                stop_name: str, actor_key: str):
    """Static source implication: presentation-only NPC driver never writes position."""
    forbidden = re.compile(
        r"(?:^|[^\w.])(?:global_)?position\s*(?:\+=|-=|\*=|/=|=)"
        r"|\bmove_and_slide\s*\(|\bmove_and_collide\s*\(|\bvelocity\s*="
    )
    texts = {}
    for key in ("male_driver", "liang_driver", "zhao_driver"):
        path = found["drivers"].get(key)
        if not path or not path_exists(path):
            rec.add("driver.%s.exists" % key, False, "driver", "missing %s driver" % key)
            continue
        raw = read_bytes(path).decode("utf-8-sig", "replace")
        texts[key] = raw
        code = "\n".join(line.split("#", 1)[0] for line in raw.splitlines())
        hits = sorted(set(match.group(0).strip() for match in forbidden.finditer(code)))
        rec.add("driver.%s.no_position_write" % key, not hits, "driver",
                {"file": os.path.relpath(path, root), "hits": hits})
        rec.add("driver.%s.loads" % key, True, "driver", os.path.relpath(path, root))

    male = texts.get("male_driver", "")
    liang = texts.get("liang_driver", "")
    zhao = texts.get("zhao_driver", "")
    if actor_key == "protagonist-male":
        rec.add("driver.male.registry_path_constant",
                ('REGISTRY_PATH := "%s"' % res_rel(set_dir, registry_name)) in male, "driver",
                res_rel(set_dir, registry_name))
        rec.add("driver.male.supplement_path_constant",
                ('SUPPLEMENT_PATH := "%s"' % res_rel(set_dir, stop_name)) in male, "driver",
                res_rel(set_dir, stop_name))
    else:
        rec.add("driver.liang.actor_constant", 'LIANG_ACTOR := "liang-xu"' in liang, "driver")
        rec.add("driver.liang.registry_path_constant",
                ('LIANG_REGISTRY_PATH := "%s"' % res_rel(set_dir, registry_name)) in liang, "driver",
                res_rel(set_dir, registry_name))
        rec.add("driver.liang.supplement_path_constant",
                ('LIANG_SUPPLEMENT_PATH := "%s"' % res_rel(set_dir, stop_name)) in liang, "driver",
                res_rel(set_dir, stop_name))
    rec.add("driver.liang.presentation_only_scale_offset",
            "target.scale =" in liang and "target.offset =" in liang
            and "target.position" not in liang, "driver")
    rec.add("driver.zhao.presentation_only_scale_offset",
            "target.scale =" in zhao and "target.offset =" in zhao
            and "target.position" not in zhao, "driver")
    rec.add("driver.male.presentation_only_scale_offset",
            "target.scale =" in male and "target.offset =" in male
            and "target.position" not in male, "driver")
    return {
        "files": {k: os.path.relpath(v, root) for k, v in found["drivers"].items() if v},
        "position_writes_detected": any(
            item["category"] == "driver" and not item["ok"] and "no_position_write" in item["id"]
            for item in rec.assertions
        ),
        "implication": "static source only: drivers select textures and set scale/offset; no position/velocity write",
        "runtime_movement_measured": False,
    }


# --------------------------------------------------------------------------- actor check
def check_actor(root: str, actor: dict, rec: Recorder):
    found = discover(root, actor)
    set_dir_name = actor["set_dir"]
    for key in ("registry", "set", "stop", "manifest"):
        rec.add("%s.%s.discovered" % (actor["key"], key), found[key] is not None, "source",
                found[key + "_candidates"] if found[key] is None else os.path.relpath(found[key], root))
    for key, candidates in found["driver_candidates"].items():
        rec.add("driver.%s.discovered" % key, found["drivers"].get(key) is not None, "driver",
                candidates)
    if not all(found[k] for k in ("registry", "set", "stop", "manifest")):
        return {"found": found, "failures": rec.failures, "frames": []}

    registry = read_json(found["registry"])
    sprite_set = read_json(found["set"])
    stop = read_json(found["stop"])
    manifest = read_json(found["manifest"])
    registry_name = base_name(found["registry"])
    set_name = base_name(found["set"])
    stop_name = base_name(found["stop"])
    manifest_name = base_name(found["manifest"])

    rec.add("%s.manifest.visual_id" % actor["key"], manifest.get("visual_id") == actor["key"],
            "source", manifest.get("visual_id"))
    rec.add("%s.manifest.run_id" % actor["key"],
            isinstance(manifest.get("run_id"), str) and len(manifest.get("run_id")) >= 6,
            "source", manifest.get("run_id"))

    # registry -> runtime set -------------------------------------------------
    rec.add("%s.registry.schema" % actor["key"], registry.get("schema") == REGISTRY_SCHEMA,
            "source", registry.get("schema"))
    listed = registry.get("actors")
    rec.add("%s.registry.exact_actor" % actor["key"],
            isinstance(listed, dict) and list(listed.keys()) == [actor["key"]], "source",
            list(listed.keys()) if isinstance(listed, dict) else listed)
    mapped = listed.get(actor["key"]) if isinstance(listed, dict) else None
    rec.add("%s.registry.maps_to_runtime_set" % actor["key"], mapped == set_name, "source",
            {"declared": mapped, "actual": set_name})
    package = manifest.get("package", {})
    rec.add("%s.package.sprite_set_path" % actor["key"],
            package.get("sprite_set") == "game/data/%s/%s" % (set_dir_name, set_name), "source",
            package.get("sprite_set"))
    rec.add("%s.package.stop_path" % actor["key"],
            package.get("stop_supplemental") == "game/data/%s/%s" % (set_dir_name, stop_name),
            "source", package.get("stop_supplemental"))
    if "registry" in package:
        rec.add("%s.package.registry_path" % actor["key"],
                package.get("registry") == "game/data/%s/%s" % (set_dir_name, registry_name),
                "source", package.get("registry"))

    # runtime set: density/frames/pivot and actions --------------------------
    rec.add("%s.set.schema" % actor["key"], sprite_set.get("schema") == SET_SCHEMA, "source",
            sprite_set.get("schema"))
    rec.add("%s.set.actor_id" % actor["key"], sprite_set.get("actor_id") == actor["key"], "source",
            sprite_set.get("actor_id"))
    rec.add("%s.set.density" % actor["key"],
            sprite_set.get("density") == DENSITY and isinstance(sprite_set.get("density"), int),
            "source", sprite_set.get("density"))
    rec.add("%s.set.frame_size" % actor["key"], sprite_set.get("frame_size") == list(FRAME_SIZE),
            "source", sprite_set.get("frame_size"))
    rec.add("%s.set.pivot" % actor["key"], sprite_set.get("pivot") == list(PIVOT), "source",
            sprite_set.get("pivot"))
    contract = manifest.get("contract", {})
    rec.add("%s.contract.cell" % actor["key"], contract.get("cell") == list(FRAME_SIZE), "source",
            contract.get("cell"))
    rec.add("%s.contract.pivot" % actor["key"], contract.get("pivot") == list(PIVOT), "source",
            contract.get("pivot"))
    rec.add("%s.contract.density" % actor["key"],
            contract.get("density", DENSITY) == DENSITY, "source", contract.get("density", DENSITY))
    rec.add("%s.contract.display_scale" % actor["key"],
            contract.get("display_scale", 1.0 / DENSITY) == 1.0 / DENSITY, "source",
            contract.get("display_scale", 1.0 / DENSITY))
    rec.add("%s.contract.alpha" % actor["key"], contract.get("alpha") == "binary", "source",
            contract.get("alpha"))
    rec.add("%s.contract.filter" % actor["key"], contract.get("filter") == "nearest", "source",
            contract.get("filter"))
    rec.add("%s.contract.body_texels" % actor["key"],
            contract.get("body_texels") == BODY_TEXELS, "source", contract.get("body_texels"))
    rec.add("%s.contract.logical_height" % actor["key"],
            contract.get("logical_height") == LOGICAL_HEIGHT, "source",
            contract.get("logical_height"))

    actions = sprite_set.get("actions")
    rec.add("%s.set.actions_exact" % actor["key"],
            isinstance(actions, dict) and list(actions.keys()) == ["idle", "walk"], "source",
            list(actions.keys()) if isinstance(actions, dict) else actions)
    directions = manifest.get("directions", {})
    rec.add("%s.directions.exact" % actor["key"], list(directions.keys()) == list(DIRECTIONS),
            "direction", list(directions.keys()))
    stop_dirs = stop.get("phase_bridges", {})
    rec.add("%s.stop.directions_exact" % actor["key"],
            isinstance(stop_dirs, dict) and list(stop_dirs.keys()) == list(DIRECTIONS), "direction",
            list(stop_dirs.keys()) if isinstance(stop_dirs, dict) else stop_dirs)

    set_files = {}
    set_entries = {}
    if isinstance(actions, dict):
        for action in ("idle", "walk"):
            by_dir = actions.get(action, {})
            rec.add("%s.set.%s.directions" % (actor["key"], action),
                    isinstance(by_dir, dict) and list(by_dir.keys()) == list(DIRECTIONS),
                    "direction", list(by_dir.keys()) if isinstance(by_dir, dict) else by_dir)
            expected_count = 4 if action == "idle" else 12
            for direction in DIRECTIONS:
                frames = by_dir.get(direction) if isinstance(by_dir, dict) else None
                rec.add("%s.set.%s.%s.count" % (actor["key"], action, direction),
                        isinstance(frames, list) and len(frames) == expected_count, "direction",
                        len(frames) if isinstance(frames, list) else frames)
                manifest_frames = directions.get(direction, {}).get(action, [])
                rec.add("%s.manifest.%s.%s.count" % (actor["key"], action, direction),
                        isinstance(manifest_frames, list) and len(manifest_frames) == expected_count,
                        "direction", len(manifest_frames) if isinstance(manifest_frames, list) else None)
                if not isinstance(frames, list) or len(frames) != expected_count:
                    continue
                for index, entry in enumerate(frames):
                    declared = manifest_frames[index] if isinstance(manifest_frames, list) and index < len(manifest_frames) else {}
                    expected_file = "png/" + base_name(declared.get("file", ""))
                    expected_ms = IDLE_MS[index] if action == "idle" else WALK_MS
                    cid = "%s.set.%s.%s.%02d" % (actor["key"], action, direction, index)
                    ok = (isinstance(entry, dict) and entry.get("file") == expected_file
                          and entry.get("duration_ms") == expected_ms
                          and declared.get("duration_ms") == expected_ms
                          and isinstance(declared.get("sha256"), str)
                          and re.fullmatch(r"[0-9a-f]{64}", declared.get("sha256", "")) is not None)
                    rec.add(cid, ok, "direction",
                            None if ok else {"declared_file": expected_file, "entry": entry,
                                             "declared_sha256": declared.get("sha256"),
                                             "expected_ms": expected_ms})
                    if isinstance(entry, dict) and isinstance(entry.get("file"), str):
                        key = (direction, action, index)
                        set_files[key] = join_rel(found["set_dir"], entry["file"])
                        set_entries[key] = (entry, declared)

    # stop supplement --------------------------------------------------------
    rec.add("%s.stop.schema" % actor["key"], stop.get("schema") == STOP_SCHEMA, "source",
            stop.get("schema"))
    rec.add("%s.stop.actor_id" % actor["key"], stop.get("actor_id") == actor["key"], "source",
            stop.get("actor_id"))
    rec.add("%s.stop.frame_ms" % actor["key"], stop.get("frame_ms") == FRAME_MS, "bridge",
            stop.get("frame_ms"))
    rec.add("%s.stop.settle_ms_inclusive" % actor["key"],
            stop.get("settle_ms_inclusive") == FRAME_MS * 3, "bridge",
            stop.get("settle_ms_inclusive"))
    rec.add("%s.stop.pivot" % actor["key"], stop.get("pivot") == list(PIVOT), "bridge",
            stop.get("pivot"))
    rec.add("%s.stop.logical_height" % actor["key"],
            stop.get("logical_height") == LOGICAL_HEIGHT, "bridge", stop.get("logical_height"))
    rec.add("%s.stop.host_position_moves_false" % actor["key"],
            all(manifest.get("stop_check", {}).get(d, {}).get("host_position_moves") is False
                for d in DIRECTIONS), "bridge",
            {d: manifest.get("stop_check", {}).get(d, {}).get("host_position_moves") for d in DIRECTIONS})

    stop_files = {}
    stop_entries = {}
    phases_ok = True
    for direction in DIRECTIONS:
        phase_map = stop_dirs.get(direction) if isinstance(stop_dirs, dict) else None
        expected_phases = ["phase%d" % i for i in range(12)]
        ok_phases = isinstance(phase_map, dict) and list(phase_map.keys()) == expected_phases
        phases_ok = phases_ok and ok_phases
        rec.add("%s.stop.%s.phase_keys" % (actor["key"], direction), ok_phases, "direction",
                list(phase_map.keys()) if isinstance(phase_map, dict) else phase_map)
        if not ok_phases:
            continue
        for phase in range(12):
            p_entries = phase_map["phase%d" % phase]
            m_entries = manifest.get("directions", {}).get(direction, {}).get("stop_bridges", {}).get("phase%d" % phase, [])
            cid = "%s.stop.%s.phase%02d.shape" % (actor["key"], direction, phase)
            ok = (isinstance(p_entries, list) and len(p_entries) == 4
                  and isinstance(m_entries, list) and len(m_entries) == 4)
            rec.add(cid, ok, "bridge", None if ok else {"package": p_entries, "manifest": m_entries})
            if not ok:
                continue
            first, last = p_entries[0], p_entries[3]
            rec.add("%s.stop.%s.phase%02d.start_walk" % (actor["key"], direction, phase),
                    isinstance(first, dict) and first.get("ref") == "walk"
                    and first.get("index") == phase and first.get("k") == 0.0, "bridge", first)
            rec.add("%s.stop.%s.phase%02d.final_idle" % (actor["key"], direction, phase),
                    isinstance(last, dict) and last.get("ref") == "idle"
                    and last.get("index") == 0 and last.get("k") == 1.0, "bridge", last)
            for middle in (1, 2):
                p_mid, m_mid = p_entries[middle], m_entries[middle]
                expected_k = round(middle / 3.0, 4)
                expected_file = "png/" + base_name(m_mid.get("file", ""))
                cid = "%s.stop.%s.phase%02d.entry%d" % (actor["key"], direction, phase, middle)
                ok = (isinstance(p_mid, dict) and isinstance(m_mid, dict)
                      and p_mid.get("file") == expected_file
                      and p_mid.get("sha256") == m_mid.get("sha256")
                      and p_mid.get("k") == expected_k
                      and isinstance(p_mid.get("sha256"), str)
                      and re.fullmatch(r"[0-9a-f]{64}", p_mid.get("sha256", "")) is not None)
                rec.add(cid, ok, "bridge",
                        None if ok else {"package": p_mid, "manifest": m_mid,
                                         "expected_file": expected_file, "expected_k": expected_k})
                if isinstance(p_mid, dict) and isinstance(p_mid.get("file"), str):
                    stop_files[(direction, phase, middle)] = join_rel(found["set_dir"], p_mid["file"])
                    stop_entries[(direction, phase, middle)] = (p_mid, m_mid)

    # source inputs and author hashes ---------------------------------------
    source_hashes = {}
    for key, item in manifest.get("source_inputs", {}).items():
        rel = item.get("file")
        if not safe_rel(rel):
            rec.add("%s.source_input.%s.safe_path" % (actor["key"], key), False, "source", rel)
            continue
        path = join_rel(root, rel)
        exists = path_exists(path)
        if not exists:
            rec.add("%s.source_input.%s.exists" % (actor["key"], key), False, "source", rel)
            continue
        if "sha256_text_lf_v1" in item:
            actual = sha256_text_lf(path)
            declared = item.get("sha256_text_lf_v1")
            normalization = "CRLF replaced with LF before sha256"
        else:
            actual = sha256_file(path)
            declared = item.get("sha256")
            normalization = "raw bytes"
        source_hashes[rel] = actual
        rec.add("%s.source_input.%s.sha256" % (actor["key"], key), actual == declared, "hash",
                {"file": rel, "declared": declared, "actual": actual,
                 "normalization": normalization})
    tool = manifest.get("tool", {})
    if safe_rel(tool.get("file", "")):
        path = join_rel(root, tool["file"])
        if path_exists(path):
            actual = sha256_text_lf(path)
            rec.add("%s.tool.sha256_text_lf" % actor["key"], actual == tool.get("sha256_text_lf_v1"),
                    "hash", {"file": tool["file"], "declared": tool.get("sha256_text_lf_v1"),
                             "actual": actual})
        else:
            rec.add("%s.tool.exists" % actor["key"], False, "hash", tool.get("file"))
    reused = manifest.get("reused_helpers", {})
    if reused:
        if safe_rel(reused.get("file", "")):
            path = join_rel(root, reused["file"])
            if path_exists(path):
                actual = sha256_text_lf(path)
                rec.add("%s.reused_helper.sha256_text_lf" % actor["key"],
                        actual == reused.get("sha256_text_lf_v1"), "hash",
                        {"file": reused["file"], "declared": reused.get("sha256_text_lf_v1"),
                         "actual": actual})
            else:
                rec.add("%s.reused_helper.exists" % actor["key"], False, "hash", reused.get("file"))

    # source author PNGs + package copies + frame geometry -------------------
    frame_records = []
    alphas = {}
    invalid_frames = 0

    def check_frame(key, source_rel, declared_sha, package_rel, action, idle=False):
        nonlocal invalid_frames
        problems = []
        if not safe_rel(source_rel) or not safe_rel(package_rel):
            problems.append("unsafe path")
        src_path = join_rel(root, source_rel)
        pkg_path = join_rel(root, package_rel)
        if not path_exists(src_path):
            problems.append("source PNG missing")
        if not path_exists(pkg_path):
            problems.append("package PNG missing")
        payload = None
        if not problems:
            src_bytes = read_bytes(src_path)
            pkg_bytes = read_bytes(pkg_path)
            src_sha = sha256_bytes(src_bytes)
            pkg_sha = sha256_bytes(pkg_bytes)
            if src_sha != declared_sha:
                problems.append("source sha %s != declared %s" % (src_sha, declared_sha))
            if pkg_sha != declared_sha:
                problems.append("package sha %s != declared %s" % (pkg_sha, declared_sha))
            if src_bytes != pkg_bytes:
                problems.append("source/package bytes differ")
            payload = pkg_bytes
        measured = None
        if payload is not None:
            try:
                measured = inspect_png(payload)
            except Exception as exc:
                problems.append("%s: %s" % (type(exc).__name__, exc))
        if measured is not None:
            alpha = measured["alpha"]
            if measured["partial_alpha"]:
                problems.append("%d partial-alpha texels" % measured["partial_alpha"])
            if measured["opaque_border_edges"]:
                problems.append("%d opaque cell borders" % measured["opaque_border_edges"])
            if measured["bottom"] > PIVOT[1] - 1:
                problems.append("opaque texels below floor row (bottom %d)" % measured["bottom"])
            if measured["body_height"] > BODY_TEXELS + 1:
                problems.append("body %d texels too tall (limit %d)" % (measured["body_height"], BODY_TEXELS + 1))
            if idle:
                if measured["bottom"] != PIVOT[1] - 1:
                    problems.append("idle bottom %d != floor row %d" % (measured["bottom"], PIVOT[1] - 1))
                if abs(measured["body_height"] - BODY_TEXELS) > 1:
                    problems.append("idle body %d != %d+-1" % (measured["body_height"], BODY_TEXELS))
            alphas[key] = alpha
        record = {
            "key": "/".join(str(part) for part in key),
            "path": package_rel,
            "source_path": source_rel,
            "sha256": sha256_file(pkg_path) if path_exists(pkg_path) else None,
            "declared_sha256": declared_sha,
            "bytes": len(payload) if payload is not None else None,
            "ok": not problems,
        }
        if measured is not None:
            record.update({
                "size": measured["size"], "bbox": measured["bbox"], "bottom": measured["bottom"],
                "body_height": measured["body_height"],
                "partial_alpha": measured["partial_alpha"],
                "opaque_border_edges": measured["opaque_border_edges"],
            })
        if problems:
            record["problems"] = problems
            invalid_frames += 1
            rec.frame_fail("frame.%s.%s" % (actor["key"], "/".join(str(part) for part in key)), problems)
        frame_records.append(record)
        return measured

    # static frames (package PNG exists but is not referenced by the set JSON)
    for direction in DIRECTIONS:
        declared = directions.get(direction, {}).get("static", {})
        source_rel = declared.get("file", "")
        expected_pkg = "game/data/%s/png/%s" % (set_dir_name, base_name(source_rel))
        check_frame((direction, "static", 0), source_rel, declared.get("sha256"), expected_pkg,
                    "static", idle=False)

    for key, (entry, declared) in set_entries.items():
        direction, action, index = key
        source_rel = declared.get("file", "")
        package_rel = "game/data/%s/%s" % (set_dir_name, entry.get("file", ""))
        check_frame(key, source_rel, declared.get("sha256"), package_rel, action,
                    idle=(action == "idle"))

    for key, (entry, declared) in stop_entries.items():
        direction, phase, middle = key
        source_rel = declared.get("file", "")
        package_rel = "game/data/%s/%s" % (set_dir_name, entry.get("file", ""))
        check_frame(key, source_rel, declared.get("sha256"), package_rel, "stop")

    # directory coverage: exactly the 164 referenced PNGs in the package folder
    expected_pkg_names = set()
    for direction in DIRECTIONS:
        static_rel = directions.get(direction, {}).get("static", {}).get("file", "")
        expected_pkg_names.add(base_name(static_rel))
    for key, (entry, _declared) in set_entries.items():
        expected_pkg_names.add(base_name(entry.get("file", "")))
    for key, (entry, _declared) in stop_entries.items():
        expected_pkg_names.add(base_name(entry.get("file", "")))
    png_dir = join_rel(found["set_dir"], "png")
    actual_png_names = {n for n in list_dir(png_dir) if n.lower().endswith(".png")} if is_dir(png_dir) else set()
    rec.add("%s.package.png_count" % actor["key"], len(expected_pkg_names) == 164, "direction",
            {"expected": len(expected_pkg_names), "actual": len(actual_png_names)})
    rec.add("%s.package.png_names_exact" % actor["key"], actual_png_names == expected_pkg_names,
            "direction", {"missing": sorted(expected_pkg_names - actual_png_names),
                          "extra": sorted(actual_png_names - expected_pkg_names)})
    rec.add("%s.package.png_files_present" % actor["key"],
            all(path_exists(join_rel(found["set_dir"], "png/" + n)) for n in expected_pkg_names),
            "frame")

    # anchors + bridge continuity -------------------------------------------
    anchor_report = {}
    bridge_report = {}
    contact = manifest.get("contact_check", {})
    stop_check = manifest.get("stop_check", {})

    def get_alpha(direction, action, index):
        return alphas.get((direction, action, index))

    for direction in ("south", "north"):
        declared_rows = contact.get(direction, {}).get("sole_rows", [])
        rec.add("%s.anchor.%s.contact_rows_count" % (actor["key"], direction),
                isinstance(declared_rows, list) and len(declared_rows) == 12, "anchor",
                len(declared_rows) if isinstance(declared_rows, list) else declared_rows)
        measured_rows = []
        rows_ok = isinstance(declared_rows, list) and len(declared_rows) == 12
        for phase in range(12):
            alpha = get_alpha(direction, "walk", phase)
            if alpha is None:
                rows_ok = False
                measured_rows.append({"phase": phase, "error": "missing walk alpha"})
                continue
            feet = half_feet(alpha)
            if feet is None:
                rows_ok = False
                measured_rows.append({"phase": phase, "error": "no L/R foot alpha"})
                continue
            item = {"phase": phase, "L_bottom": feet["L"]["bottom"], "R_bottom": feet["R"]["bottom"],
                    "L_x_min": feet["L"]["x_min"]}
            measured_rows.append(item)
            declared = declared_rows[phase] if phase < len(declared_rows) else {}
            if feet["L"]["bottom"] != declared.get("L_sole") or feet["R"]["bottom"] != declared.get("R_sole"):
                rows_ok = False
        rec.add("%s.anchor.%s.sole_rows_match_alpha" % (actor["key"], direction), rows_ok,
                "anchor", measured_rows)
        anchor_report[direction] = {"sole_rows_measured": measured_rows}

        seq_ok = True
        seq_measured = []
        for phase in range(12):
            declared_seq = stop_check.get(direction, {}).get("phases", [{}] * 12)[phase].get("planted_heel_x_seq", [])
            measured_seq = []
            # explicit bridge frame lookup
            frames_for_bridge = [
                get_alpha(direction, "walk", phase),
                alphas.get((direction, phase, 1)),
                alphas.get((direction, phase, 2)),
                get_alpha(direction, "idle", 0),
            ]
            for frame_alpha in frames_for_bridge:
                if frame_alpha is None:
                    measured_seq.append(None)
                    continue
                feet = half_feet(frame_alpha)
                measured_seq.append(None if feet is None else feet["L"]["x_min"])
            item = {"phase": phase, "measured_L_x_min": measured_seq, "declared": declared_seq}
            seq_measured.append(item)
            if measured_seq != declared_seq:
                seq_ok = False
        rec.add("%s.anchor.%s.stop_heel_sequence" % (actor["key"], direction), seq_ok, "anchor",
                seq_measured)
        anchor_report[direction]["stop_heel_sequence"] = seq_measured

        # bridge continuity: first == walk p, last == idle f00 (exact bytes)
        bridge_ok = True
        bridge_details = []
        for phase in range(12):
            walk_alpha = get_alpha(direction, "walk", phase)
            idle_alpha = get_alpha(direction, "idle", 0)
            s1 = alphas.get((direction, phase, 1))
            s2 = alphas.get((direction, phase, 2))
            item = {"phase": phase,
                    "walk_present": walk_alpha is not None,
                    "s1_present": s1 is not None, "s2_present": s2 is not None,
                    "final_idle_present": idle_alpha is not None}
            if None in (walk_alpha, s1, s2, idle_alpha):
                bridge_ok = False
            # final idle equality is asserted at the JSON/hash level below
            bridge_details.append(item)
        rec.add("%s.bridge.%s.frames_present" % (actor["key"], direction), bridge_ok,
                "bridge", bridge_details)
        bridge_report[direction] = bridge_details

    for direction in ("west", "east"):
        pairs = contact.get(direction, {}).get("pairs", [])
        rec.add("%s.anchor.%s.contact_pair_count" % (actor["key"], direction),
                isinstance(pairs, list) and len(pairs) == 10, "anchor",
                len(pairs) if isinstance(pairs, list) else pairs)
        pair_ok = True
        pair_measured = []
        for pair in pairs if isinstance(pairs, list) else []:
            start, end = pair.get("from"), pair.get("to")
            a = get_alpha(direction, "walk", start)
            b = get_alpha(direction, "walk", end)
            if a is None or b is None:
                pair_ok = False
                pair_measured.append({"from": start, "to": end, "error": "missing alpha"})
                continue
            heel_a = side_heel(a, direction)
            heel_b = side_heel(b, direction)
            expected_delta = 4 if direction == "west" else -4
            measured_slip = None if heel_a is None or heel_b is None else (heel_b - heel_a) - expected_delta
            item = {"from": start, "to": end, "planted": pair.get("planted"),
                    "heel_x": [heel_a, heel_b], "heel_dx": None if heel_a is None or heel_b is None else heel_b - heel_a,
                    "declared_heel_dx": pair.get("heel_dx"), "declared_slip": pair.get("slip_source_texels"),
                    "measured_slip": measured_slip}
            pair_measured.append(item)
            if (heel_a is None or heel_b is None or heel_b - heel_a != pair.get("heel_dx")
                    or measured_slip != pair.get("slip_source_texels")
                    or pair.get("sole_rows") != [SOLE_ROW, SOLE_ROW]):
                pair_ok = False
        rec.add("%s.anchor.%s.contact_slip_source" % (actor["key"], direction), pair_ok,
                "slip_source", pair_measured)
        anchor_report[direction] = {"contact_pairs_measured": pair_measured}

        idle_heels = load_ora_leg_heels(root, manifest, direction, actor["key"], rec)
        seq_ok = True
        seq_measured = []
        for phase in range(12):
            declared_phase = stop_check.get(direction, {}).get("phases", [{}] * 12)[phase]
            declared_seq = declared_phase.get("planted_heel_x_seq", [])
            frames_for_bridge = [
                get_alpha(direction, "walk", phase),
                alphas.get((direction, phase, 1)),
                alphas.get((direction, phase, 2)),
            ]
            planted = directions.get(direction, {}).get("walk", [{}] * 12)[phase].get("pose", {}).get("planted")
            planted_key = {"A": "leg-near", "B": "leg-far"}.get(planted)
            idle_heel = None if not idle_heels or planted_key is None else idle_heels.get(planted_key)
            measured_seq = [None if a is None else side_heel(a, direction) for a in frames_for_bridge]
            measured_seq.append(idle_heel)
            if planted_key is None or idle_heel is None:
                seq_ok = False
            steps = [] if None in measured_seq else [abs(measured_seq[i + 1] - measured_seq[i]) for i in range(3)]
            item = {"phase": phase, "measured_heel_x": measured_seq, "declared": declared_seq,
                    "planted_key": planted_key,
                    "idle_heel_source": ("ora:data/%s.png" % planted_key) if idle_heel is not None else None,
                    "measured_max_step": max(steps) if steps else None,
                    "declared_max_step": declared_phase.get("max_step_source"),
                    "measured_total_drift": abs(measured_seq[-1] - measured_seq[0]) if None not in measured_seq else None,
                    "declared_total_drift": declared_phase.get("total_drift_source")}
            seq_measured.append(item)
            if (measured_seq != declared_seq or not steps
                    or max(steps) != declared_phase.get("max_step_source")
                    or abs(measured_seq[-1] - measured_seq[0]) != declared_phase.get("total_drift_source")):
                seq_ok = False
        rec.add("%s.anchor.%s.stop_heel_sequence" % (actor["key"], direction), seq_ok,
                "anchor", seq_measured)
        anchor_report[direction]["stop_heel_sequence"] = seq_measured

    # bridge exact hashes in JSON order
    bridge_hash_ok = True
    bridge_hash_detail = []
    for direction in DIRECTIONS:
        for phase in range(12):
            p_entries = stop_dirs.get(direction, {}).get("phase%d" % phase, []) if isinstance(stop_dirs, dict) else []
            walk_key = (direction, "walk", phase)
            idle_key = (direction, "idle", 0)
            walk_decl = set_entries.get(walk_key, (None, {}))[1].get("sha256")
            idle_decl = set_entries.get(idle_key, (None, {}))[1].get("sha256")
            first_ok = bool(p_entries) and p_entries[0].get("ref") == "walk" and p_entries[0].get("index") == phase
            last_ok = len(p_entries) >= 4 and p_entries[3].get("ref") == "idle" and p_entries[3].get("index") == 0
            item = {"direction": direction, "phase": phase,
                    "walk_declared_sha": walk_decl, "idle_declared_sha": idle_decl,
                    "bridge_start_ref": first_ok, "bridge_end_ref": last_ok}
            if not first_ok or not last_ok:
                bridge_hash_ok = False
            bridge_hash_detail.append(item)
    rec.add("%s.bridge.start_walk_and_end_idle_refs" % actor["key"], bridge_hash_ok, "bridge",
            bridge_hash_detail)

    static_idle_ok = True
    static_idle_detail = []
    for direction in DIRECTIONS:
        static_decl = directions.get(direction, {}).get("static", {})
        idle_decl = directions.get(direction, {}).get("idle", [{}])[0] if directions.get(direction, {}).get("idle") else {}
        item = {"direction": direction, "static_sha": static_decl.get("sha256"),
                "idle_f00_sha": idle_decl.get("sha256"), "equal": static_decl.get("sha256") == idle_decl.get("sha256")}
        static_idle_detail.append(item)
        static_idle_ok = static_idle_ok and item["equal"]
    rec.add("%s.direction.static_equals_idle_f00" % actor["key"], static_idle_ok, "bridge",
            static_idle_detail)
    rec.add("%s.direction.neutral_endpoint_declared" % actor["key"],
            manifest.get("idle_model", {}).get("neutral_endpoint") == "f00 == static (exact)", "bridge",
            manifest.get("idle_model", {}).get("neutral_endpoint"))
    for direction in DIRECTIONS:
        static_decl = directions.get(direction, {}).get("static", {})
        exact = static_decl.get("exact_source")
        if not exact:
            continue
        cid = "%s.direction.%s.exact_source" % (actor["key"], direction)
        if not safe_rel(exact):
            rec.add(cid, False, "hash", exact)
            continue
        path = join_rel(root, exact)
        if not path_exists(path):
            rec.add(cid + ".exists", False, "hash", exact)
            continue
        actual = sha256_file(path)
        rec.add(cid, actual == static_decl.get("sha256"), "hash",
                {"file": exact, "declared": static_decl.get("sha256"), "actual": actual})

    # declared duration model
    rec.add("%s.direction.idle_duration_model" % actor["key"],
            manifest.get("idle_model", {}).get("duration_ms") == list(IDLE_MS)
            and manifest.get("idle_model", {}).get("frames") == 4, "direction",
            manifest.get("idle_model"))
    rec.add("%s.direction.walk_model" % actor["key"],
            manifest.get("walk_model", {}).get("phases") == 12
            and manifest.get("walk_model", {}).get("frame_ms_reference") == WALK_MS, "direction",
            manifest.get("walk_model"))

    # foot visibility at declared sole rows / side heel columns
    foot_ok = True
    foot_detail = []
    for direction in ("south", "north"):
        for phase in range(12):
            alpha = get_alpha(direction, "walk", phase)
            declared = contact.get(direction, {}).get("sole_rows", [{}] * 12)[phase]
            if alpha is None:
                foot_ok = False
                continue
            pixels = alpha.load()
            for side, row_key in (("L", "L_sole"), ("R", "R_sole")):
                row = declared.get(row_key)
                visible = isinstance(row, int) and any(
                    pixels[x, row] > 0 for x in (range(0, 40) if side == "L" else range(40, 80)))
                if not visible:
                    foot_ok = False
                    foot_detail.append({"direction": direction, "phase": phase, "side": side,
                                        "row": row, "visible": False})
    for direction in ("west", "east"):
        for phase in range(12):
            alpha = get_alpha(direction, "walk", phase)
            if alpha is None:
                foot_ok = False
                continue
            heel = side_heel(alpha, direction)
            pixels = alpha.load()
            if heel is None or pixels[heel, SOLE_ROW] == 0:
                foot_ok = False
                foot_detail.append({"direction": direction, "phase": phase, "heel": heel,
                                    "visible": False})
    rec.add("%s.anchor.visible_foot_alpha" % actor["key"], foot_ok, "anchor", foot_detail)

    # package / manifest hash declarations
    declared_set_sha = package.get("sprite_set_sha256")
    actual_set_sha = sha256_file(found["set"])
    rec.add("%s.package.sprite_set_sha256" % actor["key"], actual_set_sha == declared_set_sha,
            "hash", {"declared": declared_set_sha, "actual": actual_set_sha})
    declared_stop_lf = package.get("stop_supplemental_sha256_text_lf_v1")
    actual_stop_lf = sha256_text_lf(found["stop"])
    rec.add("%s.package.stop_supplemental_sha256_text_lf_v1" % actor["key"],
            actual_stop_lf == declared_stop_lf, "hash",
            {"declared": declared_stop_lf, "actual": actual_stop_lf,
             "normalization": "CRLF replaced with LF before sha256"})

    stationary = driver_stationary_analysis(
        root, found, rec, set_dir_name, registry_name, stop_name, actor["key"])

    # old limitations copied verbatim (no new audit essay)
    old_limitations = {
        "manifest_status": manifest.get("status"),
        "contact_models": {d: contact.get(d, {}).get("model") for d in DIRECTIONS},
        "normal_speed_drift": manifest.get("normal_speed_drift"),
        "measured_weaknesses": manifest.get("measured_weaknesses"),
        "stop_host_position_moves": {d: stop_check.get(d, {}).get("host_position_moves") for d in DIRECTIONS},
        "note": "verbatim fields from the current source manifest; no new limitation text",
    }

    criteria = {
        "frames_dimensions_density_pivots": {
            "pass": rec.cat_ok("frame") and rec.cat_ok("hash"),
            "frame_failures": sum(1 for f in rec.failures if f["category"] == "frame"),
            "hash_failures": sum(1 for f in rec.failures if f["category"] == "hash"),
        },
        "anchors_visible_feet": {
            "pass": rec.cat_ok("anchor"),
            "failures": sum(1 for f in rec.failures if f["category"] == "anchor"),
        },
        "directions_all4_banks": {
            "pass": rec.cat_ok("direction"),
            "failures": sum(1 for f in rec.failures if f["category"] == "direction"),
        },
        "source_slip_and_bridges": {
            "pass": rec.cat_ok("slip_source") and rec.cat_ok("bridge"),
            "failures": sum(1 for f in rec.failures if f["category"] in ("slip_source", "bridge")),
        },
        "stationary_npc_source_implication": {
            "pass": rec.cat_ok("driver"),
            "failures": sum(1 for f in rec.failures if f["category"] == "driver"),
        },
    }

    return {
        "actor": actor["key"],
        "found": {k: (os.path.relpath(v, root) if isinstance(v, str) else v) for k, v in found.items()
                  if k not in ("driver_candidates", "root", "actor")},
        "package": {
            "registry": os.path.relpath(found["registry"], root),
            "sprite_set": os.path.relpath(found["set"], root),
            "stop_supplemental": os.path.relpath(found["stop"], root),
            "source_manifest": os.path.relpath(found["manifest"], root),
            "sprite_set_sha256_raw": actual_set_sha,
            "stop_supplemental_sha256_text_lf_v1": actual_stop_lf,
            "registry_sha256_raw": sha256_file(found["registry"]),
            "source_manifest_sha256_raw": sha256_file(found["manifest"]),
        },
        "counts": {
            "package_pngs": len(actual_png_names),
            "expected_package_pngs": len(expected_pkg_names),
            "idle_frames_per_direction": 4,
            "walk_frames_per_direction": 12,
            "stop_bridges_per_direction": 12,
            "frames_checked": len(frame_records),
            "invalid_frames": invalid_frames,
        },
        "frames": frame_records,
        "anchors": anchor_report,
        "bridge": bridge_report,
        "drivers": stationary,
        "old_limitations": old_limitations,
        "oldlimitations": old_limitations,
        "criteria": criteria,
        "assertions": rec.assertions,
        "failures": rec.failures,
        "source_checks_pass": not rec.failures,
        "slip": {
            "source_geometry_pass": criteria["source_slip_and_bridges"]["pass"],
            "stance_foot_lock_runtime": "not_measured",
            "world_movement_runtime": "not_measured",
            "cosmetic_quality": "not_assessed",
            "note": "Alpha anchors reproduce the declared contact/stop tables in source space; this does not measure runtime foot lock, world slip, or playback.",
        },
    }


# --------------------------------------------------------------------------- self-test
def copy_file(src: str, dst: str) -> None:
    write_bytes(dst, read_bytes(src))


def copy_tree(src: str, dst: str) -> None:
    os.makedirs(wp(dst), exist_ok=True)
    for name in list_dir(src):
        s = os.path.join(src, name)
        d = os.path.join(dst, name)
        if is_dir(s):
            copy_tree(s, d)
        else:
            copy_file(s, d)


def build_mirror(src_root: str, dst_root: str, found_list) -> None:
    os.makedirs(wp(dst_root), exist_ok=True)
    for found in found_list:
        actor = found["actor"]
        copy_tree(os.path.join(src_root, "game/data", actor["set_dir"]),
                  os.path.join(dst_root, "game/data", actor["set_dir"]))
        copy_tree(os.path.join(src_root, actor["out_dir"], "png"),
                  os.path.join(dst_root, actor["out_dir"], "png"))
        copy_file(found["manifest"], os.path.join(dst_root, actor["out_dir"], base_name(found["manifest"])))
        # source inputs / author tools / reused helper
        try:
            manifest = read_json(found["manifest"])
        except Exception:
            manifest = {}
        rels = [v.get("file") for v in manifest.get("source_inputs", {}).values()]
        rels.append(manifest.get("tool", {}).get("file"))
        rels.append(manifest.get("reused_helpers", {}).get("file"))
        for direction in DIRECTIONS:
            rels.append(manifest.get("directions", {}).get(direction, {}).get("ora", {}).get("file"))
        for rel in rels:
            if safe_rel(rel) and path_exists(join_rel(src_root, rel)):
                copy_file(join_rel(src_root, rel), join_rel(dst_root, rel))
    for rel in ("game/scripts/mpath24", "game/scripts/lpath30", "game/scripts/zpath27",
                "game/scripts/exploration_sprite_set_pilot.gd"):
        src = join_rel(src_root, rel)
        dst = join_rel(dst_root, rel)
        if is_dir(src):
            copy_tree(src, dst)
        elif path_exists(src):
            copy_file(src, dst)


def perform_self_test(root: str, out_dir: str, found_list):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    uid = uuid.uuid4().hex[:8]
    temp = os.path.join(out_dir, "selfcheck-%s-%s" % (stamp, uid))
    mirror = os.path.join(temp, "root")
    result = {"temp_dir": os.path.relpath(temp, root), "mirror": os.path.relpath(mirror, root),
              "clean_control_pass": False, "frame_corruption": {}, "stop_manifest_corruption": {},
              "cleaned": False, "unexpected_exceptions": []}
    try:
        build_mirror(root, mirror, found_list)
        clean = run_checks(mirror, self_test=False)
        result["clean_control_pass"] = bool(clean.get("source_checks_pass"))
        result["clean_control_failures"] = clean.get("failures", [])[:10]

        actor = found_list[0]["actor"]
        frame_rel = "game/data/%s/png/%s" % (
            actor["set_dir"],
            base_name(clean["actors"][actor["key"]]["frames"][0]["path"]),
        )
        frame_path = join_rel(mirror, frame_rel)
        backup = os.path.join(temp, "frame.backup")
        copy_file(frame_path, backup)
        original = read_bytes(frame_path)
        image = Image.open(io.BytesIO(original)).convert("RGBA")
        pixels = image.load()
        x, y = 6, 6
        old = pixels[x, y]
        pixels[x, y] = (255, 0, 255, old[3] if old[3] else 255)
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        write_bytes(frame_path, buffer.getvalue())
        mutated = run_checks(mirror, self_test=False)
        frame_ids = [f["id"] for f in mutated.get("failures", [])]
        result["frame_corruption"] = {
            "mutated": frame_rel,
            "rejected": not mutated.get("source_checks_pass", True),
            "matched_failure_ids": [i for i in frame_ids if "frame." in i or "sha" in i][:20],
            "expected": "source/package frame sha or frame geometry rejection",
            "matched": any(("frame." in i) or ("sha" in i) for i in frame_ids),
        }
        copy_file(backup, frame_path)

        actor2 = found_list[1]["actor"] if len(found_list) > 1 else found_list[0]["actor"]
        stop_rel = "game/data/%s/%s" % (
            actor2["set_dir"],
            base_name(clean["actors"][actor2["key"]]["package"]["stop_supplemental"]),
        )
        stop_path = join_rel(mirror, stop_rel)
        backup2 = os.path.join(temp, "stop.backup")
        copy_file(stop_path, backup2)
        data = read_json(stop_path)
        data["phase_bridges"]["south"]["phase0"][3]["index"] = 1
        write_text(stop_path, json.dumps(data, ensure_ascii=False, indent=1) + "\n")
        mutated2 = run_checks(mirror, self_test=False)
        stop_ids = [f["id"] for f in mutated2.get("failures", [])]
        result["stop_manifest_corruption"] = {
            "mutated": stop_rel,
            "mutation": "phase_bridges.south.phase0[3].index 0 -> 1",
            "rejected": not mutated2.get("source_checks_pass", True),
            "matched_failure_ids": [i for i in stop_ids if "stop." in i or "hash" in i][:20],
            "expected": "stop.*.final_idle and/or stop text hash rejection",
            "matched": any(("final_idle" in i) or ("stop." in i) or ("hash" in i) for i in stop_ids),
        }
        copy_file(backup2, stop_path)
        control = run_checks(mirror, self_test=False)
        result["restored_control_pass"] = bool(control.get("source_checks_pass"))
    finally:
        try:
            shutil.rmtree(wp(temp))
        except Exception as exc:  # report, do not hide
            result["cleanup_error"] = "%s: %s" % (type(exc).__name__, exc)
        result["cleaned"] = not path_exists(temp)
    return result


# --------------------------------------------------------------------------- top-level run
def run_checks(root: str, self_test: bool = False, out_dir: str = None):
    if Image is None:
        return {
            "schema": SCHEMA, "root": os.path.abspath(root),
            "source_checks_pass": False,
            "failures": [{"id": "environment.pillow", "category": "environment",
                          "detail": "%s: %s" % (type(_PIL_IMPORT_ERROR).__name__, _PIL_IMPORT_ERROR)}],
            "unexpected_exceptions": [],
        }
    root = os.path.abspath(root)
    revision = None
    try:
        proc = subprocess.run(["git", "-C", root, "rev-parse", "HEAD"], capture_output=True,
                              text=True, encoding="utf-8", timeout=15)
        if proc.returncode == 0:
            revision = proc.stdout.strip()
    except Exception:
        revision = None

    found_list = []
    discovery_failures = []
    for actor in ACTORS:
        found = discover(root, actor)
        found_list.append(found)
        for key in ("registry", "set", "stop", "manifest"):
            if found[key] is None:
                discovery_failures.append({
                    "id": "%s.%s.discovery" % (actor["key"], key), "category": "source",
                    "detail": found[key + "_candidates"],
                })
    actors_out = {}
    all_failures = []
    for found in found_list:
        rec = Recorder()
        result = check_actor(root, found["actor"], rec)
        actors_out[found["actor"]["key"]] = result
        all_failures.extend(result.get("failures", []))
    all_failures.extend(discovery_failures)
    source_pass = not all_failures

    out = {
        "schema": SCHEMA,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "tool": os.path.relpath(os.path.abspath(__file__), root),
        "tool_sha256_text_lf_v1": sha256_text_lf(os.path.abspath(__file__)),
        "tested_revision": revision,
        "root": root,
        "python": sys.version.split()[0],
        "pillow": getattr(Image, "__version__", None),
        "text_hash_normalization": "sha256 of UTF-8 bytes with CRLF replaced by LF for *_text_lf_v1; PNG/set hashes are raw bytes",
        "hash_gate_limitation": "working-tree bytes only; no staged Git blob comparison (index edits prohibited by this task)",
        "source_checks_pass": source_pass,
        "overall": "source_pass_runtime_unverified" if source_pass else "source_fail",
        "qa_runtime_checks": {
            "status": "not_run",
            "reason": "Python-only source/package check; no Godot, renderer, import or playback run",
            "closure_ready": False,
        },
        "not_measured": [
            {"id": "slip.stance_foot_lock", "status": "not_measured",
             "reason": "static source alpha anchors only; runtime stance-foot lock not measured"},
            {"id": "slip.world_movement", "status": "not_measured",
             "reason": "no runtime movement/playback; ordinary stationary NPC is source-implied only"},
            {"id": "cosmetic.quality", "status": "not_assessed",
             "reason": "no art/motion judgement in this probe"},
            {"id": "runtime.godot", "status": "not_run",
             "reason": "no Godot/renderer/import; QA task frames/anchors/directions/slip closure cannot be claimed here"},
        ],
        "tasks": {
            "qa.char.protagonist-male.runtime-set-check": {
                "source_components": actors_out.get("protagonist-male", {}).get("criteria"),
                "slip_runtime": "not_measured",
                "closure_ready": False,
            },
            "qa.char.liang-xu.runtime-set-check": {
                "source_components": actors_out.get("liang-xu", {}).get("criteria"),
                "slip_runtime": "not_measured",
                "closure_ready": False,
            },
        },
        "actors": actors_out,
        "failures": all_failures,
        "unexpected_exceptions": [],
        "self_check": None,
    }
    if self_test:
        try:
            out["self_check"] = perform_self_test(
                root, out_dir or os.path.join(root, "outputs/xcheck36/deepseek"), found_list)
        except Exception as exc:
            out["unexpected_exceptions"].append("%s: %s" % (type(exc).__name__, exc))
            out["source_checks_pass"] = False
            out["overall"] = "self_test_fail"
        else:
            sc = out["self_check"]
            corruption_ok = (sc.get("clean_control_pass") and sc.get("restored_control_pass")
                             and sc.get("frame_corruption", {}).get("rejected")
                             and sc.get("frame_corruption", {}).get("matched")
                             and sc.get("stop_manifest_corruption", {}).get("rejected")
                             and sc.get("stop_manifest_corruption", {}).get("matched")
                             and sc.get("cleaned"))
            if not corruption_ok:
                out["source_checks_pass"] = False
                out["overall"] = "self_test_fail"
                out["failures"].append({"id": "self_check", "category": "self_check",
                                        "detail": sc})
    return out


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        help="project root (default: parent of tools/)")
    parser.add_argument("--out", default=None,
                        help="output directory (default: <root>/outputs/xcheck36/deepseek)")
    parser.add_argument("--self-test", action="store_true",
                        help="run the same-root temporary corruption self-test")
    parser.add_argument("--tag", default=None, help="optional lowercase run tag")
    args = parser.parse_args(argv)
    root = os.path.abspath(args.root)
    out_dir = os.path.abspath(args.out) if args.out else os.path.join(root, "outputs/xcheck36/deepseek")
    os.makedirs(wp(out_dir), exist_ok=True)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    uid = args.tag or uuid.uuid4().hex[:8]
    uid = re.sub(r"[^a-z0-9-]", "", uid.lower())
    result = run_checks(root, self_test=args.self_test, out_dir=out_dir)
    name = "%s_male-liang_source-contact-check_v01_%s-%s.json" % (PROJECT, stamp, uid)
    out_path = os.path.join(out_dir, name)
    write_text(out_path, json.dumps(result, ensure_ascii=False, indent=1) + "\n")
    print(json.dumps({
        "output": os.path.relpath(out_path, root),
        "source_checks_pass": result["source_checks_pass"],
        "overall": result["overall"],
        "failures": len(result["failures"]),
        "self_check": None if not result.get("self_check") else {
            "clean": result["self_check"].get("clean_control_pass"),
            "frame_rejected": result["self_check"].get("frame_corruption", {}).get("rejected"),
            "stop_rejected": result["self_check"].get("stop_manifest_corruption", {}).get("rejected"),
            "cleaned": result["self_check"].get("cleaned"),
        },
    }, ensure_ascii=False, indent=1))
    return 0 if result["source_checks_pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
