# M8 source-identity review followup — Claude producer (m8reg63)

Producer: Claude Code (Opus 5.5). Everything below is a **producer observation**. Hermes runs the final checks, and only those runs count as coordinator verification.
HEAD `ababe587c3f3504a592dca11e7f966ee946955ec`. The only edit outside `work/m8reg63/` is `game/tests/m8_city_integration_smoke.gd`. I made no runtime, default, asset, registry, manifest, ledger, Bible, Git index or commit changes. The `outputs/` Bible and ledger modifications and `outputs/m8reg63/` were already dirty when this session started; I did not touch them. No art or motion approval is claimed, and no points are claimed.

## Source hashes (raw sha256, no normalization)
| file | before | after |
|---|---|---|
| `game/tests/m8_city_integration_smoke.gd` | `3a73e14cdd95d2b802407dc2dd0902c9e38a4201d8b4868e00d64bee488d3b81` | `1e0ad13dcbaf242b4db93b0b5c7dd6e726e8bca51678e601a0d8d139cebd4bff` |
| `work/m8reg63/run_checks.py` | (not hashed before edit) | `b4718dc76a4e22318ce9ec5b9f8a178b75114e9d860f204eeed236be96d2d0db` |
| `work/m8reg63/neg_set_pin.py` (new) | — | `4a8c48aaecf5052ab82fb939242271ceab9628ec54b3e74d1bb4b94c4f2c1351` |

`run_checks.py` changes: it now counts the `SAME_ID_SET` and `BREATHING` negatives and `M8_ACTIVE_SET_VERIFIED`, and the markers now match with a trailing `:`.

## Pinned inputs (traced with `python3 -I work/m8reg63/trace_sources.py`; set paths derived from the pinned registries)
| actor | set manifest (derived from registry) | set sha256 | idle/dir | walk/dir |
|---|---|---|---|---|
| protagonist-male | `data/mexplore23/…explore-sprite-set-runtime_unapproved-mexplore23-v01_20261021-162551-ae9d34cb.json` | `6e3df976b3def0fdb56e1bd738dc13076e60108bf7b16b20a15824cd07dfd2da` | 4 | 12 |
| protagonist-female | `data/hsea-front17/…exploration-sprite-set_runtime-v01_20261020-222654-d77f7769.json` | `3ccf615a536fef4938dafa869ea7f454860a3dca72fdb0c6c566e03f4fea3fa1` | 1 | 12 |
| liang-xu | `data/lexplore28/…explore-sprite-set-runtime_unapproved-lexplore28-v01_20261021-194350-fa84819b.json` | `138ae2f3660139d90a2e9d784315c9eac8ab1ca27c6d753ddf98d39ce40cd379` | 4 | 12 |

Female breathing trace: in hsea09 `ADDITIONAL_SOURCE_PROFILES`, the key `3ccf615a…` is the female set sha above. That profile maps to `idle_supplement_path` `data/hsea-idle21/…breathing-idle-manifest_unapproved-idle21-v01_20261021-151339-cf9f5d3c.json` with sha256 `dc6f4496fe268fd07d1ba674c415f8063977263a29549e82a578d5901c657e96`. hsea21 `load_supplement` loads it into `driver.breathing.clips`. The test pins the same path and sha in `ACTIVE`, plus 8 frames per direction. It requires `source_set_sha256 == 3ccf615a…` and checks each frame's raw sha256 against its manifest entry.

## Test changes
- **`_expected(actor)` (new): an independent pinned read.** It runs **before any `SpriteSetPilot.load_registry/load_set` call**, and the byte pins are rechecked on every call:
  1. registry raw sha256;
  2. the test parses the registry JSON itself and derives the set path;
  3. set manifest raw sha256;
  4. for the female actor only, the breathing manifest raw sha256.
  
  Only after those pins pass does it parse the manifest. It checks `set_id`, `actor_id`, density 2, frame_size 80x112 and pivot (40,104). It checks exact idle counts (4/1/4), exactly 12 walk frames per direction, and 8 breathing frames per direction. It loads every frame with `ResourceLoader.load` and checks that each one is 80x112 and has no opaque texel below the floor row. For idle and breathing frames, the soles must end exactly on row 103. This keeps the old all-walk-frame integrity invariant, now applied to the current set. The 32x48 legacy fallback check is still there too. On success it prints `M8_ACTIVE_SET_VERIFIED`. The loaded result is memoized per actor, but only after that call's byte pins have passed.
- **`_source_problem`** keeps the driver-script and parent checks and the production-loader `set_id` check. It now also requires:
  - the driver's own `sprite_set` idle and walk texture arrays to equal the independent arrays for every action and direction;
  - the production loader's arrays to equal them too;
  - the driver's `breathing.clips` to equal the independently loaded breathing frames direction by direction. Actors without breathing must have none.
  
  The drawn texture must belong to the **independent** set, not to the driver's dictionaries.
- **`_facing_textures` / `_facing_problem`** now take the actor and use the independent lists. For idle, they add the pinned breathing frames, not the driver's clip membership. The direction negative takes its wrong frame from the independent set.
- **`_negative`** now accepts any `Object`, so it can mutate a driver as well as a sprite.

## Negative controls (inline mutate → same predicate must reject → restore → must re-accept)
- `SOURCE` ×2: Liang's south idle (independent) drawn on the hero → `drawn texture is not from the active set`.
- `SAME_ID_SET` ×2 (**new**): `pilot.sprite_set` is replaced with a shallow copy of Liang's validated set whose `set_id` is overwritten with the expected hero id. Liang's driver is untouched. Result: `driver idle south textures are not the pinned set's`. Restoring it re-accepts.
- `BREATHING` ×1 (female only, **new**): a deep copy of `breathing.clips` with south breathing frame 1 replaced by Liang's idle → `driver breathing south textures are not the pinned supplement's`.
- `SCALE` ×2, `PIVOT` ×2, `DIRECTION` ×8: kept.
- **Pin negative in a separate process** (`python3 -I work/m8reg63/neg_set_pin.py`): a mutated copy `work/m8reg63/neg-set-pin-mutant.gd` (sha256 `3603f94aaef590029139e4974c4f6551c55c4eeb99b93a02f15ddea8ad08afd9`) has one hex digit of the male set sha changed. The checked runner reports `passed:false` (reason `diagnostic`, exit −9 when the runner stopped it on the marker). The log contains `active hero source male: set manifest bytes are not pinned: …ae9d34cb.json` and no `SCRIPT ERROR`. Files: `neg-set-pin.log`, `neg-set-pin-summary.json`. The mutant lives only in `work/`.

## Runs (checked runner `tools/…checked-runner_v01_20261018-203400-f74ac6d1.py`, 120 s, `--headless --audio-driver Dummy`, expected `M8_CITY_INTEGRATION_OK`)
- `python3 -I work/m8reg63/run_checks.py headless` → `headless-20261023-203344.log` / `-summary.json`: **passed**, exit 0, 3.28 s, test sha `1e0ad13d…4bff`, no diagnostics. Marker counts: SOURCE 2, SAME_ID_SET 2, BREATHING 1, SCALE 2, PIVOT 2, DIRECTION 8, ACTIVE_SET_VERIFIED 3. This run passed on the first attempt after the edit, and there were no failed attempts in this followup.
- I did not run Xvfb, M7, M1, navigation or re-entry in this followup. Those runs are coordinator-owned.

## Correction to the first producer report
The first report left out **`headless-20261023-202622.log`**, a second failed debug run. That run used the debug snapshot, whose failure messages included the full driver `state()` dump. It failed at the same point as `headless-20261023-202612.log`: `walk continues female south` (driver in `settle`, `actual_distance 0.0`, line 218). The cause was the same test-geometry error (the heroine walked into the plaza edge about 12 px south of spawn). It was not a runtime defect. The full producer run history is: 202612 FAIL, 202622 FAIL (debug), 202649 pass, 202704 pass, xvfb 202707 pass, and now 203344 pass. The four earlier snapshot hashes in `provider-snapshot-history.json` were reconstructed and matched by the coordinator, not by me.

## Limitations
- The set manifests carry no per-frame sha256. The set pin covers frame **paths**, durations and metadata, but not the PNG bytes or their `.import`/`.ctex` artifacts. Only the breathing frames are byte-pinned per frame.
- Texture identity relies on Godot's resource cache, which returns the same `Texture2D` instance for a path. Array equality compares those instances.
- The memoized independent result is reused within one process only after that call's byte pins have passed. A mid-run file swap that preserved the sha is not a meaningful threat.
- The inline negatives mutate live objects. The only separate mutated-process negative is the set-sha pin. Registry and breathing pin mutants were not run as separate processes.
- Release still observes the settled idle after 30 ticks. Intermediate stop-bridge frames and timing are not asserted, and that is out of scope.
