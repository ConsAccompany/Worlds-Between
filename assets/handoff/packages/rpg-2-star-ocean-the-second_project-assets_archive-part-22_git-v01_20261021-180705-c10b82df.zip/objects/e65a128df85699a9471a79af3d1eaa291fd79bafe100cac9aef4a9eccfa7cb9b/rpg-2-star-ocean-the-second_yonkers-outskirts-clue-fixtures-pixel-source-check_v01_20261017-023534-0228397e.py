"""Source and in-engine pixel-fidelity checks for the Yonkers outskirts clue fixtures v01.

python -I <this file> --artonly <capture> --plateonly <capture> [--pixelorama <exe>] [--report <json>]

1. Each .ora is a valid OpenRaster archive with exactly three named layers.
2. Alpha-compositing the three .ora layers reproduces the runtime PNG exactly.
3. Runtime PNG == source PNG == manifest sha256-bytes.
4. Every opaque texel is from the authored palette; structure/detail alpha is
   binary and the contact shadow uses one alpha value.
5. In-engine: the art-only Godot capture equals the plate-only capture with each
   fixture PNG composited at its manifest origin (opaque texels exact, shadow
   texels within 1/255), and is unchanged everywhere outside the fixtures.
6. Optional: Pixelorama CLI --split-layers export of each .ora equals its layers.
"""

from __future__ import annotations

from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from io import BytesIO
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parents[1]
STAMP = "20261017-023534-0228397e"
SRC = ROOT / "outputs" / "yonkers-outskirts-fixtures-pilot"
RUNTIME = ROOT / "game" / "assets" / "props" / "yonkers-outskirts-fixtures"
MANIFEST = SRC / f"rpg-2-star-ocean-the-second_yonkers-outskirts_seven-clue-fixtures-manifest_unapproved-v01_{STAMP}.json"
AUTHOR = ROOT / "tools" / f"rpg-2-star-ocean-the-second_yonkers-outskirts-clue-fixtures-author_v01_{STAMP}.py"
POINTS = {"trace:0": (125, 240), "trace:1": (408, 95), "relay": (470, 128), "assist": (505, 258),
          "survey": (558, 277), "bypass": (575, 105), "patrol": (355, 238)}

results = []


def check(ok, message):
    results.append({"ok": bool(ok), "check": message})
    print(("ok  " if ok else "FAIL ") + message)


def ora_layers(path):
    with ZipFile(path) as z:
        names = z.namelist()
        first = z.infolist()[0]
        check(first.filename == "mimetype" and first.compress_type == 0 and z.read("mimetype") == b"image/openraster",
              f"{path.name[46:90]}: mimetype first, stored")
        stack = ET.fromstring(z.read("stack.xml"))
        layers = stack.find("stack").findall("layer")
        images = {l.get("name"): Image.open(BytesIO(z.read(l.get("src")))).convert("RGBA") for l in layers}
        check("mergedimage.png" in names, f"{path.name[46:90]}: mergedimage.png present")
        return [l.get("name") for l in layers], images, Image.open(BytesIO(z.read("mergedimage.png"))).convert("RGBA")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--artonly", type=Path, required=True)
    parser.add_argument("--plateonly", type=Path, required=True)
    parser.add_argument("--pixelorama", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    spec = spec_from_file_location("fixture_author", AUTHOR)
    author = module_from_spec(spec)
    spec.loader.exec_module(author)
    palette = {author.rgba(v)[:3] for k, v in author.C.items()}
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    check(len(manifest["assets"]) == 7, "manifest lists 7 fixtures")
    art = Image.open(args.artonly).convert("RGBA")
    plate = Image.open(args.plateonly).convert("RGBA")
    check(art.size == plate.size == (640, 360), "art-only and plate-only captures are 640x360")
    expected = plate.copy()
    covered = Image.new("L", (640, 360), 0)
    stats = {}
    for asset in manifest["assets"]:
        slug = asset["purpose"]
        runtime_png = RUNTIME / asset["png"]
        source_png = SRC / asset["png"]
        data = runtime_png.read_bytes()
        check(data == source_png.read_bytes() and sha256(data).hexdigest() == asset["pngSha256"],
              f"{slug}: runtime PNG == source PNG == manifest sha256")
        png = Image.open(runtime_png).convert("RGBA")
        check(list(png.size) == asset["size"], f"{slug}: size {png.size}")
        order, layers, merged_img = ora_layers(SRC / asset["ora"])
        check(order == ["identity-detail", "structure", "contact-shadow"], f"{slug}: three named layers, top-first")
        comp = Image.new("RGBA", png.size, (0, 0, 0, 0))
        for name in ["contact-shadow", "structure", "identity-detail"]:
            check(layers[name].size == png.size, f"{slug}: layer {name} full canvas")
            comp = Image.alpha_composite(comp, layers[name])
        check(comp.tobytes() == png.tobytes() and merged_img.tobytes() == png.tobytes(),
              f"{slug}: layer composite and mergedimage reproduce runtime PNG exactly")
        shadow_alpha = {a for a in layers["contact-shadow"].getchannel("A").getdata()} - {0}
        check(shadow_alpha == {author.SHADOW[3]}, f"{slug}: contact shadow single alpha {sorted(shadow_alpha)}")
        for name in ["structure", "identity-detail"]:
            alphas = set(layers[name].getchannel("A").getdata())
            check(alphas <= {0, 255}, f"{slug}: {name} alpha is binary")
            colours = {p[:3] for p in layers[name].getdata() if p[3] == 255}
            check(colours <= palette, f"{slug}: {name} uses only authored palette ({len(colours)} colours)")
        opaque_colours = {p[:3] for p in png.getdata() if p[3] == 255}
        stats[slug] = {"size": png.size, "opaqueTexels": sum(1 for p in png.getdata() if p[3] == 255),
                       "opaqueColours": len(opaque_colours)}
        ox, oy = asset["offsetFromSitePoint"]
        x, y = POINTS[asset["clueSite"]]
        expected.alpha_composite(png, (x + ox, y + oy))
        covered.paste(255, (x + ox, y + oy, x + ox + png.width, y + oy + png.height), png.getchannel("A"))
        # Opaque texels must land exactly, 1:1, in the engine capture.
        region = art.crop((x + ox, y + oy, x + ox + png.width, y + oy + png.height))
        mism = sum(1 for a, b in zip(region.getdata(), png.getdata()) if b[3] == 255 and a[:3] != b[:3])
        check(mism == 0, f"{slug}: all {stats[slug]['opaqueTexels']} opaque texels exact in Godot capture ({mism} differ)")
    diff = ImageChops.difference(art.convert("RGB"), expected.convert("RGB"))
    inside = [max(px) for px, m in zip(diff.getdata(), covered.getdata()) if m]
    outside = [max(px) for px, m in zip(diff.getdata(), covered.getdata()) if not m]
    check(max(inside) <= 1, f"in-engine fixture texels incl. shadows within 1/255 of offline composite (max {max(inside)})")
    check(max(outside) == 0, f"no change outside fixture texels ({sum(1 for v in outside if v)} differ)")
    if args.pixelorama:
        pixelorama_roundtrip(args.pixelorama, manifest)
    failures = sum(1 for r in results if not r["ok"])
    print(f"YONKERS_OUTSKIRTS_PIXEL_SOURCE_CHECK checks={len(results)} failures={failures}")
    if args.report:
        args.report.write_text(json.dumps({"status": "UNAPPROVED v01 technical check", "checks": results,
                                           "fixtureStats": stats, "artonly": args.artonly.name, "plateonly": args.plateonly.name,
                                           "failures": failures}, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(1 if failures else 0)


def pixelorama_roundtrip(exe, manifest):
    real = Path(os.environ.get("APPDATA", "")) / "pixelorama"
    before = {p.name: p.stat().st_mtime for p in real.iterdir()} if real.exists() else {}
    with tempfile.TemporaryDirectory(prefix="yonk-pxo-") as tmp:
        env = dict(os.environ, APPDATA=str(Path(tmp) / "appdata"))
        (Path(tmp) / "appdata").mkdir()
        for asset in manifest["assets"]:
            out = Path(tmp) / asset["purpose"]
            out.mkdir()
            src = out / "f.ora"
            shutil.copyfile(SRC / asset["ora"], src)
            subprocess.run([str(exe), "--headless", "--quit", "--", "--export", "--split-layers", "-o", str(out / "f.png"), str(src)],
                           env=env, capture_output=True, timeout=180)
            exported = [Image.open(p).convert("RGBA") for p in sorted(out.glob("*.png"))]
            _, layers, _ = ora_layers(SRC / asset["ora"])
            want = sorted(l.tobytes() for l in layers.values())
            got = sorted(e.tobytes() for e in exported)
            check(len(exported) == 3 and got == want, f"{asset['purpose']}: Pixelorama 1.2.3 split-layer export == .ora layers ({len(exported)} files)")
    after = {p.name: p.stat().st_mtime for p in real.iterdir()} if real.exists() else {}
    # An open Pixelorama GUI (another session) rewrites .running every ~15 s and
    # autosaves into backups/ every ~62 s; those two entries are not ours.
    changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k) and k not in (".running", "backups"))
    check(not changed, f"real %APPDATA%/pixelorama untouched apart from GUI heartbeat/backups (changed: {changed})")


if __name__ == "__main__":
    main()
