"""UNAPPROVED, test-only candidate: female protagonist side-view battle idle, facing right, ONE static frame.

Hand-placed pixel art. Every texel below is typed in an ASCII row map; there is no resampling, filtering,
quantizing, dithering, gradient, AI generation or upscaling anywhere in this file. Each palette key maps
to one colour taken verbatim from the owner-approved v8 south static frame (identity/palette baseline),
so the candidate palette is a subset of v8's 32 colours. Alpha is binary.

Density and scale: authored at 2x logical density like v8 (1 texel = 1 screen pixel at 1280x720), so the
96-texel body is the approved 48 logical px when drawn at node scale 0.5 in the 640x360 canvas.

Read-only inputs (hash-gated, never written): the v8 PNG and its editable .pxo, and the old rough combat
prototype idle (game/assets/characters/combat-prototypes/...sideview-idle-right-phase-01...), used only for
the comparison sheet. No runtime script, scene, Game Bible, tracker or acceptance count is touched.

Modes
  preview <dir>   render the composite + zoomed comparison sheets into <dir> (outside the repo).
  build           write the candidate PNG, .pxo (pxo_version 7), .ora and manifest into
                  game/assets/characters/combat-sideview-pilots/. Never overwrites a different file.
  check [--no-pixelorama]
                  technical gates on the built files; unless --no-pixelorama, also Pixelorama 1.2.3
                  headless flat + --split-layers exports of temp copies of the .pxo and .ora, run with
                  APPDATA redirected to a fresh temp dir so the real %APPDATA%\\pixelorama is never touched.
                  Prints a JSON report; writes nothing in the repo.

Run with the real Python in isolated mode:  python -I -B <this file> preview|build|check
"""
import argparse, hashlib, io, json, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
VER = "unapproved-v01"
STAMP = "20261015-194937"
RUN_ID = "03b8a0ab"
W, H = 112, 112
PIN = (52, 104)                 # ground contact, first transparent row under the soles (v8 uses row 104 too)
BODY_ROWS = (8, 103)            # 96-texel body = 48 logical px at display scale 0.5
OUT_DIR_REL = "game/assets/characters/combat-sideview-pilots"
V8_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
          "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
V8_SHA256 = "ccf9d2a293e7f1b9c706b4d2f1bf9c00b3c7714ec4e9b8bddf023e166f68b6fd"
V8_PXO_SHA256 = "cafa4998b107ae4b884cc877b80bbc695df267f37e09fb6e69701567f08a849e"
V8_PXO_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
              "south-idle-selout-v8-editable_m8-v08_20261015-080907-c8a1c140.pxo")
OLD_SHA256 = "c80c4c33eff203025e3afe9464350369f35291ff2733db02fc74fc3fac058b9e"
OLD_REL = ("game/assets/characters/combat-prototypes/rpg-2-star-ocean-the-second_protagonist-female_"
           "sideview-idle-right-phase-01_m8-prototype_20261014-143059-fda7d2c5.png")
PIXELORAMA_REL = "work/tooling/pixelorama-1-2-3/Pixelorama-Windows-64bit/Pixelorama.exe"
PIXELORAMA_VERSION = "v1.2.3-stable"
GUIDE_RGB = (255, 0, 255)


def fid(role):
    return hashlib.sha256(f"{RUN_ID}:{role}".encode()).hexdigest()[:8]


SUBJECT = "protagonist-female_sideview-battle-idle-right"
PNG_NAME = f"{SLUG}_{SUBJECT}_candidate-frame_{VER}_{STAMP}-{fid('png')}.png"
PXO_NAME = f"{SLUG}_{SUBJECT}_editable-layers_{VER}_{STAMP}-{fid('pxo')}.pxo"
ORA_NAME = f"{SLUG}_{SUBJECT}_editable-layers_{VER}_{STAMP}-{fid('ora')}.ora"
MANIFEST_NAME = f"{SLUG}_{SUBJECT}_candidate-manifest_{VER}_{STAMP}-{fid('manifest')}.json"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))

# ============================================================================ palette
# key -> v8 colour. Several keys share one colour so each layer keeps its own material vocabulary.
PALETTE = {
    "K": "#0a0a0e",                                                                  # line
    "H": "#533b32", "Y": "#41302b", "C": "#634739", "B": "#845436", "Z": "#302526",  # hair
    "i": "#fbc38d", "k": "#e39664", "n": "#bb7c50", "w": "#9a4634", "O": "#faead4",  # skin, catchlight
    "7": "#1a767b", "d": "#11525b", "j": "#0a323b", "u": "#249b98",                  # teal scarf / roll
    "g": "#5e6e8c", "4": "#3a4560", "3": "#222839", "r": "#c07a40", "m": "#a16f4b",  # slate coat, copper trim
    "e": "#d7c0a8", "o": "#faead4", "9": "#b09986", "l": "#cfc8bd",                  # cream shirt, buckle
    "b": "#845436", "a": "#714730", "8": "#41302b", "6": "#302526", "p": "#7e5f4a",  # leather
    "5": "#324542", "f": "#4a625c", "T": "#222839",                                  # spruce trousers
    "s": "#474b54", "t": "#30333a", "v": "#626873", "q": "#23252b",                  # gunmetal
    "L": "#cfc8bd", "P": "#faead4", "U": "#249b98",                                  # blade, gadget light
}

# ============================================================================ layers (bottom -> top)
# Each layer: (name, origin x, origin y, rows). "." is transparent. Rows are padded on the right.
LAYERS = []


def layer(name, ox, oy, rows):
    LAYERS.append((name, ox, oy, rows))


# Rows are either strings placed at the layer origin x, or (absolute x, string) tuples for limbs.
layer("back-leg", 0, 70, [
    (43, "KT55555ffK"),          # y70 (under the coat hem)
    (43, "KT55555ffK"),
    (42, "KT55555ffK"),
    (42, "KT55555ffK"),
    (42, "KT55555ffK"),
    (41, "KT55555ffK"),          # y75
    (41, "KT55555ffK"),
    (41, "KT55555ffK"),
    (40, "KTT5555ffK"),
    (40, "KT55555ffK"),
    (40, "KT55555ffK"),          # y80 knee
    (39, "KT55555ffK"),
    (39, "KT5555ffK"),
    (38, "KT5555ffK"),
    (38, "KT5555ffK"),
    (37, "KTT555ffK"),           # y85
    (37, "KT5555ffK"),
    (37, "KabbbbbbK"),           # y87 boot cuff
    (37, "K8888888K"),
    (37, "K8aaaaabK"),
    (37, "K8aaaaabK"),           # y90
    (37, "K8aaaaabK"),
    (37, "K8aaaaabK"),
    (37, "K8eeeelbK"),           # y93 ankle strap + buckle
    (37, "K8aaaaabK"),
    (37, "K8aaaaabbK"),          # y95
    (36, "K68aaaaaabK"),
    (36, "K68aaaaaaabK"),
    (36, "K68aaaaaaaabK"),
    (36, "K668aaaaaaaabbK"),
    (36, "K6688888aaaaabK"),     # y100
    (36, "K6666666888888K"),
    (36, "K6666666666666K"),
    (37, "KKKKKKKKKKKKK"),       # y103 sole line
])

layer("scarf-tail", 22, 50, [
    "...............K77777777K",  # y50 (under the pack)
    "...............K77777777K",
    "...............K77777777K",
    "...............K77777777K",
    "..............K77777777K.",  # y54
    ".............Kd7777777uK.",
    "............Kdd7777777K..",
    "...........Kjd77777u77K..",
    "..........Kjdd7777u777K..",
    ".........Kjd7d777u7777K..",  # y59
    "........Kjd77d777u7777K..",
    ".......Kjd777d7777u777K..",
    "......Kjd7777d7777u777K..",
    ".....Kjd7777d777777u7K...",
    "....Kjd77777d77777u7K....",  # y64
    "....Kjdd7777dd7777uK.....",
    "...Kjd777dKd7777u7K......",
    "...Kjd77dK.Kd777uK.......",
    "...Kjd7dK...Kd7uK........",
    "....KddK.....KdK.........",  # y69
    ".....KK.......K..........",
])

layer("backpack", 33, 30, [
    ".....KKKKK.....",   # y30 bedroll end
    "...KK77uu7KK...",
    "..Kd77777uu7K..",
    "..Kd7ddddd7uK..",
    "..Kd7d777d7uK..",
    "..Kd7d7j7d77K..",   # y35
    "..Kd7d77dd77K..",
    "..Kd7dddd777K..",
    "..Kdd7777777K..",
    ".K6KKdddddKK88K",
    ".K8bbKKKKKbbbaK",   # y40 pack
    ".K8abbbbbbbbbaK",
    ".K88888888888aK",
    ".K8aaaaalllaaaK",   # y43 buckle
    ".K8aaaaal8laaaK",
    ".K8aaaaalllaaaK",   # y45
    ".K8aaaaaaaaabaK",
    ".K8aaaaaaaaabaK",
    ".K8aaaaaaaaabaK",
    ".K68aaaaaaaabaK",
    ".K668888888888K",   # y50
    "..KKKKKKKKKKKK.",
])

layer("front-leg", 0, 62, [
    (55, "KT55555fffK"),         # y62 (under the coat)
    (55, "KT55555fffK"),
    (56, "KT55555fffK"),
    (56, "KT55555fffK"),
    (56, "KT55555fffK"),         # y66
    (57, "KT55555fffK"),
    (55, "KKKKKKK55fffK"),       # y68 thigh holster
    (55, "KqtvvtK55fffK"),
    (55, "KaaaaaaabbbaK"),       # y70 thigh strap
    (55, "KqtUUtK55fffK"),
    (55, "KqtUvtK555fffK"),
    (55, "KqtttqK555fffK"),
    (56, "KqqqK5555fffK"),
    (57, "KKKT5555ffffK"),       # y75
    (58, "KT55555ffffK"),
    (59, "KT55555ffffK"),
    (59, "KT55555fffffK"),
    (59, "KT55555fffffK"),
    (59, "KTT5555ffffK"),        # y80 knee
    (59, "KT55555fffK"),
    (58, "KT55555fffK"),
    (58, "KT5555fffK"),
    (57, "KTT5555ffK"),
    (57, "KT5555fffK"),          # y85
    (57, "KT5555ffK"),
    (57, "KbbbbbbbK"),           # y87 boot cuff
    (57, "K8888888K"),
    (57, "K8aaaabbK"),
    (57, "K8aaaabbK"),           # y90
    (57, "K8aaaabbK"),
    (57, "K8aaaabbK"),
    (57, "K8eeeelbK"),           # y93 ankle strap + buckle
    (57, "K8aaaabbK"),
    (57, "K8aaaaabbK"),          # y95
    (56, "K68aaaaaabbK"),
    (56, "K68aaaaaaabbK"),
    (56, "K68aaaaaaaabbK"),
    (56, "K668aaaaaaaaabK"),
    (56, "K6688888aaaaabbK"),    # y100
    (56, "K66666668888888K"),
    (56, "K66666666666666K"),
    (57, "KKKKKKKKKKKKKK"),      # y103 sole line
])

layer("body-coat", 34, 34, [
    "...........K334444444gggK.........",   # y34
    "..........K3344444444ggggK........",
    ".........K3344444444gggrmeK.......",
    ".........K3344444444gggreoeK......",
    ".........K3344444444gggr9eoeK.....",   # y38
    ".........K3344444444gggr9eooK.....",
    ".........K3344444444gg4r9eoeK.....",
    ".........K3344444444gg4r9e9eK.....",
    ".........K3334444444gg4r9eoeK.....",
    ".........K3334444444gg4r99eeK.....",
    ".........K3334444444g44r9eoeK.....",   # y44
    ".........K3334444444g44r9e9eK.....",
    ".........K3334444444g44r9eeeK.....",
    ".........K3334444444444r99eeK.....",
    ".........K3334444444444r9eoeK.....",
    ".........K3334444444444r9e9eK.....",
    ".........K3334444444444m9eeeK.....",   # y50
    ".........K3334444444444m9eeK......",
    ".........K3334444444444m99eK......",
    ".........K3334444444444m999K......",
    ".........KabbbbbbbbbbbbblllbbK....",   # y54 belt
    ".........K8aaaaaaaaaaaaal8laaK....",
    ".........K68888888888888lll88K....",
    ".........K3344444444444444ggrK....",   # y57 skirt
    "........K334444444444333333ggrK...",
    "........K3344344444344gggggggrK...",
    ".......K334443g44443g33r333ggrK...",   # y60
    ".......K334443g44443g4444444ggrK..",
    "......K3344443g44443g4444444ggrK..",
    "......K3344443g44443g4444444ggrK..",
    ".....K33444443g44443g4444444gmmK..",
    ".....K33444443g44443g444444mmKKK..",   # y65
    "....K334444443g44443g4444mmKK.....",
    "....K334444443g44443g44mmKK.......",
    "....K334444443g44443gmmKK.........",
    "...K3344444443g4444mmKK...........",
    "...K3344444443g44mmKK.............",   # y70
    "...K3344444443gmmKK...............",
    "..K3344444444mmKK.................",
    "..K33444444amKK...................",
    "..K334444aaKK.....................",
    ".K33444aaKK.......................",   # y75
    ".KaaaaaKK.........................",
    ".KKKKKK...........................",
])

layer("front-arm-sword", 46, 35, [
    "...KKKKKKKK.............................................",   # y35 shoulder
    "..K34444gggK............................................",
    "..K334444ggK............................................",
    "..K334444ggK............................................",
    "..K334444g4K............................................",
    "..K33444g44K............................................",   # y40
    "..K33444gg4K............................................",
    "..K334444g4K............................................",
    "..K334444ggK............................................",
    "..K3344444gK............................................",
    "..KmmrrrrrrK............................................",   # y45 copper cuff
    "...K9eeeoeK.............................................",
    "...K9eeeeeoK............................................",
    "....K8aabbbK............................................",
    "....K88aabbbK.KKKK.KKK..................................",   # y49 fist top, guard top
    ".....K88aabbKkiiiKKrK...................................",   # y50
    "......K88aaKnkiiiiKrK...................................",
    ".......K8aaKnkkikiKmrKK.................................",   # y52 blade begins x67
    "........K88KnnkkkkKmuPPKK...............................",
    ".........KKKKnnnnKKmrLLPPKK.............................",
    "............KKKK..KmrvvLLPPKK...........................",   # y55
    "..................KmrKKvvLLPPKK.........................",
    "..................KmrK..KKvvLLPPKK......................",
    "..................KKKK....KKvvLLPPKK....................",
    "............................KKvvLLPPKK..................",
    "..............................KKvvLLPPKK................",   # y60
    "................................KKvvLLPPKK..............",
    "..................................KKvvLLPPKK............",
    "....................................KKvvLLPPKK..........",
    "......................................KKvvLLPKK.........",
    "........................................KKvvLPK.........",   # y65
    "..........................................KKvLK.........",
    "............................................KKK.........",
])

layer("scarf-neck", 43, 33, [
    "....KKKKKKKKKKKK......",   # y33
    "...Kd77777777uu7K.....",
    "..Kdd777777777u77K....",
    ".Kjdd77dddd77777uK....",
    ".Kjjdd7777dd777u7K....",
    "..Kjjddddddd7Kd77u7K..",   # y38 knot
    "...KKKKKKKKKKKd777uK..",
    ".............Kjd77uK..",
    ".............Kjd7uK...",
    "..............Kd7uK...",   # y42 front tail
    "..............Kd77K...",
    "..............Kd7uK...",
    "..............Kjd7K...",
    "...............KdK....",
    "...............KjK....",
    "................K.....",   # y48
])

layer("ponytail", 26, 5, [
    "............KKKKK.......",   # y5
    "..........KKCBBBCKK.....",
    "........KKHHCCBBBCCHK...",
    ".......KHHHHHCCCCCHHHK..",
    "......KYHHHHHHHHHHCCHHK.",
    ".....KYYHHHHYYYYHHHCCHHK",   # y10
    "....KYYHHHHYK...KYHHCHH.",
    "....KZYHHHHYK.....KYHHHH",
    "...KZYHHHHYK............",
    "...KZYHHHHCK............",
    "..KZYYHHHHCK............",   # y15
    "..KZYHHHHCHK............",
    "..KZYHHHHCK.............",
    "..KZYYHHHCK.............",
    "..KZYHHHCHK.............",
    "..KZZYHHHCK.............",   # y20
    "..KZYYHHCK..............",
    "..KZYHHHCK..............",
    "..KZZYHHCK..............",
    "..KZYKYHCK..............",
    "..KZK.KYCK..............",   # y25
    "..KK..KYK...............",
    "......KK................",
])

layer("head", 0, 10, [
    (50, "KKKKKK"),                              # y10
    (48, "KKHCBBBCKK"),
    (47, "KHHCBBBBBCHK"),
    (46, "KYHHCCBBBBCCHK"),
    (45, "KYYHHHZCCBBBCCHK"),                    # y14 clump groove starts (Z)
    (45, "KYYHHZCHCCBBCCHHK"),                   # y15
    (44, "KZYYHHZCHHHCCBBCHHK"),
    (44, "KZYYHZCHHHHHCCBCHHHK"),
    (43, "KZZYYHZCHHYHHHHCCBCHHK"),
    (42, "KZZYYHHZCHHYHHHHHHCCHHHK"),
    (42, "KZZYYHZCHHYYHCHHYHHHCHHHK"),           # y20
    (42, "KZZYYHZCHHYYHCkHiiYHiiHHK"),           # y21 fringe tips
    (42, "KZZYYHZCHHYYHCkYiiiYiiiiK"),
    (42, "KZZYYHZCHHYYHCkiiYYYiiiiK"),           # y23 brow
    (41, "KZZZYYZCHHHYYHCkiiKKKiiiiK"),          # y24 lash
    (41, "KZZZYYZCHHYYYHCkiiiKOiiiiK"),          # y25 eye
    (41, "KZZZYYZHHHYYYHCkiiiKKiiiiiK"),         # y26 nose
    (42, "KZZYYZHHYYYYHCnkkiiiiiiikK"),
    (43, "KZYYZHYYYYYHCnkkiiiiiiK"),
    (43, "KZYYZYYHYYYHCnkkiiiiwiK"),             # y29 mouth
    (43, "KZZYZYYHYZYHCnnkkiiiiK"),              # y30
    (44, "KZYZYHYYZYHCnnkkiiiK"),
    (44, "KZZYYYHYZYHCnnnkkK"),
    (45, "KZZYZYYHZYKKKKKK"),                    # y33 chin
    (45, "KZKZYKYYKYK"),                         # y34 hair tips over the scarf
    (46, "K.KK.KK.K"),
])

LAYER_NAMES = [n for n, *_ in LAYERS] + ["guides"]


# ============================================================================ raster
def hex_rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def layer_rgba(name, ox, oy, rows):
    a = np.zeros((H, W, 4), np.uint8)
    for r, row in enumerate(rows):
        x0, row = row if isinstance(row, tuple) else (ox, row)
        for c, ch in enumerate(row):
            if ch == ".":
                continue
            if ch not in PALETTE:
                raise SystemExit(f"{name}: unknown palette key {ch!r} at row {r} col {c}")
            x, y = x0 + c, oy + r
            if not (0 <= x < W and 0 <= y < H):
                raise SystemExit(f"{name}: texel ({x},{y}) outside the {W}x{H} cell")
            a[y, x, :3] = hex_rgb(PALETTE[ch])
            a[y, x, 3] = 255
    return a


def guides_rgba(comp):
    g = np.zeros((H, W, 4), np.uint8)
    pts = set()
    pts.update((x, 0) for x in range(W)); pts.update((x, H - 1) for x in range(W))
    pts.update((0, y) for y in range(H)); pts.update((W - 1, y) for y in range(H))
    for y in BODY_ROWS:
        pts.update((x, y) for x in list(range(1, 7)) + list(range(W - 7, W - 1)))
    pts.add(PIN)
    for x, y in pts:
        g[y, x, :3] = GUIDE_RGB
        g[y, x, 3] = 255
    if (comp[..., 3][g[..., 3] > 0] != 0).any():
        raise SystemExit("a guide texel overlaps an opaque art texel")
    return g


def render():
    """Returns ({layer name: RGBA}, composite RGBA). Alpha is binary, so 'over' is a plain copy."""
    blobs = {}
    comp = np.zeros((H, W, 4), np.uint8)
    for name, ox, oy, rows in LAYERS:
        a = layer_rgba(name, ox, oy, rows)
        blobs[name] = a
        m = a[..., 3] == 255
        comp[m] = a[m]
    blobs["guides"] = guides_rgba(comp)
    return blobs, comp


def png_bytes(rgba):
    buf = io.BytesIO()
    Image.fromarray(rgba, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


# ============================================================================ paths / hashes
WIN_MAX_PATH = 259
WIN_LONG_PREFIX = "\\\\?\\"


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > WIN_MAX_PATH - 12 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def repo_path(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(path):
    with open(_fs(path), "rb") as f:
        return f.read()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def text_sha256_lf(data):
    return hashlib.sha256(data.replace(b"\r\n", b"\n")).hexdigest()


def inputs_checked():
    v8 = read_bytes(repo_path(V8_REL))
    if sha256_bytes(v8) != V8_SHA256:
        raise SystemExit("v8 source hash mismatch; refusing to run")
    v8a = np.array(Image.open(io.BytesIO(v8)).convert("RGBA"))
    old = np.array(Image.open(_fs(repo_path(OLD_REL))).convert("RGBA"))
    return v8a, old


def v8_palette(v8a):
    m = v8a[..., 3] > 0
    return {"#%02x%02x%02x" % tuple(int(c) for c in px) for px in v8a[m][:, :3]}


# ============================================================================ preview sheets
def on_bg(rgba, bg, scale):
    im = Image.new("RGBA", (rgba.shape[1], rgba.shape[0]), bg + (255,))
    im.alpha_composite(Image.fromarray(rgba, "RGBA"))
    return im.resize((im.width * scale, im.height * scale), Image.NEAREST)


def sheet(v8a, old, comp, scale=5):
    """v8 | old prototype | candidate at the same zoom, each on a mid grey and a warm floor tone."""
    panels = []
    for bg in [(74, 78, 86), (150, 132, 108)]:
        for a in (v8a, old, comp):
            panels.append(on_bg(a, bg, scale))
    pad = 8
    cw = max(p.width for p in panels)
    ch = max(p.height for p in panels)
    out = Image.new("RGBA", (3 * cw + 4 * pad, 2 * ch + 3 * pad), (24, 26, 30, 255))
    for i, p in enumerate(panels):
        r, c = divmod(i, 3)
        out.paste(p, (pad + c * (cw + pad), pad + r * (ch + pad) + (ch - p.height)))
    return out


def preview(out_dir):
    v8a, old = inputs_checked()
    blobs, comp = render()
    os.makedirs(out_dir, exist_ok=True)
    Image.fromarray(comp, "RGBA").save(os.path.join(out_dir, "candidate_1x.png"))
    on_bg(comp, (74, 78, 86), 6).save(os.path.join(out_dir, "candidate_x6.png"))
    sheet(v8a, old, comp).save(os.path.join(out_dir, "compare_x5.png"))
    # 1x / display-size check: logical 48 px => node scale 0.5 => 1 texel per screen pixel at 1280x720
    on_bg(comp, (74, 78, 86), 2).save(os.path.join(out_dir, "candidate_x2.png"))
    print(stats(comp, v8a))


def stats(comp, v8a):
    m = comp[..., 3] > 0
    ys, xs = np.nonzero(m)
    cols = {"#%02x%02x%02x" % tuple(int(c) for c in px) for px in comp[m][:, :3]}
    return {"opaque_texels": int(m.sum()), "colours": len(cols),
            "colours_outside_v8": sorted(cols - v8_palette(v8a)),
            "alpha_values": sorted({int(v) for v in np.unique(comp[..., 3])}),
            "alpha_bounds_inclusive": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
            "body_rows": [int(ys.min()), int(ys.max())], "body_height_texels": int(ys.max() - ys.min() + 1)}


def isolated_texels(comp):
    """Opaque non-line texels whose 4 opaque neighbours all differ from them (single-pixel noise)."""
    rgb = comp[..., :3].astype(np.int32)
    key = (rgb[..., 0] << 16) | (rgb[..., 1] << 8) | rgb[..., 2]
    op = comp[..., 3] > 0
    line = key == int(PALETTE["K"][1:], 16)
    n = 0
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            if not op[y, x] or line[y, x]:
                continue
            same = any(op[y + dy, x + dx] and key[y + dy, x + dx] == key[y, x]
                       for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
            if not same:
                n += 1
    return n


def silhouette_line_share(comp):
    """Share of opaque texels touching transparency (4-neighbour) that are the line colour."""
    op = comp[..., 3] > 0
    pad = np.pad(op, 1)
    edge = op & ~(pad[:-2, 1:-1] & pad[2:, 1:-1] & pad[1:-1, :-2] & pad[1:-1, 2:])
    line = (comp[..., 0] == 0x0a) & (comp[..., 1] == 0x0a) & (comp[..., 2] == 0x0e)
    return int((edge & line).sum()), int(edge.sum())


# ============================================================================ editable files
def make_pxo(png, blobs):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in LAYER_NAMES]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYER_NAMES], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps("sideview-battle-idle-right-unapproved-v01"),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": len(LAYER_NAMES) - 2,
            "export_profile": export_profile, "fps": 6.0, "frames": frames_json, "guides": [],
            "layers": layer_json, "license": "", "metadata": {}, "next_keyframe_id": 0, "palettes": [],
            "pixelorama_version": PIXELORAMA_VERSION, "project_current_palette_name": "", "pxo_version": 7,
            "reference_images": [], "size_x": W, "size_y": H, "symmetry_points": [W - 1.0, H - 1.0], "tags": [],
            "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0, "tile_mode_y_basis_x": 0,
            "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "", "vanishing_points": []}
    buf = io.BytesIO()
    dt = (2026, 10, 15, 19, 49, 36)     # fixed (zip needs even seconds) -> byte-identical rebuilds
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def put(name, payload):
            z.writestr(zipfile.ZipInfo(name, dt), payload, zipfile.ZIP_DEFLATED)
        put("data.json", json.dumps(data, separators=(",", ":")))
        put("mimetype", "application/x-pixelorama")
        put("preview.png", png)
        put("image_data/frames/1/", b"")
        for li, name in enumerate(LAYER_NAMES, start=1):
            put(f"image_data/frames/1/layer_{li}", np.ascontiguousarray(blobs[name]).tobytes())
            put(f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_ora(png, blobs):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.3" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for name in reversed(LAYER_NAMES):                      # ORA lists the top layer first
        vis = "hidden" if name == "guides" else "visible"
        stack.append(f'<layer name="{name}" src="data/{name}.png" x="0" y="0" opacity="1.0" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>"]
    thumb = Image.fromarray(render()[1], "RGBA")
    tb = io.BytesIO(); thumb.save(tb, "PNG", optimize=False, compress_level=9)
    buf = io.BytesIO()
    dt = (2026, 10, 15, 19, 49, 36)
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype", dt), "image/openraster", zipfile.ZIP_STORED)
        z.writestr(zipfile.ZipInfo("stack.xml", dt), "\n".join(stack) + "\n", zipfile.ZIP_DEFLATED)
        for name in LAYER_NAMES:
            z.writestr(zipfile.ZipInfo(f"data/{name}.png", dt), png_bytes(blobs[name]), zipfile.ZIP_DEFLATED)
        z.writestr(zipfile.ZipInfo("mergedimage.png", dt), png, zipfile.ZIP_DEFLATED)
        z.writestr(zipfile.ZipInfo("Thumbnails/thumbnail.png", dt), tb.getvalue(), zipfile.ZIP_DEFLATED)
    return buf.getvalue()


LAYER_NOTES = {
    "back-leg": "far (left) leg: spruce trouser shin and boot, darker shading",
    "scarf-tail": "long teal scarf tail hanging behind the coat (only the part below the pack shows)",
    "backpack": "brown leather pack with buckle and the teal bedroll end (spiral)",
    "front-leg": "near (right) leg: bent knee, thigh holster with teal light and strap, boot",
    "body-coat": "storm-slate coat torso + skirt with copper lapel/hem trim, cream shirt strip, leather belt "
                 "and buckle, pocket flap",
    "front-arm-sword": "near arm (slate sleeve, copper cuff, rolled cream sleeve, leather bracer), fist and the "
                       "short sword (copper guard, teal stone, 2:1 blade)",
    "scarf-neck": "teal scarf neck wrap, knot and short front tail",
    "ponytail": "high ponytail arcing up and back",
    "head": "head: clumped brown hair with crown highlight, fringe, side lock, face (eye, nose, mouth)",
    "guides": f"hidden + locked #ff00ff: cell border, ticks on rows {BODY_ROWS[0]} and {BODY_ROWS[1]}, pin {list(PIN)}",
}


def make_manifest(png, pxo, ora, comp, blobs, v8a):
    st = stats(comp, v8a)
    il, ie = silhouette_line_share(comp)
    m = {
        "project": "Worlds Between",
        "project_slug": SLUG,
        "milestone": "M8",
        "visual_id": "protagonist-female",
        "asset": "side-view battle idle, facing right, single static frame",
        "status": "UNAPPROVED test-only candidate; not runtime-integrated; no animation",
        "art_approved": False,
        "human_reviewed": False,
        "runtime_integrated": False,
        "game_bible_or_acceptance_counters_changed": False,
        "animation_frames": 0,
        "replaces_nothing": "The rough combat prototype frames and the v8 south static are unchanged and still "
                            "the only files the runtime or the approval record point at.",
        "authorship": "Every texel is hand-placed in ASCII row maps in the author tool, written and run by "
                      "Claude (Claude Code). No AI image generation, upscaling, resampling, filtering, "
                      "quantizing or dithering.",
        "identity_baseline": {
            "file": V8_REL, "sha256": V8_SHA256, "hash_algorithm": "sha256-bytes",
            "editable": V8_PXO_REL, "editable_sha256": V8_PXO_SHA256,
            "use": "palette (every candidate colour is one of v8's 32) and identity cues: storm-slate coat with "
                   "copper trim, cream shirt, teal scarf + bedroll, brown hair with high ponytail, spruce "
                   "trousers, leather belt/boots with cream straps, thigh holster with teal light",
        },
        "replaced_placeholder_for_comparison_only": {"file": OLD_REL, "sha256": OLD_SHA256,
                                                     "note": "unaccepted rough prototype; read for the "
                                                             "comparison sheet only"},
        "cell": {"w": W, "h": H, "pin": list(PIN), "pin_meaning": "ground contact; first transparent row "
                 "under the soles, horizontally under the hips", "display_scale": 0.5,
                 "display_note": "authored at 2x logical density like v8: drawn at node scale 0.5 in the "
                                 "640x360 canvas, 1 texel = 1 screen pixel at 1280x720",
                 "filter": "nearest", "alpha": "binary", **st,
                 "head_crown_to_sole_texels": 103 - 10 + 1,
                 "head_crown_to_sole_logical_px": (103 - 10 + 1) / 2,
                 "with_ponytail_logical_px": st["body_height_texels"] / 2,
                 "v8_reference_body_rows": [8, 103]},
        "quality_metrics": {"isolated_single_texels": isolated_texels(comp),
                            "silhouette_edge_texels": ie, "silhouette_edge_line_colour": il},
        "palette": {k: v for k, v in PALETTE.items()},
        "files": {
            "png": {"file": f"{OUT_DIR_REL}/{PNG_NAME}", "sha256": sha256_bytes(png), "hash_algorithm": "sha256-bytes"},
            "pxo": {"file": f"{OUT_DIR_REL}/{PXO_NAME}", "sha256": sha256_bytes(pxo), "hash_algorithm": "sha256-bytes",
                    "format": f"Pixelorama pxo_version 7 ({PIXELORAMA_VERSION}), color_mode 5 (RGBA8), 1 frame x "
                              f"{len(LAYER_NAMES)} layers, fixed zip timestamps"},
            "ora": {"file": f"{OUT_DIR_REL}/{ORA_NAME}", "sha256": sha256_bytes(ora), "hash_algorithm": "sha256-bytes",
                    "format": "OpenRaster 0.0.3, one PNG per layer, guides hidden"},
        },
        "layers_bottom_to_top": [
            {"name": n, "visible": n != "guides", "locked": n == "guides",
             "opaque_texels": int((blobs[n][..., 3] > 0).sum()), "content": LAYER_NOTES[n]} for n in LAYER_NAMES],
        "tool": {"file": TOOL_REL, "sha256": text_sha256_lf(read_bytes(os.path.abspath(__file__))),
                 "hash_algorithm": "sha256-text-lf-v1", "python": sys.version.split()[0],
                 "pillow": Image.__version__, "numpy": np.__version__, "run_flags": "-I -B"},
        "checks": {"command": f"python -I -B {TOOL_REL} check",
                   "result": "see the QA/report output; this manifest is written before the check runs"},
        "battle_capture": "outputs/ (see the capture manifest written by the Godot test-only capture script)",
    }
    return (json.dumps(m, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def source_locks():
    got = {V8_REL: sha256_bytes(read_bytes(repo_path(V8_REL))),
           V8_PXO_REL: sha256_bytes(read_bytes(repo_path(V8_PXO_REL))),
           OLD_REL: sha256_bytes(read_bytes(repo_path(OLD_REL)))}
    want = {V8_REL: V8_SHA256, V8_PXO_REL: V8_PXO_SHA256, OLD_REL: OLD_SHA256}
    return {k: {"sha256": got[k], "unchanged": got[k] == want[k]} for k in got}


def build():
    locks = source_locks()
    if not all(v["unchanged"] for v in locks.values()):
        raise SystemExit(f"read-only source changed: {locks}")
    v8a, _ = inputs_checked()
    blobs, comp = render()
    st = stats(comp, v8a)
    if st["colours_outside_v8"] or st["alpha_values"] != [0, 255]:
        raise SystemExit(f"palette/alpha gate failed: {st}")
    png = png_bytes(comp)
    pxo, ora = make_pxo(png, blobs), make_ora(png, blobs)
    if make_pxo(png, blobs) != pxo or make_ora(png, blobs) != ora:
        raise SystemExit("editable build is not deterministic")
    out = repo_path(OUT_DIR_REL)
    os.makedirs(_fs(out), exist_ok=True)
    for name, data in ((PNG_NAME, png), (PXO_NAME, pxo), (ORA_NAME, ora),
                       (MANIFEST_NAME, make_manifest(png, pxo, ora, comp, blobs, v8a))):
        print(write_new(os.path.join(out, name), data), f"{OUT_DIR_REL}/{name}", sha256_bytes(data))
    if not all(v["unchanged"] for v in source_locks().values()):
        raise SystemExit("a read-only source changed during build")


# ============================================================================ check
def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


def appdata_snapshot():
    root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    snap = {}
    if os.path.isdir(root):
        for d, _, files in os.walk(root):
            for f in files:
                p = os.path.join(d, f)
                rel = os.path.relpath(p, root).replace("\\", "/")
                if rel == ".running":          # the open GUI's 15 s heartbeat; not ours
                    continue
                try:
                    snap[rel] = sha256_bytes(read_bytes(p))
                except OSError:
                    snap[rel] = "unreadable"
    return snap


def pixelorama_export(exe, src, out_dir, split):
    """Headless export with APPDATA redirected to a fresh temp dir (never touches the real config)."""
    env = dict(os.environ)
    env["APPDATA"] = tempfile.mkdtemp(prefix="wb-pxappdata-")
    args = [exe, "--headless", "--quit", "--", "--export"] + (["--split-layers"] if split else []) + \
           ["-o", os.path.join(out_dir, "f.png"), src]
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=240, env=env)
    finally:
        shutil.rmtree(env["APPDATA"], ignore_errors=True)
    files = sorted(f for f in os.listdir(out_dir) if f.lower().endswith(".png"))
    return p.returncode, {f: decode(read_bytes(os.path.join(out_dir, f)))[2] for f in files}


def check(exe):
    report = {"result": None, "status": "UNAPPROVED test-only candidate", "source_locks_before": source_locks()}
    v8a, _ = inputs_checked()
    blobs, comp = render()
    out = repo_path(OUT_DIR_REL)
    png = read_bytes(os.path.join(out, PNG_NAME))
    pxo = read_bytes(os.path.join(out, PXO_NAME))
    ora = read_bytes(os.path.join(out, ORA_NAME))
    man = json.loads(read_bytes(os.path.join(out, MANIFEST_NAME)))
    mode, size, a = decode(png)
    st = stats(a, v8a)
    il, ie = silhouette_line_share(a)
    ys = np.nonzero(a[..., 3] > 0)[0]
    feet_row = a[103]
    g = {
        "png_rgba_112x112": mode == "RGBA" and size == (W, H),
        "png_equals_tool_render": a.tobytes() == comp.tobytes(),
        "binary_alpha": st["alpha_values"] == [0, 255],
        "palette_subset_of_v8": not st["colours_outside_v8"],
        "colours_le_32": st["colours"] <= 32,
        "sole_on_row_103_pin_row_104_empty": int(ys.max()) == 103 and not (a[104:, :, 3] > 0).any(),
        "both_boots_touch_row_103": bool((feet_row[30:52, 3] > 0).any() and (feet_row[52:80, 3] > 0).any()),
        "pin_texel_transparent": a[PIN[1], PIN[0], 3] == 0,
        "head_crown_to_sole_94_texels_eq_47_logical": int(np.nonzero(a[:, 50:70, 3].any(axis=1))[0].min()) == 10,  # x>=50 excludes the ponytail
        "manifest_hashes_match": (man["files"]["png"]["sha256"] == sha256_bytes(png)
                                  and man["files"]["pxo"]["sha256"] == sha256_bytes(pxo)
                                  and man["files"]["ora"]["sha256"] == sha256_bytes(ora)),
        "manifest_unapproved_flags": (man["art_approved"] is False and man["runtime_integrated"] is False
                                      and man["game_bible_or_acceptance_counters_changed"] is False),
        "rebuild_byte_identical": png_bytes(comp) == png and make_pxo(png, blobs) == pxo and make_ora(png, blobs) == ora,
    }
    with zipfile.ZipFile(io.BytesIO(pxo)) as z:
        data = json.loads(z.read("data.json"))
        names = [l["name"] for l in data["layers"]]
        g["pxo_layers_match"] = names == LAYER_NAMES and all(
            z.read(f"image_data/frames/1/layer_{i + 1}") == blobs[n].tobytes() for i, n in enumerate(names))
    with zipfile.ZipFile(io.BytesIO(ora)) as z:
        g["ora_mimetype_first_stored"] = z.infolist()[0].filename == "mimetype" and z.infolist()[0].compress_type == 0
        g["ora_layers_match"] = all(decode(z.read(f"data/{n}.png"))[2].tobytes() == blobs[n].tobytes()
                                    for n in LAYER_NAMES)
        g["ora_merged_equals_png"] = z.read("mergedimage.png") == png
    over = np.zeros((H, W, 4), np.uint8)
    for n in LAYER_NAMES[:-1]:
        m = blobs[n][..., 3] == 255
        over[m] = blobs[n][m]
    g["visible_layers_composite_to_png"] = over.tobytes() == a.tobytes()
    report["metrics"] = {**st, "isolated_single_texels": isolated_texels(a),
                         "silhouette_edge_line_share": f"{il}/{ie}"}
    if exe:
        snap0 = appdata_snapshot()
        tmp = tempfile.mkdtemp(prefix="wb-svcheck-")
        px = {}
        try:
            for kind, data_ in (("pxo", pxo), ("ora", ora)):
                src = os.path.join(tmp, f"cand.{kind}")
                with open(src, "wb") as f:
                    f.write(data_)
                for split in (False, True):
                    od = os.path.join(tmp, f"{kind}-{'split' if split else 'flat'}")
                    os.makedirs(od)
                    rc, outs = pixelorama_export(exe, src, od, split)
                    key = f"{kind}_{'split' if split else 'flat'}"
                    if split:
                        want = {n: blobs[n].tobytes() for n in LAYER_NAMES[:-1]}
                        matched = {n for n, b in want.items() if any(o.tobytes() == b for o in outs.values())}
                        guide_leak = any(o.tobytes() == blobs["guides"].tobytes() for o in outs.values())
                        px[key] = {"exit": rc, "pngs": len(outs), "visible_layers_matched": len(matched),
                                   "visible_layers": len(want), "guides_exported": guide_leak,
                                   "pass": rc == 0 and len(matched) == len(want) and not guide_leak
                                   and len(outs) == len(want)}
                    else:
                        ok = rc == 0 and len(outs) == 1 and next(iter(outs.values())).tobytes() == a.tobytes()
                        px[key] = {"exit": rc, "pngs": len(outs), "rgba_equals_png": ok, "pass": ok}
                    with open(src, "rb") as f:
                        px[key]["input_copy_unchanged"] = f.read() == data_
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        snap1 = appdata_snapshot()
        px["real_appdata_pixelorama_untouched_except_heartbeat"] = snap0 == snap1
        report["pixelorama_1_2_3_headless"] = px
        g["pixelorama_roundtrip"] = all(v["pass"] for k, v in px.items() if isinstance(v, dict)) and snap0 == snap1
    report["source_locks_after"] = source_locks()
    g["read_only_sources_unchanged"] = all(v["unchanged"] for v in report["source_locks_after"].values())
    report["gates"] = g
    report["result"] = "PASS" if all(g.values()) else "FAIL"
    print(json.dumps(report, indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    return 0 if report["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("out", nargs="?")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--pixelorama", default=repo_path(PIXELORAMA_REL))
    args = ap.parse_args()
    if args.mode == "preview":
        if not args.out:
            raise SystemExit("preview needs an output dir outside the repo")
        preview(args.out)
        return 0
    if args.mode == "build":
        build()
        return 0
    exe = None if args.no_pixelorama else os.path.abspath(args.pixelorama)
    if exe and not os.path.isfile(exe):
        raise SystemExit(f"Pixelorama not found: {exe}")
    return check(exe)


if __name__ == "__main__":
    sys.exit(main())
