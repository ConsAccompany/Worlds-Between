extends SceneTree
# NORTH v04 source-bound pose bake + small 30/60 Hz contact/endpoint tests (test only).
# Contact measure is unchanged from v02/v03: in every frame the static heel block of each boot (boots-layer
# texels, rows sole-3..sole of that leg, taken from the static PNG) is searched as an exact RGBA template
# in the rendered 80x128 cell. Its bottom row is the heel-cap underside; world Y of that edge =
# renderY + (row + 1 - 104) * 0.5. Every frame the model calls grounded must contain exactly one exact
# match, and each continuous grounded interval (all frames, boundaries included) must keep the edge
# within 1 world px. v04 additions: explicit peel, airborne honesty, stance coverage/minimum samples,
# segment proportions, width bound, quick re-press, and the v03 ease-out check carried unchanged.
# Usage: -s <this> -- <new folder> <stamp-id> <report path>
const MODEL_PATH := "res://../tools/rpg-2-star-ocean-the-second_female-north_run-stop-source_unapproved-v04_20261018-215034-17f6bb42.gd"
const V03_PATH := "res://../tools/rpg-2-star-ocean-the-second_female-north_run-stop-source_unapproved-v03_20261018-212210-26c19e30.gd"
const STATIC_PNG := "res://assets/characters/protagonist-female/north-idle-static-pilot-unapproved-v01/rpg-2-star-ocean-the-second_protagonist-female_north-idle-static-pilot_unapproved-v01_20261018-090713-6ed8d8dd.png"
const CORE := [[26,39],[42,54]]
const SOLE := [103,102]
const BEHIND_CAP := 7
var checks := []
func _initialize() -> void:call_deferred("_run")
func _check(key: String,ok: bool,detail: Variant=null) -> void:
	var c:={"key":key,"pass":ok}
	if detail!=null:c["detail"]=detail
	checks.append(c)
func _templates(boots: Image) -> Array:
	var out:=[]
	for leg in 2:
		var t:=[]
		for y in range(SOLE[leg]-3,SOLE[leg]+1):
			for x in range(CORE[leg][0],CORE[leg][1]+1):
				var c:=boots.get_pixel(x,y)
				if c.a8>0:t.append([x,y-SOLE[leg],c])
		out.append(t)
	return out
# Exact template matches of a leg's heel block: returns [[bottomRow, dx], ...].
func _find(image: Image,template: Array) -> Array:
	var hits:=[]
	for bottom in range(60,image.get_height()):
		for dx in range(-2,3):
			var ok:=true
			for t: Array in template:
				var x: int=t[0]+dx
				var y: int=bottom+t[1]
				if y<0 or y>=image.get_height() or image.get_pixel(x,y)!=t[2]:ok=false;break
			if ok:hits.append([bottom,dx])
	return hits
func _diff_count(a: Image,b: Image) -> int:
	var n:=0
	for y in a.get_height():
		for x in a.get_width():
			if a.get_pixel(x,y)!=b.get_pixel(x,y):n+=1
	return n
# Opaque width of one leg's legs+boots roles per row.
func _leg_widths(roles: Dictionary,leg: int,y0: int,y1: int) -> Array:
	var out:=[]
	for y in range(y0,y1+1):
		var x0:=-1
		var x1:=-1
		for x in 80:
			if (x<41)!=(leg==0):continue
			if roles.legs.get_pixel(x,y).a8>0 or roles.boots.get_pixel(x,y).a8>0:
				if x0<0:x0=x
				x1=x
		out.append(0 if x0<0 else x1-x0+1)
	return out
# Opaque width per row of one leg's own drawn trousers+boot images (no column split, so a swing leg
# shifted medially across x=41 is not merged with the other leg).
func _own_widths(pair: Dictionary,y0: int,y1: int) -> Array:
	var out:=[]
	for y in range(y0,y1+1):
		var x0:=-1
		var x1:=-1
		for x in 80:
			if pair.trousers.get_pixel(x,y).a8>0 or pair.boot.get_pixel(x,y).a8>0:
				if x0<0:x0=x
				x1=x
		out.append(0 if x0<0 else x1-x0+1)
	return out
func _alpha_binary(image: Image) -> bool:
	for y in image.get_height():
		for x in image.get_width():
			var a:=image.get_pixel(x,y).a8
			if a!=0 and a!=255:return false
	return true
func _palette(image: Image) -> Dictionary:
	var out:={}
	for y in image.get_height():
		for x in image.get_width():
			var c:=image.get_pixel(x,y)
			if c.a8>0:out[c.to_html(false)]=true
	return out
func _ser(state: Dictionary) -> Dictionary:
	var s:=state.duplicate(true)
	s.body=[s.body.x,s.body.y]
	return s
# Ordinary-input schedule at a fixed rate: idle, run, release, re-press, release, then a quick tap
# (release for ~1-2 frames during the run and press again) and a final release.
const SEGMENTS := [["idle",.10,0],["run",1.20,1],["stop",.40,0],["repress",.60,1],["final-stop",.40,0],["tap-run",.50,1],["quick-stop",.05,0],["quick-repress",.50,1],["end-stop",.40,0]]
func _simulate(model: RefCounted,fps: int,start_y: float,templates: Array,original: Image) -> Dictionary:
	model.physical_y=start_y
	model.render_y=roundf(start_y*2.)*.5
	var y:=start_y
	var frames:=[]
	var tick:=0
	for seg: Array in SEGMENTS:
		for f in maxi(1,roundi(seg[1]*fps)):
			if seg[2]>0:y-=140./fps
			var state: Dictionary=model.advance(1./fps,y,float(seg[2]))
			var rendered: Dictionary=model.render_pose(state)
			var image: Image=rendered.full
			var near:=[0.,0.]
			var legs:=[]
			if rendered.has("legs"):
				near=[rendered.legs[0].near,rendered.legs[1].near]
				legs=rendered.legs
			var measured:=[]
			for leg in 2:
				var hits:=_find(image,templates[leg])
				measured.append({"hits":hits,"worldY":(state.renderY+(float(hits[0][0])+1.-104.)*.5) if hits.size()==1 else null,"col":hits[0][1] if hits.size()==1 else null})
			frames.append({"tick":tick,"segment":seg[0],"state":state,"measured":measured,"isStatic":image.get_data()==original.get_data(),"image":image,"near":near,"legs":legs,"diffToStatic":_diff_count(image,original)})
			tick+=1
	return {"fps":fps,"startY":start_y,"frames":frames}
func _contact_segments(run: Dictionary) -> Array:
	var out:=[]
	for leg in 2:
		var current:=[]
		var k:=0
		for fr in run.frames+[null]:
			var grounded: bool=fr!=null and fr.state.mode!="idle" and fr.state.feet[leg].ground
			if grounded:current.append(fr)
			elif current.size()>0:
				var ys:=[]
				var cols:=[]
				var missing:=0
				for g: Dictionary in current:
					var m: Dictionary=g.measured[leg]
					if m.worldY==null:missing+=1;continue
					ys.append(m.worldY)
					cols.append(m.col)
				var travel: float=(ys.max()-ys.min()) if ys.size()>0 else INF
				var phases:=[]
				for g: Dictionary in current:phases.append(g.state.feet[leg].phase)
				# The frame right after the interval (first airborne frame) for the peel/lift check.
				var after: Variant=fr
				out.append({"leg":leg,"firstTick":current[0].tick,"lastTick":current[-1].tick,"frames":current.size(),"segments":current.map(func(g):return g.segment),"mode":current.map(func(g):return g.state.mode),"stancePhases":phases,"missingMatches":missing,"heelCapWorldY":ys,"heelCapTravelWorldPx":travel,"lateralShiftCols":cols,"after":after,"lastWorldY":ys[-1] if ys.size()>0 else null})
				current=[]
			k+=1
	return out
func _run() -> void:
	var args:=OS.get_cmdline_user_args()
	var folder: String=args[0]
	var tag: String=args[1]
	var report_path: String=args[2]
	DirAccess.make_dir_recursive_absolute(folder)
	var model: RefCounted=load(MODEL_PATH).new()
	var static_png:=Image.load_from_file(ProjectSettings.globalize_path(STATIC_PNG))
	static_png.convert(Image.FORMAT_RGBA8)
	var padded:=Image.create(80,128,false,Image.FORMAT_RGBA8)
	padded.blit_rect(static_png,Rect2i(0,0,80,112),Vector2i.ZERO)
	var original: Image=model.original
	var consts: Dictionary=(load(MODEL_PATH) as Script).get_script_constant_map()
	_check("cell-80x128-pivot-40-104-cycle-128",consts.CELL==Vector2i(80,128) and consts.PIVOT==Vector2i(40,104) and consts.CYCLE==128.)
	_check("padded-composite-equals-static-png-top-112-rows-bottom-16-transparent",original.get_data()==padded.get_data())
	var templates:=_templates(padded)
	_check("heel-templates-nonempty",templates[0].size()>=20 and templates[1].size()>=20,[templates[0].size(),templates[1].size()])
	var hits_static:=[_find(padded,templates[0]),_find(padded,templates[1])]
	_check("static-heel-template-unique-at-static-sole",hits_static[0]==[[103,0]] and hits_static[1]==[[102,0]],hits_static)
	var rest_r: Dictionary=model.render_pose({"mode":"run","q":0.,"feet":[model._home(),model._home()],"body":Vector2.ZERO,"live":0.})
	_check("rest-parameters-render-exact-static",rest_r.full.get_data()==original.get_data())
	_check("rest-parameters-identity-leg-map",rest_r.legs[0].identityMap and rest_r.legs[1].identityMap)
	var static_palette:=_palette(padded)
	var static_w:=[_leg_widths({"legs":model.layers.legs,"boots":model.layers.boots},0,75,103).max(),_leg_widths({"legs":model.layers.legs,"boots":model.layers.boots},1,75,102).max()]
	# Steady poses: 280 Hz ticks of exactly one source row (0.5 world px) north.
	var y:=300.
	model.physical_y=y
	model.render_y=y
	var by_q:={}
	for t in 400:
		y-=.5
		var st: Dictionary=model.advance(1./280.,y,1.)
		if t>=128:by_q[int(st.q)]=st
	_check("all-128-phases-reached",by_q.size()==128,by_q.size())
	var alpha_ok:=true
	var palette_ok:=true
	var extra:={}
	var lowest:=0
	var behind_max:=-99
	var air_ok:=true
	var air_bad:=[]
	var stance_law_ok:=true
	var max_shin:=0.
	var max_thigh:=0.
	var min_shin:=9.
	var width_ok:=true
	var width_bad:=[]
	var phase_table:={}
	for qq: int in by_q:
		var st: Dictionary=by_q[qq]
		var r: Dictionary=model.render_pose(st)
		var img: Image=r.full
		alpha_ok=alpha_ok and _alpha_binary(img)
		for c in _palette(img):
			if not static_palette.has(c):palette_ok=false;extra[c]=true
		lowest=maxi(lowest,img.get_used_rect().end.y-1)
		var row:=[]
		for leg in 2:
			var f: Dictionary=st.feet[leg]
			var info: Dictionary=r.legs[leg]
			behind_max=maxi(behind_max,int(info.soleRow)-SOLE[leg])
			if f.ground:
				if absf(f.depth-(consts.MID-f.phase))>.0001 or f.lift!=0. or f.reveal!=0.:stance_law_ok=false
			elif roundi(f.lift)<1 and int(info.patch)<1:
				air_ok=false
				air_bad.append([qq,leg,f.phase])
			max_shin=maxf(max_shin,info.shinRatio)
			max_thigh=maxf(max_thigh,info.thighRatio)
			min_shin=minf(min_shin,info.shinRatio)
			var w: int=_own_widths(r.legImages[leg],75,int(info.soleRow)).max()
			if w>static_w[leg]:width_ok=false;width_bad.append([qq,leg,w])
			row.append({"phase":f.phase,"ground":f.ground,"heelRow":info.soleRow,"kneeRow":info.knee,"thighRatio":snappedf(info.thighRatio,.001),"shinRatio":snappedf(info.shinRatio,.001),"patch":info.patch,"crease":info.kneeCrease})
		phase_table[qq]={"body":[st.body.x,st.body.y],"legs":row}
	_check("all-phases-binary-alpha",alpha_ok)
	_check("all-phases-static-palette-only",palette_ok,extra.keys())
	_check("lowest-opaque-row-inside-128-cell",lowest<=127,lowest)
	_check("stance-law-depth-MID-minus-phase-flat-boot",stance_law_ok)
	_check("stance-window-20-phases-touchdown+12-to-7-behind",consts.STANCE==20. and consts.MID==12.)
	_check("heel-never-more-than-7-rows-below-static-sole-any-phase",behind_max<=BEHIND_CAP,behind_max)
	_check("every-airborne-phase-visibly-off-ground-lift>=1-or-sole-showing",air_ok,air_bad)
	_check("shin-screen-length<=1.20x-static-every-phase",max_shin<=1.2,max_shin)
	_check("thigh-screen-length<=1.20x-static-every-phase",max_thigh<=1.2,max_thigh)
	_check("leg-width-never-exceeds-static-leg-width",width_ok,{"staticMax":static_w,"bad":width_bad})
	# Explicit peel at the first airborne phase (20): heel cap at least 2 rows above where the planted heel
	# would be, at least one sole row shown, knee bent (bend > 0).
	var peel_q: int=int(consts.STANCE)
	var pr: Dictionary=model.render_pose(by_q[peel_q])
	var would_be: int=SOLE[0]-int(consts.MID-float(peel_q))
	_check("phase20-explicit-heel-peel-2-rows-up-sole-showing",int(pr.legs[0].soleRow)<=would_be-2 and int(pr.legs[0].patch)>=1 and float(by_q[peel_q].feet[0].bend)>0.,{"heelRow":pr.legs[0].soleRow,"plantedWouldBe":would_be,"patch":pr.legs[0].patch})
	_check("phase20-heel-template-not-present-at-planted-row",not _find(pr.full,templates[0]).has([would_be,0]))
	# Passing = stance-phase frame where the swing heel is closest in depth to the planted heel.
	var passing_q:=0
	var best:=INF
	for qq in range(0,20):
		var d: float=absf(by_q[qq].feet[1].depth-by_q[qq].feet[0].depth)
		if d<best:best=d;passing_q=qq
	var poses:={"contact":0,"passing":passing_q,"late-stance":19,"peel":20,"peel-b":24,"flight":40}
	var pose_report:={}
	for name: String in poses:
		var st: Dictionary=by_q[poses[name]]
		var r: Dictionary=model.render_pose(st)
		var img: Image=r.full
		var path:=folder.path_join("rpg-2-star-ocean-the-second_female-north-run-%s-native-80x128_unapproved-v04_%s.png"%[name,tag])
		img.save_png(path)
		var w0:=_own_widths(r.legImages[0],75,int(r.legs[0].soleRow))
		pose_report[name]={"q":poses[name],"file":path.get_file(),"sha256":FileAccess.get_sha256(path),"state":_ser(st),"legs":r.legs,"leg0WidthProfileFromRow75":w0,"usedRect":[img.get_used_rect().position.x,img.get_used_rect().position.y,img.get_used_rect().size.x,img.get_used_rect().size.y]}
	_check("flight-pose-both-feet-airborne",not by_q[40].feet[0].ground and not by_q[40].feet[1].ground)
	# Comparison with v03 at the same 'late stance' role (last grounded phase of leg 0).
	var v03m: RefCounted=load(V03_PATH).new()
	var v03_late_state: Dictionary=by_q[19].duplicate(true)
	var v03_late:={"note":"v03 late stance was q37 (heel 18 rows below its static sole); v04 last grounded phase is q19"}
	v03_late["v04HeelRowsBelowStaticSole"]=int(model.render_pose(by_q[19]).legs[0].soleRow)-SOLE[0]
	v03_late["v03HeelRowsBelowStaticSole"]=18
	pose_report["lateStanceVsV03"]=v03_late
	# 30/60 Hz ordinary-input schedules from three sub-pixel start positions.
	var runs:=[]
	var all_segments:=[]
	var coverage:={}
	for fps in [60,30]:
		for start in [300.,300.25,300.1]:
			var m: RefCounted=load(MODEL_PATH).new()
			var run:=_simulate(m,fps,start,templates,original)
			var segs:=_contact_segments(run)
			for s: Dictionary in segs:
				s["fps"]=fps
				s["startY"]=start
			all_segments.append_array(segs)
			var name:="%dhz-start%s"%[fps,str(start)]
			var declared_ok:=true
			var guard_ok:=true
			var air_frames_ok:=true
			var air_frames_bad:=[]
			var prev_body:=0
			for fr: Dictionary in run.frames:
				for leg in 2:
					var m2: Dictionary=fr.measured[leg]
					var f: Dictionary=fr.state.feet[leg]
					if fr.state.mode!="idle" and f.ground and m2.worldY!=null:
						var declared: int=SOLE[leg]-roundi(f.depth)-roundi(f.lift)
						if declared!=m2.hits[0][0]:declared_ok=false
					if fr.state.mode!="idle" and not f.ground and roundi(f.lift)<1 and int(fr.legs[leg].patch)<1:
						air_frames_ok=false
						air_frames_bad.append([fr.tick,leg])
				var by: int=roundi(fr.state.body.y)
				if absi(by-prev_body)>ceili(48./fps-0.000000001):guard_ok=false
				prev_body=by
			_check(name+"-declared-sole-row-equals-raster-heel-cap",declared_ok)
			_check(name+"-rendered-torso-step-within-guard",guard_ok)
			_check(name+"-every-airborne-frame-visibly-off-ground",air_frames_ok,air_frames_bad)
			for stop_name in ["stop","final-stop","end-stop"]:
				var seg: Array=run.frames.filter(func(fr):return fr.segment==stop_name)
				var first:=-1
				for k in seg.size():
					if seg[k].isStatic:first=k;break
				_check(name+"-"+stop_name+"-settles-to-exact-static",first>=0 and seg.slice(first).all(func(fr):return fr.isStatic),{"framesToStatic":first+1,"seconds":float(first+1)/fps})
				_check(name+"-"+stop_name+"-immediate-physical-stop-model-sees-no-motion",seg.all(func(fr):return fr.state.mode!="run"))
			# v03 check carried unchanged: the last two moving frames of each stop use no leg articulation
			# (v04 'near' = foot state differs from the exact home pose), and report the last-frame diff.
			for stop_name in ["stop","final-stop","end-stop"]:
				var moving: Array=run.frames.filter(func(fr):return fr.segment==stop_name and not fr.isStatic)
				var tail: Array=moving.slice(maxi(0,moving.size()-2))
				var eased: bool=tail.all(func(fr):return fr.near[0]==0. and fr.near[1]==0.)
				var last_diff: int=moving[-1].diffToStatic if moving.size()>0 else 0
				var leg_rows_diff:=0
				if moving.size()>0:
					var a: Image=moving[-1].image
					for yy in range(75,128):
						for xx in 80:
							if a.get_pixel(xx,yy)!=original.get_pixel(xx,yy) and (model.layers.legs.get_pixel(xx,yy).a8>0 or model.layers.boots.get_pixel(xx,yy).a8>0 or a.get_pixel(xx,yy).a8>0 and yy>85):leg_rows_diff+=1
				_check(name+"-"+stop_name+"-near-leg-eased-out-before-static",eased,{"tailNear":tail.map(func(fr):return fr.near),"lastMovingFrameDiffTexels":last_diff,"lastMovingFrameLegRegionDiffTexels":leg_rows_diff,"movingFrames":moving.size()})
			var idle_ok: bool=run.frames.filter(func(fr):return fr.segment=="idle").all(func(fr):return fr.isStatic)
			_check(name+"-idle-is-exact-static",idle_ok)
			for press in ["run","repress","tap-run","quick-repress"]:
				var first_run: Dictionary=run.frames.filter(func(fr):return fr.segment==press)[0]
				_check(name+"-"+press+"-first-press-frame-runs-not-static",first_run.state.mode=="run" and not first_run.isStatic)
			var qs: Array=run.frames.filter(func(fr):return fr.segment=="quick-stop")
			_check(name+"-quick-stop-is-a-real-release",qs.size()>=1 and qs.all(func(fr):return fr.state.mode=="stop"),qs.size())
			# Cadence from landings in the first run.
			var landings:=[]
			var rf: Array=run.frames.filter(func(fr):return fr.segment=="run")
			for k in range(1,rf.size()):
				for leg in 2:
					if not rf[k-1].state.feet[leg].ground and rf[k].state.feet[leg].ground:landings.append(rf[k].tick)
			var cadence:=0.
			if landings.size()>=3:cadence=float(landings.size()-1)/(float(landings[-1]-landings[0])/fps)
			_check(name+"-cadence-4.0-4.5",cadence>=4.0 and cadence<=4.5,{"landingTicks":landings,"stepsPerSecond":cadence})
			# Peel after every steady grounded interval: first airborne frame is a visible lift, not a
			# relabelled flat boot (heel cap >= 2 rows above the planted world point or sole showing).
			var peel_ok:=true
			var peel_detail:=[]
			for s: Dictionary in segs:
				var after: Variant=s.after
				if after==null or s.lastWorldY==null or after.state.mode!="run":continue
				var leg: int=s.leg
				var planted_row: float=(float(s.lastWorldY)-float(after.state.renderY))*2.+104.-1.
				var row: int=int(after.legs[leg].soleRow)
				var lifted: float=planted_row-float(row)
				var ok: bool=lifted>=2. or int(after.legs[leg].patch)>=1
				if not ok:peel_ok=false
				peel_detail.append({"leg":leg,"tick":after.tick,"phase":after.state.feet[leg].phase,"rowsAbovePlantedPoint":lifted,"soleRows":after.legs[leg].patch})
			_check(name+"-first-airborne-frame-after-each-stance-is-visible-peel",peel_ok,peel_detail)
			runs.append({"name":name,"fps":fps,"startY":start,"frames":run.frames.map(func(fr):return {"tick":fr.tick,"segment":fr.segment,"state":_ser(fr.state),"heelCap":fr.measured.map(func(m):return {"matches":m.hits.size(),"worldY":m.worldY,"col":m.col}),"isStatic":fr.isStatic,"near":fr.near})})
			if fps==60 and start==300.:
				var seg: Array=run.frames.filter(func(fr):return fr.segment=="stop")
				var moving: Array=seg.filter(func(fr):return not fr.isStatic)
				var mid: Dictionary=moving[moving.size()/2]
				for item in [["settle",mid],["final",seg[-1]]]:
					var path:=folder.path_join("rpg-2-star-ocean-the-second_female-north-run-%s-native-80x128_unapproved-v04_%s.png"%[item[0],tag])
					(item[1].image as Image).save_png(path)
					pose_report[item[0]]={"tick":item[1].tick,"file":path.get_file(),"sha256":FileAccess.get_sha256(path),"state":_ser(item[1].state),"isStatic":item[1].isStatic}
	# Contact interval checks: every grounded frame matched; travel <= 1 world px; lateral fixed.
	var worst:=0.
	var missing_total:=0
	var steady:={60:[],30:[]}
	for s: Dictionary in all_segments:
		worst=maxf(worst,s.heelCapTravelWorldPx)
		missing_total+=s.missingMatches
		var lateral_ok: bool=s.lateralShiftCols.all(func(c):return c==s.lateralShiftCols[0])
		_check("contact-%dhz-start%s-leg%d-ticks%d-%d-heel-cap-travel<=1px"%[s.fps,str(s.startY),s.leg,s.firstTick,s.lastTick],s.missingMatches==0 and s.heelCapTravelWorldPx<=1. and lateral_ok,{"frames":s.frames,"travel":s.heelCapTravelWorldPx,"missing":s.missingMatches,"segments":s.segments})
		var run_only: bool=s.mode.all(func(m):return m=="run")
		if run_only and s.firstTick>0 and s.stancePhases.size()>0 and s.stancePhases[0]<(9.4 if s.fps==30 else 4.7):steady[s.fps].append(s.frames)
		s.erase("after")
	_check("no-grounded-frame-without-unique-heel-match",missing_total==0,missing_total)
	_check("steady-run-stances-observed-at-both-rates",steady[60].size()>=12 and steady[30].size()>=12,{"60":steady[60].size(),"30":steady[30].size()})
	coverage={"stancePhases":20,"stanceSeconds":20./280.,"stepPhases":64,"groundedShareOfStep":20./64.,"flightShareOfStep":44./64.,"samplesPerStanceTheory":{"60":20./(280./60.),"30":20./(280./30.)},"steadySamples60":{"min":steady[60].min() if steady[60].size()>0 else 0,"max":steady[60].max() if steady[60].size()>0 else 0},"steadySamples30":{"min":steady[30].min() if steady[30].size()>0 else 0,"max":steady[30].max() if steady[30].size()>0 else 0}}
	_check("every-steady-stance-has-at-least-2-samples-at-30hz-and-4-at-60hz",coverage.steadySamples30.min>=2 and coverage.steadySamples60.min>=4,coverage)
	# v03 same measure, for comparison only.
	var v03_run:=_simulate(load(V03_PATH).new(),60,300.,templates,original)
	var v03_worst:=0.
	for s: Dictionary in _contact_segments(v03_run):
		if s.heelCapTravelWorldPx<INF:v03_worst=maxf(v03_worst,s.heelCapTravelWorldPx)
	var report:={"tool":"NORTH v04 compact-stance poses/contact tests","prototypeOnly":true,"artApproved":false,"motionApproved":false,"modelSha256":FileAccess.get_sha256(MODEL_PATH),"toolSha256":FileAccess.get_sha256(get_script().resource_path),"staticPngSha256":FileAccess.get_sha256(STATIC_PNG),"v03ModelSha256":FileAccess.get_sha256(V03_PATH),"measure":"Exact RGBA template of each boot's static heel block (rows sole-3..sole, boots layer) searched in every rendered cell; heel cap underside world Y = renderY + (row+1-104)*0.5.","stanceCoverage":coverage,"poses":pose_report,"passingQ":passing_q,"phaseTable":phase_table,"contactSegments":all_segments,"worstHeelCapTravelWorldPx":worst,"v03SameMeasure60HzWorstTravelWorldPx":v03_worst,"runs":runs,"checks":checks,"passed":checks.filter(func(c):return c["pass"]).size(),"failed":checks.filter(func(c):return not c["pass"]).size()}
	var file:=FileAccess.open(report_path,FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"  ")+"\n")
	file.close()
	for c in checks:
		if not c["pass"]:print("FAIL ",c["key"]," ",c.get("detail"))
	print("coverage ",coverage)
	print("worst heel-cap travel world px v04=",worst," v03 same measure=",v03_worst)
	print("NORTH V04 TESTS passed=",report.passed," failed=",report.failed)
	if report.failed==0:print("NORTH_V04_TESTS_OK")
	quit(1 if report.failed>0 else 0)
