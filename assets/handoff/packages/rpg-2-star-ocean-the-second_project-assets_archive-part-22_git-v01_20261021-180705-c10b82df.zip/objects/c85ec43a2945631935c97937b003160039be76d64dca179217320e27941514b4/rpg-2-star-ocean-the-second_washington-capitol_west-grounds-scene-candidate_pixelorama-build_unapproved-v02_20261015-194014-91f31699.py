"""UNAPPROVED v02 refinement of the Washington (U.S. Capitol west grounds) exploration-scene candidate.

Deterministic Python tool authored and run by Claude (Claude Code, claude.ai Max, firstParty). It paints ONE
1280x720 pixel-art exploration scene from a fixed 45-colour palette into the same 9-layer stack as v01
(docs/qa/...washington-capitol_pixelorama-scene-production-spec_technical-unapproved-v01_20261015-174500-5e0d2b71.md)
and writes it as a native Pixelorama .pxo (pxo_version 7) plus an .ora, a flattened PNG and a manifest.
Nothing here is accepted art. Nothing is wired into the game runtime. The v01 candidate and its builder
(tools/...west-grounds-scene-candidate_pixelorama-build_unapproved-v01_20261015-181440-4f6ec80a.py) are only read.

Lineage: this file (run 91f31699) forks an earlier, never-built v02 draft
(tools/...pixelorama-build_unapproved-v02_20261015-185126-4ad6947e.py, left untouched) and continues it.

v02 answers the visual QA of v01 (lawn sparse, ~58 similar canopies, collapse flat brown, railings repeated, survey
post tiny, Capitol identity weak):
  * top rows: west-front cues. Rusticated wings with round-arched openings and keystones, a projecting central
    portico of paired columns (Attic bases, stepped stylobate, bronze doors), two wing porticos, bronze candelabra
    lamp standards on the stair newels and the terrace. The site layout (terrace, balustrade, central stairs, open
    lawn, curved walks, tree belts) is unchanged from v01.
  * balustrade bays of uneven width, each with its own weathering state (stained, mossy, chipped, missing
    balusters, replaced, ivy-choked); varied wall-face spalls, efflorescence and cracks.
  * collapse: horizontal soil strata with lateral light, embedded stones, undercut shadow, stepped wall ends, broken
    balustrade ends with a dangling baluster, a lit talus heightfield carrying rubble of mixed size, tone and kind
    (ashlar, moulded cornice pieces, column drums, baluster runs).
  * four tree families (round oak, spreading elm, conical holly, small blossoming magnolia) mixed in irregular
    clumps and glades; hollies only as specimens or small groups; understory shrubs at canopy edges.
  * layered flora with a purpose: rough unmown meadow drifts with seed heads on the lawn panels, a mown survey lane
    along the patrol route and a mown pad round the post, verge planting along walks, clover and wildflowers.
    The axial walk (granite-curbed) is kept clear and fully walkable (gated).
  * survey post about 2.5x the actor's height, ink-outlined, with stronger lit/shade contrast.

Camera: top-down with mild 3/4 front faces. Top of frame = east (Capitol west front + terrace), bottom = west.
NOT drawn (deliberately): any moat, basin, pool or water; any compass medallion; the Summerhouse; the western road
loop; the dome. Game fiction on top (not site fact): collapse of one terrace-wall bay, a broken wing-portico
column, overgrowth, survey post and kit, patrol-route beacons, cordon tape.

Every file this tool writes is named <project slug>_<area>_<purpose>_unapproved-v02_<stamp>-<run id>.<ext>.

Modes
  preview <dir>   render everything into <dir> (outside the repo) for visual iteration; writes nothing in the repo
  build           write candidate files (game/assets/environments/candidates/<RUN>/) and QA previews
                  (outputs/<RUN>/); refuses to overwrite a different existing file
  check           technical gates on the built files and, unless --no-pixelorama, Pixelorama 1.2.3 headless flat and
                  --split-layers exports of temp copies, run with APPDATA redirected to a temp dir so the open
                  GUI's %APPDATA%\\pixelorama (config.ini, logs, .running crash marker) is never touched; unless
                  --no-godot, a throwaway Godot project in temp renders heroine-scale runtime-stack stills.
                  --write-report writes the JSON report and evidence PNGs into outputs/<RUN>/ (never overwrites).

Run: python -I -B <this file> preview <tempdir> | build | check [--write-report] [--no-pixelorama] [--no-godot]
"""
import argparse, hashlib, io, json, math, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
AREA = "wdc-capitol-west"
VER = "unapproved-v02"
STAMP = "20261015-194014"
RUN_ID = "91f31699"
RUN = f"wdc-capitol-west-v02_{STAMP}-{RUN_ID}"
CAND_REL = f"game/assets/environments/candidates/{RUN}"
OUT_REL = f"outputs/{RUN}"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))
V01_RUN = "wdc-capitol-west-v01_20261015-181440-4f6ec80a"
V01_FLAT_REL = f"game/assets/environments/candidates/{V01_RUN}/wdc-capitol-west-v01_flat.png"
V01_TOOL_REL = ("tools/rpg-2-star-ocean-the-second_washington-capitol_west-grounds-scene-candidate_pixelorama-build_"
                "unapproved-v01_20261015-181440-4f6ec80a.py")
SPEC_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_pixelorama-scene-production-spec_"
            "technical-unapproved-v01_20261015-174500-5e0d2b71.md")
AUDIT_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_site-map-visual-audit_"
             "qa-note-unapproved-v01_20261015-175832-86c8c714.md")
HEROINE_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
               "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
PIXELORAMA_DEFAULT = ("C:/Users/hkzha/AppData/Local/Programs/Pixelorama-1.2.3/"
                      "Pixelorama-Windows-64bit/Pixelorama.exe")
PIXELORAMA_VERSION = "v1.2.3-stable"
GODOT_REL = "work/tooling/godot-4-7-2/Godot_v4.7.2-stable_win64_console.exe"      # gitignored local tooling
W, H = 1280, 720
WIN_LONG_PREFIX = "\\\\?\\"


def fname(purpose, ext):
    """AGENTS naming: project slug, area, purpose, version, timestamp and run id are all in the file name."""
    return f"{SLUG}_{AREA}_{purpose}_{VER}_{STAMP}-{RUN_ID}.{ext}"


EXPORT_STEM = f"{SLUG}_{AREA}_pixelorama-export_{VER}_{STAMP}-{RUN_ID}"

LAYERS = ["ground-base", "paving-walks", "terrace-walls", "ground-detail", "cast-shadows",
          "props-low", "survey-post", "fg-occlusion", "guides"]                     # bottom -> top
ART_LAYERS = LAYERS[:8]                                                            # guides: hidden, locked

# ============================================================================ palette (45 art colours)
PALETTE = [
    ("ink", "1a1c22"),
    ("g0", "1f3324"), ("g1", "2c4a2c"), ("g2", "3d6234"), ("g3", "557a3c"), ("g4", "6f9145"),
    ("g5", "93ad55"), ("g6", "b9c26c"), ("g7", "d3d98a"),
    ("d0", "7f7c45"), ("d1", "a99a5e"),
    ("f0", "16262a"), ("f1", "223d3a"), ("f2", "2f5644"),
    ("e2", "2a5a52"), ("e3", "40806c"), ("e4", "6aa58a"),
    ("s0", "3a2c22"), ("s1", "5a4430"), ("s2", "7d6345"), ("s3", "a08458"), ("s4", "c6aa76"),
    ("m0", "4a4c58"), ("m1", "6e6f78"), ("m2", "93918f"), ("m3", "b8b3a8"), ("m4", "d6d0c2"), ("m5", "ece6d6"),
    ("p0", "6b5f52"), ("p1", "8d7f6c"), ("p2", "ab9d86"), ("p3", "c6b99e"),
    ("k0", "232a36"), ("k1", "3a4656"), ("k2", "5a6a7c"), ("k3", "8d9cab"),
    ("c0", "1f6f78"), ("c1", "49c6cf"), ("c2", "b4f4f0"),
    ("o0", "a34a1e"), ("o1", "e07a2e"), ("o2", "f4b860"),
    ("fl", "c79ad0"), ("bl", "eda7b6"), ("y0", "e8cf58"),
]
GUIDE_PALETTE = [("gd-walk", "3cdcff"), ("gd-block", "ff285a"), ("gd-pin", "ffe600"), ("gd-tick", "ffffff"),
                 ("gd-route", "ff78ff")]
ALL_PAL = PALETTE + GUIDE_PALETTE
I = {n: i for i, (n, _) in enumerate(ALL_PAL)}
RGB = np.array([[int(h[j:j + 2], 16) for j in (0, 2, 4)] for _, h in ALL_PAL], np.uint8)
N_ART = len(PALETTE)

GR = [I[n] for n in ("g0", "g1", "g2", "g3", "g4", "g5", "g6", "g7")]           # grass ramp
FOL = [I[n] for n in ("f0", "f1", "f2", "g2", "g3", "g4", "g5")]                # oak canopy ramp
ELM = [I[n] for n in ("f1", "g1", "g2", "g3", "g4", "g5", "g6")]                # elm canopy ramp (yellower)
CON = [I[n] for n in ("f0", "f1", "e2", "e3", "e4")]                            # holly / conifer ramp
MAG = [I[n] for n in ("f0", "f1", "f2", "e2", "e3", "g4")]                      # magnolia ramp (glossy)
BOX = [I[n] for n in ("f0", "f1", "e2", "g2", "g3", "g4")]                      # clipped boxwood / verge shrubs
STONE = [I[n] for n in ("ink", "m0", "m1", "m2", "m3", "m4", "m5")]             # marble / granite ramp
PAVE = [I[n] for n in ("m0", "p0", "p1", "p2", "p3", "m4")]                     # walk paving ramp
SOIL = [I[n] for n in ("ink", "s0", "s1", "s2", "s3", "s4")]
METAL = [I[n] for n in ("ink", "k0", "k1", "k2", "k3")]

SHADE = {  # opaque cast-shadow colour for each art colour underneath (no semi-alpha anywhere)
    "ink": "ink", "g0": "f0", "g1": "g0", "g2": "g1", "g3": "g1", "g4": "g2", "g5": "g3", "g6": "g4", "g7": "g5",
    "d0": "g1", "d1": "d0", "f0": "f0", "f1": "f0", "f2": "f1", "e2": "f1", "e3": "e2", "e4": "e3",
    "s0": "ink", "s1": "s0", "s2": "s1", "s3": "s1", "s4": "s2",
    "m0": "ink", "m1": "m0", "m2": "m1", "m3": "m1", "m4": "m2", "m5": "m3",
    "p0": "m0", "p1": "p0", "p2": "p0", "p3": "p1",
    "k0": "ink", "k1": "k0", "k2": "k1", "k3": "k2", "c0": "k0", "c1": "c0", "c2": "c0",
    "o0": "s0", "o1": "o0", "o2": "o1", "fl": "s1", "bl": "fl", "y0": "d1",
}
SHADE_LUT = np.arange(len(ALL_PAL), dtype=np.int16)
for _a, _b in SHADE.items():
    SHADE_LUT[I[_a]] = I[_b]

# ============================================================================ scene geometry (logical px)
FACADE_Y1 = 40            # wing facade rows 0..39 (rusticated ground story + water table); deck starts here
PAV = (476, 804)          # central projecting west portico (symmetric about x 639.5)
PAV_Y1 = 52               # its stepped stylobate ends at row 51
SUBP = ((128, 276), (1003, 1151))    # wing porticos with engaged columns
SUBP_Y1 = 46
COL_BROKEN = (1, 1)       # (wing portico index, column index): game-fiction broken column on the damaged south end
EDGE_Y = 106              # terrace deck edge = top of the west retaining-wall face
WALL_H = 42               # wall face rows 106..147 (compressed; real height unverified)
FOOT_Y = EDGE_Y + WALL_H  # 148: lawn level at the wall foot
BAL_H = 20                # balustrade rows 86..105
STAIR_X0, STAIR_X1 = 546, 734       # stair flight between the cheek walls (188 px ~ 7 m, unverified)
CHEEK_W = 14
STAIR_BOT = 202           # bottom tread row (stairs project 54 px onto the lawn plane)
FORE = (452, 202, 828, 252)          # paved forecourt at the stair foot (x0, y0, x1, y1), plain paving
AXIS = (600, 680)                    # axial walk x range, runs to the bottom (west) edge
WALK_W = 36
LEFT_WALK = [(500, 230), (322, 242), (244, 352), (206, 740)]       # cubic Bezier control points (as v01)
RIGHT_WALK = [(779, 230), (950, 248), (1046, 372), (1056, 740)]
BRANCH_W = 26
LEFT_BRANCH = [(222, 520), (160, 548), (80, 572), (-30, 600)]
COLLAPSE = (880, 1104)               # collapsed terrace-wall bay (game fiction)
POST = (900, 380)                    # survey-post pivot: base centre (x, contact row y)
# balustrade piers: symmetric about the axis, bay widths uneven (v01 used a strict 64 px pitch)
PIERS_L = [482, 420, 352, 294, 228, 168, 98, 42]
PIERS = PIERS_L + [W - 1 - x for x in PIERS_L]
# per-bay weathering, listed from the stairs outward (left side, then right side)
BAY_STATE_L = ["clean", "stained", "missing", "mossy", "chipped", "ivy", "replaced", "stained", "mossy"]
BAY_STATE_R = ["mossy", "chipped", "breach", "breach", "breach", "stained", "missing", "ivy", "clean"]
PATROL = [(640, 214), (800, 262), (856, 300), (900, 396), (1010, 444), (1046, 604), (700, 640), (640, 640)]
SURVEY_GRID = [(x, y) for y in (452, 492, 532) for x in (760, 800, 840, 880)]       # orange pin flags
ENTRY = (640, 700)
# ============================================================================ small helpers
def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > 247 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def rp(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(p):
    with open(_fs(p), "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha_text(b):
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def blank():
    return np.full((H, W), -1, np.int16)


def rng_for(*key):
    return np.random.default_rng(int.from_bytes(hashlib.sha256(repr(key).encode()).digest()[:8], "little"))


def vnoise(seed, cell, h=H, w=W):
    """Smooth value noise in [0,1] (bicubic-upsampled random lattice), deterministic for a seed."""
    r = rng_for("noise", seed, cell, h, w)
    gh, gw = h // cell + 4, w // cell + 4
    g = r.random((gh, gw), dtype=np.float32)
    a = np.asarray(Image.fromarray(g, "F").resize((gw * cell, gh * cell), Image.BICUBIC))[cell:cell + h, cell:cell + w]
    return (a - a.min()) / (a.max() - a.min() + 1e-9)


def despeckle(m, passes=2, valid=None):
    """Replace pixels whose 4 neighbours all differ from them: keeps clusters deliberate, no lone noise."""
    for _ in range(passes):
        p = np.pad(m, 1, mode="edge")
        up, dn, lf, rt = p[:-2, 1:-1], p[2:, 1:-1], p[1:-1, :-2], p[1:-1, 2:]
        iso = (m != up) & (m != dn) & (m != lf) & (m != rt) & (m >= 0)
        if valid is not None:
            iso &= valid
        rep = np.where(lf == rt, lf, np.where(up == dn, up, np.where(lf >= 0, lf, up)))
        m = np.where(iso & (rep >= 0), rep, m)
    return m


def majority(m, r, passes=1):
    """Box majority filter on a boolean mask (window 2r+1): rounds off lace and pinholes into firm shapes."""
    k = 2 * r + 1
    for _ in range(passes):
        p = np.pad(m.astype(np.int32), r + 1)
        c = p.cumsum(0).cumsum(1)
        s_ = c[k:, k:] - c[:-k, k:] - c[k:, :-k] + c[:-k, :-k]
        m = s_[:m.shape[0], :m.shape[1]] * 2 > k * k
    return m


def ramp_shift(idx, ramp, d):
    """Move palette index idx by d steps along ramp (clamped); colours not on the ramp map to its middle."""
    pos = {v: k for k, v in enumerate(ramp)}
    k = pos.get(int(idx), len(ramp) // 2)
    return ramp[max(0, min(len(ramp) - 1, k + d))]


def ramp_shift_arr(arr, ramp, d):
    lut = np.arange(len(ALL_PAL), dtype=np.int16)
    for k, v in enumerate(ramp):
        lut[v] = ramp[max(0, min(len(ramp) - 1, k + d))]
    out = arr.copy()
    ok = arr >= 0
    out[ok] = lut[arr[ok]]
    return out


def put(layer, mask, idx):
    layer[mask] = idx


def rect(layer, x0, y0, x1, y1, idx):
    """Fill inclusive rect, clipped."""
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W - 1, x1), min(H - 1, y1)
    if x0 <= x1 and y0 <= y1:
        layer[y0:y1 + 1, x0:x1 + 1] = idx


def setpx(layer, x, y, idx):
    if 0 <= x < W and 0 <= y < H:
        layer[y, x] = idx


def line(layer, x0, y0, x1, y1, idx):
    n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
    for t in np.linspace(0, 1, n):
        setpx(layer, int(round(x0 + (x1 - x0) * t)), int(round(y0 + (y1 - y0) * t)), idx)


def stamp(layer, x, y, rows, cmap, under=None, ramp=None, mask=None):
    """Draw an ASCII sprite. cmap: char -> palette name, or int offset along `ramp` relative to `under`."""
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if ch == ".":
                continue
            px, py = x + i, y + j
            if not (0 <= px < W and 0 <= py < H) or (mask is not None and not mask[py, px]):
                continue
            v = cmap[ch]
            if isinstance(v, int):
                if isinstance(under, np.ndarray):
                    base = under[py, px]
                else:
                    base = under if under is not None else ramp[len(ramp) // 2]
                layer[py, px] = ramp_shift(base, ramp, v)
            else:
                layer[py, px] = I[v]


def composite_idx(layers, names):
    out = layers[names[0]].copy()
    for n in names[1:]:
        m = layers[n] >= 0
        out[m] = layers[n][m]
    return out


def bezier(pts, n=1600):
    t = np.linspace(0, 1, n)[:, None]
    p = [np.array(q, float) for q in pts]
    c = ((1 - t) ** 3) * p[0] + 3 * ((1 - t) ** 2) * t * p[1] + 3 * (1 - t) * t * t * p[2] + (t ** 3) * p[3]
    seg = np.r_[0, np.cumsum(np.hypot(*np.diff(c, axis=0).T))]
    return c, seg


def band_coords(pts, half):
    """Per-pixel (s along curve, signed t across) for pixels within `half`+6 px of a cubic Bezier."""
    c, seg = bezier(pts)
    tang = np.gradient(c, axis=0)
    tang /= np.linalg.norm(tang, axis=1, keepdims=True)
    S = np.full((H, W), np.nan, np.float32)
    T = np.full((H, W), np.nan, np.float32)
    x0 = int(max(0, c[:, 0].min() - half - 8)); x1 = int(min(W, c[:, 0].max() + half + 9))
    y0 = int(max(0, c[:, 1].min() - half - 8)); y1 = int(min(H, c[:, 1].max() + half + 9))
    xs = np.arange(x0, x1)
    for y in range(y0, y1):
        dx = xs[:, None] - c[None, :, 0]
        dy = y - c[None, :, 1]
        d2 = dx * dx + dy * dy
        k = d2.argmin(axis=1)
        d = np.sqrt(d2[np.arange(len(xs)), k])
        sgn = np.sign(tang[k, 0] * (y - c[k, 1]) - tang[k, 1] * (xs - c[k, 0]))
        ok = d <= half + 6
        S[y, xs[ok]] = seg[k[ok]]
        T[y, xs[ok]] = (d * sgn)[ok]
    return S, T, c


# ============================================================================ hand-authored stamps
TUFTS = [  # grass clumps, relative to the tone underneath: a=-2 b=-1 e=0 c=+1 d=+2 (tips lit, base shaded)
    ["..d..", ".c.c.", "cbcbc", ".bbb.", "..a.."],
    [".c...c", "c.c.c.", ".cbcbc", "bbcbb.", ".aaa.."],
    ["c..c..", ".cc.c.", "bccbc.", ".bbbb.", "..aa.."],
    ["..c.", ".dc.", "cbcc", "bbb.", ".a.."],
    [".c.c..", "cdc.c.", "bcbcb.", ".bbab.", "..a..."],
    ["...c...", ".c.cc..", "c.cbc.c", "bcbbcb.", ".abba..", "..aa..."],
    ["c.c", "bcb", ".a."],
    [".b.", "b.b", ".a."],
]
TUFT_MAP = {"a": -2, "b": -1, "e": 0, "c": 1, "d": 2}
TALL_TUFTS = [  # overgrown edges: longer blades
    ["d...d.", "c..c.c", ".c.cb.", "bccb..", "abba..", ".aa..."],
    [".d..d", "c.cc.", "c.c.b", "bcbb.", "abba.", ".aa.."],
    ["..d...", ".dc.d.", "c.cc.c", "bcbcb.", ".abba.", "..aa.."],
]
BENCH = [
    ".K......................K.",
    ".KWWWWWWWWWWWWWWWWWWWWWWK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    ".KwwwwwwwwwwwwwwwwwwwwwwK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    "KkkkkkkkkkkkkkkkkkkkkkkkkK",
    "KWWWWWWWWWWWWWWWWWWWWWWWWK",
    "KwwwwwwwwwwwwwwwwwwwwwwwwK",
    "KWWWWWWWWWWWWWWWWWWWWWWWWK",
    "KvvvvvvvvvvvvvvvvvvvvvvvvK",
    ".KkK..................KkK.",
    ".K.K..................K.K.",
]
BENCH_BROKEN = [
    ".K......................K.",
    ".KWWWWWWWWWWWWWWW.......K.",
    ".KvvvvvvvvvvvvvvvK......K.",
    ".KwwwwwwwwwwwwwwwwwwwwwwK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    "KkkkkkkkkkkkkkkkkkkkkkkkkK",
    "KWWWWWWWWWWWWW..WWWWWWWWWK",
    "KwwwwwwwwwwwwvK.wwwwwwwwwK",
    "K..............vWWWWWWWWWK",
    "K..........WWWvvvvvvvvvvvK",
    ".KkK.........vv.......KkK.",
    ".K.K..................K.K.",
]
BENCH_MAP = {"K": "k0", "k": "k1", "W": "s3", "w": "s2", "v": "s1"}
CRATE = [
    ".kkkkkkkkkkkk.",
    "kHHHHHHHHHHHHk",
    "kHhhhhhhhhhhhk",
    "kHhhhhhhhhhhhk",
    "kKKKKKKKKKKKKk",
    "kMMMMMMMMMMMMk",
    "kMoooooooooMMk",
    "kMOOOOOOOOOMMk",
    "kMMMMcCMMMMMMk",
    "kMMMMccMMMMMMk",
    "kMMMMMMMMMMMMk",
    ".kkkkkkkkkkkk.",
]
CRATE_MAP = {"k": "k0", "H": "k3", "h": "k2", "K": "k1", "M": "k1", "o": "o1", "O": "o0", "c": "c0", "C": "c1"}
BEACON = [  # patrol-route marker (about 16 px: below the 48 px actor's waist)
    ".C.",
    "CXC",
    ".C.",
    ".k.",
    ".kO",
    ".kO",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    "kKk",
    "KKK",
]
BEACON_MAP = {"C": "c1", "X": "c2", "k": "k2", "K": "k0", "O": "o1"}
STAKE = [".o", "oO", "w.", "w.", "w.", "w.", "W.", "W."]
STAKE_MAP = {"o": "o1", "O": "o0", "w": "s3", "W": "s1"}
LAMP_STUB = [  # broken cast-iron lamp post, base only
    "..kk..",
    ".kKk..",
    ".kKk..",
    ".kKK..",
    ".kKK..",
    ".kKK..",
    "kkKKk.",
    "kHKKKk",
    "kHKKKk",
    "kKKKKk",
    "KKKKKK",
]
LAMP_MAP = {"k": "k2", "K": "k1", "H": "k3"}
FLOWERS = ["m5", "m5", "o2", "fl", "m5", "o2"]
BIN = [  # litter receptacle beside a bench
    ".xxxxxxxx.",
    "xHHHHHHHMx",
    "xKKKKKKKKx",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHbbbbDx.",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHMMMDDx.",
    ".xxxxxxxx.",
]
BIN_MAP = {"x": "ink", "H": "k3", "M": "k2", "D": "k1", "K": "k0", "b": "s2"}
SIGN = [  # wayfinding sign; the 'text' is deliberately unreadable dashes
    "xxxxxxxxxxxxxxxxxxxxxx",
    "xHHHHHHHHHHHHHHHHHHHHx",
    "xHPPPPPPPPPPPPPPPPPPDx",
    "xHPTTTTTTT.PPPPPPPPPDx",
    "xHPPPPPPPPPPPPPPPPPPDx",
    "xHPtttt.ttttt.tttPPPDx",
    "xHPtttttt.tttt.ttPPPDx",
    "xHPttt.tttttt.tttPPPDx",
    "xHPPPPPPPPPPPPPPPPPPDx",
    "xHPoooPPPPPPPPPPPPPPDx",
    "xHDDDDDDDDDDDDDDDDDDDx",
    "xxxxxxxxxxxxxxxxxxxxxx",
] + ["...xpqx........xpqx..."] * 13 + ["...xxxx........xxxx..."]
SIGN_MAP = {"x": "ink", "H": "k3", "P": "k1", "D": "k0", "T": "m5", "t": "m3", "o": "o1", "p": "k2", "q": "k0"}
PLAQUE = ["xxxxx", "xHHDx", "xHPDx", "xxxxx", "..q..", "..q.."]
PLAQUE_MAP = {"x": "ink", "H": "s3", "P": "s2", "D": "s1", "q": "k0"}
TRIPOD = [
    "....xxxxxxx.....",
    "...xOOOOOoox....",
    "...xOCXOOoox....",
    "...xOOOOOoox....",
    "....xxxxxxx.....",
    ".......kk.......",
    "......kHKk......",
    "......kHKk......",
    ".....k.kk.k.....",
    ".....k.kk.k.....",
    "....k..kk..k....",
    "....k..kk..k....",
    "...k...kk...k...",
    "...k...kk...k...",
    "..k....kk....k..",
    "..k....kk....k..",
    ".k.....kk.....k.",
    ".k.....kk.....k.",
    "k......kk......k",
    "K......KK......K",
]
TRIPOD_MAP = {"x": "ink", "O": "o1", "o": "o0", "C": "c1", "X": "c2", "k": "k2", "H": "k3", "K": "k0"}
REEL = [
    "..xxxxxxxxxx..",
    ".xWWWWWWWWWWx.",
    "xWKKKKKKKKKKwx",
    "xWKqKqKqKqKKwx",
    "xWKKKKKKKKKKwx",
    "xWKqKqKqKqKKwx",
    "xWKKKKKKKKKKwx",
    ".xwwwwwwwwwwx.",
    "..xxxxxxxxxx..",
    "..s........s..",
]
REEL_MAP = {"x": "ink", "W": "s3", "w": "s1", "K": "k1", "q": "k0", "s": "s0"}
TARP = [
    "....xxxxxxx.....xxxx....",
    "..xxHHHHHHHxxxxxHHHHx...",
    ".xHHHMMMMMHHHHHHMMMMHx..",
    "xHMMMMoMMMMMMMMMMMoMMDx.",
    "xMMMMMoMMMMMMMMMMMoMMMDx",
    "xMMMMMoMMMMMMMMMMMoMMMDx",
    "xMMMMMoMMMMMMMMMMMoMMDDx",
    "xDMMMMoMMMMMMMMMMMoMDDDx",
    "xDDDDDoDDDDDDDDDDDoDDDx.",
    ".xDDDDODDDDDDDDDDDODDx..",
    "..xxxxxxxxxxxxxxxxxxx...",
]
TARP_MAP = {"x": "ink", "H": "k3", "M": "k2", "D": "k1", "o": "o1", "O": "o0"}
SANDBAG = [".xxxxxx.", "xLLLLMMx", "xLMMMMDx", "xMMMMDDx", ".xxxxxx."]
SANDBAG_MAP = {"x": "s0", "L": "s4", "M": "s3", "D": "s2"}
STUMP = [
    "....xxxxxxxxxx......",
    "..xxLLLLMMMMMMxx....",
    ".xLLMRRRRRRRMMMDx...",
    "xLLMRRrrrrrRRMMMDx..",
    "xLMRRrRRRRRrRRMMDx..",
    "xLMRRrRrrrRrRRMMDx..",
    "xLMMRRrrrrrRRMMMDx..",
    ".xLMMRRRRRRRMMMDDxo.",
    "..xxMMMMMMMMMMDDxooo",
    ".xbbbBbbbbBbbbbDDxo.",
    "xbbBbbBbbBbbBbbbDDx.",
    "xbBBbBBbBBbBBbBDDDDx",
    "xBBBBbBBBbBBBBDDDDDx",
    ".xxxxxxxxxxxxxxxxxx.",
]
STUMP_MAP = {"x": "ink", "L": "s4", "M": "s3", "R": "s2", "r": "s1", "D": "s1", "b": "s2", "B": "s1", "o": "o2"}
WARN = [
    ".....x.....",
    "....xox....",
    "...xoOox...",
    "..xooxoox..",
    ".xoooxooox.",
    "xooooxoooox",
    ".xoooooox..",
    "..xooxoox..",
    "...xoOox...",
    "....xox....",
    ".....x.....",
] + [".....k....."] * 8 + [".....K....."]
WARN_MAP = {"x": "ink", "o": "o1", "O": "o2", "k": "k2", "K": "k0"}


# ============================================================================ painters
class Scene:
    def __init__(self):
        self.L = {n: blank() for n in LAYERS}
        self.walk_mask = np.zeros((H, W), bool)          # paved (walks, forecourt, deck, stairs)
        self.block = np.zeros((H, W), bool)              # collision footprints (for guides / walkability)
        self.prop_shadow = []                            # (mask) cast-shadow footprints from props/trees
        self.notes = []

    # ------------------------------------------------------------------ ground-base
    def ground_base(self):
        g = self.L["ground-base"]
        # v02: broader tonal drifts (fewer, larger shapes) and less fine mottling than v01
        n1, n2, n3 = vnoise("lawn1v2", 170), vnoise("lawn2v2", 44), vnoise("lawn3v2", 9)
        v = 0.62 * n1 + 0.27 * n2 + 0.11 * n3
        t = np.full((H, W), I["g3"], np.int16)
        t[v > 0.5] = I["g4"]
        t[v > 0.8] = I["g5"]
        t[v < 0.16] = I["g2"]                                  # fewer, smaller dark blotches (v01 read camouflage)
        dry = 0.7 * vnoise("dry1", 60) + 0.3 * vnoise("dry2", 6)
        lawnish = (v > 0.45)
        t[(dry > 0.78) & lawnish] = I["d0"]
        t[(dry > 0.85) & lawnish] = I["d1"]
        y = np.arange(H)[:, None]
        x = np.arange(W)[None, :]
        self.belt = self.belt_mask()
        # purposeful lawn: the survey crew keeps a mown pad round the post and a mown lane along the patrol loop
        # (diagonal mowing stripes); the rest of the lawn panels have gone to rough meadow drifts since the fall
        yy, xx = np.mgrid[0:H, 0:W]
        px, py = POST
        pad = ((xx - (px - 8)) / 84.0) ** 2 + ((yy - (py + 6)) / 50.0) ** 2 + (vnoise("padedge", 5) - 0.5) * 0.12 < 1
        dl = np.full((H, W), 1e9, np.float32)
        for (ax_, ay_), (bx_, by_) in zip(PATROL[1:4], PATROL[2:5]):
            vx, vy = bx_ - ax_, by_ - ay_
            tt = np.clip(((xx - ax_) * vx + (yy - ay_) * vy) / float(vx * vx + vy * vy), 0, 1)
            dl = np.minimum(dl, np.hypot(xx - (ax_ + tt * vx), yy - (ay_ + tt * vy)).astype(np.float32))
        lane = dl < 15 + (vnoise("laneedge", 6) - 0.5) * 4
        axis_zone = (xx >= AXIS[0] - 6) & (xx <= AXIS[1] + 6)
        grass = (yy >= FOOT_Y + 14) & ~self.belt & ~axis_zone
        mown = (pad | lane) & grass
        stripe = ((xx + yy) // 10) % 2 == 0
        mt = np.where(stripe, I["g5"], I["g4"])
        mt[(vnoise("mownwear", 4) > 0.8) & stripe] = I["g4"]
        mt[(vnoise("mownwear2", 5) > 0.86)] = I["g3"]
        t[mown] = mt[mown]
        self.mown = mown
        mp = np.pad(mown, 6)
        near_mown = mp[12:, 6:-6] | mp[:-12, 6:-6] | mp[6:-6, 12:] | mp[6:-6, :-12] | mown
        cs = 4
        gy_, gx_ = np.mgrid[0:H:cs, 0:W:cs]
        dmin = np.full(gy_.shape, 1e9, np.float32)
        for c in (self.lc, self.rc):
            for q in c[::8]:
                dmin = np.minimum(dmin, np.hypot(gx_ - q[0], gy_ - q[1]).astype(np.float32))
        dfull = np.repeat(np.repeat(dmin, cs, 0), cs, 1)[:H, :W]
        verge_bias = np.clip(1 - (dfull - WALK_W / 2) / 80.0, 0, 1)            # unmown verges along the walks
        field = 0.72 * vnoise("meadowb3", 120) + 0.34 * verge_bias + 0.1 * np.clip((yy - 300) / 400.0, 0, 1)
        ok = (yy > FOOT_Y + 40) & grass & ~near_mown & ~((xx > STAIR_X0 - 120) & (xx < STAIR_X1 + 120) & (yy < 300))
        meadow = majority((field > 0.57) & ok, 3, 3) & ok
        mtx = vnoise("meadowt", 3)
        t[meadow] = np.where(mtx < 0.55, I["g4"], np.where(mtx < 0.9, I["g5"], I["d1"]))[meadow]
        self.meadow = meadow
        # wall-foot planting strip (soil) and tree-belt floor (darker, litter)
        strip = (y >= FOOT_Y) & (y < FOOT_Y + 14) & ~((x >= STAIR_X0 - CHEEK_W - 2) & (x <= STAIR_X1 + CHEEK_W + 2))
        sn = vnoise("strip", 5)
        t[strip & (sn < 0.55)] = I["s1"]
        t[strip & (sn >= 0.55)] = I["s2"]
        t[strip & (sn < 0.2)] = I["s0"]
        self.belt = self.belt_mask()
        bn = 0.6 * vnoise("belt1", 22) + 0.4 * vnoise("belt2", 5)
        bt = np.where(bn < 0.35, I["g0"], np.where(bn < 0.55, I["g1"], np.where(bn < 0.8, I["g2"], I["s1"])))
        t[self.belt] = bt[self.belt]
        # deck under the facade (terrace): ground-base holds the marble deck too
        deck = self.deck_slabs()
        t[:EDGE_Y, :] = deck[:EDGE_Y, :]
        # worn patrol trail through grass (desire lines), drawn before despeckle so edges stay clumpy
        trail = self.trail_mask()
        tn = vnoise("trail", 4)
        tt = np.where(tn < 0.35, I["s2"], np.where(tn < 0.7, I["d1"], I["d0"]))
        core = trail & (t != I["s1"])
        t[core] = tt[core]
        t[:EDGE_Y, :] = deck[:EDGE_Y, :]
        t = despeckle(t, 2)
        g[:] = t
        self.trail = trail

    def belt_mask(self):
        """Tree-belt floor: outside the curved walks (plus margin) on both flanks, below the wall-foot strip."""
        if hasattr(self, "_belt"):
            return self._belt
        self.lS, self.lT, self.lc = band_coords(LEFT_WALK, WALK_W / 2)
        self.rS, self.rT, self.rc = band_coords(RIGHT_WALK, WALK_W / 2)
        m = np.zeros((H, W), bool)
        jit = (vnoise("beltedge", 11) - 0.5) * 14
        xs = np.arange(W)
        inner = np.zeros((H, W), bool)       # lawn inside the curved walks (the walkable lawn)
        def smooth(a, b, y, y0, y1):
            s = min(1.0, max(0.0, (y - y0) / (y1 - y0)))
            s = s * s * (3 - 2 * s)
            return a * (1 - s) + b * s

        for y in range(FOOT_Y + 10, H):
            xl = np.interp(y, self.lc[:, 1], self.lc[:, 0])
            xr = np.interp(y, self.rc[:, 1], self.rc[:, 0])
            # belt edges follow the walks lower down and ease out to the far corners near the terrace foot
            bl = smooth(112, xl - WALK_W / 2 - 18, y, 236, 336)
            br = smooth(W - 112, xr + WALK_W / 2 + 18, y, 330, 430)     # rubble spill zone stays open longer
            m[y] = (xs < bl + jit[y]) | (xs > br + jit[y])
            if y < 252:          # lawn margin along the terrace foot
                inner[y] = (xs > 196) & (xs < W - 196)
            else:
                inner[y] = (xs > xl + WALK_W / 2) & (xs < xr - WALK_W / 2)
        self._belt = m
        self.inner_lawn = inner
        return m

    def trail_mask(self):
        """Worn patrol desire lines through the grass: gently curved, ragged, only where the route leaves paving."""
        m = np.zeros((H, W), bool)
        jit = vnoise("trailw", 6)
        curves = [([800, 262], [840, 274], [872, 300], [892, 366], 3.2),
                  ([912, 398], [948, 414], [984, 428], [1020, 446], 3.0),
                  ([1046, 604], [940, 640], [810, 628], [690, 640], 2.2)]
        for ax_, b_, c_, d_, wd in curves:
            c, _ = bezier([ax_, b_, c_, d_], 500)
            x0 = int(max(0, c[:, 0].min() - 12)); x1 = int(min(W, c[:, 0].max() + 13))
            y0 = int(max(0, c[:, 1].min() - 12)); y1 = int(min(H, c[:, 1].max() + 13))
            yy, xx = np.mgrid[y0:y1, x0:x1]
            d = np.full(yy.shape, 1e9)
            for px, py in c[::4]:
                d = np.minimum(d, np.hypot(xx - px, yy - py))
            m[y0:y1, x0:x1] |= d < (wd + 2.6 * jit[y0:y1, x0:x1])
        return m

    def deck_slabs(self):
        """Marble terrace deck: large slabs, lit top/left bevels, grime and moss in joints near the edge."""
        t = np.full((H, W), I["m3"], np.int16)
        sw, sh = 30, 13
        y = np.arange(H)[:, None].repeat(W, 1)
        x = np.arange(W)[None, :].repeat(H, 0)
        row = (y - FACADE_Y1) // sh
        off = (row % 2) * (sw // 2)
        col = (x + off) // sw
        u = (x + off) % sw
        v = (y - FACADE_Y1) % sh
        h = (row * 7919 + col * 104729) % 97
        base = np.where(h < 40, I["m4"], np.where(h < 80, I["m3"], I["m4"]))
        t[:] = base
        t[(v == 1) | (u == 1)] = np.where(base == I["m4"], I["m5"], I["m4"])[(v == 1) | (u == 1)]
        t[(v == sh - 1) | (u == sw - 1)] = I["m2"]
        joint = (u == 0) | (v == 0)
        t[joint] = I["m1"]
        pits = vnoise("deckpit", 3) > 0.86
        t[pits & ~joint] = np.where(base == I["m4"], I["m3"], I["m2"])[pits & ~joint]
        moss = (vnoise("deckmoss", 13) > 0.55) & joint
        t[moss] = I["g2"]
        stain = (vnoise("deckstain", 22) > 0.8) & (vnoise("deckstain2", 3) > 0.45)
        t[stain & ~joint & (t == I["m4"])] = I["m3"]
        return t

    # ------------------------------------------------------------------ paving-walks
    def paving(self):
        p = self.L["paving-walks"]
        self.bS, self.bT, self.bc = band_coords(LEFT_BRANCH, BRANCH_W / 2)
        self.curved_walk(p, self.bS, self.bT, "bw", half=BRANCH_W / 2, below=FORE[1] + 20)
        for S, T, key in ((self.lS, self.lT, "lw"), (self.rS, self.rT, "rw")):
            self.curved_walk(p, S, T, key, below=FORE[1])
        # forecourt and axial walk last, so the curved walks start underneath the forecourt edge
        self.flag_paving(p, FORE[0], FORE[1], FORE[2], FORE[3], 24, 12, "fore")
        self.flag_paving(p, AXIS[0], FORE[3], AXIS[1], H - 1, 20, 10, "axis")
        # granite curbs along the axial walk (3 px, lit edge toward the upper-left light), joints every 22 px;
        # gives the axis a designed edge so it reads as the formal approach rather than a strip of flags
        ys = np.arange(FORE[3] + 1, H)
        for xa, cols in ((AXIS[0], ("m1", "m4", "m3")), (AXIS[1] - 2, ("m4", "m3", "m1"))):
            for i, c in enumerate(cols):
                p[ys, xa + i] = I[c]
            p[ys[(ys - FORE[3]) % 22 == 0], xa:xa + 3] = I["m1"]
            p[ys[(ys - FORE[3]) % 22 == 1], xa:xa + 3] = I["m2"]
        self.walk_mask |= p >= 0

    def flag_paving(self, p, x0, y0, x1, y1, sw, sh, key):
        ys, xs = np.mgrid[y0:y1 + 1, x0:x1 + 1]
        row = (ys - y0) // sh
        off = (row % 2) * (sw // 2)
        col = (xs - x0 + off) // sw
        u = (xs - x0 + off) % sw
        v = (ys - y0) % sh
        h = (row * 7919 + col * 104729 + len(key) * 31) % 101
        base = np.where(h < 34, I["p2"], np.where(h < 70, I["p3"], np.where(h < 92, I["p2"], I["p1"])))
        t = base.copy()
        lit = (v == 1) | (u == 1)
        t[lit] = ramp_shift_arr(base, PAVE, 1)[lit]
        dark = (v == sh - 1) | (u == sw - 1)
        t[dark] = ramp_shift_arr(base, PAVE, -1)[dark]
        joint = (u == 0) | (v == 0)
        t[joint] = I["p0"]
        pits = vnoise(key + "pit", 3)[y0:y1 + 1, x0:x1 + 1] > 0.85
        t[pits & ~joint] = ramp_shift_arr(base, PAVE, -1)[pits & ~joint]
        wear = vnoise(key + "wear", 26)[y0:y1 + 1, x0:x1 + 1]
        t[joint & (wear > 0.55)] = I["g2"]
        t[joint & (wear > 0.75)] = I["g3"]
        # missing slabs: soil + rubble chips
        miss = (h == 3) | (h == 57) | ((h == 88) & (wear > 0.5))
        sn = vnoise(key + "soil", 3)[y0:y1 + 1, x0:x1 + 1]
        t[miss & ~joint] = np.where(sn < 0.5, I["s1"], I["s2"])[miss & ~joint]
        t[miss & (v == 1)] = I["s0"]
        p[y0:y1 + 1, x0:x1 + 1] = t

    def curved_walk(self, p, S, T, key, half=WALK_W / 2, below=FORE[1] + 20):
        band = np.abs(np.nan_to_num(T, nan=99)) <= half
        band &= np.arange(H)[:, None] >= below
        agg = vnoise(key + "agg", 2)
        tone = vnoise(key + "tone", 40)
        t = np.full((H, W), I["p2"], np.int16)
        t[(agg < 0.2) | ((tone < 0.3) & (agg < 0.42))] = I["p1"]
        t[(agg > 0.8) & (tone > 0.35)] = I["p3"]
        Sn = np.nan_to_num(S)
        Tn = np.nan_to_num(T)
        joint = (np.mod(Sn, 34.0) < 1.0) & (np.abs(Tn) < half - 3)
        t[joint] = I["p0"]
        lip = (np.mod(Sn, 34.0) >= 1.0) & (np.mod(Sn, 34.0) < 2.0) & (np.abs(Tn) < half - 3)
        t[lip] = I["p3"]
        # granite curbs (3 px) both sides; the side facing the light is lit
        curb = np.abs(Tn) >= half - 3
        cj = np.mod(Sn + (Tn > 0) * 9, 22.0) < 1.0
        t[curb] = I["m2"]
        t[curb & (np.abs(Tn) < half - 2)] = I["m3"]
        t[curb & (np.abs(Tn) >= half - 1)] = I["m1"]
        t[curb & cj] = I["m1"]
        # weathering: grass in joints, a few broken-out patches showing soil
        gj = (vnoise(key + "gj", 14) > 0.6) & (joint | (curb & cj))
        t[gj] = I["g2"]
        pot = (vnoise(key + "pot", 9) > 0.86) & (np.abs(Tn) < half - 5)
        t[pot] = I["s1"]
        pr = np.pad(pot, 1)
        rimp = ~pot & (pr[2:, 1:-1] | pr[1:-1, 2:]) & (np.abs(Tn) < half - 3)
        t[rimp] = I["p3"]
        t = despeckle(t, 1)
        p[band] = t[band]

    # ------------------------------------------------------------------ terrace-walls
    def terrace(self):
        tw = self.L["terrace-walls"]
        self.col_shadows = []                      # (x_right_of_base, base_row, stylobate_front_row)
        self.fixture_mask = np.zeros((H, W), bool)  # lamp standards: never shaded by the cast-shadow layer
        self.facade(tw)
        self.wall_face(tw)
        self.balustrade(tw)
        self.stairs(tw)
        self.collapse(tw)
        b = np.zeros((H, W), bool)
        b[EDGE_Y - BAL_H:FOOT_Y, :] = True
        b[EDGE_Y - BAL_H:FOOT_Y, STAIR_X0:STAIR_X1 + 1] = False
        b[EDGE_Y - BAL_H:STAIR_BOT + 1, STAIR_X0 - CHEEK_W:STAIR_X0] = True
        b[EDGE_Y - BAL_H:STAIR_BOT + 1, STAIR_X1 + 1:STAIR_X1 + 1 + CHEEK_W] = True
        b[:FACADE_Y1 + 2, :] = True
        b[:PAV_Y1 + 2, PAV[0] - 1:PAV[1] + 2] = True
        for s0, s1 in SUBP:
            b[:SUBP_Y1 + 2, s0 - 1:s1 + 2] = True
        self.block |= b

    # ------------------------------------------------------------------ west front (top 52 rows)
    def rusticated_rows(self, y0, y1, key, dark=0):
        """Banded rustication: 6-row courses, lit upper arris, shaded lower bevel and a deep channel per course."""
        out = np.zeros((y1 - y0, W), np.int16)
        xs = np.arange(W)
        for y in range(y0, y1):
            c, v = divmod(y, 6)
            r = rng_for("rust", key, c)
            edges = np.cumsum(r.integers(38, 66, size=40)) - int(r.integers(0, 40))
            k = np.searchsorted(edges, xs, side="right")
            tone = np.where((k * 37 + c * 11) % 5 < 2, I["m3"], I["m4"])
            if v == 0:
                row = np.where(tone == I["m4"], I["m5"], I["m4"])
            elif v == 4:
                row = np.full(W, I["m2"], np.int16)
            elif v == 5:
                row = np.full(W, I["m0"], np.int16)
            else:
                row = tone.copy()
            row[np.isin(xs, edges) & (v < 4)] = I["m2"]
            out[y - y0] = row
        if dark:
            out = ramp_shift_arr(out, STONE, -dark)
        return out

    def facade(self, tw):
        """West front of the Capitol, cropped to its lowest storey: banded-rusticated wings with pilasters and
        windows, a projecting central portico of 8 columns with Attic bases on a 3-step stylobate, and two
        4-column wing porticos. Shafts run off the top of the frame. Arrangement is a readability cue, not a
        measured elevation (see manifest site_fidelity)."""
        t = self.rusticated_rows(0, FACADE_Y1, "wing")
        # water table / plinth course under the wings
        for y, c in zip(range(34, 40), ("m5", "m4", "m3", "m3", "m2", "m1")):
            t[y, :] = I[c]
        tw[:FACADE_Y1, :] = t
        # wing bays: pilasters + windows (symmetric about the axis; each window has its own condition)
        pil_l = [30, 84, 316, 370, 424]
        pils = pil_l + [W - 1 - x for x in pil_l]
        for k, px in enumerate(pils):
            self.pilaster(tw, px, 0, 34, k)
        edges_l = [0, 30, 84, 128, 276, 316, 370, 424, 476]
        bays = [(a, b) for a, b in zip(edges_l, edges_l[1:]) if b - a >= 36 and not (a == 128 and b == 276)]
        bays += [(W - 1 - b, W - 1 - a) for a, b in bays]
        states = ["glass", "boarded", "dark", "broken", "glass", "ivy", "glass", "dark", "broken", "boarded",
                  "glass", "broken"]
        for k, (a, b) in enumerate(sorted(bays)):
            self.window(tw, (a + b) // 2, states[k % len(states)], k)
        # wing porticos
        for pi, (s0, s1) in enumerate(SUBP):
            back = self.rusticated_rows(0, 34, ("subp", pi), dark=2)
            tw[0:34, s0:s1 + 1] = back[:, s0:s1 + 1]
            n = 4
            cxs = [int(round(s0 + 18 + i * (s1 - s0 - 36) / (n - 1))) for i in range(n)]
            for i in range(n - 1):                                    # dark niches between the columns
                a, b = cxs[i] + 9, cxs[i + 1] - 9
                rect(tw, a, 0, b, 27, I["k0"]); rect(tw, a, 0, a, 27, I["ink"])
                rect(tw, b, 0, b, 27, I["m1"]); rect(tw, a, 28, b, 28, I["m1"])
            # stylobate: top surface rows 34..39, riser 40..45
            for y, c in zip(range(34, SUBP_Y1), ("m5", "m4", "m4", "m4", "m4", "m3", "m3", "m2", "m2", "m2", "m1",
                                                  "m0")):
                tw[y, s0:s1 + 1] = I[c]
            for x in range(s0 + 20, s1, 26):
                tw[35:39, x] = I["m3"]
                tw[40:45, x + 9] = I["m1"]
            tw[34:SUBP_Y1, s0] = I["m5"]; tw[34:SUBP_Y1, s1] = I["m1"]
            for i, cx in enumerate(cxs):
                broken = 16 if (pi, i) == COL_BROKEN else None
                self.column(tw, cx, 37, SUBP_Y1, broken_at=broken, key=("w", pi, i))
        # central portico
        x0, x1 = PAV
        back = self.rusticated_rows(0, 34, "pav", dark=2)
        tw[0:34, x0:x1 + 1] = back[:, x0:x1 + 1]
        n = 8
        cxs = [int(round(x0 + 20 + i * (x1 - x0 - 40) / (n - 1))) for i in range(n)]
        for i in range(n - 1):
            a, b = cxs[i] + 8, cxs[i + 1] - 8
            if i == 3:                                                  # central bronze doors
                rect(tw, a, 0, b, 29, I["m2"]); rect(tw, a + 2, 0, b - 2, 28, I["k1"])
                rect(tw, a + 2, 0, a + 2, 28, I["k0"]); rect(tw, (a + b) // 2, 0, (a + b) // 2, 28, I["k0"])
                for yy in (6, 16):
                    rect(tw, a + 4, yy, (a + b) // 2 - 2, yy + 6, I["k2"])
                    rect(tw, (a + b) // 2 + 2, yy, b - 4, yy + 6, I["k2"])
                    rect(tw, a + 4, yy, (a + b) // 2 - 2, yy, I["k3"])
                    rect(tw, (a + b) // 2 + 2, yy, b - 4, yy, I["k3"])
                rect(tw, a + 2, 29, b - 2, 29, I["m4"])
            elif i in (1, 5):                                           # tall dark openings
                rect(tw, a + 3, 0, b - 3, 26, I["m2"]); rect(tw, a + 4, 0, b - 4, 25, I["k0"])
                rect(tw, a + 4, 0, a + 4, 25, I["ink"]); rect(tw, a + 3, 26, b - 3, 26, I["m4"])
            else:
                rect(tw, a, 0, b, 28, I["m1"])
                rect(tw, a, 0, a, 28, I["m0"])
        steps = (("m5", "m4", "m4", "m4", "m2", "m1"), ("m5", "m4", "m4", "m2", "m1"), ("m5", "m4", "m3", "m2", "m2",
                                                                                        "m1", "m0"))
        y = 34
        for si, st in enumerate(steps):
            for c in st:
                tw[y, x0:x1 + 1] = I[c]
                y += 1
            jx = range(x0 + 12 + si * 9, x1, 31)
            for x in jx:
                tw[y - len(st) + 1:y - len(st) + 3, x] = I["m3"]
        assert y == PAV_Y1, y
        tw[34:PAV_Y1, x0] = I["m5"]; tw[34:PAV_Y1, x0 + 1] = I["m4"]
        tw[34:PAV_Y1, x1] = I["m0"]; tw[34:PAV_Y1, x1 - 1] = I["m1"]
        for i, cx in enumerate(cxs):
            self.column(tw, cx, 36, PAV_Y1, key=("p", i))
        # a few weathered / missing ashlar blocks in the wings, heavier toward the damaged south (right) end
        rng = rng_for("facdamage")
        for k in range(22):
            x = int(rng.integers(8, W - 30)) if k < 10 else int(rng.integers(820, W - 20))
            y = int(rng.integers(1, 5)) * 6 + 1
            if PAV[0] - 4 <= x <= PAV[1] + 4 or any(s0 - 4 <= x <= s1 + 4 for s0, s1 in SUBP):
                continue
            if tw[y, x] in (I["k0"], I["k1"], I["ink"]):
                continue
            w = int(rng.integers(6, 16))
            seg = tw[y:y + 3, x:x + w]
            ok = ~np.isin(seg, [I["k0"], I["k1"], I["ink"], I["k2"]])
            seg[ok] = ramp_shift_arr(seg, STONE, -1)[ok]
            if k % 3 == 0:                                              # spalled face: dark pit, lit lower lip
                tw[y, x + 1:x + w - 1] = I["m1"]
                tw[y + 1, x + 1:x + w - 2] = I["m0"]
                tw[y + 2, x + 2:x + w - 2] = I["m4"]

    def pilaster(self, tw, cx, y0, y1, key):
        prof = ("m5", "m4", "m4", "m4", "m4", "m3", "m3", "m3", "m2", "m1")
        x0 = cx - 5
        for i, c in enumerate(prof):
            tw[y0:y1, x0 + i] = I[c]
        # base moulding stepping out 1 px per side
        for y, c in ((y1 - 4, "m5"), (y1 - 3, "m3"), (y1 - 2, "m4"), (y1 - 1, "m1")):
            tw[y, x0 - 1:x0 + 11] = I[c]
        tw[y1 - 4:y1, x0 + 10] = I["m1"]
        r = rng_for("pil", key)
        if r.random() < 0.6:                                            # grime streak
            gx = x0 + int(r.integers(2, 8)); gl = int(r.integers(8, 22))
            seg = tw[y1 - 4 - gl:y1 - 4, gx]
            seg[:] = ramp_shift_arr(seg, STONE, -1)

    def window(self, tw, cx, state, key):
        w = 16
        x0, x1 = cx - w // 2, cx + w // 2 - 1
        backup = tw[0:12, x0 - 4:x1 + 5].copy()
        self.window_body(tw, cx, state, key, x0, x1, w)
        # round-arched head with voussoir ring and keystone: the rusticated arcade is the strongest neoclassical
        # cue that fits in this crop (arrangement cue, not the measured West Front fenestration)
        cxf, cyf, r = (x0 + x1) / 2.0, 10.0, 8.0
        for y in range(0, 11):
            for x in range(x0 - 4, x1 + 5):
                d = math.hypot(x - cxf, y - cyf)
                if d <= r:
                    continue
                if d <= r + 1.2:
                    tw[y, x] = I["m2"] if x > cxf + 2 else I["m3"]
                elif d <= r + 2.6:
                    tw[y, x] = I["m4"] if x < cxf - 1 else I["m3"] if x <= cxf + 2 else I["m2"]
                    if abs(abs(x - cxf) - abs(y - cyf)) < 0.6 and y < cyf - 2:
                        tw[y, x] = I["m1"]                                # voussoir joint
                else:
                    tw[y, x] = backup[y, x - (x0 - 4)]
        stamp(tw, cx - 3, 0, ["LMMMD", "LMMMD", ".LMD.", ".LMD.", "..N.."],
              {"L": "m5", "M": "m4", "D": "m2", "N": "m3"})

    def window_body(self, tw, cx, state, key, x0, x1, w):
        rect(tw, x0 - 2, 0, x1 + 2, 25, I["m3"])                         # architrave
        rect(tw, x0 - 2, 0, x0 - 2, 25, I["m4"]); rect(tw, x1 + 2, 0, x1 + 2, 25, I["m1"])
        rect(tw, x0, 0, x1, 24, I["k1"])
        rect(tw, x0, 0, x0 + 1, 24, I["ink"])                           # left reveal faces away from the light
        rect(tw, x1, 0, x1, 24, I["m4"])                                # right reveal catches it
        rect(tw, x0 + 2, 0, x1 - 1, 2, I["k0"])
        rect(tw, cx, 3, cx, 24, I["k2"]); rect(tw, x0 + 2, 13, x1 - 1, 13, I["k2"])
        rect(tw, x0 - 3, 25, x1 + 3, 25, I["m5"]); rect(tw, x0 - 3, 26, x1 + 3, 26, I["m3"])   # sill
        rect(tw, x0 - 2, 27, x1 + 2, 27, I["m1"])
        if state == "glass":
            for j in range(5):
                setpx(tw, x0 + 4 + j, 18 - j, I["k3"]); setpx(tw, x0 + 5 + j, 18 - j, I["k2"])
        elif state == "dark":
            rect(tw, x0 + 2, 3, x1 - 1, 24, I["k0"])
        elif state == "broken":
            rect(tw, x0 + 3, 6, x0 + 9, 16, I["ink"])
            for (a, b_) in ((x0 + 3, 6), (x0 + 9, 9), (x0 + 5, 16), (x0 + 8, 14)):
                setpx(tw, a, b_, I["k3"])
            setpx(tw, x0 + 4, 7, I["k2"]); setpx(tw, x0 + 8, 15, I["k2"])
        elif state == "boarded":
            for j, y in enumerate(range(3, 24, 4)):
                rect(tw, x0 + 1, y, x1, y + 2, I["s2"] if j % 2 else I["s3"])
                rect(tw, x0 + 1, y + 2, x1, y + 2, I["s1"])
                setpx(tw, x0 + 3, y + 1, I["s0"]); setpx(tw, x1 - 2, y + 1, I["s0"])
        r = rng_for("winstreak", key)
        if r.random() < 0.7:                                            # soot / rain streak under the sill
            sx = x0 + int(r.integers(0, w - 4))
            for y in range(28, 34):
                for xx in (sx, sx + 1, sx + 2)[: 3 - (y - 28) // 3]:
                    tw[y, xx] = ramp_shift(tw[y, xx], STONE, -1)

    def column(self, tw, cx, yb, sty_front, broken_at=None, key=None):
        """A column shaft (fluted, lit from the left) on an Attic base (torus, scotia, torus, square plinth),
        base bottom at row yb. The shaft continues off the top of the frame unless broken_at is set."""
        sw = 10
        x0 = cx - sw // 2
        tones = ("m3", "m5", "m4", "m5", "m4", "m3", "m4", "m3", "m2", "m1")
        top = 0 if broken_at is None else broken_at
        r = rng_for("col", key)
        backup = tw[:, x0:x0 + sw].copy()
        for i, c in enumerate(tones):
            tw[top:yb - 8, x0 + i] = I[c]
        tw[top:yb - 8, x0 - 1] = I["m1"]                                # dark contact against the loggia
        if r.random() < 0.5:                                             # weathering streak down one flute
            fx = x0 + int(r.integers(2, 7))
            tw[int(r.integers(top + 2, top + 10)):yb - 8, fx] = I["m2"]
        if broken_at is not None:                                        # jagged broken top, lit fracture face
            jag = (0, 1, 3, 2, 4, 3, 1, 2, 0, 1)
            for i in range(sw):
                y = broken_at + jag[i]
                tw[broken_at:y, x0 + i] = backup[broken_at:y, i]          # the loggia wall shows through
                tw[y, x0 + i] = I["m5"] if i < 6 else I["m4"]
                tw[y + 1, x0 + i] = I["m3"]
            for y in range(broken_at + 6, yb - 10, 3):                  # crack down the stump
                setpx(tw, x0 + 4 + (y // 3) % 2, y, I["m1"])
        # Attic base
        rows = ((yb - 8, sw + 2, ("m5", "m4", "m2")), (yb - 7, sw + 2, ("m4", "m3", "m1")),
                (yb - 6, sw, ("m1", "m1", "m0")), (yb - 5, sw + 4, ("m5", "m4", "m2")),
                (yb - 4, sw + 4, ("m4", "m3", "m1")), (yb - 3, sw + 6, ("m5", "m5", "m2")),
                (yb - 2, sw + 6, ("m4", "m4", "m1")), (yb - 1, sw + 6, ("m4", "m3", "m1")),
                (yb, sw + 6, ("m2", "m1", "m0")))
        for y, w, (lit, mid, dark) in rows:
            a = cx - w // 2
            tw[y, a:a + w] = I[mid]
            tw[y, a:a + max(2, w // 3)] = I[lit]
            tw[y, a + w - 2:a + w] = I[dark]
        self.col_shadows.append((cx + sw // 2 + 3, yb + 1, sty_front))

    def wall_face(self, tw):
        rng = rng_for("wall")
        x = np.arange(W)
        for y in range(EDGE_Y, FOOT_Y):
            r = y - EDGE_Y
            course, v = divmod(r - 2, 8) if r >= 2 else (-1, r)
            row = np.full(W, I["m2"], np.int16)
            if r < 2:
                row[:] = I["m1"] if r == 0 else I["m0"]       # shadow under the plinth overhang
            else:
                widths = rng_for("wallc", course).integers(18, 34, size=80)
                edges = np.cumsum(widths) - (course * 13) % 30
                k = np.searchsorted(edges, x, side="right")
                tone = np.where((k * 37 + course * 11) % 5 < 2, I["m3"], I["m2"])
                row[:] = tone
                if v == 0:
                    row[:] = I["m1"]
                elif v == 1:
                    row[:] = np.where(tone == I["m3"], I["m4"], I["m3"])
                elif v == 7:
                    row[:] = np.where(tone == I["m3"], I["m2"], I["m1"])
                vj = np.isin(x, edges)
                row[vj & (v > 0)] = I["m1"]
            tw[y, :] = row
        # pilasters under the piers, each with its own wear
        for k, px in enumerate(PIERS):
            tw[EDGE_Y + 2:FOOT_Y, px - 6:px + 6] = I["m3"]
            tw[EDGE_Y + 2:FOOT_Y, px - 6] = I["m4"]
            tw[EDGE_Y + 2:FOOT_Y, px + 5] = I["m1"]
            tw[EDGE_Y + 2:FOOT_Y, px + 6] = I["m0"]
            tw[FOOT_Y - 6, px - 7:px + 7] = I["m4"]                # base moulding
            tw[FOOT_Y - 5:FOOT_Y, px - 7:px + 7] = I["m2"]
            r = rng_for("pilw", k)
            if r.random() < 0.5:                                   # chipped corner
                cy = EDGE_Y + int(r.integers(6, 30))
                tw[cy:cy + 4, px + 3:px + 6] = I["m1"]; tw[cy + 4, px + 3:px + 6] = I["m4"]
        # per-bay condition: tone, damp streaks, spalls, efflorescence, stepped cracks
        bays = self.bay_list()
        sn = vnoise("damp", 4)
        for (a, b, state, k) in bays:
            if state == "breach":
                continue
            a, b = max(0, a), min(W - 1, b)
            r = rng_for("bayface", k)
            face = np.zeros((H, W), bool)
            face[EDGE_Y + 2:FOOT_Y - 6, a + 7:b - 6] = True
            if state in ("stained", "missing", "ivy"):
                damp = face & (sn > 0.38 + 0.25 * r.random())
                tw[damp] = ramp_shift_arr(tw, STONE, -1)[damp]
            for _ in range(int(r.integers(0, 3)) + (1 if state in ("chipped", "missing") else 0)):
                sx = int(r.integers(a + 12, max(a + 13, b - 22))); sy = int(r.integers(EDGE_Y + 6, FOOT_Y - 16))
                sw_, sh_ = int(r.integers(6, 14)), int(r.integers(3, 6))
                rect(tw, sx, sy, sx + sw_, sy + sh_, I["m1"])
                rect(tw, sx + 1, sy, sx + sw_ - 1, sy, I["m0"])
                rect(tw, sx, sy + sh_, sx + sw_, sy + sh_, I["m4"])
                rect(tw, sx + sw_, sy + 1, sx + sw_, sy + sh_, I["m3"])
            if state in ("stained", "chipped") or (a > 760 and r.random() < 0.6):   # efflorescence drips
                for _ in range(int(r.integers(2, 6))):
                    ex = int(r.integers(a + 10, max(a + 11, b - 8)))
                    ey = EDGE_Y + 2 + int(r.integers(0, 6) * 8 % 32)
                    for j in range(int(r.integers(4, 12))):
                        if ey + j < FOOT_Y - 6 and tw[ey + j, ex] != I["m1"]:
                            tw[ey + j, ex] = I["m4"] if j % 3 else I["m5"]
            if state in ("chipped", "missing", "mossy") and r.random() < 0.8:      # stepped crack along joints
                cx, cy = int(r.integers(a + 14, max(a + 15, b - 14))), EDGE_Y + 3
                while cy < FOOT_Y - 2:
                    tw[cy, cx] = I["ink"]
                    if tw[cy, cx - 1] != I["m1"]:
                        tw[cy, cx - 1] = I["m4"]
                    cy += 1
                    if (cy - EDGE_Y) % 8 == 2:
                        for _ in range(int(r.integers(2, 7))):
                            cx = min(W - 2, max(1, cx + (1 if r.random() < 0.6 else -1)))
                            tw[cy, cx] = I["ink"]
        # rain streaks and grime at the foot
        for x0 in range(0, W, 3):
            if (x0 * 7919) % 11 < 3:
                ln = 6 + (x0 * 104729) % 22
                seg = tw[EDGE_Y + 2:EDGE_Y + 2 + ln, x0]
                seg[:] = ramp_shift_arr(seg, STONE, -1)
        foot = np.zeros((H, W), bool)
        foot[FOOT_Y - 7:FOOT_Y, :] = True
        gr = foot & (vnoise("wallgrime", 6) > 0.45)
        tw[gr] = ramp_shift_arr(tw, STONE, -1)[gr]
        moss = foot & (vnoise("wallmoss", 4) > 0.62)
        tw[moss & (np.arange(H)[:, None] >= FOOT_Y - 5)] = I["g1"]
        tw[moss & (np.arange(H)[:, None] >= FOOT_Y - 2) & (vnoise("wallmoss2", 2) > 0.5)] = I["g2"]

    def bay_list(self):
        """Balustrade bays between piers (and between the end piers and the stair cheeks / frame edges)."""
        if hasattr(self, "_bays"):
            return self._bays
        left = [STAIR_X0 - CHEEK_W] + PIERS_L + [-30]
        right = [STAIR_X1 + CHEEK_W] + [W - 1 - x for x in PIERS_L] + [W + 30]
        bays = []
        for k, (a, b) in enumerate(zip(left, left[1:])):
            bays.append((b, a, BAY_STATE_L[k], ("L", k)))
        for k, (a, b) in enumerate(zip(right, right[1:])):
            st = BAY_STATE_R[k]
            if st != "breach" and COLLAPSE[0] - 6 < (a + b) / 2 < COLLAPSE[1] + 6:
                st = "breach"
            bays.append((a, b, st, ("R", k)))
        self._bays = bays
        return bays

    def balustrade(self, tw):
        y0 = EDGE_Y - BAL_H
        prof = ["xLMMDx", "xxLDxx", "xxLDxx", "xLMMDx", "LMMMMD", "LMMMMD", "xLMMDx", "xxLDxx", "xxLDxx",
                "xLMMDx", "LMMMMD"]
        pitch = 7
        for (a, b, state, key) in self.bay_list():
            a0 = a + 7 if a in PIERS else max(0, a + 1)
            b0 = b - 7 if b in PIERS else min(W - 1, b - 1)
            if b0 <= a0:
                continue
            r = rng_for("bay", key)
            # rail: lit top, front, shadow line; tone shifts with the bay's condition
            rail = {"y0": "m5", "y1": "m4", "y2": "m4", "y3": "m3", "y4": "m1"}
            if state in ("stained", "missing"):
                rail = {"y0": "m4", "y1": "m3", "y2": "m3", "y3": "m2", "y4": "m1"}
            for j, kk in enumerate(("y0", "y1", "y2", "y3", "y4")):
                tw[y0 + j, a0:b0 + 1] = I[rail[kk]]
            # balusters centred in the bay (so the rhythm restarts at each pier)
            n = (b0 - a0 + 1) // pitch
            off = a0 + ((b0 - a0 + 1) - n * pitch) // 2
            tw[y0 + 5:y0 + 16, a0:b0 + 1] = I["m1"]
            tw[y0 + 13:y0 + 16, a0:b0 + 1] = I["m0"]
            missing = set()
            if state == "missing":
                s = int(r.integers(1, max(2, n - 3)))
                missing = {s, s + 1} | ({s + 2} if r.random() < 0.5 else set())
            replaced = {int(r.integers(0, n))} if state == "replaced" and n else set()
            cracked = {int(r.integers(0, n))} if state in ("chipped", "stained") and n else set()
            for i in range(n):
                bx = off + i * pitch
                if i in missing:
                    # stump: the bottom of the broken baluster, the gap shows the shadowed deck behind
                    for j in range(8, 11):
                        for q, ch in enumerate(prof[j]):
                            if ch != "x":
                                tw[y0 + 5 + j, bx + q] = I["m3"] if ch in "LM" else I["m2"]
                    tw[y0 + 13, bx + 1:bx + 5] = I["m4"]
                    continue
                cm = {"L": "m4", "M": "m3", "D": "m2"}
                if i in replaced:
                    cm = {"L": "m5", "M": "m4", "D": "m3"}
                elif state in ("stained", "missing"):
                    cm = {"L": "m3", "M": "m2", "D": "m1"}
                for j, row in enumerate(prof):
                    for q, ch in enumerate(row):
                        if ch == "x":
                            continue
                        c = cm[ch]
                        if state == "mossy" and j >= 9 and (q + i + j) % 3:
                            c = "g2" if ch == "D" else "g3"
                        tw[y0 + 5 + j, bx + q] = I[c]
                if i in cracked:
                    for j in range(3, 9):
                        setpx(tw, bx + 1 + (j - 3) // 2, y0 + 5 + j, I["ink"])
            # bottom rail / plinth of the balustrade
            for j, c in ((16, "m4"), (17, "m3"), (18, "m2"), (19, "m1")):
                tw[y0 + j, a0:b0 + 1] = I[c]
            if state == "chipped":                                      # notches knocked out of the rail
                for _ in range(2):
                    nx = int(r.integers(a0 + 4, max(a0 + 5, b0 - 8)))
                    tw[y0:y0 + 2, nx:nx + int(r.integers(3, 7))] = I["m2"]
                    tw[y0 + 2, nx:nx + 3] = I["m1"]
            if state == "mossy":
                mo = vnoise(("railmoss", key), 3, 1, W)[0]
                for x in range(a0, b0 + 1):
                    if mo[x] > 0.45:
                        tw[y0, x] = I["g3"] if mo[x] > 0.7 else I["g2"]
                        if mo[x] > 0.62:
                            tw[y0 + 1, x] = I["g2"]
            if state == "stained":                                      # drips from the rail down the balusters
                for x in range(a0, b0 + 1, 3):
                    if r.random() < 0.4:
                        ln = int(r.integers(3, 9))
                        seg = tw[y0 + 4:y0 + 4 + ln, x]
                        ok = seg != I["m1"]
                        seg[ok] = ramp_shift_arr(seg, STONE, -1)[ok]
        for k, px in enumerate(PIERS):
            x0 = px - 6
            tw[y0 - 4:EDGE_Y, x0:x0 + 12] = I["m3"]
            tw[y0 - 4:EDGE_Y, x0] = I["m4"]
            tw[y0 - 4:EDGE_Y, x0 + 11] = I["m2"]
            tw[y0 - 4:EDGE_Y, x0 + 12] = I["m1"]
            tw[y0 + 4:y0 + 14, x0 + 3:x0 + 9] = I["m2"]              # recessed panel
            tw[y0 + 4, x0 + 3:x0 + 9] = I["m1"]
            tw[y0 + 4:y0 + 14, x0 + 3] = I["m1"]
            tw[y0 - 7, x0 - 1:x0 + 13] = I["m5"]                     # cap
            tw[y0 - 6:y0 - 4, x0 - 1:x0 + 13] = I["m4"]
            tw[y0 - 4, x0 - 1:x0 + 13] = I["m2"]
            tw[y0 - 7:y0 - 3, x0 + 13] = I["m1"]
            r = rng_for("pier", k)
            if r.random() < 0.45:                                     # chipped cap corner
                cxp = x0 - 1 if r.random() < 0.5 else x0 + 10
                tw[y0 - 7:y0 - 5, cxp:cxp + 3] = I["m2"]
                tw[y0 - 5, cxp:cxp + 3] = I["m1"]
            if r.random() < 0.4:                                      # moss cushion on the cap
                tw[y0 - 7, x0 + 2:x0 + 2 + int(r.integers(3, 8))] = I["g3"]
                tw[y0 - 6, x0 + 3:x0 + 3 + int(r.integers(2, 5))] = I["g2"]
        # vines draped over the balustrade/wall are drawn in ground-detail

    def stairs(self, tw):
        top = EDGE_Y - 2
        n = 16
        step = (STAIR_BOT - top) / n
        xs = np.arange(STAIR_X0, STAIR_X1 + 1)
        wear = np.exp(-((xs - 640) / 34.0) ** 2)                      # traffic dished the centre line
        mossn = vnoise("stairmoss", 3)
        self.stair_rows = []
        for k in range(n):
            ya = int(round(top + k * step))
            yb = int(round(top + (k + 1) * step))
            h = yb - ya
            rk = rng_for("tread", k)
            joints = np.cumsum(rk.integers(26, 46, size=12)) + STAIR_X0 - int(rk.integers(0, 20))
            jmask = np.isin(xs, joints)
            blk = np.searchsorted(joints, xs)
            btone = np.where((blk * 5 + k * 3) % 7 < 2, I["m3"], I["m4"])
            for y in range(ya, yb):
                r = y - ya
                if r < h - 2:
                    row = btone.copy()
                    row[(wear > 0.55) & (r == 0)] = I["m3"]
                    row[(wear > 0.8)] = I["m3"]
                    if r == h - 3:                                   # bright nose, chipped in places
                        row[:] = I["m5"]
                        chip = (rk.random(len(xs)) < 0.06)
                        row[chip] = I["m3"]
                    row[jmask] = I["m2"]
                elif r == h - 2:
                    row = np.full(len(xs), I["m1"], np.int16)       # shadow under the nose
                else:
                    row = np.full(len(xs), I["m2"], np.int16)       # riser face
                    row[jmask] = I["m1"]
                # moss creeping in from both cheek walls
                edge = np.minimum(xs - STAIR_X0, STAIR_X1 - xs)
                mm = (edge < 3 + 9 * mossn[y, xs]) & (mossn[y, xs] > 0.45)
                row[mm & (row != I["m5"])] = np.where(mossn[y, xs] > 0.7, I["g3"], I["g2"])[mm & (row != I["m5"])]
                tw[y, STAIR_X0:STAIR_X1 + 1] = row
            self.stair_rows.append((ya, yb))
        # cracked treads and one broken-out tread corner with soil and a weed
        for (cx, cy, w) in ((580, 140, 18), (700, 168, 22), (650, 118, 12)):
            tw[cy, cx:cx + w] = I["ink"]
            tw[cy + 1, cx + 2:cx + w - 2] = I["m2"]
        ya, yb = self.stair_rows[9]
        tw[ya:yb - 1, STAIR_X1 - 26:STAIR_X1 - 6] = I["s1"]
        tw[ya, STAIR_X1 - 26:STAIR_X1 - 6] = I["s0"]
        tw[yb - 2, STAIR_X1 - 26:STAIR_X1 - 6] = I["m2"]
        stamp(tw, STAIR_X1 - 20, ya - 2, [".c.c.", "cbcbc", ".bbb."], {"c": "g4", "b": "g2"})
        # cheek walls: cap strip, inner/outer faces, newel blocks at the foot
        for x0, side in ((STAIR_X0 - CHEEK_W, -1), (STAIR_X1 + 1, 1)):
            tw[EDGE_Y - BAL_H - 6:STAIR_BOT - 14, x0:x0 + CHEEK_W] = I["m4"]
            tw[EDGE_Y - BAL_H - 6:STAIR_BOT - 14, x0] = I["m5"]
            tw[EDGE_Y - BAL_H - 6:STAIR_BOT - 14, x0 + CHEEK_W - 1] = I["m2"]
            tw[EDGE_Y - BAL_H - 7, x0:x0 + CHEEK_W] = I["m5"]
            # newel block: cap + front face
            tw[STAIR_BOT - 22:STAIR_BOT - 14, x0 - 2:x0 + CHEEK_W + 2] = I["m4"]
            tw[STAIR_BOT - 22, x0 - 2:x0 + CHEEK_W + 2] = I["m5"]
            tw[STAIR_BOT - 22:STAIR_BOT - 14, x0 + CHEEK_W + 1] = I["m2"]
            tw[STAIR_BOT - 14:STAIR_BOT + 1, x0 - 2:x0 + CHEEK_W + 2] = I["m2"]
            tw[STAIR_BOT - 14, x0 - 2:x0 + CHEEK_W + 2] = I["m1"]
            tw[STAIR_BOT - 13:STAIR_BOT - 11, x0 - 2:x0 + CHEEK_W + 2] = I["m3"]
            tw[STAIR_BOT - 1:STAIR_BOT + 1, x0 - 2:x0 + CHEEK_W + 2] = I["m1"]
            tw[STAIR_BOT - 14:STAIR_BOT + 1, x0 + CHEEK_W + 1] = I["m1"]
            tw[STAIR_BOT - 14:STAIR_BOT + 1, x0 - 2] = I["m3"]
            # the cheek wall's own face on its outer side, down to the lawn
            if side < 0:
                tw[EDGE_Y:STAIR_BOT - 22, x0 - 1] = I["m3"]
            else:
                tw[EDGE_Y:STAIR_BOT - 22, x0 + CHEEK_W] = I["m1"]
            # bronze candelabra lamp standard on the newel (verdigris patina, white globes); the south one has
            # lost its crown globe (game fiction). Placement is a readability cue, not a surveyed fixture.
            self.candelabra(tw, x0 + CHEEK_W // 2, STAIR_BOT - 19, broken=side > 0)

    def candelabra(self, tw, cx, base_y, broken=False):
        spr = [".....x.....",
               "....xLx....",
               "...xLMMx...",
               "...xLMDx...",
               "....xxx....",
               ".....B.....",
               ".xx..B..xx.",
               "xLMx.B.xLMx",
               "xLDx.B.xLDx",
               ".xx..B..xx.",
               "..b..B..k..",
               "..bBBBBBk..",
               ".....B.....",
               ".....B.....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "...bbBkk...",
               "...bBBBk...",
               "..bbBBBkk..",
               "..bBBBBBk..",
               ".bbBBBBBkk.",
               "xxxxxxxxxxx"]
        if broken:
            spr = ["...........", "...........", "...........", "....xkx....", "....xbx...."] + spr[5:]
        stamp(tw, cx - 5, base_y - len(spr) + 1, spr,
              {"x": "ink", "M": "m4", "L": "m5", "D": "m2", "B": "e2", "b": "e3", "k": "f1"})
        y0 = base_y - len(spr) + 1
        for j, row in enumerate(spr):
            for i, ch in enumerate(row):
                if ch != ".":
                    self.fixture_mask[y0 + j, cx - 5 + i] = True
        self.prop_shadow.append(("box", cx + 2, base_y + 1, 6, 2))

    def collapse(self, tw):
        """Game fiction: one terrace bay has slumped outward. The deck edge is bitten back, the wall face is gone in a
        stepped notch that shows the wall's rubble core, the exposed fill is a cut bank of soil strata with embedded
        stones and erosion rills (left half in the wall end's shadow, right half lit), and a lit talus heightfield
        spills onto the lawn carrying shadowed blocks, balusters, rail lengths and a toppled pier."""
        x0, x1 = COLLAPSE
        rng = rng_for("collapse-v02")
        self.piece_mask = np.zeros((H, W), bool)
        xs = np.arange(x0, x1 + 1)
        cxm = (x0 + x1) / 2 + 6
        half = (x1 - x0) / 2
        u = (xs - cxm) / half
        b = np.clip(1 - np.abs(u) ** 1.6, 0, 1)
        jag = (vnoise("breach", 3, 1, W)[0, x0:x1 + 1] - 0.5) * 7
        lip = np.round(EDGE_Y - BAL_H + 1 - 18 * b ** 0.8 + jag * (b > 0.05)).astype(int)
        frac = np.clip((b - 0.12) / 0.55, 0, 1)
        jw = (vnoise("breachw", 28, 1, W)[0, x0:x1 + 1] - 0.5) * 12       # broad steps, not a picket of ends
        lip_smooth = EDGE_Y - BAL_H + 1 - 18 * b ** 0.8                    # strata datum follows the scarp
        wall_top = EDGE_Y + 2 + np.round((frac * (WALL_H + 6) + jw * (frac > 0)) / 8).astype(int) * 8
        wall_top = np.where(frac <= 0, EDGE_Y, wall_top)
        self.breach_top = {}
        wob = vnoise("strata-wob", 16)
        grit = vnoise("strata-grit", 2)
        stn = vnoise("strata-stones", 4)
        turf = vnoise("strata-turf", 7)
        rill = vnoise("strata-rill", 3, 1, W)[0]
        g = self.L["ground-base"]
        # strata from the top of the fill down (fraction of the exposed height): name, SOIL index
        strata = ((0.10, 2), (0.19, 4), (0.24, -1), (0.42, 3), (0.47, 4), (0.60, 3), (0.80, 2), (9.0, 1))
        breach = np.zeros((H, W), bool)
        for i, x in enumerate(xs):
            if b[i] < 0.06:
                continue
            yl, yw = int(lip[i]), int(min(wall_top[i], FOOT_Y + 4))
            self.breach_top[int(x)] = yl
            for y in range(EDGE_Y - BAL_H - 8, max(yl, EDGE_Y - BAL_H - 8)):
                tw[y, x] = -1
            under = 3 + int(round(3 * b[i]))
            lat = u[i]
            for y in range(yl, yw):
                d = y - yl
                if d == 0:
                    c = I["m5"] if (x * 7) % 5 else I["m4"]                       # broken slab edge, lit
                elif d == 1:
                    c = I["m3"]
                elif d == 2:
                    c = I["m1"]                                                 # slab underside
                elif d < under + 2:
                    c = I["ink"] if d < 5 else I["s0"]                          # undercut shadow
                else:
                    # depth below a smooth datum parallel to the scarp top, so bands run across the bank instead
                    # of being re-stretched per column (that read as vertical planks)
                    zn = (y - (lip_smooth[i] + under + 2)) / 64.0 + (wob[y, x] - 0.5) * 0.08
                    k = next(s for lim, s in strata if zn < lim)
                    if k < 0:                                                   # gravel band
                        c = I["m2"] if grit[y, x] > 0.55 else I["m1"] if grit[y, x] > 0.3 else I["s1"]
                    else:
                        ld = lat + (grit[y, x] - 0.5) * 0.22                    # dithered, not a vertical seam
                        if ld < -0.38:
                            k -= 1 if ld > -0.7 else 2                          # in the left wall end's shadow
                        elif ld > 0.35:
                            k += 1                                              # faces the light
                        if rill[x] > 0.8 and zn > 0.12:
                            k -= 1                                              # erosion rill
                        if zn < 0.1 and grit[y, x] > 0.72:
                            k -= 1                                              # roots / humus flecks
                        c = SOIL[max(1, min(5, k))]
                        if zn > 0.7 and turf[y, x] > 0.56:                      # turf re-colonising the slump
                            c = I["g3"] if (lat > 0 and turf[y, x] > 0.66) else I["g2"]
                    if stn[y, x] > 0.8 and zn > 0.16:
                        c = I["m3"] if stn[y, x] > 0.87 else I["m2"]            # embedded stones
                tw[y, x] = c
                breach[y, x] = True
            if wall_top[i] < FOOT_Y:
                wt = int(wall_top[i])
                for y in range(max(yl + under + 2, wt - 3), wt):               # wall core rubble behind the face
                    tw[y, x] = I["m1"] if grit[y, x] > 0.5 else I["s1"] if grit[y, x] > 0.25 else I["m2"]
                tw[wt, x] = I["m4"]                                             # broken top of the remaining courses
                tw[wt + 1, x] = I["m3"]
            for y in range(max(FACADE_Y1 + 2, yl - 5), yl):                     # deck slabs behind the lip sink
                if g[y, x] in (I["m4"], I["m5"]):
                    g[y, x] = I["m3"]
        # stone outlines: lit top edge, shaded underside
        st = breach & np.isin(tw, [I["m2"], I["m3"]])
        pst = np.pad(st, 1)
        tw[st & ~pst[:-2, 1:-1]] = I["m4"]
        tw[st & ~pst[2:, 1:-1]] = I["m1"]
        # stepped wall ends: thin end faces where the broken courses step (left ends shaded, right ends lit)
        for i in range(1, len(xs)):
            if b[i] < 0.06 or b[i - 1] < 0.06:
                continue
            ta, tb = int(min(wall_top[i - 1], FOOT_Y)), int(min(wall_top[i], FOOT_Y))
            if tb > ta:
                tw[ta:tb, xs[i - 1]] = I["m1"]; tw[ta:tb, xs[i - 1] - 1] = I["m2"]
            elif ta > tb:
                tw[tb:ta, xs[i]] = I["m5"]; tw[tb:ta, xs[i] + 1] = I["m4"]
        # roots hanging out of the topsoil
        for _ in range(26):
            rx = int(rng.integers(x0 + 20, x1 - 20))
            if rx not in self.breach_top:
                continue
            ry = self.breach_top[rx] + 7
            for _ in range(int(rng.integers(5, 15))):
                if breach[ry, rx] and tw[ry, rx] in SOIL:
                    tw[ry, rx] = I["s0"]
                ry += 1
                rx += int(rng.integers(-1, 2))
        # broken balustrade ends
        y0 = EDGE_Y - BAL_H
        il = int(np.argmax(b > 0.06)); ir = len(b) - 1 - int(np.argmax(b[::-1] > 0.06))
        xl, xr = x0 + il, x0 + ir
        # left: rail snapped, fracture face turned away from the light, last baluster dangling into the breach
        tw[y0:y0 + 2, xl - 4:xl] = -1
        tw[y0 + 2, xl - 5:xl - 1] = I["m4"]
        tw[y0 + 2:y0 + 5, xl - 1] = I["m1"]
        tw[y0 + 5:y0 + 16, xl - 6:xl] = I["m1"]
        for t in range(14):
            px, py = int(round(xl - 3 + t * 0.6)), y0 + 4 + t
            belly = t in (4, 5, 6, 10, 11)
            for q, c in enumerate(("m4", "m3", "m3", "m1") if belly else ("m4", "m3", "m1")):
                setpx(tw, px + q - 1, py, I[c])
                self.piece_mask[py, px + q - 1] = True
        # right: rail end lit (faces the light), one baluster gone, the next one leaning
        tw[y0:y0 + 5, xr + 1] = I["m5"]
        tw[y0, xr + 1:xr + 4] = I["m3"]
        tw[y0 + 5:y0 + 16, xr + 2:xr + 9] = I["m1"]
        tw[y0 + 13:y0 + 16, xr + 2:xr + 9] = I["m0"]
        tw[y0 + 13:y0 + 16, xr + 4:xr + 7] = I["m3"]
        for t in range(10):
            setpx(tw, xr + 9 + t // 4, y0 + 5 + t, I["m4"]); setpx(tw, xr + 10 + t // 4, y0 + 5 + t, I["m2"])
        # talus: a lit heightfield of soil and turf
        yy, xx = np.mgrid[0:H, 0:W]
        cy = FOOT_Y + 8
        e = ((xx - cxm) / 140.0) ** 2 + ((yy - cy) / 72.0) ** 2 + (vnoise("mound2", 9) - 0.5) * 0.5
        hgt = (np.clip(1 - e, 0, None) ** 0.75 * 46 + vnoise("moundbump", 6) * 9 + vnoise("moundbump2", 15) * 12)
        mound = (e < 1) & (yy >= FOOT_Y - 6) & (tw < 0)
        gy_, gx_ = np.gradient(hgt.astype(np.float32))
        Lv = np.array([-0.55, -0.62, 0.56]); Lv /= np.linalg.norm(Lv)
        nn = np.sqrt(gx_ ** 2 + gy_ ** 2 + 1)
        shv = (-gx_ * Lv[0] - gy_ * Lv[1] + Lv[2]) / nn + (vnoise("moundtex", 2) - 0.5) * 0.06
        qs = np.quantile(shv[mound], [0.12, 0.36, 0.66, 0.9])
        q = np.digitize(shv, qs)                                               # 0..4
        soil_c = np.array([I["s0"], I["s1"], I["s2"], I["s3"], I["s4"]], np.int16)[q]
        turf_c = np.array([I["g1"], I["g2"], I["g3"], I["g4"], I["g5"]], np.int16)[q]
        rim = e > 0.62
        is_turf = mound & ((rim & (vnoise("moundturf", 7) > 0.38)) | (vnoise("moundturf2", 5) > 0.78))
        mt = np.where(is_turf, turf_c, soil_c)
        mt[mound & ~is_turf & (vnoise("moundgrit", 2) > 0.8)] = I["m2"]
        tw[mound] = mt[mound]
        self.mound_mask = mound.copy()
        self.rubble = mound.copy()
        # pieces, painter's order (far = smaller y first); bigger near the wall foot
        pieces = []
        for k in range(74):
            ty = FOOT_Y - 6 + rng.random() ** 1.5 * 98
            spread = 128 * (1 - (ty - FOOT_Y + 6) / 140)
            tx = cxm + rng.normal(0, 0.45) * spread
            pieces.append((ty, tx, k))
        for k in range(9):                                                      # resting on the slumped fill
            pieces.append((float(rng.integers(118, FOOT_Y - 8)), float(rng.integers(x0 + 50, x1 - 50)), 100 + k))
        pieces.sort()
        for ty, tx, k in pieces:
            r = rng.random()
            size = max(0.2, 1 - (ty - FOOT_Y + 8) / 100)
            if r < 0.1:
                self.baluster_piece(tw, int(tx), int(ty), rng)
            elif r < 0.17 and size > 0.35:
                self.drum_piece(tw, int(tx) - 10, int(ty), int(rng.integers(14, 24)), rng)
            elif r < 0.24 and size > 0.45:
                self.cornice_piece(tw, int(tx) - 14, int(ty), int(rng.integers(20, 34)), rng)
            elif r < 0.46:
                w = int(rng.integers(4, 9))
                self.block_3q(tw, int(tx) - w // 2, int(ty), w, 2, 3, rng)
            else:
                # sizes skew small with a few big near the wall foot, so the heap is not a field of equal slabs
                w = int(7 + rng.integers(2, 9) + 30 * size * rng.random() ** 1.8)
                d = int(rng.integers(3, 6) + 5 * size * rng.random()); h = int(rng.integers(3, 6) + 6 * size)
                self.block_3q(tw, int(tx) - w // 2, int(ty), w, d, h, rng, tilt=int(rng.integers(-2, 3)))
        # toppled pier (with its recessed panel and cap) and fallen lengths of rail, lying below the bay
        self.block_3q(tw, 1008, 210, 48, 12, 13, rng, cap=True, top_c=I["m4"])
        rect(tw, 1016, 224, 1040, 229, I["m2"]); rect(tw, 1016, 224, 1040, 224, I["m1"])
        rect(tw, 1016, 224, 1016, 229, I["m1"])
        rect(tw, 1050, 208, 1059, 221, I["m3"]); rect(tw, 1050, 208, 1059, 208, I["m5"])
        rect(tw, 1059, 209, 1060, 221, I["m1"]); rect(tw, 1050, 221, 1060, 221, I["ink"])
        self.piece_mask[208:222, 1050:1061] = True
        self.fallen_rail(tw, 892, 238, 46)
        self.fallen_rail(tw, 1064, 252, 28)
        self.fallen_rail(tw, xl + 6, 128, 20)
        # facade debris on the deck, and a drum from the broken wing-portico column
        for (bx, by, w) in ((936, 62, 16), (1072, 72, 12), (1164, 58, 18), (846, 74, 10), (994, 76, 14),
                            (1110, 60, 8)):
            self.block_3q(tw, bx, by, w, 5, 5, rng)
            self.block[by + 2:by + 10, bx:bx + w] = True
        drum = ["....LLLLLLLLLLLLLLLLLLL...",
                "..LLMMMMMMMMMMMMMMMMMMMEE.",
                ".LMMMMMMMMMMMMMMMMMMMMEeeE",
                "LMMMNMMMNMMMNMMMNMMMNMEeeE",
                "MMMMMMMMMMMMMMMMMMMMMMEecE",
                "DMMDNMMDNMMDNMMDNMMDNDEeeE",
                "DDDDDDDDDDDDDDDDDDDDDDEeeE",
                ".DDDDDDDDDDDDDDDDDDDDDEeE.",
                "..kkkkkkkkkkkkkkkkkkkkkk.."]
        dx0, dy0 = 1032, 52
        stamp(tw, dx0, dy0, drum, {"L": "m5", "M": "m4", "N": "m3", "D": "m2", "E": "m3", "e": "m4", "c": "m1",
                                   "k": "ink"})
        self.block[dy0 + 3:dy0 + 9, dx0:dx0 + 26] = True
        self.prop_shadow.append(("block", dx0, dy0, 26, 5, 4))
        self.rubble |= (tw >= 0) & (yy >= FOOT_Y) & (xx >= x0 - 20) & (xx <= x1 + 40)
        self.block |= self.rubble

    def fallen_rail(self, tw, x, y, n):
        """A length of the balustrade's top rail lying on its side, a few balusters still attached."""
        for i in range(n):
            tw[y, x + i] = I["m5"]
            tw[y + 1, x + i] = I["m4"]
            tw[y + 2, x + i] = I["m3"]
            tw[y + 3, x + i] = I["m1"]
        tw[y:y + 4, x + n - 1] = I["m1"]
        tw[y:y + 3, x] = I["m4"]
        self.piece_mask[y:y + 4, x:x + n] = True
        for i in range(2, n - 2, 7):
            if (i // 7) % 3 == 1:
                continue
            stamp(tw, x + i, y + 4, ["LMD", "LMD", ".M.", "LMD", "DDD"], {"L": "m4", "M": "m3", "D": "m1"})
            self.piece_mask[y + 4:y + 9, x + i:x + i + 3] = True
        self.prop_shadow.append(("block", x, y, n, 4, 5))

    def block_3q(self, layer, x, y, w, d, h, rng, cap=False, tilt=0, top_c=None):
        """A tumbled ashlar block in 3/4: lit top face (tone varies per block) with a bright leading arris, darker
        front face shading down to an ink contact row, a shaded right edge and chipped corners. `tilt` shears the
        top face sideways by up to 2 px so blocks do not all sit square."""
        # tone families: white marble, grey weathered marble, and warm sandstone core (the stone behind the marble
        # facing); each with its own lit arris / face / low-face steps
        fam = {I["m4"]: ("m5", "m3", "m2"), I["m3"]: ("m4", "m2", "m1"), I["m2"]: ("m3", "m1", "m0"),
               I["p3"]: ("m4", "p1", "p0"), I["p2"]: ("p3", "p1", "p0")}
        top = top_c if top_c is not None else [I["m4"], I["m3"], I["m4"], I["m3"], I["m2"], I["p3"], I["p2"],
                                               I["m4"]][int(rng.integers(0, 8))]
        lit, face, face_lo = (I[n] for n in fam[top])
        for j in range(d + h):
            sh = int(round(tilt * (1 - j / max(1, d)))) if j < d else 0
            for i in range(w):
                px, py = x + i + sh, y + j
                if not (0 <= px < W and 0 <= py < H):
                    continue
                corner = (i == 0 or i == w - 1) and (j == 0 or j == d + h - 1)
                if corner and rng.random() < 0.8:
                    continue
                if j < d:
                    c = lit if (j == 0 or i == 0) else top
                    if i >= w - 2:
                        c = face
                    if cap and j == d - 1:
                        c = face
                else:
                    c = face if j < d + h // 2 else face_lo
                    if j == d + h - 1:
                        c = I["ink"]
                    if i >= w - 2 and j < d + h - 1:
                        c = ramp_shift(face_lo, STONE, -1)
                layer[py, px] = c
                self.piece_mask[py, px] = True
        if w > 12 and rng.random() < 0.5:                       # crack across the top face
            cx = x + int(rng.integers(3, w - 3))
            for j in range(1, d):
                setpx(layer, cx + (j // 2), y + j, face)
        if w > 10 and rng.random() < 0.4:                       # chipped leading edge
            cx = x + int(rng.integers(2, w - 4))
            for i in range(int(rng.integers(2, 4))):
                setpx(layer, cx + i, y + d, face_lo); setpx(layer, cx + i, y + d - 1, face)
        if w > 14 and d > 4 and rng.random() < 0.45:           # lichen / soot patch on the top face (2x2 clusters)
            sx, sy = x + int(rng.integers(2, w - 5)), y + int(rng.integers(1, d - 2))
            c = I["g2"] if rng.random() < 0.5 else face
            for (i, j) in ((0, 0), (1, 0), (2, 0), (1, 1), (2, 1)):
                setpx(layer, sx + i, sy + j, c)
        self.prop_shadow.append(("block", x, y, w, d, h))

    def drum_piece(self, layer, x, y, ln, rng):
        """A fallen fluted column drum lying across the slope: flutes read as long bands lit from the top, the
        sawn end faces the light on the left with its bedding circle, ink contact line underneath."""
        bands = ("m4", "m5", "m4", "m5", "m3", "m4", "m3", "m2", "m1")
        if rng.random() < 0.4:
            bands = ("m3", "m4", "m3", "m4", "m2", "m3", "m2", "m1", "m0")
        for j, c in enumerate(bands):
            for i in range(ln):
                if j in (0, 8) and (i < 2 or i >= ln - 2):
                    continue
                if j in (1, 7) and (i < 1 or i >= ln - 1):
                    continue
                setpx(layer, x + i, y + j, I[c])
                self.piece_mask[min(H - 1, y + j), min(W - 1, max(0, x + i))] = True
        end = ("..L.", ".LLM", "LLMM", "LMNM", "LMNM", "LMNM", "LLMM", ".LMD", "..D.")  # sawn end, left
        stamp(layer, x - 2, y, end, {"L": "m5", "M": "m4", "N": "m3", "D": "m2"})
        for i in range(2, ln - 1):
            setpx(layer, x + i, y + 9, I["ink"])
        if rng.random() < 0.5:                                  # broken right end: jagged dark fracture
            for j in range(1, 8):
                setpx(layer, x + ln - 1 - (j % 3), y + j, I["m1"])
        self.prop_shadow.append(("block", x, y, ln, 5, 4))

    def cornice_piece(self, layer, x, y, w, rng):
        """A fallen cornice fragment: lit top bed, then the classical profile on its front face (fillet, shadow,
        a dentil course, ovolo, fascia) ending in an ink contact row. Ends are broken, not square."""
        prof = ("m5", "m4", "m4", "m3", "m5", "m1", "dent", "m0", "m4", "m3", "m2", "ink")
        for j, c in enumerate(prof):
            for i in range(w):
                lo = 2 if j < 4 else 0
                if i < lo + (j * 3 + int(x)) % 2 or i > w - 1 - (j * 5 + int(y)) % 3:
                    continue
                if c == "dent":
                    cc = I["m4"] if (i // 2) % 2 == 0 else I["ink"]
                else:
                    cc = I[c]
                if i >= w - 3 and j < 4:
                    cc = I["m3"]
                setpx(layer, x + i, y + j, cc)
                self.piece_mask[min(H - 1, y + j), min(W - 1, max(0, x + i))] = True
        if w > 22:                                              # moss in the dentil recesses
            for i in range(3, w - 4, 7):
                setpx(layer, x + i, y + 7, I["g2"])
        self.prop_shadow.append(("block", x, y, w, 4, 8))

    def baluster_piece(self, layer, x, y, rng):
        """A fallen baluster: short lathe-turned cylinder lying on its side."""
        rows = ["..LLLL....", ".LMMMMLLL.", "LMMMMMMMMD", "DMMMMMMMMD", ".DDDMMDDD.", "..kkk.kkk."]
        cm = {"L": "m5", "M": "m4", "D": "m2", "k": "ink"}
        if rng.random() < 0.5:
            rows = [r[::-1] for r in rows]
        stamp(layer, x - 5, y, rows, cm)
        self.piece_mask[y:y + 6, max(0, x - 5):x + 5] = True
        self.prop_shadow.append(("block", x - 5, y, 10, 2, 4))

    # ------------------------------------------------------------------ ground-detail
    def detail(self):
        d = self.L["ground-detail"]
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls"])
        rng = rng_for("tufts-v02")
        walk = self.walk_mask
        tw = self.L["terrace-walls"]
        yy = np.arange(H)[:, None]
        lawn = ~walk & (yy >= FOOT_Y) & (tw < 0)
        self.lawn = lawn
        # 1) tufts across the lawn: denser at walk edges, in the belts, in meadow drifts and in the lower half
        dens = 0.08 + 0.34 * vnoise("tuftd", 36) + 0.1 * np.clip((yy - 330) / 300.0, 0, 1)
        near_walk = np.zeros((H, W), bool)
        wm = walk.copy()
        for k in range(1, 9):
            near_walk[k:, :] |= wm[:-k, :]; near_walk[:-k, :] |= wm[k:, :]
            near_walk[:, k:] |= wm[:, :-k]; near_walk[:, :-k] |= wm[:, k:]
        near_walk &= ~walk
        self.near_walk = near_walk
        meadow = self.meadow & lawn
        for gy in range(FOOT_Y, H, 5):
            for gx in range(0, W, 6):
                x = gx + int(rng.integers(0, 5)); y = gy + int(rng.integers(0, 4))
                if not (0 <= x < W and 0 <= y < H) or not lawn[y, x]:
                    continue
                p = dens[y, x] + (0.35 if near_walk[y, x] else 0) + (0.2 if self.belt[y, x] else 0) + \
                    (0.4 if meadow[y, x] else 0)
                if self.mown[y, x]:
                    p *= 0.12                                            # short mown sward: few clumps
                if rng.random() > p:
                    continue
                tall = (near_walk[y, x] or meadow[y, x]) and rng.random() < 0.6
                t = TALL_TUFTS[int(rng.integers(len(TALL_TUFTS)))] if tall else TUFTS[int(rng.integers(len(TUFTS)))]
                base = comp[y, x]
                if base not in GR:
                    base = I["g3"] if base not in (I["d0"], I["d1"]) else I["g4"]
                stamp(d, x, y, t, TUFT_MAP, under=int(base), ramp=GR)
                if tall and meadow[y, x] and rng.random() < 0.35:            # seed heads on unmown grass
                    setpx(d, x + 1, y - 1, I["d1"]); setpx(d, x + 1, y, I["g6"])
        # 2) grass encroaching over walk edges (irregular overhang onto the curbs)
        edge = np.zeros((H, W), bool)
        for k in (1, 2, 3):
            edge[k:, :] |= lawn[:-k, :]; edge[:-k, :] |= lawn[k:, :]
            edge[:, k:] |= lawn[:, :-k]; edge[:, :-k] |= lawn[:, k:]
        edge &= walk
        ov = edge & (vnoise("overhang", 3) > 0.42)
        d[ov] = np.where(vnoise("ovtone", 2)[ov] > 0.5, I["g3"], I["g2"])
        d[:] = despeckle(d, 1, valid=edge)
        self.meadow_edges(d, lawn)
        # 3) verge planting along the curved walks and the axial walk; clover and wildflower drifts on the lawn
        self.verge(d, rng, lawn)
        self.lawn_features(d, rng, lawn)
        # 4) shrubs along the wall-foot strip and in the tree belts
        for x in range(4, W, 22):
            if STAIR_X0 - CHEEK_W - 6 <= x <= STAIR_X1 + CHEEK_W + 6 or COLLAPSE[0] - 8 <= x <= COLLAPSE[1] + 10:
                continue
            if rng.random() < 0.72:
                self.shrub(d, x + int(rng.integers(-4, 5)), FOOT_Y + 6 + int(rng.integers(0, 4)),
                           int(rng.integers(7, 12)), ("wallshrub", x), ramp=BOX if x % 3 else None)
        bp = np.pad(self.belt, 20)
        margin = self.belt & ~(bp[40:, 20:-20] & bp[:-40, 20:-20] & bp[20:-20, 40:] & bp[20:-20, :-40])
        for k in range(200):
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 20, H))
            if margin[y, x] and not walk[y, x]:
                self.shrub(d, x, y, int(rng.integers(6, 13)), ("beltshrub", k),
                           ramp=(FOL, BOX, CON)[k % 3])
        for k, (x, y, r) in enumerate(((912, 160, 9), (1040, 128, 12), (1080, 206, 8), (948, 232, 7),
                                       (1094, 160, 10), (872, 206, 6), (990, 118, 8))):
            self.shrub(d, x, y, r, ("rubbleshrub", k), ramp=GR[:7])
        # 5) leaf litter at belt edges and under the canopies near walks; fallen branches
        self.litter(d, rng, lawn)
        # moss on rubble top faces and weeds at the foot of tumbled blocks
        rub = self.rubble & (tw >= 0)
        tops = rub & np.isin(tw, [I["m4"], I["m3"]])
        mo = tops & (vnoise("rubmoss", 3) > 0.74)
        d[mo] = np.where(vnoise("rubmoss2", 2)[mo] > 0.5, I["g3"], I["g4"])
        stone = rub & np.isin(tw, [I["m1"], I["m0"], I["ink"]])
        foot = stone & ~np.roll(stone, -1, axis=0)
        fy, fx = np.nonzero(foot)
        for i in range(0, len(fy), 9):
            if rng.random() < 0.6:
                stamp(d, int(fx[i]) - 2, int(fy[i]) - 2, TUFTS[int(rng.integers(len(TUFTS)))], TUFT_MAP,
                      under=I["g3"], ramp=GR)
        # 6) vines and ivy, per balustrade bay condition
        y0 = EDGE_Y - BAL_H
        for (a, b, state, key) in self.bay_list():
            if state == "breach":
                continue
            pr = {"ivy": 0.95, "mossy": 0.55, "clean": 0.1, "replaced": 0.18, "missing": 0.45}.get(state, 0.3)
            for x in range(max(2, a + 8), min(W - 2, b - 7), 4 if state == "ivy" else 5):
                if rng.random() > pr:
                    continue
                if state == "ivy":
                    self.vine(d, x, y0 + int(rng.integers(-2, 6)), int(24 + rng.integers(0, 30)), rng, dense=True)
                else:
                    self.vine(d, x, EDGE_Y - 6, int(6 + rng.integers(0, 26)), rng)
            if state == "ivy":                                          # leaf mass smothering the rail
                ivn = vnoise(("ivymass", key), 3, 1, W)[0]
                for x in range(max(0, a + 10), min(W, b - 9)):
                    for y in range(y0 - 3, y0 + 9):
                        v = ivn[x] * 10 - (y - y0 + 3) * 0.6
                        if v > 4.2 and (x + 2 * y) % 3:
                            d[y, x] = I["g4"] if (x + y) % 4 == 0 else I["g3"] if (x * 3 + y) % 5 else I["g2"]
        for x in range(COLLAPSE[0] + 10, COLLAPSE[1] - 10, 9):
            yt = self.breach_top.get(x, EDGE_Y)
            self.vine(d, x, yt, int(rng.integers(6, 20)), rng)
        # ivy on the west front, heaviest toward the damaged south (right) end; not over the column bases
        fvn = vnoise("facvine", 30, 1, W)[0]
        for x in range(6, W, 4):
            fv = fvn[x] + (0.25 if x > 820 else 0)
            if fv > 0.8 and rng.random() < 0.8:
                self.vine(d, x, 0, int(rng.integers(8, 26)), rng, stop=30)
        # 7) cracks on paving and deck; small debris chips
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls", "ground-detail"])
        for k in range(70):
            if k < 24:
                x = int(rng.integers(20, W - 20)); y = int(rng.integers(FACADE_Y1 + 4, EDGE_Y - BAL_H - 4))
                if tw[y, x] >= 0 or y < PAV_Y1 + 2 and PAV[0] <= x <= PAV[1]:
                    continue
            else:
                x = int(rng.integers(0, W)); y = int(rng.integers(FORE[1], H))
                if not walk[y, x]:
                    continue
            self.crack(d, comp, x, y, int(rng.integers(8, 30)), rng)
        for k in range(160):
            x = int(rng.integers(0, W)); y = int(rng.integers(FACADE_Y1, H))
            near_rubble = abs(x - 990) < 170 and FOOT_Y - 70 < y < 300
            if not (walk[y, x] or near_rubble) or rng.random() < 0.4 and not near_rubble:
                continue
            if tw[y, x] >= 0 and not near_rubble:
                continue
            c = I["m4"] if rng.random() < 0.5 else I["m3"]
            setpx(d, x, y, c); setpx(d, x + 1, y, I["m2"]); setpx(d, x, y + 1, I["m1"])
        # 8) survey paint on paving: orange grid ticks and arrows toward the post
        for (x, y) in ((760, 220), (790, 236), (708, 214)):
            d[y, x:x + 5] = I["o1"]; d[y - 2:y + 3, x + 2] = I["o1"]
        for (x, y) in ((690, 300), (690, 420), (690, 540)):
            stamp(d, x - 3, y, ["..o..", ".ooo.", "o.o.o", "..o..", "..o.."], {"o": "o1"})
        # cables from the post to the collapse sensors and to the first beacon
        px, py = POST
        for a, b in (((px + 2, py - 12), (968, 232)), ((px + 20, py), (1014, 452)), ((px - 24, py - 4), (860, 404))):
            n = int(max(abs(b[0] - a[0]), abs(b[1] - a[1])))
            for t in range(n):
                x = int(a[0] + (b[0] - a[0]) * t / n + 2 * math.sin(t / 9))
                y = int(a[1] + (b[1] - a[1]) * t / n)
                setpx(d, x, y, I["k0"])
                if t % 5 == 0:
                    setpx(d, x, y - 1, I["k1"])

    def meadow_edges(self, d, lawn):
        """Give the rough drifts height. Along a drift's lower (south) edge the blade fronts face away from the
        upper-left light and drop a short shadow onto the short grass; along its upper edge lit tips stand up.
        Seed heads sit on top in small clusters, not single texels."""
        m = self.meadow & lawn
        pm = np.pad(m, 1)
        south = m & ~pm[2:, 1:-1]
        north = m & ~pm[:-2, 1:-1]
        ys, xs = np.nonzero(south)
        for y, x in zip(ys.tolist(), xs.tolist()):
            if (x + y // 3) % 4 == 3:                                   # gaps between blade clumps
                continue
            h = 2 + ((x * 7 + y * 3) % 5 > 2) + ((x * 13) % 7 == 0)     # 2..4 rows
            d[y, x] = I["g3"]
            for j in range(h):
                yj = y + 1 + j
                if yj >= H or not lawn[yj, x] or self.walk_mask[yj, x]:
                    break
                d[yj, x] = I["g2"] if j < h - 1 else I["g1"]
        ys, xs = np.nonzero(north)
        for y, x in zip(ys.tolist(), xs.tolist()):
            if (x * 5 + y) % 4 == 0:
                continue
            d[y, x] = I["g5"]
            if (x * 3) % 4 == 1 and y > 0 and lawn[y - 1, x]:
                d[y - 1, x] = I["g6"]
        r = rng_for("seeds")
        ys, xs = np.nonzero(m)
        for k in r.choice(len(ys), size=len(ys) // 90, replace=False):
            y, x = int(ys[k]), int(xs[k])
            setpx(d, x, y, I["d1"]); setpx(d, x + 1, y, I["g7"]); setpx(d, x, y + 1, I["g3"])

    def verge(self, d, rng, lawn):
        """Purposeful planting where people walk: clipped box and ferns on the belt side of the curved walks,
        perennials and small beds on the lawn side, low drifts along both edges of the axial walk (kept clear)."""
        curves = [(self.lc, WALK_W / 2, "L"), (self.rc, WALK_W / 2, "R"), (self.bc, BRANCH_W / 2, "B")]
        self.verge_items = []
        for c, hw, key in curves:
            tang = np.gradient(c, axis=0)
            tang /= np.linalg.norm(tang, axis=1, keepdims=True)
            nrm = np.stack([-tang[:, 1], tang[:, 0]], 1)
            seg = np.r_[0, np.cumsum(np.hypot(*np.diff(c, axis=0).T))]
            s = float(rng.uniform(4, 16))
            while s < seg[-1]:
                k = int(np.searchsorted(seg, s))
                s += float(rng.uniform(13, 30))
                if k >= len(c):
                    break
                p = c[k]
                if p[1] < FORE[3] + 6 or p[1] > H + 6:
                    continue
                for side in (-1, 1):
                    q = p + nrm[k] * side * (hw + 12)
                    qx, qy = int(q[0]), int(q[1])
                    if not (2 <= qx < W - 2 and FOOT_Y + 8 <= qy < H - 2):
                        continue
                    outer = bool(self.belt[qy, qx])
                    if rng.random() > (0.82 if outer else 0.4):
                        continue
                    if outer:
                        kind = ("box", "box", "fern", "bed", "shrub")[int(rng.integers(0, 5))]
                    else:
                        kind = ("perennial", "perennial", "boxsmall", "bed")[int(rng.integers(0, 4))]
                    r = {"box": 8, "shrub": 10, "fern": 6, "bed": 7, "perennial": 5, "boxsmall": 5}[kind]
                    r += int(rng.integers(-1, 3))
                    off = hw + r * 0.75 + 4
                    q = p + nrm[k] * side * off
                    qx, qy = int(q[0]), int(q[1])
                    if not (0 <= qx < W and 0 <= qy < H) or self.walk_mask[qy, qx]:
                        continue
                    self.verge_item(d, kind, qx, qy, r, rng, (key, int(s), side))
        # axial walk: low drifts 8+ px off each curb, never on the walk
        y = FORE[3] + 14
        while y < H - 6:
            y += int(rng.integers(16, 34))
            for side in (-1, 1):
                if rng.random() > 0.5:
                    continue
                x = AXIS[0] - 9 - int(rng.integers(0, 10)) if side < 0 else AXIS[1] + 9 + int(rng.integers(0, 10))
                if 0 <= y < H and lawn[y, x]:
                    kind = ("perennial", "bed", "perennial", "clover")[int(rng.integers(0, 4))]
                    self.verge_item(d, kind, x, y, 4, rng, ("axis", y, side))

    def verge_item(self, d, kind, x, y, r, rng, key):
        self.verge_items.append((kind, x, y))
        if kind in ("box", "boxsmall", "shrub"):
            self.shrub(d, x, y, r, ("verge",) + key, ramp=BOX if kind != "shrub" else FOL)
            if kind == "box" and rng.random() < 0.3:                     # a few box balls hold white blossom
                for _ in range(3):
                    fx, fy = x + int(rng.integers(-r // 2, r // 2 + 1)), y - r // 2 - int(rng.integers(0, r // 2 + 1))
                    setpx(d, fx, fy, I["m5"]); setpx(d, fx + 1, fy, I["m4"])
        elif kind == "fern":
            n = int(rng.integers(6, 9))
            for i in range(n):
                a = math.pi * (0.1 + 0.8 * i / (n - 1)) + rng.uniform(-0.15, 0.15)
                ln = r + int(rng.integers(0, 3))
                for t in range(ln):
                    fx = int(round(x + math.cos(a) * t * 1.2)); fy = int(round(y - math.sin(a) * t * 0.8))
                    setpx(d, fx, fy, I["g4"] if t > ln // 2 else I["g3"])
                    if t % 2 == 1 and t < ln - 1:
                        setpx(d, fx, fy + 1, I["g2"])
                setpx(d, int(round(x + math.cos(a) * ln * 1.2)), int(round(y - math.sin(a) * ln * 0.8)), I["g5"])
            setpx(d, x, y, I["g1"]); setpx(d, x + 1, y, I["g1"])
            self.prop_shadow.append(("shrub", x, y, r))
        elif kind in ("bed", "perennial", "clover"):
            col = ("y0", "fl", "bl", "m5", "o2", "y0")[int(rng.integers(0, 6))]
            if kind == "clover":
                col = "m5"
            leaves = 10 if kind == "perennial" else 16
            for _ in range(leaves):
                fx = x + int(rng.integers(-r, r + 1)); fy = y + int(rng.integers(-r // 2, r // 2 + 1))
                if self.walk_mask[min(H - 1, fy), min(W - 1, max(0, fx))]:
                    continue
                setpx(d, fx, fy, I["g4"]); setpx(d, fx + 1, fy, I["g3"]); setpx(d, fx, fy + 1, I["g2"])
            heads = int(rng.integers(5, 9)) if kind != "bed" else int(rng.integers(9, 15))
            for _ in range(heads):
                fx = x + int(rng.integers(-r, r + 1)); fy = y - int(rng.integers(0, r // 2 + 3))
                if self.walk_mask[min(H - 1, fy + 1), min(W - 1, max(0, fx))]:
                    continue
                setpx(d, fx, fy, I[col]); setpx(d, fx + 1, fy, I[col] if col != "m5" else I["m4"])
                setpx(d, fx, fy + 1, I["g1"])

    def lawn_features(self, d, rng, lawn):
        """Open-lawn interest without props: clover cushions, dandelion drifts and worn scuffs."""
        inner = lawn & self.inner_lawn
        tries = 0
        n = 0
        while n < 46 and tries < 3000:
            tries += 1
            x = int(rng.integers(0, W)); y = int(rng.integers(300, H - 6))
            if not inner[y, x] or AXIS[0] - 8 <= x <= AXIS[1] + 8:
                continue
            n += 1
            r = int(rng.integers(4, 9))
            base = self.L["ground-base"][y, x]
            hi = ramp_shift(base if base in GR else I["g3"], GR, 1)
            lo = ramp_shift(base if base in GR else I["g3"], GR, -1)
            bn = vnoise(("clover", n), 2, 2 * r + 3, 2 * r + 3)
            for j in range(-r, r + 1):
                for i in range(-r - 2, r + 3):
                    e = (i / (r + 1.5)) ** 2 + (j / (r * 0.7 + 0.5)) ** 2 + (bn[j + r, i + r] - 0.5) * 0.6
                    if e < 1 and lawn[min(H - 1, y + j), min(W - 1, max(0, x + i))]:
                        setpx(d, x + i, y + j, hi if e < 0.7 else (lo if j > 0 and i > 0 else hi))
            for _ in range(int(rng.integers(2, 6))):
                fx, fy = x + int(rng.integers(-r + 1, r)), y + int(rng.integers(-r // 2, r // 2 + 1))
                setpx(d, fx, fy, I["m5"]); setpx(d, fx, fy + 1, I["g2"])
        mead = lawn & self.meadow
        for k in range(30):                                              # wildflower drifts in the rough meadow
            for _ in range(80):
                x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 40, H - 4))
                if (mead[y, x] if k < 24 else inner[y, x]) and not (AXIS[0] - 6 <= x <= AXIS[1] + 6):
                    break
            else:
                continue
            col, col2 = (("y0", "o2"), ("fl", "bl"), ("m5", "m4"), ("y0", "y0"), ("bl", "fl"))[k % 5]
            for _ in range(int(rng.integers(14, 34))):
                fx = x + int(rng.normal(0, 11)); fy = y + int(rng.normal(0, 5))
                if 0 <= fx < W - 1 and 0 <= fy < H - 1 and lawn[fy, fx] and not (AXIS[0] - 2 <= fx <= AXIS[1] + 2):
                    setpx(d, fx, fy, I[col]); setpx(d, fx + 1, fy, I[col2]); setpx(d, fx, fy + 1, I["g2"])
        # self-sown shrub clumps on the meadow edges (ruin succession), each with a flowering skirt
        self.lawn_shrubs = []
        tries = 0
        while len(self.lawn_shrubs) < 8 and tries < 4000:
            tries += 1
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 60, H - 10))
            if not mead[y, x] or abs(x - 640) < 110 or self.mown[max(0, y - 20):y + 20, max(0, x - 20):x + 20].any():
                continue
            if any(abs(x - a) + abs(y - b) < 120 for a, b in self.lawn_shrubs + list(getattr(self, "stumps", []))):
                continue
            self.lawn_shrubs.append((x, y))
            r = int(rng.integers(10, 15))
            ramp = (ELM, BOX, FOL)[len(self.lawn_shrubs) % 3]
            for j in range(int(rng.integers(1, 3))):                   # companions, smaller, offset down-right
                ox, oy = int(rng.integers(8, 16)) * (1 if j == 0 else -1), int(rng.integers(3, 9))
                if 0 <= x + ox < W and 0 <= y + oy < H and lawn[y + oy, x + ox]:
                    self.shrub(d, x + ox, y + oy, r - 4 - 2 * j, ("lawnshrub", x, y, j), ramp=ramp)
            self.shrub(d, x, y, r, ("lawnshrub", x, y), ramp=ramp)
            for _ in range(10):
                fx, fy = x + int(rng.integers(-r - 3, r + 4)), y + int(rng.integers(0, 4))
                if 0 <= fx < W - 1 and fy < H and lawn[fy, fx]:
                    setpx(d, fx, fy, I["fl"] if (fx + fy) % 2 else I["m5"]); setpx(d, fx + 1, fy, I["g3"])

    def litter(self, d, rng, lawn):
        """Leaf litter at belt margins and under canopies near the walks; a few fallen branches."""
        bp = np.pad(self.belt, 14)
        near_belt = (bp[28:, 14:-14] | bp[:-28, 14:-14] | bp[14:-14, 28:] | bp[14:-14, :-28]) & ~self.belt
        cols = (("s2", "s3"), ("o0", "o2"), ("d1", "s3"), ("s1", "s2"), ("d0", "d1"))
        k = 0
        for _ in range(9000):
            if k >= 520:
                break
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 10, H - 2))
            ok = (near_belt[y, x] and lawn[y, x]) or (self.walk_mask[y, x] and self.belt_near_walk[y, x])
            if not ok or AXIS[0] - 2 <= x <= AXIS[1] + 2:
                continue
            k += 1
            a, b = cols[int(rng.integers(0, len(cols)))]
            for _ in range(int(rng.integers(2, 6))):
                fx, fy = x + int(rng.integers(-4, 5)), y + int(rng.integers(-2, 3))
                if 0 <= fx < W - 1 and 0 <= fy < H and not (AXIS[0] - 2 <= fx <= AXIS[1] + 2):
                    setpx(d, fx, fy, I[a]); setpx(d, fx + 1, fy, I[b])
        branches = ((150, 452, 0.3, 30), (322, 640, -0.25, 24), (1130, 520, 0.5, 34), (968, 664, -0.15, 22),
                    (420, 330, 0.1, 18))
        for bx, by, ang, ln in branches:
            if not lawn[by, bx]:
                continue
            for t in range(ln):
                x = int(round(bx + math.cos(ang) * t)); y = int(round(by + math.sin(ang) * t))
                setpx(d, x, y, I["s2"]); setpx(d, x, y + 1, I["s1"]); setpx(d, x, y + 2, I["s0"])
                if t in (ln // 3, 2 * ln // 3):                          # twigs
                    for q in range(1, 6):
                        setpx(d, x + q, y - q, I["s1"])
                        if q == 5:
                            stamp(d, x + q - 2, y - q - 2, [".c.", "cbc", ".b."], {"c": "g4", "b": "g2"})
            self.prop_shadow.append(("box", bx + 2, by + 3, ln, 2))

    def shrub(self, layer, cx, cy, r, key, ramp=None):
        ramp = ramp or [I[n] for n in ("f0", "f1", "g1", "g2", "g3", "g4", "g5")]
        m, idx, (x0, y0) = self.canopy_raster(cx, cy - r // 2, r, key, ramp=ramp, squash=0.75, tex_cell=2)
        sub = layer[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
        sub[m] = idx[m]
        self.prop_shadow.append(("shrub", cx, cy, r))

    def vine(self, layer, x, y, ln, rng, dense=False, stop=None):
        stop = FOOT_Y - 1 if stop is None else stop
        for j in range(ln):
            yy = y + j
            if yy >= stop or yy >= H:
                break
            x += int(rng.integers(-1, 2)) if j % 3 == 0 else 0
            setpx(layer, x, yy, I["g1"])
            if j % 3 == 0 or (dense and j % 3 == 1):
                side = 1 if (j // 3) % 2 else -1
                setpx(layer, x + side, yy, I["g3"])
                setpx(layer, x + side, yy - 1, I["g4"])
                setpx(layer, x + 2 * side, yy, I["g2"])
                setpx(layer, x + side, yy + 1, I["g1"])
                if dense:
                    setpx(layer, x - side, yy + 1, I["g3"]); setpx(layer, x - side, yy, I["g2"])

    def crack(self, layer, comp, x, y, n, rng):
        ang = rng.uniform(0, math.pi)
        for _ in range(n):
            if not (0 <= x < W - 1 and 1 <= y < H):
                return
            base = comp[y, x]
            ramp = STONE if base in STONE else PAVE
            layer[y, x] = ramp_shift(base, ramp, -2)
            if layer[y - 1, x] < 0 and rng.random() < 0.35:
                layer[y - 1, x] = ramp_shift(comp[y - 1, x], ramp, 1)
            ang += rng.normal(0, 0.45)
            x += int(round(math.cos(ang))); y += int(round(math.sin(ang)))

    # ------------------------------------------------------------------ canopies (4 tree families)
    @staticmethod
    def quant(ramp):
        n = len(ramp)
        return {5: [-0.05, 0.3, 0.6, 0.85], 6: [-0.08, 0.22, 0.48, 0.7, 0.9],
                7: [-0.1, 0.18, 0.4, 0.6, 0.78, 0.95]}.get(n, list(np.linspace(-0.1, 0.95, n - 1)))

    def canopy_raster(self, cx, cy, r, key, ramp=FOL, squash=0.86, tex_cell=3, shape="round"):
        rng = rng_for("canopy", key)
        if shape == "spread":                                           # elm: three sub-crowns, flatter, ragged
            blobs = []
            for sx, sy, sr in ((-0.52, 0.06, 0.55), (0.0, -0.14, 0.6), (0.52, 0.08, 0.53)):
                bx0 = (sx + rng.uniform(-0.08, 0.08)) * r
                by0 = (sy + rng.uniform(-0.06, 0.06)) * r * squash
                rb0 = sr * r * rng.uniform(0.9, 1.1)
                blobs.append((bx0, by0, rb0 * 0.78))
                k = int(rng.integers(5, 8))
                for i in range(k):
                    a = 2 * math.pi * i / k + rng.uniform(-0.4, 0.4)
                    dd = rb0 * rng.uniform(0.45, 0.72)
                    blobs.append((bx0 + math.cos(a) * dd, by0 + math.sin(a) * dd * squash,
                                  rb0 * rng.uniform(0.3, 0.46)))
            R = int(r * 1.5) + 4
        elif shape == "small":                                          # magnolia: compact, glossy, few big lobes
            blobs = [(0.0, 0.0, r * 0.72)]
            k = int(rng.integers(5, 8))
            for i in range(k):
                a = 2 * math.pi * i / k + rng.uniform(-0.3, 0.3)
                dd = r * rng.uniform(0.38, 0.52)
                blobs.append((math.cos(a) * dd, math.sin(a) * dd * squash, r * rng.uniform(0.38, 0.5)))
            R = int(r * 1.25) + 4
        else:                                                           # oak / shrubs: round, many lobes
            blobs = [(0.0, 0.0, r * 0.74)]
            k = int(rng.integers(7, 11))
            for i in range(k):
                a = 2 * math.pi * i / k + rng.uniform(-0.3, 0.3)
                dd = r * rng.uniform(0.42, 0.6)
                blobs.append((math.cos(a) * dd, math.sin(a) * dd * squash, r * rng.uniform(0.32, 0.46)))
            for i in range(3):
                blobs.append((rng.uniform(-0.3, 0.3) * r, -rng.uniform(0.1, 0.38) * r, r * rng.uniform(0.28, 0.4)))
            R = int(r * 1.25) + 4
        yy, xx = np.mgrid[-R:R + 1, -R:R + 1].astype(np.float32)
        zbest = np.full(yy.shape, -1e9, np.float32)
        nx = np.zeros_like(yy); ny = np.zeros_like(yy); nz = np.zeros_like(yy)
        for bi, (bx, by, rb) in enumerate(blobs):
            ph1, ph2 = rng.uniform(0, 6.3), rng.uniform(0, 6.3)
            ang = np.arctan2(yy - by, xx - bx)
            rough = 0.12 if shape == "spread" else 0.08
            rr = rb * (1 + rough * np.sin(ang * 7 + ph1) + 0.05 * np.sin(ang * 12 + ph2))
            d2 = ((xx - bx) ** 2 + (yy - by) ** 2) / (rr ** 2)
            inside = d2 < 1
            z = np.sqrt(np.clip(1 - d2, 0, 1)) * rb + by * 0.35 + rb * 0.3
            take = inside & (z > zbest)
            zbest[take] = z[take]
            nx[take] = ((xx - bx) / rr)[take]; ny[take] = ((yy - by) / rr)[take]
            nz[take] = np.sqrt(np.clip(1 - d2, 0, 1))[take]
        m = zbest > -1e8
        L = np.array([-0.55, -0.75, 0.85]); L /= np.linalg.norm(L)
        sh = nx * L[0] + ny * L[1] + nz * L[2]
        tex = vnoise(("leaf", key), tex_cell, yy.shape[0], yy.shape[1])
        sh = sh + (tex - 0.5) * (0.36 if shape == "small" else 0.42)
        q = np.digitize(sh, self.quant(ramp))
        idx = np.array(ramp, np.int16)[np.clip(q, 0, len(ramp) - 1)]
        if shape == "spread":                                           # dark pockets between the sub-crowns
            pock = m & (vnoise(("pocket", key), 4, yy.shape[0], yy.shape[1]) > 0.8) & (q <= 3)
            idx[pock] = ramp[1]
        p = np.pad(m, 1)
        rim = m & (~p[2:, 1:-1] | ~p[1:-1, 2:])
        idx[rim] = ramp[0]
        idx = np.where(m, idx, -1).astype(np.int16)
        idx = despeckle(idx, 2, valid=m)
        self._last_q = (q, m)
        x0, y0 = int(cx) - R, int(cy) - R
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(W, x0 + 2 * R + 1), min(H, y0 + 2 * R + 1)
        mm = m[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        ii = idx[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        return mm, ii, (cx0, cy0)

    def cone_raster(self, cx, base_y, r, key, ramp=CON):
        """Holly / conifer: a tiered cone seen from above-front, tip at the top, lit from the left; each tier's
        underside falls into shadow."""
        rng = rng_for("cone", key)
        h = int(r * 2.3)
        tiers = int(rng.integers(4, 6))
        R = r + 4
        yy, xx = np.mgrid[0:h + 1, -R:R + 1].astype(np.float32)
        t = yy / h
        tp = (t * tiers + rng.uniform(0, 0.3)) % 1.0
        edge = vnoise(("coneedge", key), 2, h + 1, 2 * R + 1)
        hw = r * (0.1 + 0.9 * t ** 0.85) * (0.68 + 0.32 * tp) + (edge - 0.5) * 3.2
        m = np.abs(xx) <= hw
        nxn = np.clip(xx / np.maximum(hw, 1), -1, 1)
        tex = vnoise(("conetex", key), 2, h + 1, 2 * R + 1)
        sh = -0.6 * nxn + 0.42 * (1 - tp) + (tex - 0.5) * 0.4 - 0.12 * t
        q = np.digitize(sh, [-0.3, 0.05, 0.35, 0.62])
        idx = np.array(ramp, np.int16)[np.clip(q, 0, len(ramp) - 1)]
        under = m & (tp > 0.84)
        idx[under] = np.where(nxn[under] > 0.1, ramp[0], ramp[1])
        p = np.pad(m, 1)
        rim = m & (~p[2:, 1:-1] | ~p[1:-1, 2:])
        idx[rim] = ramp[0]
        idx = np.where(m, idx, -1).astype(np.int16)
        idx = despeckle(idx, 2, valid=m)
        x0, y0 = int(cx) - R, int(base_y) - h
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(W, x0 + 2 * R + 1), min(H, y0 + h + 1)
        mm = m[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        ii = idx[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        return mm, ii, (cx0, cy0)

    @staticmethod
    def canopy_centre(fam, x, y, r):
        """(centre x, centre y, reach) of a family's canopy for a trunk base at (x, y)."""
        if fam == "holly":
            return x, y - 6 - 1.15 * r, 1.15 * r
        if fam == "magnolia":
            return x, y - 8 - 0.85 * r, 0.95 * r
        if fam == "elm":
            return x, y - 12 - 0.8 * r, 1.2 * r
        return x, y - 10 - 0.9 * r, 0.92 * r

    def tree_sites(self):
        """Four families in irregular clumps and glades. Trunks stay clear of every walk so canopies only overhang
        the walk edges (Olmsted: trees frame the lawn; the central axis stays open). Specimen magnolias and hollies
        stand nearer the walks; oaks and elms fill the belt interiors."""
        rng = rng_for("treesites-v02")
        clump = vnoise("treeclump", 80)
        famn = vnoise("treefam", 150)
        curves = [(self.lc, WALK_W / 2), (self.rc, WALK_W / 2), (self.bc, BRANCH_W / 2)]
        cands = []
        for gy in range(FOOT_Y + 50, H + 70, 20):
            for gx in range(-24, W + 30, 20):
                x = gx + int(rng.integers(-8, 9)); y = gy + int(rng.integers(-7, 8))
                cx_, cy_ = min(W - 1, max(0, x)), min(H - 1, max(0, y))
                if not self.belt[cy_, cx_]:
                    continue
                if 820 < x < W - 90 and y < 400:          # keep the collapsed bay and its rubble readable
                    continue
                if 90 < x < W - 90 and y < 330:           # terrace-foot margin stays open lawn
                    continue
                cands.append((x, y))
        sites = []
        n_holly = 0
        for oi in rng.permutation(len(cands)):
            x, y = cands[oi]
            cx_, cy_ = min(W - 1, max(0, x)), min(H - 1, max(0, y))
            if clump[cy_, cx_] < 0.3 and rng.random() < 0.9:              # glades
                continue
            dwalk = min(np.hypot(c[:, 0] - x, c[:, 1] - y).min() - hw for c, hw in curves)
            fv = famn[cy_, cx_] + rng.uniform(-0.25, 0.25)
            # broad-crowned oaks and elms make the belts; magnolias and hollies are specimens near the walks.
            # Hollies are capped so they read as accents, not as a conifer block (the earlier draft drew 39).
            if dwalk < 56 and rng.random() < 0.5:
                fam = "magnolia" if rng.random() < 0.6 else "holly"
            else:
                fam = "oak" if fv < 0.5 else "elm" if fv < 0.9 else "holly"
            if fam == "holly":
                if n_holly >= 9:
                    fam = "oak" if fv < 0.6 else "elm"
            r = int(rng.integers(*{"oak": (30, 54), "elm": (40, 58), "holly": (17, 26), "magnolia": (16, 25)}[fam]))
            if any(np.hypot(x - sx, y - sy) < 0.6 * (r + sr) * (0.85 + 0.3 * rng.random()) for sx, sy, sr, _ in sites):
                continue
            ccx, ccy, reach = self.canopy_centre(fam, x, y, r)
            clear = True
            for c, hw in curves:
                dd = np.hypot(c[:, 0] - x, c[:, 1] - y).min()
                dc = np.hypot(c[:, 0] - ccx, c[:, 1] - ccy).min()
                if dd < hw + 16 or dc < hw + reach:
                    clear = False
            if clear:
                sites.append((x, y, r, fam))
                n_holly += fam == "holly"
        sites.sort(key=lambda s: s[1])
        return sites

    def tree_raster(self, tx, ty, r, fam):
        key = ("tree", tx, ty)
        ccx, ccy, _ = self.canopy_centre(fam, tx, ty, r)
        if fam == "holly":
            return self.cone_raster(tx, ty - 6, r, key)
        if fam == "elm":
            return self.canopy_raster(ccx, ccy, r, key, ramp=ELM, squash=0.72, shape="spread")
        if fam == "magnolia":
            m, idx, o = self.canopy_raster(ccx, ccy, r, key, ramp=MAG, squash=0.8, tex_cell=2, shape="small")
            rng = rng_for("blossom", key)
            ys, xs = np.nonzero(m & (idx >= 0) & np.isin(idx, [I["e2"], I["e3"], I["g4"]]))
            for k in rng.permutation(len(ys))[: max(4, len(ys) // 14)]:
                y, x = int(ys[k]), int(xs[k])
                c = I["bl"] if rng.random() < 0.7 else I["m5"]
                idx[y, x] = c
                if x + 1 < idx.shape[1] and m[y, x + 1]:
                    idx[y, x + 1] = c if c == I["m5"] else I["fl"]
            return m, idx, o
        return self.canopy_raster(ccx, ccy, r, key, ramp=FOL)

    def trees(self):
        fg = self.L["fg-occlusion"]
        props = self.L["props-low"]
        sites = self.tree_sites()
        rasters = [self.tree_raster(*s) for s in sites]
        # occluder rule (spec section 4): a 48 px actor anywhere walkable keeps >= 1/3 of its height visible.
        # Drop, one at a time, the tree whose canopy hides the most failing actor positions.
        keep = list(range(len(sites)))
        walk = self.walkable_mask()
        spr = heroine_48()[..., 3] == 255
        while True:
            cover = np.zeros((H, W), np.int16) - 1
            for k in keep:
                m, idx, (x0, y0) = rasters[k]
                cover[y0:y0 + m.shape[0], x0:x0 + m.shape[1]][m] = k
            fails = visibility_fails(cover >= 0, walk, spr)
            if not fails:
                break
            votes = {}
            sh, sw = spr.shape
            for (x, y) in fails:
                ids = cover[y - sh + 1:y + 1, x - sw // 2:x - sw // 2 + sw][spr]
                for k in np.unique(ids[ids >= 0]):
                    votes[int(k)] = votes.get(int(k), 0) + 1
            keep.remove(max(votes, key=votes.get))
        self.trees_dropped_for_visibility = len(sites) - len(keep)
        self.tree_list = [sites[k] for k in keep]
        for k in keep:
            tx, ty, r, fam = sites[k]
            m, idx, (x0, y0) = rasters[k]
            sub = fg[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
            sub[m] = idx[m]
            self.trunk(props, tx, ty, fam)
            self.block[ty - 4:ty + 1, tx - 5:tx + 5] = True
            self.prop_shadow.append(("tree", tx, ty, r, fam))
        bnw = np.zeros((H, W), bool)                                    # walk texels under a canopy
        bnw[fg >= 0] = True
        self.belt_near_walk = bnw

    def trunk(self, layer, tx, ty, fam):
        """Trunk below the canopy with a root flare; lit on the left, bark furrows, dark on the right."""
        if fam == "magnolia":                                           # multi-stemmed, smooth grey bark
            for sx, lean in ((-3, -1), (0, 0), (3, 1)):
                for j in range(8):
                    x = tx + sx + (lean * j) // 4; y = ty - j
                    setpx(layer, x, y, I["m1"]); setpx(layer, x + 1, y, I["m0"])
                    if j < 3:
                        setpx(layer, x - 1, y, I["m2"])
            return
        if fam == "holly":                                              # short dark stem under the skirt
            for j in range(6):
                for i in (-2, -1, 0, 1, 2):
                    setpx(layer, tx + i, ty - j, I["s1"] if i < 0 else I["s0"])
            setpx(layer, tx - 3, ty, I["s1"]); setpx(layer, tx + 3, ty, I["s0"])
            return
        tall = 16 if fam == "oak" else 20
        for j in range(tall):
            y = ty - tall + 1 + j
            hw = 3 if j < tall - 6 else 3 + (j - tall + 7) // 2
            for i in range(-hw, hw + 1):
                x = tx + i
                rel = (i + hw) / (2 * hw)
                c = I["s2"] if rel < 0.3 else I["s1"] if rel < 0.75 else I["s0"]
                if j < tall - 6 and i == 0 and (j * 3 + tx) % 4 == 0:
                    c = I["s0"]
                if j >= tall - 3 and abs(i) == hw and (j + i) % 2:
                    c = I["s0"]
                setpx(layer, x, y, c)
        if fam == "elm":                                                # vase fork visible under the crown
            for q in range(1, 6):
                setpx(layer, tx - 2 - q, ty - tall - q + 1, I["s1"]); setpx(layer, tx - 1 - q, ty - tall - q + 1, I["s2"])
                setpx(layer, tx + 2 + q, ty - tall - q + 1, I["s0"]); setpx(layer, tx + 1 + q, ty - tall - q + 1, I["s1"])
        setpx(layer, tx - hw - 1, ty, I["s1"]); setpx(layer, tx + hw + 1, ty, I["s0"])

    # ------------------------------------------------------------------ props-low and survey post
    def props(self):
        pr = self.L["props-low"]
        rng = rng_for("props-v02")
        # benches (AOC: "Benches along the paths"), some on the lawn side; litter bins beside three of them
        specs = ((LEFT_WALK, -1, 0.42, False, True), (LEFT_WALK, -1, 0.7, True, False),
                 (LEFT_WALK, 1, 0.56, False, False), (RIGHT_WALK, 1, 0.62, False, True),
                 (RIGHT_WALK, 1, 0.86, False, False), (RIGHT_WALK, -1, 0.78, False, True),
                 (LEFT_BRANCH, -1, 0.46, True, False))
        self.bench_list = []
        for pts, sgn, s, broken, binned in specs:
            c, seg = bezier(pts)
            k = int(s * (len(c) - 1))
            x, y = c[k]
            hw = (BRANCH_W if pts is LEFT_BRANCH else WALK_W) / 2
            bx = int(x + sgn * (hw + 18)) - 13
            by = int(y) - 8
            stamp(pr, bx, by, BENCH_BROKEN if broken else BENCH, BENCH_MAP)
            self.block[by + 5:by + 12, bx:bx + 26] = True
            self.prop_shadow.append(("box", bx + 4, by + 11, 26, 3))
            self.bench_list.append((bx, by))
            if binned:
                lx = bx + (30 if sgn > 0 else -14)
                stamp(pr, lx, by + 12 - len(BIN), BIN, BIN_MAP)
                self.block[by + 8:by + 13, lx:lx + 10] = True
                self.prop_shadow.append(("box", lx + 4, by + 12, 9, 3))
        # broken lamp-post stubs at the forecourt corners
        for x, y in ((FORE[0] + 6, FORE[1] + 8), (FORE[2] - 12, FORE[1] + 8)):
            stamp(pr, x, y - 11, LAMP_STUB, LAMP_MAP)
            self.block[y - 3:y, x:x + 6] = True
            self.prop_shadow.append(("box", x + 3, y - 1, 7, 3))
        # wayfinding signs (text unreadable at this scale by design) at the branch junction and near the entry
        for sx, sy in ((262, 486), (722, 684)):
            stamp(pr, sx, sy - len(SIGN) + 1, SIGN, SIGN_MAP)
            self.block[sy - 2:sy + 1, sx + 2:sx + 20] = True
            self.prop_shadow.append(("box", sx + 6, sy, 20, 3))
        # commemorative-tree plaques (AOC page legend: "Commemorative Trees") at three trees nearest a walk
        curves = [(self.lc, WALK_W / 2), (self.rc, WALK_W / 2), (self.bc, BRANCH_W / 2)]
        near = sorted(self.tree_list, key=lambda s: min(np.hypot(c[:, 0] - s[0], c[:, 1] - s[1]).min() - hw
                                                       for c, hw in curves))
        self.plaques = []
        for tx, ty, r, fam in near[:3]:
            stamp(pr, tx + 7, ty - 3, PLAQUE, PLAQUE_MAP)
            self.plaques.append((tx + 9, ty + 3))
        # vegetation-survey quadrats: square PVC frames (~1 m) pegged on the lawn panels, numbered tags
        self.quadrats = [(452, 430), (300, 612), (760, 470), (930, 640)]
        for k, (qx, qy) in enumerate(self.quadrats):
            self.quadrat(pr, qx, qy, k)
        # two old stumps with bracket fungus on the lawn panels (game fiction), well off the axis
        for (sx, sy) in ((404, 566), (884, 540)):
            stamp(pr, sx, sy - len(STUMP) + 1, STUMP, STUMP_MAP)
            self.block[sy - 6:sy + 1, sx + 1:sx + 19] = True
            self.prop_shadow.append(("box", sx + 7, sy + 1, 17, 4))
        self.stumps = [(404, 566), (884, 540)]
        # survey kit around the post
        px, py = POST
        for (x, y) in ((px - 56, py - 4), (px - 42, py + 7), (px + 30, py - 2)):
            stamp(pr, x, y - 11, CRATE, CRATE_MAP)
            self.block[y - 5:y + 1, x:x + 14] = True
            self.prop_shadow.append(("box", x + 3, y + 1, 14, 3))
        for spr_, cmap_, x, yb, foot in ((TRIPOD, TRIPOD_MAP, 954, 350, 4), (REEL, REEL_MAP, 852, 408, 6),
                                         (TARP, TARP_MAP, 806, 364, 7)):
            stamp(pr, x, yb - len(spr_) + 1, spr_, cmap_)                # theodolite, cable reel, tarp-covered kit
            wdt = len(spr_[0])
            self.block[yb - foot:yb + 1, x:x + wdt] = True
            self.prop_shadow.append(("box", x + 4, yb + 1, wdt - 2, 3))
        for (x, y) in ((px - 32, py + 1), (px + 20, py + 3), (px - 8, py + 4)):   # sandbags at the pad
            stamp(pr, x, y - len(SANDBAG) + 1, SANDBAG, SANDBAG_MAP)
        # guy-wire anchors
        for (x, y) in ((px - 48, py + 4), (px + 52, py - 6)):
            stamp(pr, x - 1, y - 4, [".k.", "kKk", ".k.", ".K."], {"k": "k2", "K": "k0"})
        # patrol-route beacons
        for (x, y) in (PATROL[1], PATROL[2], PATROL[4], PATROL[5], PATROL[6]):
            bx, by = x + 10, y + 4
            stamp(pr, bx - 1, by - 13, BEACON, BEACON_MAP)
            self.block[by - 1:by + 1, bx - 1:bx + 2] = True
            self.prop_shadow.append(("box", bx + 1, by + 1, 4, 2))
        # survey grid: small orange pin flags on the lawn panel nearest the collapse (waist-low)
        for (x, y) in SURVEY_GRID:
            stamp(pr, x, y - 6, ["oo.", "oOo", "k..", "k..", "k..", "K.."], {"o": "o1", "O": "o0", "k": "k2", "K": "k0"})
            self.prop_shadow.append(("box", x + 1, y, 3, 1))
        # strain sensors on stakes at the collapse, and the cordon with a warning sign
        for (x, y) in ((872, 246), (958, 296), (1066, 298), (1126, 246)):
            stamp(pr, x - 1, y - 9, [".C.", "CXC", ".k.", ".k.", ".k.", ".k.", ".k.", ".k.", "kKk"],
                  {"C": "c1", "X": "c2", "k": "k2", "K": "k0"})
            self.prop_shadow.append(("box", x + 1, y, 4, 2))
        cord = [(858, 160), (862, 222), (916, 272), (1000, 286), (1088, 268), (1132, 218), (1130, 160)]
        tops = []
        for (x, y) in cord:
            stamp(pr, x, y - 7, STAKE, STAKE_MAP)
            tops.append((x + 1, y - 7))
            self.prop_shadow.append(("box", x + 1, y, 3, 1))
        for (ax, ay), (bx, by) in zip(tops, tops[1:]):
            n = int(max(abs(bx - ax), abs(by - ay)))
            for t in range(1, n):
                sag = 2.5 * math.sin(math.pi * t / n)
                setpx(pr, int(round(ax + (bx - ax) * t / n)), int(round(ay + (by - ay) * t / n + sag)), I["o1"])
        stamp(pr, 1000 - 4, 286 - len(WARN) - 2, WARN, WARN_MAP)        # warning diamond beside the middle stake
        self.cordon = cord

    def quadrat(self, layer, x, y, k):
        """A 27 x 17 px PVC quadrat seen in 3/4 (white tube, lit top edge, shaded near edge), orange corner tags
        and a small numbered stake tag; grass shows through. Ground-level: never blocks walking."""
        w, h = 27, 17
        for i in range(w):
            setpx(layer, x + i, y, I["m5"]); setpx(layer, x + i, y + h - 1, I["m4"])
            setpx(layer, x + i, y + h, I["m2"])
        for j in range(h):
            setpx(layer, x, y + j, I["m5"]); setpx(layer, x + w - 1, y + j, I["m4"])
            setpx(layer, x + w, y + j, I["m2"])
        for (cx, cy) in ((x, y), (x + w - 2, y), (x, y + h - 2), (x + w - 2, y + h - 2)):
            for (i, j) in ((0, 0), (1, 0), (0, 1), (1, 1)):
                setpx(layer, cx + i, cy + j, I["o1"])
        stamp(layer, x + w + 2, y - 4, ["xxxx", "xooO", "xoOO", "xxxx", ".k..", ".k..", ".K.."],
              {"x": "ink", "o": "o2", "O": "o1", "k": "k2", "K": "k0"})
        if k % 2 == 0:                                                  # a clipped sample square inside
            for j in range(5, 10):
                for i in range(6, 13):
                    setpx(layer, x + i, y + j, I["g5"] if (i + j) % 2 else I["g4"])
            for i in range(6, 13):
                setpx(layer, x + i, y + 10, I["s1"])
        self.prop_shadow.append(("box", x + 2, y + h + 1, w, 1))

    def survey_post(self):
        """Science survey post, about 2.8x the actor: ink-outlined so it holds against the lawn, lit left edges,
        hazard band, screen, mast with rungs, angled solar panel, dish, sensor head with a cyan beacon, pennant
        and two guy wires. All accents are opaque palette colours (no glow alpha)."""
        sp = self.L["survey-post"]
        px, py = POST
        # concrete pad
        rect(sp, px - 25, py - 11, px + 24, py, I["ink"])
        rect(sp, px - 24, py - 10, px + 23, py - 5, I["m3"]); rect(sp, px - 24, py - 10, px + 23, py - 10, I["m5"])
        rect(sp, px - 24, py - 10, px - 24, py - 5, I["m4"])
        rect(sp, px - 24, py - 4, px + 23, py - 1, I["m2"]); rect(sp, px - 24, py - 4, px + 23, py - 4, I["m1"])
        rect(sp, px + 22, py - 10, px + 23, py - 1, I["m1"])
        # cabinet
        x0, x1 = px - 16, px + 15
        rect(sp, x0 - 1, py - 47, x1 + 1, py - 10, I["ink"])
        rect(sp, x0, py - 46, x1, py - 42, I["k3"]); rect(sp, x0, py - 46, x1, py - 46, I["m4"])
        rect(sp, x0, py - 41, x1, py - 41, I["k0"])
        rect(sp, x0, py - 40, x1, py - 11, I["k1"])
        rect(sp, x0, py - 40, x0, py - 11, I["k3"]); rect(sp, x0 + 1, py - 40, x0 + 1, py - 11, I["k2"])
        rect(sp, x1 - 1, py - 40, x1, py - 11, I["k0"])
        rect(sp, x0 + 1, py - 19, x1 - 1, py - 15, I["o1"])                              # hazard band
        for i in range(x0 + 1, x1, 5):
            for j in range(5):
                setpx(sp, i + j // 2 + 1, py - 19 + j, I["ink"]); setpx(sp, i + j // 2 + 2, py - 19 + j, I["ink"])
        rect(sp, x0 + 1, py - 14, x1 - 1, py - 14, I["o0"])
        rect(sp, px - 13, py - 37, px + 4, py - 24, I["k0"])                             # screen
        rect(sp, px - 12, py - 36, px + 3, py - 25, I["c0"])
        for i, h_ in enumerate((3, 5, 4, 7, 6, 8, 5, 9, 7, 6, 8, 10, 9, 8)):
            setpx(sp, px - 11 + i, py - 26 - h_, I["c1"])
            setpx(sp, px - 11 + i, py - 25 - h_, I["c0"] if h_ < 9 else I["c1"])
        setpx(sp, px + 1, py - 35, I["c2"]); setpx(sp, px + 2, py - 35, I["c2"])
        for j, c in enumerate(("c2", "c1", "o1", "k3")):                                   # status LEDs
            rect(sp, px + 8, py - 37 + 3 * j, px + 9, py - 37 + 3 * j, I[c])
        for yy in range(py - 24, py - 20, 2):                                              # vents
            rect(sp, px + 6, yy, px + 13, yy, I["k0"]); rect(sp, px + 6, yy + 1, px + 13, yy + 1, I["k2"])
        rect(sp, px + 12, py - 31, px + 12, py - 28, I["m4"])
        # mast with rungs and bracket rings
        mx = px + 6
        top = py - 120
        rect(sp, mx - 1, top, mx + 4, py - 47, I["ink"])
        rect(sp, mx, top, mx, py - 48, I["k3"]); rect(sp, mx + 1, top, mx + 2, py - 48, I["k2"])
        rect(sp, mx + 3, top, mx + 3, py - 48, I["k1"])
        for yy in range(top + 4, py - 50, 6):
            rect(sp, mx, yy, mx + 3, yy, I["k0"])
        for yy in range(top + 14, py - 50, 20):
            rect(sp, mx - 2, yy, mx + 5, yy, I["k3"]); rect(sp, mx - 2, yy + 1, mx + 5, yy + 1, I["k0"])
        # solar panel on an arm, angled toward the light
        rect(sp, px - 12, py - 79, mx - 2, py - 78, I["k1"]); rect(sp, px - 12, py - 77, mx - 2, py - 77, I["ink"])
        for j in range(16):
            xa = px - 42 + j // 2
            y = py - 96 + j
            rect(sp, xa, y, xa + 29, y, I["c0"])
            setpx(sp, xa, y, I["ink"]); setpx(sp, xa + 29, y, I["ink"])
            if j in (0, 15):
                rect(sp, xa, y, xa + 29, y, I["ink"])
            elif j in (5, 10):
                rect(sp, xa + 1, y, xa + 28, y, I["k1"])
            if 0 < j < 15:
                for cx_ in (7, 14, 21):
                    setpx(sp, xa + cx_, y, I["k1"])
        for j in range(1, 5):
            rect(sp, px - 41 + j // 2, py - 96 + j, px - 36 + j // 2 - j, py - 96 + j, I["c1"])
        setpx(sp, px - 40, py - 94, I["c2"]); setpx(sp, px - 39, py - 94, I["c2"])
        rect(sp, px - 25, py - 80, px - 24, py - 78, I["k1"])
        # dish on the right
        stamp(sp, mx + 6, py - 108, [".kkkkk...", "kHHHHMk..", "kHMMMMMk.", "kHMMMMMkK", ".kMMMMk.K", "..kkkk..K",
                                     "...kk....", "...kk...."], {"H": "m5", "M": "m4", "k": "ink", "K": "k2"})
        rect(sp, mx + 4, py - 102, mx + 8, py - 101, I["k1"])
        # sensor head + beacon
        hx = mx - 5
        hy = top - 14
        stamp(sp, hx, hy, ["....CC.......", "...CXXC......", "....CC.......", ".kkkkkkkkkk..",
                           "kHHHHHHHHMMk.", "kHMMMMMMMMMk.", "kHMcCCCcMMMk.", "kHMCXXXCMMMk.", "kHMcCCCcMMMk.",
                           "kHMMMMMMMMMk.", ".kkkkkkkkkk..", "....kkkk.....", "....kKKk....."],
              {"C": "c1", "X": "c2", "k": "ink", "H": "k3", "M": "k2", "c": "c0", "K": "k1"})
        # whip antenna with pennant
        rect(sp, x0 + 3, py - 86, x0 + 3, py - 48, I["k2"])
        stamp(sp, x0 + 4, py - 86, ["kkkkkk", "kooooOk", "kooOOk", "kOOk", "kk"], {"o": "o1", "O": "o0", "k": "ink"})
        # guy wires to the anchors
        for (ax, ay) in ((px - 48, py + 1), (px + 52, py - 9)):
            line(sp, mx + 1, py - 110, ax, ay, I["k0"])
        self.block[py - 10:py + 1, px - 25:px + 25] = True
        self.post_mask = sp >= 0

    # ------------------------------------------------------------------ cast shadows (light from upper left)
    def shadows(self):
        cs = self.L["cast-shadows"]
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls", "ground-detail"])
        m1 = np.zeros((H, W), bool)          # one ramp step darker
        m2 = np.zeros((H, W), bool)          # two steps darker (contact / deep cores)
        yy, xx = np.mgrid[0:H, 0:W]
        noise = vnoise("shedge", 3)

        def ell(mask, cx, cy, rx, ry, jit=0.25, rot=None):
            x0, x1 = int(max(0, cx - rx * 1.6 - 2)), int(min(W, cx + rx * 1.6 + 3))
            y0, y1 = int(max(0, cy - rx * 1.6 - 2)), int(min(H, cy + rx * 1.6 + 3))
            if x0 >= x1 or y0 >= y1:
                return
            X, Y = xx[y0:y1, x0:x1] - cx, yy[y0:y1, x0:x1] - cy
            if rot is not None:
                c, s = math.cos(rot), math.sin(rot)
                X, Y = X * c + Y * s, -X * s + Y * c
            e = (X / rx) ** 2 + (Y / ry) ** 2 + (noise[y0:y1, x0:x1] - 0.5) * jit
            mask[y0:y1, x0:x1] |= e < 1

        # west front on the deck; porticos project, so their shadow widens to the lower right
        wing = (yy >= FACADE_Y1) & (yy < FACADE_Y1 + 5 + (noise * 2).astype(int))
        m1 |= wing; m2 |= (yy >= FACADE_Y1) & (yy < FACADE_Y1 + 2)
        for a, b, ybot in [(PAV[0], PAV[1], PAV_Y1)] + [(s0, s1, SUBP_Y1) for s0, s1 in SUBP]:
            sh = (yy >= ybot) & (yy < ybot + 7) & (xx >= a + 3 + (yy - ybot)) & (xx <= b + 4 + (yy - ybot) * 1.2)
            m1 |= sh; m2 |= sh & (yy < ybot + 3)
            m1 |= (xx > b) & (xx <= b + 7) & (yy >= FACADE_Y1) & (yy < ybot + 3)
        # terrace wall: band at the foot, deeper close in
        band = (yy >= FOOT_Y) & (yy < FOOT_Y + 8 + (vnoise("wsh", 6) * 5).astype(int))
        band &= ~((xx >= STAIR_X0 - CHEEK_W - 2) & (xx <= STAIR_X1 + CHEEK_W + 2))
        m1 |= band; m2 |= band & (yy < FOOT_Y + 3)
        # cheek walls throw a shadow to their right onto the treads/forecourt
        for x0 in (STAIR_X0, STAIR_X1 + CHEEK_W + 3):
            cw = (xx >= x0) & (xx < x0 + 6) & (yy >= EDGE_Y - 2) & (yy <= STAIR_BOT + 6)
            m1 |= cw; m2 |= cw & (xx < x0 + 2)
        for kind, *a in self.prop_shadow:
            if kind == "tree":
                tx, ty, r, fam = a
                if fam == "holly":
                    ell(m1, tx + 0.85 * r, ty + 0.5 * r, 1.25 * r, 0.42 * r, rot=0.55)
                    ell(m2, tx + 3, ty + 1, 0.4 * r, 0.16 * r, jit=0.1)
                else:
                    k = {"elm": (0.75, 0.16, 1.3, 0.44), "magnolia": (0.55, 0.14, 1.0, 0.46)}.get(
                        fam, (0.62, 0.14, 1.12, 0.5))
                    ell(m1, tx + k[0] * r, ty + k[1] * r + 3, k[2] * r, k[3] * r, jit=0.3)
                    ell(m2, tx + 0.3 * r, ty + 2, 0.5 * r, 0.2 * r, jit=0.15)
            elif kind == "shrub":
                cx, cy, r = a
                ell(m1, cx + 0.5 * r, cy + 1, 0.95 * r, 0.45 * r, jit=0.3)
                ell(m2, cx + 0.3 * r, cy, 0.5 * r, 0.22 * r, jit=0.1)
            elif kind == "block":
                x, y, w, d, h = a
                dx, dy = max(2, int(round(h * 0.8))), max(1, int(round(h * 0.45)))
                sh = (xx >= x + dx) & (xx < x + w + dx) & (yy >= y + dy) & (yy < y + d + h + dy)
                m1 |= sh
                m2 |= sh & (xx < x + w + 2) & (yy < y + d + h + 2)
            elif kind == "box":
                x, y, w, h = a
                bx_ = (xx >= x) & (xx < x + w) & (yy >= y) & (yy < y + h)
                m1 |= bx_; m2 |= bx_ & (yy == y)
        # talus casts off its lower-right rim
        mm = self.mound_mask
        m1 |= np.roll(np.roll(mm, 6, 0), 9, 1) & ~mm
        m2 |= np.roll(np.roll(mm, 2, 0), 3, 1) & ~mm
        # survey post: pad + cabinet + long mast and panel shadows to the lower right
        px, py = POST
        cab = (yy >= py + 1) & (yy <= py + 16) & (xx >= px - 22 + (yy - py) * 1.6) & (xx <= px + 28 + (yy - py) * 1.6)
        mast = (np.abs((xx - (px + 26)) - (yy - py) * 1.6) < 2.2) & (yy > py) & (yy < py + 44)
        m1 |= cab | mast
        m2 |= cab & (yy <= py + 5)
        ell(m1, px + 44, py + 30, 18, 6, jit=0.1)                        # panel
        ell(m1, px + 98, py + 44, 6, 3, jit=0.1)                         # sensor head
        m1 &= (yy >= FACADE_Y1)
        tw = self.L["terrace-walls"]
        # never paint over the walls' vertical faces, the west front, or the tumbled pieces themselves
        walls = (tw >= 0) & (yy < FOOT_Y) & (yy >= EDGE_Y - BAL_H - 8) & ~self.mound_mask
        front = (tw >= 0) & (yy < PAV_Y1)
        bad = walls | front | self.piece_mask | self.fixture_mask
        m1 &= ~bad; m2 &= ~bad
        # columns throw diagonal shadows across their own stylobate
        colsh = np.zeros((H, W), bool)
        for (sx, sy, fr) in self.col_shadows:
            colsh |= (yy >= sy) & (yy < fr) & (xx >= sx + (yy - sy) * 0.8 - 1) & (xx < sx + (yy - sy) * 0.8 + 5)
        colsh &= (tw >= 0) & ~np.isin(tw, [I["m0"], I["ink"]])
        m1 |= colsh
        m2 &= m1
        cs[m1] = SHADE_LUT[comp[m1]]
        cs[m2] = SHADE_LUT[SHADE_LUT[comp[m2]]]

    # ------------------------------------------------------------------ guides (hidden, locked layer)
    def guides(self):
        g = self.L["guides"]
        walkable = self.walkable_mask()
        p = np.pad(walkable, 1)
        edge = walkable & (~p[:-2, 1:-1] | ~p[2:, 1:-1] | ~p[1:-1, :-2] | ~p[1:-1, 2:])
        g[edge] = I["gd-walk"]
        b = self.block
        pb = np.pad(b, 1)
        bedge = b & (~pb[:-2, 1:-1] | ~pb[2:, 1:-1] | ~pb[1:-1, :-2] | ~pb[1:-1, 2:])
        g[bedge] = I["gd-block"]
        for (ax, ay), (bx, by) in zip(PATROL, PATROL[1:] + PATROL[:1]):
            n = int(max(abs(bx - ax), abs(by - ay)))
            for t in range(0, n, 3):
                setpx(g, int(ax + (bx - ax) * t / n), int(ay + (by - ay) * t / n), I["gd-route"])
        for name, (x, y) in self.pins().items():
            for k in range(-4, 5):
                setpx(g, x + k, y, I["gd-pin"]); setpx(g, x, y + k, I["gd-pin"])
        for (x, y) in ((40, 700), (640, 196), (944, 470), (1240, 700), (300, 560)):
            rect(g, x, y - 47, x, y, I["gd-tick"])
            for k in range(0, 48, 8):
                rect(g, x - 2, y - k, x + 2, y - k, I["gd-tick"])
            rect(g, x - 3, y - 47, x + 3, y - 47, I["gd-tick"])

    def pins(self):
        return {"spawn_entry_west": ENTRY, "exit_west_axis": (640, 716), "exit_northwest_walk": (154, 716),
                "exit_southwest_walk": (1126, 716), "exit_east_terrace_stairs": (640, 64),
                "survey_post_interaction": (POST[0], POST[1] + 14), "survey_post_pivot": POST}

    def walkable_mask(self):
        yy = np.arange(H)[:, None]
        wm = self.inner_lawn.copy()                                 # lawn inside the curved walks + foot margin
        wm[:FOOT_Y + 4, :] = False
        wm &= ~self.belt
        wm |= self.walk_mask & (yy >= FORE[1])
        wm[FACADE_Y1 + 4:EDGE_Y - BAL_H - 2, :] = True              # terrace deck
        wm[EDGE_Y - BAL_H - 2:STAIR_BOT + 1, STAIR_X0:STAIR_X1 + 1] = True
        wm &= ~self.block
        if hasattr(self, "breach_top"):
            for x, yt in self.breach_top.items():
                wm[yt - 3:FOOT_Y, x] = False
        return wm

    # ------------------------------------------------------------------ build all
    def build(self):
        self.ground_base()
        self.paving()
        self.terrace()
        self.trees()
        self.props()
        self.survey_post()
        self.detail()
        self.shadows()
        self.guides()
        # ground-base must be opaque; the rest binary alpha by construction
        assert (self.L["ground-base"] >= 0).all()
        return self


def visibility_fails(fg, walk, spr, step=4):
    """Foot positions (sampled every `step` px over walkable texels) where fg hides > 2/3 of the actor's texels."""
    sh, sw = spr.shape
    tot = spr.sum()
    out = []
    for y in range(0, H, step):
        for x in range(0, W, step):
            if not walk[y, x]:
                continue
            x0, y0 = x - sw // 2, y - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            if 1 - (fg[y0:y0 + sh, x0:x0 + sw] & spr).sum() / tot < 1 / 3:
                out.append((x, y))
    return out


# ============================================================================ raster output
def to_rgba(idx):
    a = np.zeros((H, W, 4), np.uint8)
    m = idx >= 0
    a[m, :3] = RGB[idx[m]]
    a[m, 3] = 255
    return a


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


def composite_rgba(rgba_layers, names):
    out = rgba_layers[names[0]].copy()
    for n in names[1:]:
        m = rgba_layers[n][..., 3] == 255
        out[m] = rgba_layers[n][m]
    return out


def heroine_48():
    """Approved v8 static south idle (96 texels = 48 logical px) sampled at 2:1 for scale overlays only."""
    a = np.array(Image.open(rp(HEROINE_REL)).convert("RGBA"))
    ys, xs = np.nonzero(a[..., 3])
    a = a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = a.shape[:2]
    small = np.array(Image.fromarray(a, "RGBA").resize((max(1, w // 2), h // 2), Image.NEAREST))
    small[..., 3] = np.where(small[..., 3] >= 128, 255, 0)
    return small


def paste(dst, spr, x, ybase):
    h, w = spr.shape[:2]
    x0, y0 = x - w // 2, ybase - h + 1
    for j in range(h):
        for i in range(w):
            if spr[j, i, 3] and 0 <= x0 + i < W and 0 <= y0 + j < H:
                dst[y0 + j, x0 + i] = spr[j, i]


def actor_cases():
    """Foot positions for the scale/Y-sort/occlusion stills (behind = north of the post base, front = south)."""
    px, py = POST
    return {"entry": ENTRY, "post_behind": (px - 4, py - 10), "post_front": (px - 2, py + 16),
            "terrace_stairs": (640, 176), "terrace_deck": (420, 70), "terrace_portico": (588, 80),
            "left_walk_canopy": (238, 420)}


def runtime_stack_still(rgba, spr, foot):
    """Runtime draw order proposal: base (layers 1-6 merged) -> Y-sorted {post, actor} -> fg-occlusion."""
    base = composite_rgba(rgba, ART_LAYERS[:6])
    px, py = POST
    out = base.copy()
    post = rgba["survey-post"]
    m = post[..., 3] == 255
    if foot[1] < py:                       # actor north of the post base: drawn behind it
        paste(out, spr, foot[0], foot[1]); out[m] = post[m]
    else:
        out[m] = post[m]; paste(out, spr, foot[0], foot[1])
    fg = rgba["fg-occlusion"]
    fm = fg[..., 3] == 255
    out[fm] = fg[fm]
    return out


def zoom(arr, k):
    return np.array(Image.fromarray(arr, "RGBA").resize((arr.shape[1] * k, arr.shape[0] * k), Image.NEAREST))


def guide_overlay(flat, guides):
    out = flat.copy()
    m = guides[..., 3] == 255
    out[m] = guides[m]
    return out


# ============================================================================ containers
DT = (2026, 10, 15, 19, 40, 14)


def zput(z, name, payload, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, DT)
    zi.compress_type = method
    z.writestr(zi, payload)


def make_ora(rgba, comp_png):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.5" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for n in reversed(LAYERS):                                                # ORA lists top first
        vis = "hidden" if n == "guides" else "visible"
        stack.append(f'<layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.000" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>", ""]
    thumb = Image.fromarray(comp_png_arr(comp_png), "RGBA").resize((256, 144), Image.NEAREST)
    tb = io.BytesIO(); thumb.save(tb, "PNG")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "mimetype", b"image/openraster", zipfile.ZIP_STORED)
        zput(z, "stack.xml", "\n".join(stack).encode())
        for n in LAYERS:
            zput(z, f"data/{n}.png", png_bytes(rgba[n]))
        zput(z, "mergedimage.png", comp_png)
        zput(z, "Thumbnails/thumbnail.png", tb.getvalue())
    return buf.getvalue()


def comp_png_arr(b):
    return np.array(Image.open(io.BytesIO(b)).convert("RGBA"))


def make_pxo(rgba, comp_png):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in LAYERS]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYERS], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(EXPORT_STEM), "frame_current_tag": "0",
                      "include_tag_in_filename": "false", "interpolation": "0", "lines_count": "1",
                      "new_dir_for_each_frame_tag": "false", "number_of_digits": "4", "number_of_frames": "1",
                      "orientation": "0", "repeat_count": "0", "resize": "100", "save_quality": "0.75",
                      "separator_character": "\"_\"", "sheet_layers_as_separate_files": "false",
                      "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": 0, "export_profile": export_profile,
            "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json, "license": "", "metadata": {},
            "next_keyframe_id": 0, "palettes": [], "pixelorama_version": PIXELORAMA_VERSION,
            "project_current_palette_name": "", "pxo_version": 7, "reference_images": [], "size_x": W, "size_y": H,
            "symmetry_points": [W - 1.0, H - 1.0], "tags": [], "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0,
            "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "",
            "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "data.json", json.dumps(data, separators=(",", ":")))
        zput(z, "mimetype", "application/x-pixelorama")
        zput(z, "preview.png", comp_png)
        zput(z, "image_data/frames/1/", b"")
        for li, n in enumerate(LAYERS, start=1):
            zput(z, f"image_data/frames/1/layer_{li}", np.ascontiguousarray(rgba[n]).tobytes())
            zput(z, f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_gpl():
    lines = ["GIMP Palette", f"Name: {SLUG}_{AREA}_scene-palette_{VER}", "Columns: 9", "#"]
    for n, h in PALETTE:
        r, g, b = (int(h[j:j + 2], 16) for j in (0, 2, 4))
        lines.append(f"{r:3d} {g:3d} {b:3d}\t{n}")
    return ("\n".join(lines) + "\n").encode()


# ============================================================================ metrics and checks
def metrics(sc, rgba, flat):
    out = {}
    used = set()
    for n in ART_LAYERS:
        a = rgba[n]
        opaque = a[..., 3] == 255
        semi = (a[..., 3] > 0) & (a[..., 3] < 255)
        cols = {tuple(c) for c in a[opaque][:, :3].tolist()} if opaque.any() else set()
        used |= cols
        out[n] = {"opaque_texels": int(opaque.sum()), "semi_alpha_texels": int(semi.sum()),
                  "distinct_colours": len(cols),
                  "colours_outside_art_palette": len(cols - {tuple(RGB[i].tolist()) for i in range(N_ART)})}
    flat_cols = {tuple(c) for c in flat[..., :3].reshape(-1, 3).tolist()}
    idx = np.full((H, W), -1, np.int32)
    lut = {tuple(RGB[i].tolist()): i for i in range(N_ART)}
    fl = flat[..., :3].reshape(-1, 3)
    idx = np.array([lut.get(tuple(c), -1) for c in map(tuple, fl.tolist())], np.int32).reshape(H, W)
    p = np.pad(idx, 1, mode="edge")
    iso = (idx != p[:-2, 1:-1]) & (idx != p[2:, 1:-1]) & (idx != p[1:-1, :-2]) & (idx != p[1:-1, 2:])
    # occlusion limits (proposed in the spec, creator to confirm)
    walk = sc.walkable_mask()
    fg = rgba["fg-occlusion"][..., 3] == 255
    spr = heroine_48()
    sm = spr[..., 3] == 255
    sh, sw = sm.shape
    worst, fails, tested = 1.0, 0, 0
    worst_at = None
    for y in range(0, H, 4):
        for x in range(0, W, 4):
            if not walk[y, x]:
                continue
            x0, y0 = x - sw // 2, y - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            cov = fg[y0:y0 + sh, x0:x0 + sw] & sm
            vis = 1 - cov.sum() / sm.sum()
            tested += 1
            if vis < worst:
                worst, worst_at = vis, (x, y)
            if vis < 1 / 3:
                fails += 1
    out["_summary"] = {
        "art_palette_size": N_ART, "distinct_colours_in_flat": len(flat_cols),
        "distinct_colours_all_art_layers": len(used),
        "isolated_single_texels_in_flat": int(iso.sum()),
        "isolated_single_texel_ratio": round(float(iso.mean()), 5),
        "walkable_texels": int(walk.sum()),
        "fg_occlusion_over_walkable_ratio": round(float((fg & walk).sum() / walk.sum()), 4),
        "fg_limit_ratio": 0.12,
        "actor_visibility_samples": tested, "actor_visibility_worst": round(float(worst), 3),
        "actor_visibility_worst_at_foot": worst_at, "actor_visibility_below_one_third": fails,
        "heroine_overlay_px": [int(sw), int(sh)],
        "survey_post_height_px": int(np.ptp(np.nonzero(sc.post_mask.any(axis=1))[0]) + 1),
        "lawn_meadow_texels": int((sc.meadow & sc.lawn).sum()), "lawn_mown_texels": int((sc.mown & sc.lawn).sum()),
        "lawn_texels": int(sc.lawn.sum()), "quadrats": len(sc.quadrats), "lawn_shrub_clumps": len(sc.lawn_shrubs),
    }
    return out


def ysort_check(rgba):
    """Actor north of the post base must be hidden where the post overlaps; south of it must be on top."""
    spr = heroine_48()
    post = rgba["survey-post"][..., 3] == 255
    res = {}
    for name in ("post_behind", "post_front"):
        foot = actor_cases()[name]
        still = runtime_stack_still(rgba, spr, foot)
        act = np.zeros((H, W, 4), np.uint8)
        paste(act, spr, foot[0], foot[1])
        am = act[..., 3] == 255
        overlap = am & post & ~(rgba["fg-occlusion"][..., 3] == 255)
        if not overlap.any():
            res[name] = {"overlap_texels": 0, "ok": False}
            continue
        shows_actor = (still[overlap] == act[overlap]).all(axis=1)
        shows_post = (still[overlap] == rgba["survey-post"][overlap]).all(axis=1)
        exp_actor = name == "post_front"
        res[name] = {"overlap_texels": int(overlap.sum()),
                     "actor_on_top_texels": int(shows_actor.sum()), "post_on_top_texels": int(shows_post.sum()),
                     "ok": bool(shows_actor.all()) if exp_actor else bool(shows_post.all())}
    return res


# ============================================================================ build artefacts
def artefacts():
    sc = Scene().build()
    rgba = {n: to_rgba(sc.L[n]) for n in LAYERS}
    flat = composite_rgba(rgba, ART_LAYERS)
    flat_png = png_bytes(flat)
    files = {"pxo": make_pxo(rgba, flat_png), "ora": make_ora(rgba, flat_png), "flat": flat_png,
             "gpl": make_gpl()}
    return sc, rgba, flat, files


def names():
    return {"pxo": fname("scene-editable-9layer", "pxo"), "ora": fname("scene-editable-9layer", "ora"),
            "flat": fname("scene-flat-art", "png"), "gpl": fname("scene-palette", "gpl"),
            "manifest": fname("scene-manifest", "json"), "walk": fname("scene-walkability", "json")}


def walkability_json(sc):
    wm = sc.walkable_mask()
    cell = 8
    rows = []
    for gy in range(0, H, cell):
        r = ""
        for gx in range(0, W, cell):
            blk = wm[gy:gy + cell, gx:gx + cell]
            r += "." if blk.mean() >= 0.5 else "#"
        rows.append(r)
    px, py = POST
    return {"status": "UNAPPROVED candidate data derived from the guides layer; not runtime-integrated",
            "run": RUN, "canvas": [W, H], "cell_px": cell,
            "grid_legend": {".": "walkable (>=50% of cell)", "#": "blocked"},
            "grid": rows, "pins": {k: list(v) for k, v in sc.pins().items()},
            "survey_post": {"pivot_base_centre": [px, py], "footprint_xyxy": [px - 25, py - 10, px + 24, py],
                            "y_sort_rule": "actor foot y < pivot y -> drawn behind the post; else in front"},
            "patrol_route_loop": [list(p) for p in PATROL],
            "cordon_stakes": [list(p) for p in sc.cordon]}


def v01_flat():
    p = rp(V01_FLAT_REL)
    if not os.path.isfile(_fs(p)):
        return None
    return np.array(Image.open(_fs(p)).convert("RGBA"))


def previews(sc, rgba, flat):
    spr = heroine_48()
    out = {}
    scale = flat.copy()
    for k, foot in actor_cases().items():
        if k in ("post_behind", "post_front"):
            continue
        paste(scale, spr, *foot)
    out["preview-heroine48-scale"] = scale
    out["preview-guides-overlay"] = guide_overlay(flat, rgba["guides"])
    for name in ("post_behind", "post_front", "entry", "terrace_stairs", "terrace_portico", "left_walk_canopy"):
        out["still-runtime-stack-" + name.replace("_", "-")] = runtime_stack_still(rgba, spr, actor_cases()[name])
    crops = {"terrace-portico": (400, 0, 880, 270), "collapse-post": (840, 60, 1180, 440),
             "left-walk-belt": (0, 200, 400, 520), "lawn-axis": (480, 420, 800, 720),
             "right-belt-trees": (960, 400, 1280, 720)}
    for k, (x0, y0, x1, y1) in crops.items():
        out[f"zoom3x-{k}"] = zoom(scale[y0:y1, x0:x1], 3)
    old = v01_flat()
    if old is not None and old.shape == flat.shape:                     # read-only comparison with v01
        v1 = old.copy()
        for k, foot in actor_cases().items():
            if k in ("entry", "terrace_stairs", "left_walk_canopy"):
                paste(v1, spr, *foot)
        out["compare-v01-top-v02-bottom"] = np.concatenate([v1, scale], axis=0)
    return out


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def tree_family_counts(sc):
    c = {}
    for *_, fam in sc.tree_list:
        c[fam] = c.get(fam, 0) + 1
    return c


def manifest(sc, rgba, flat, files, met):
    nm = names()
    rows = np.nonzero(sc.post_mask.any(axis=1))[0]
    post_h = int(rows.max() - rows.min() + 1)
    return {
        "project": SLUG, "area": "washington-capitol-west-grounds", "run": RUN, "version": "v02",
        "status": "UNAPPROVED exploration-scene candidate (test-only). Not accepted art, not runtime-integrated. "
                  "Acceptance is creator review only.",
        "art_approved": False, "runtime_integrated": False, "counters_changed": False,
        "supersedes_nothing": "v01 (" + V01_RUN + ") is kept untouched; v02 is a parallel refinement candidate.",
        "authorship": "Deterministic Python tool authored and run by Claude (Claude Code, claude.ai Max, firstParty). "
                      "No image-generation model; every texel is placed by the tool's rules and hand-authored stamps.",
        "spec": SPEC_REL, "site_audit": AUDIT_REL, "previous_candidate_tool": V01_TOOL_REL,
        "canvas": {"w": W, "h": H, "texel": "1 authored texel = 1 logical/screen px; nearest-neighbour only",
                   "camera": "top-down, mild 3/4 front faces; top = east (Capitol west front), bottom = west",
                   "light": "from the upper left; cast shadows fall to the lower right in two opaque steps",
                   "scale_reference": {"file": HEROINE_REL, "logical_height_px": 48,
                                       "note": "approved v8 static south idle (96 texels at 2:1) sampled 2:1 for "
                                               "overlays only; not part of any layer"},
                   "px_per_m_estimate": 27},
        "lineage": "forks the never-built v02 draft tools/rpg-2-star-ocean-the-second_washington-capitol_west-grounds-"
                   "scene-candidate_pixelorama-build_unapproved-v02_20261015-185126-4ad6947e.py (left untouched; it "
                   "produced no repo files) and continues it under its own stamp and run id",
        "v02_changes_vs_v01": [
            "Capitol identity: rusticated wings with round-arched openings, voussoir rings and keystones; a projecting "
            "central portico (8 columns, Attic bases, 3-step stylobate, bronze doors); two 4-column wing porticos; "
            "bronze candelabra lamp standards on both stair newels (one missing its crown globe)",
            "railings: uneven bay widths with balusters re-centred per bay and 8 weathering states; wall-face spalls, "
            "efflorescence and stepped cracks vary per bay",
            "collapse volume: horizontal soil strata parallel to the scarp (v02 draft re-stretched them per column), "
            "dithered lateral light, undercut shadow, wall rubble core, broad stepped wall ends, dangling and leaning "
            "balusters, lit talus heightfield; rubble mixes white/grey marble and warm sandstone-core ashlar of skewed "
            "sizes, fallen column drums and cornice fragments with dentils, each with an opaque two-step cast shadow",
            "trees: 4 shape families (round oak, three-crown elm, tiered conical holly, small magnolia in blossom); "
            "oaks and elms make the belts, hollies capped at 9 as specimens, magnolias near the walks",
            "lawn with a purpose: rough unmown meadow drifts with height (shaded south fringe, lit tips, seed heads) "
            "along the walk verges; a mown pad round the survey post and a mown lane from the forecourt to the "
            "collapse sensors with diagonal mowing stripes; four vegetation-survey quadrats; two stumps; self-sown "
            "shrub clumps; wildflower drifts; fewer tufts on short grass (isolated single texels 9.2 % -> ~6 %)",
            "axial walk: 3 px granite curbs with joints; kept clear and fully walkable (gated)",
            "survey post ~2.8x actor height (v01 1.96x), ink outline, stronger value contrast, mown pad behind it",
            "palette 38 -> 45 colours (g7 sunlit grass, e2-e4 holly / verdigris blue-greens, s4 lit soil and cut "
            "wood, bl blossom, y0 wildflower)"],
        "site_fidelity": {
            "observed_or_AOC": ["West terrace edge with balustrade and central stairs at the top (east)",
                                "Open West Front Lawn on the axis; trees only in the flank belts",
                                "Curved walks through tree belts on both flanks; benches along the paths",
                                "Commemorative trees exist on the grounds (CVC page 20 legend item 4)"],
            "cue_not_measured": ["the west front is shown only as its lowest storey: banded rustication, pilasters, "
                                 "round-arched openings with keystones, a central projecting portico and two wing "
                                 "porticos with columns on Attic bases. The real west front's fenestration, column "
                                 "count, spacing, storey heights and the porticos' exact positions were NOT measured; "
                                 "this is a readability cue",
                                 "bronze candelabra lamp standards on the stair newels: a period-style readability cue, "
                                 "not a surveyed fixture",
                                 "column shafts run off the top of the frame; no pediment, no dome",
                                 "plaque, sign, bin and lamp-stub placements are decoration, not surveyed"],
            "deliberately_absent": ["moat / basins / any water", "compass medallion", "gate-pier avenue",
                                    "Summerhouse (NW corner of the grounds per CVC page 20 and AOC; with top = east, "
                                    "NW is off the lower-left edge; the NW branch walk and its wayfinding sign lead "
                                    "there; not compressed into this ~47 m x 26 m crop)",
                                    "western road loop with island (farther west beyond the lawn and tree belts; "
                                    "outside the scene)",
                                    "Reflecting Pool (on the Mall, outside the grounds)", "dome"],
            "estimated_not_measured": ["terrace wall drawn 42 px (~1.6 m) high: compressed, real height unverified",
                                       "stair flight 188 px (~7 m) wide, 16 steps: count and layout unverified",
                                       "deck depth between the west front and the balustrade: compressed",
                                       "walk widths 36 px (~1.3 m), axial walk 80 px (~3 m): unverified",
                                       "lawn panels, walk radii, tree positions and species: arrangement only"],
            "game_fiction": ["collapsed terrace-wall bay (x 880-1104) with breach, strata, talus and toppled pier",
                             "one broken column in the south wing portico, its drum lying on the deck",
                             "overgrowth, vines, ivy-choked bays, cracks, missing slabs, missing balusters",
                             "science survey post and kit, strain sensors, cables, patrol-route beacons, worn "
                             "patrol trail, orange survey paint, cordon stakes, tape and warning sign",
                             "mown survey pad and lane, vegetation-survey quadrats, rough meadow drifts, self-sown "
                             "shrub clumps, two stumps, one candelabra missing its globe"],
            "concepts_used_as": "mood only (palette temperature, ruin-and-overgrowth feel); no shapes traced"},
        "layers_bottom_to_top": [
            {"index": i + 1, "name": n, "visible": n != "guides", "locked": n == "guides",
             "runtime_export": {"survey-post": "separate Y-sorted sprite, pivot = base centre " + str(list(POST)),
                                "fg-occlusion": "separate overlay above actors",
                                "guides": "never exported"}.get(n, "merged into base"),
             **{k: v for k, v in met.get(n, {}).items()}} for i, n in enumerate(LAYERS)],
        "layer_notes": {
            "terrace-walls": "west front, columns, stylobates, wall, balustrade, stairs, collapse and rubble; the "
                             "stair flight is kept whole here so it edits as one unit",
            "ground-detail": "tufts, verge planting, clover, wildflowers, leaf litter, branches, shrubs, vines, ivy, "
                             "cracks, chips, survey paint, cables",
            "cast-shadows": "opaque palette shadow colours chosen per texel from the colour underneath (SHADE map, "
                            "one or two steps); re-run the tool after editing lower layers",
            "props-low": "trunks, benches, bins, signs, plaques, survey kit, beacons, flags, cordon; all drawn under "
                         "actors at runtime (tall items sit on unwalkable verges)",
            "guides": "walk envelope (cyan), collision outlines (red), pins (yellow), 48 px height ticks (white), "
                      "patrol route (magenta); guide colours are outside the art palette and never exported"},
        "palette": [{"name": n, "hex": "#" + h} for n, h in PALETTE],
        "guide_palette": [{"name": n, "hex": "#" + h} for n, h in GUIDE_PALETTE],
        "metrics": met["_summary"],
        "files_sha256_bytes": {nm[k]: sha(v) for k, v in files.items()},
        "survey_post": {"pivot_base_centre": list(POST), "height_px": post_h, "height_vs_actor": round(post_h / 48, 2)},
        "tree_belts": {"trees": len(sc.tree_list), "families": tree_family_counts(sc),
                       "dropped_by_actor_visibility_rule": sc.trees_dropped_for_visibility},
        "tool": {"file": TOOL_REL, "sha256_text_lf_v1": sha_text(read_bytes(os.path.abspath(__file__))),
                 "python": sys.version.split()[0], "pillow": Image.__version__, "numpy": np.__version__},
    }


def build(preview_dir=None):
    sc, rgba, flat, files = artefacts()
    met = metrics(sc, rgba, flat)
    met["_ysort"] = ysort_check(rgba)
    pv = previews(sc, rgba, flat)
    if preview_dir:
        os.makedirs(preview_dir, exist_ok=True)
        Image.fromarray(flat, "RGBA").save(os.path.join(preview_dir, "flat.png"))
        for k, a in pv.items():
            Image.fromarray(a, "RGBA").save(os.path.join(preview_dir, k + ".png"))
        for n in LAYERS:
            Image.fromarray(rgba[n], "RGBA").save(os.path.join(preview_dir, f"layer-{n}.png"))
        print(json.dumps({"summary": met["_summary"], "ysort": met["_ysort"], "trees": tree_family_counts(sc),
                          "dropped": sc.trees_dropped_for_visibility,
                          "layers": {n: met[n] for n in ART_LAYERS}}, indent=1))
        return 0
    sc2, rgba2, flat2, files2 = artefacts()
    if files2 != files:
        raise SystemExit("build is not deterministic")
    cand, out = rp(CAND_REL), rp(OUT_REL)
    os.makedirs(_fs(cand), exist_ok=True)
    os.makedirs(_fs(out), exist_ok=True)
    nm = names()
    for k in ("pxo", "ora", "flat", "gpl"):
        print(write_new(os.path.join(cand, nm[k]), files[k]), nm[k])
    wj = (json.dumps(walkability_json(sc), indent=1) + "\n").encode()
    files["walk"] = wj
    print(write_new(os.path.join(cand, nm["walk"]), wj), nm["walk"])
    man = manifest(sc, rgba, flat, files, met)
    man["ysort_check"] = met["_ysort"]
    man["qa_previews_dir"] = OUT_REL
    print(write_new(os.path.join(cand, nm["manifest"]), (json.dumps(man, indent=2) + "\n").encode()), nm["manifest"])
    for k, a in pv.items():
        print(write_new(os.path.join(out, fname(k, "png")), png_bytes(a)), k)
    return 0


# ============================================================================ Pixelorama gate (isolated APPDATA)
def snapshot_dir(root):
    snap = {}
    if root and os.path.isdir(root):
        for d, _, fs in os.walk(root):
            for f in fs:
                p = os.path.join(d, f)
                try:
                    st = os.stat(p)
                    snap[os.path.relpath(p, root).replace("\\", "/")] = (st.st_size, st.st_mtime_ns)
                except OSError:
                    snap[os.path.relpath(p, root).replace("\\", "/")] = None
    return snap


def run_isolated(exe, args, fake_appdata, real_root):
    """Run Pixelorama headless with APPDATA pointed at a temp dir. Kill-switch: if anything in the real
    %APPDATA%\\pixelorama other than the GUI's own .running heartbeat changes, or .running disappears, kill at once."""
    env = dict(os.environ)
    env["APPDATA"] = fake_appdata
    before = snapshot_dir(real_root)
    t0 = time.time()
    p = subprocess.Popen([exe, "--headless", "--quit", "--"] + args, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    killed, saw_fake_user_dir, marker_missing = False, False, False
    while p.poll() is None:
        now = snapshot_dir(real_root)
        changed = {k for k in set(before) | set(now) if before.get(k) != now.get(k) and k != ".running"}
        if ".running" in before and ".running" not in now:
            marker_missing = True
        if changed or marker_missing:
            p.kill(); killed = True
            break
        if os.path.isdir(os.path.join(fake_appdata, "pixelorama")):
            saw_fake_user_dir = True
        if time.time() - t0 > 240:
            p.kill(); killed = True
            break
        time.sleep(0.01)
    so, se = p.communicate()
    after = snapshot_dir(real_root)
    noise = ("shader_compiler", "custom_samplers", "Condition \"!actions")
    tail = [l for l in so.splitlines() + se.splitlines() if l.strip() and not any(s in l for s in noise)]
    return {"args": [os.path.basename(a) if os.path.isabs(a) else a for a in args], "exit_code": p.returncode,
            "seconds": round(time.time() - t0, 1), "killed_by_guard": killed,
            "fake_user_dir_created": saw_fake_user_dir or os.path.isdir(os.path.join(fake_appdata, "pixelorama")),
            "real_dir_changed_except_running": sorted(k for k in set(before) | set(after)
                                                      if before.get(k) != after.get(k) and k != ".running"),
            "real_running_marker_present_after": ".running" in after, "output_tail": tail[-5:]}


def list_pngs(d):
    return sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))


def axial_clear(sc, rgba):
    """The axial walk (forecourt foot to the west edge) must stay fully walkable, with no prop, post or canopy
    texel over it (ground-detail overhang tufts and cracks are allowed)."""
    y0 = FORE[3] + 1
    band = np.zeros((H, W), bool)
    band[y0:H, AXIS[0] + 3:AXIS[1] - 2] = True
    walk = sc.walkable_mask()
    over = {n: int(((rgba[n][..., 3] == 255) & band).sum()) for n in ("props-low", "survey-post", "fg-occlusion")}
    return {"band_xyxy": [AXIS[0] + 3, y0, AXIS[1] - 3, H - 1], "walkable_ratio": round(float(walk[band].mean()), 4),
            "texels_over_band": over, "ok": bool(walk[band].all() and not any(over.values()))}


def check(exe, write_report, use_pixelorama, godot=None):
    sc, rgba, flat, files = artefacts()
    nm = names()
    cand = rp(CAND_REL)
    for k in ("pxo", "ora", "flat", "gpl"):
        if read_bytes(os.path.join(cand, nm[k])) != files[k]:
            raise SystemExit(f"{nm[k]} on disk differs from a fresh rebuild")
    met = metrics(sc, rgba, flat)
    ys = ysort_check(rgba)
    ax = axial_clear(sc, rgba)
    fams = tree_family_counts(sc)
    rep = {"run": RUN, "gates": {}, "metrics": met["_summary"], "ysort": ys, "axial_walk": ax,
           "tree_families": fams}
    s = met["_summary"]
    gates = rep["gates"]
    gates["canvas_1280x720_rgba"] = all(rgba[n].shape == (H, W, 4) for n in LAYERS)
    gates["ground_base_opaque"] = met["ground-base"]["opaque_texels"] == W * H
    gates["binary_alpha_all_layers"] = all(met[n]["semi_alpha_texels"] == 0 for n in ART_LAYERS) and \
        not ((rgba["guides"][..., 3] > 0) & (rgba["guides"][..., 3] < 255)).any()
    gates["art_layers_use_only_palette"] = all(met[n]["colours_outside_art_palette"] == 0 for n in ART_LAYERS)
    gates["palette_38_to_48_in_flat"] = 38 <= s["distinct_colours_in_flat"] <= 48
    gates["fg_occlusion_le_12pct_walkable"] = s["fg_occlusion_over_walkable_ratio"] <= 0.12
    gates["actor_visible_ge_one_third_everywhere"] = s["actor_visibility_below_one_third"] == 0
    gates["ysort_post"] = all(v["ok"] for v in ys.values())
    gates["axial_walk_clear_and_walkable"] = ax["ok"]
    gates["tree_shape_families_ge_3"] = len(fams) >= 3
    gates["survey_post_ge_2x_actor"] = s["survey_post_height_px"] >= 96
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        dj = json.loads(z.read("data.json"))
    gates["pxo_layer_stack_matches_spec"] = [l["name"] for l in dj["layers"]] == LAYERS and \
        [l["visible"] for l in dj["layers"]] == [n != "guides" for n in LAYERS]
    gates["build_deterministic"] = artefacts()[3] == files
    evidence = {}
    if use_pixelorama:
        rep["pixelorama"] = pixelorama_gate(exe, files, rgba, flat)
        gates.update(rep["pixelorama"]["verdicts"])
        fp = rep["pixelorama"].pop("_flat_png", None)
        if fp is not None:
            evidence[fname("pixelorama-pxo-flat-export", "png")] = fp
    if godot:
        rep["godot"], stills = godot_gate(godot, files, rgba)
        gates.update(rep["godot"]["verdicts"])
        for k, b in stills.items():
            evidence[fname("godot-still-" + k.replace("_", "-"), "png")] = b
    rep["result"] = "PASS" if all(gates.values()) else "FAIL"
    rep["note"] = "Technical gates only. Passing them does not make the art accepted; acceptance is creator review."
    text = json.dumps(rep, indent=2) + "\n"
    print(text)
    if write_report:
        out = rp(OUT_REL)
        print(write_new(os.path.join(out, fname("technical-check-report", "json")), text.encode()))
        for name, b in evidence.items():
            print(write_new(os.path.join(out, name), b), name)
    return 0 if rep["result"] == "PASS" else 1


GODOT_SCRIPT = r'''extends SceneTree
# Test-only, nonruntime: load the split layer PNGs with Image.load, report size/format/sha256 of the raw RGBA,
# then composite runtime-stack stills (base 1-6 -> Y-sorted {post, actor} -> fg-occlusion) with blend_rect.
func _init():
	var a = OS.get_cmdline_user_args()
	var dir: String = a[0]
	var names = ["ground-base", "paving-walks", "terrace-walls", "ground-detail", "cast-shadows", "props-low", "survey-post", "fg-occlusion"]
	var out = {"layers": {}, "stills": {}}
	var imgs = {}
	for n in names:
		var img = Image.load_from_file(dir + "/" + n + ".png")
		var fmt_in = img.get_format()
		if fmt_in != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		var h = HashingContext.new()
		h.start(HashingContext.HASH_SHA256)
		h.update(img.get_data())
		out["layers"][n] = {"w": img.get_width(), "h": img.get_height(), "format_loaded": fmt_in, "sha256_rgba": h.finish().hex_encode()}
		imgs[n] = img
	var hero = Image.load_from_file(dir + "/heroine48.png")
	hero.convert(Image.FORMAT_RGBA8)
	var cases = JSON.parse_string(FileAccess.get_file_as_string(dir + "/cases.json"))
	var pivot_y: int = int(cases["pivot_y"])
	for key in cases["feet"].keys():
		var foot = cases["feet"][key]
		var st = imgs["ground-base"].duplicate()
		for n in ["paving-walks", "terrace-walls", "ground-detail", "cast-shadows", "props-low"]:
			st.blend_rect(imgs[n], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		var hp = Vector2i(int(foot[0]) - hero.get_width() / 2, int(foot[1]) - hero.get_height() + 1)
		if int(foot[1]) < pivot_y:
			st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
			st.blend_rect(imgs["survey-post"], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		else:
			st.blend_rect(imgs["survey-post"], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
			st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
		st.blend_rect(imgs["fg-occlusion"], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		st.save_png(dir + "/still_" + key + ".png")
		out["stills"][key] = "still_" + key + ".png"
	var f = FileAccess.open(dir + "/godot_report.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("GODOT_GATE_DONE")
	quit()
'''


def godot_gate(godot, files, rgba):
    """Gate 4 (test-only, nonruntime): a throwaway Godot project under %LOCALAPPDATA%\\Temp with APPDATA also
    redirected there, so nothing is written to the repo or to the real Godot user dir."""
    tmp = tempfile.mkdtemp(prefix="wb-wdcgodot-")
    rep = {"godot": godot, "godot_sha256": sha(read_bytes(godot)), "steps": {}}
    stills = {}
    try:
        proj = os.path.join(tmp, "proj"); os.makedirs(proj)
        data = os.path.join(tmp, "data"); os.makedirs(data)
        fake = os.path.join(tmp, "appdata"); os.makedirs(fake)
        with open(os.path.join(proj, "project.godot"), "w", newline="\n") as f:
            f.write('config_version=5\n\n[application]\nconfig/name="wdc-scene-gate-v02-91f31699"\n')
        with open(os.path.join(proj, "gate.gd"), "w", newline="\n") as f:
            f.write(GODOT_SCRIPT)
        # the layer PNGs exactly as stored in the .ora (the interchange copy of the editable stack)
        with zipfile.ZipFile(io.BytesIO(files["ora"])) as z:
            for n in ART_LAYERS:
                with open(os.path.join(data, f"{n}.png"), "wb") as f:
                    f.write(z.read(f"data/{n}.png"))
        spr = heroine_48()
        Image.fromarray(spr, "RGBA").save(os.path.join(data, "heroine48.png"))
        feet = {k: list(v) for k, v in actor_cases().items() if k in ("entry", "post_behind", "post_front",
                                                                      "terrace_stairs", "terrace_portico")}
        with open(os.path.join(data, "cases.json"), "w") as f:
            json.dump({"pivot_y": POST[1], "feet": feet}, f)
        env = dict(os.environ); env["APPDATA"] = fake
        p = subprocess.run([godot, "--headless", "--path", proj, "--script", "gate.gd", "--", data],
                           capture_output=True, text=True, timeout=300, env=env, encoding="utf-8", errors="replace")
        rep["exit_code"] = p.returncode
        rep["printed_done"] = "GODOT_GATE_DONE" in p.stdout
        gr = json.load(open(os.path.join(data, "godot_report.json")))
        lay_ok = {}
        for n in ART_LAYERS:
            g = gr["layers"][n]
            lay_ok[n] = g["w"] == W and g["h"] == H and g["sha256_rgba"] == sha(np.ascontiguousarray(rgba[n]).tobytes())
            rep["steps"][n] = {**g, "exact_texels_vs_source": lay_ok[n]}
        st_ok = {}
        for k, foot in feet.items():
            b = read_bytes(os.path.join(data, f"still_{k}.png"))
            got = decode(b)[2]
            exp = runtime_stack_still(rgba, spr, tuple(foot))
            st_ok[k] = bool(got.shape == exp.shape and (got == exp).all())
            rep["steps"]["still_" + k] = {"foot": foot, "equals_python_runtime_stack": st_ok[k],
                                          "differing_texels": int((got != exp).any(axis=2).sum())}
            stills[k] = b
        rep["verdicts"] = {"godot_loads_layers_exact": all(lay_ok.values()) and rep["exit_code"] == 0,
                           "godot_stills_match_ysort_and_occlusion": all(st_ok.values()),
                           "godot_wrote_nothing_outside_temp": not os.path.isdir(
                               os.path.join(os.environ.get("APPDATA", ""), "Godot", "app_userdata", "wdc-scene-gate-v02-91f31699"))}
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    return rep, stills


def pixelorama_gate(exe, files, rgba, flat):
    real_root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    rep = {"pixelorama": exe, "pixelorama_sha256": sha(read_bytes(exe)),
           "isolation": "APPDATA redirected to a fresh temp dir per run; real %APPDATA%\\pixelorama polled every "
                        "10 ms with a kill-switch", "steps": {}}
    tmp = tempfile.mkdtemp(prefix="wb-wdcscene-")
    try:
        src = {}
        for k in ("pxo", "ora"):
            src[k] = os.path.join(tmp, f"src.{k}")
            with open(src[k], "wb") as f:
                f.write(files[k])
        flats = []
        for label, k, split in (("pxo_flat_1", "pxo", False), ("pxo_flat_2", "pxo", False),
                                ("pxo_split", "pxo", True), ("ora_flat", "ora", False), ("ora_split", "ora", True)):
            d = os.path.join(tmp, label); os.makedirs(d)
            fake = os.path.join(tmp, "appdata_" + label); os.makedirs(fake)
            args = ["--export"] + (["--split-layers"] if split else []) + ["-o", os.path.join(d, "f.png"), src[k]]
            r = run_isolated(exe, args, fake, real_root)
            r["pngs"] = list_pngs(d)
            r["source_copy_unchanged"] = read_bytes(src[k]) == files[k]
            if not split and len(r["pngs"]) == 1:
                b = read_bytes(os.path.join(d, r["pngs"][0]))
                a = decode(b)[2]
                r["png_sha256"] = sha(b)
                r["flat_equals_expected"] = a.shape == flat.shape and bool((a == flat).all())
                r["differing_texels"] = int((a != flat).any(axis=2).sum()) if a.shape == flat.shape else None
                if k == "pxo":
                    flats.append(b)
            if split:
                got = []
                comp = None
                for f in r["pngs"]:
                    a = decode(read_bytes(os.path.join(d, f)))[2]
                    hit = [n for n in LAYERS if a.shape == rgba[n].shape and a.tobytes() == rgba[n].tobytes()]
                    semi = int(((a[..., 3] > 0) & (a[..., 3] < 255)).sum())
                    got.append({"file": f, "exact_layer_match": hit, "semi_alpha": semi})
                r["split"] = got
                matched = [h for g in got for h in g["exact_layer_match"]]
                r["art_layers_all_exact"] = all(n in matched for n in ART_LAYERS)
                r["guides_exported"] = "guides" in matched or any("guides" in g["file"] for g in got)
                # composite of the split art layers (bottom->top) must equal the flattened expectation
                order = {n: i for i, n in enumerate(LAYERS)}
                stack = sorted(((order[g["exact_layer_match"][0]], g["file"]) for g in got
                                if g["exact_layer_match"] and g["exact_layer_match"][0] != "guides"))
                if stack:
                    comp = decode(read_bytes(os.path.join(d, stack[0][1])))[2].copy()
                    for _, f in stack[1:]:
                        a = decode(read_bytes(os.path.join(d, f)))[2]
                        m = a[..., 3] == 255
                        comp[m] = a[m]
                    r["split_composite_equals_flat"] = bool((comp == flat).all())
            rep["steps"][label] = r
        rep["pxo_flat_runs_identical"] = len(flats) == 2 and flats[0] == flats[1]
        if flats:
            rep["_flat_png"] = flats[0]
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    st = rep["steps"]
    guard_ok = all(not v["killed_by_guard"] and not v["real_dir_changed_except_running"]
                   and v["real_running_marker_present_after"] for v in st.values())
    rep["verdicts"] = {
        "pixelorama_isolation_held": guard_ok,
        "pixelorama_pxo_flat_exact": all(st[k].get("flat_equals_expected") for k in ("pxo_flat_1", "pxo_flat_2")),
        "pixelorama_pxo_flat_deterministic": rep["pxo_flat_runs_identical"],
        "pixelorama_pxo_split_layers_exact": st["pxo_split"].get("art_layers_all_exact", False),
        "pixelorama_pxo_split_composite_equals_flat": st["pxo_split"].get("split_composite_equals_flat", False),
        "pixelorama_ora_flat_exact": st["ora_flat"].get("flat_equals_expected", False),
        "pixelorama_ora_split_layers_exact": st["ora_split"].get("art_layers_all_exact", False),
        "pixelorama_sources_unchanged": all(v["source_copy_unchanged"] for v in st.values()),
        "pixelorama_split_does_not_export_hidden_guides": not any(st[k].get("guides_exported")
                                                                  for k in ("pxo_split", "ora_split")),
    }
    return rep


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("dir", nargs="?")
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    ap.add_argument("--write-report", action="store_true")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--godot", default=rp(GODOT_REL))
    ap.add_argument("--no-godot", action="store_true")
    a = ap.parse_args()
    if a.mode == "preview":
        if not a.dir or os.path.abspath(a.dir).startswith(REPO):
            raise SystemExit("preview needs a directory outside the repo")
        return build(a.dir)
    if a.mode == "build":
        return build()
    if not a.no_pixelorama and not os.path.isfile(a.pixelorama):
        raise SystemExit(f"Pixelorama not found: {a.pixelorama}")
    godot = None
    if not a.no_godot:
        if not os.path.isfile(a.godot):
            raise SystemExit(f"Godot not found: {a.godot} (or pass --no-godot)")
        godot = os.path.abspath(a.godot)
    return check(os.path.abspath(a.pixelorama), a.write_report, not a.no_pixelorama, godot)


if __name__ == "__main__":
    sys.exit(main())
