"""UNAPPROVED, NONRUNTIME test-only pilot v11: female protagonist side-view battle idle, facing right, ONE static frame.

Identity-density pass over v10 (no motion, no batch, no runtime swap). Same cell (68x72), same pin (32, 68), same sole
row 67, same crown row 7, so the creator-approved 0.65 battle display proportion (crown-to-sole 61 logical px at node
scale 1.0) and the foot baseline are unchanged. v10's files are read (hash-gated) and never written. The interrupted
author tool ...-author_unapproved-v11_20261016-175823-e1e2a4b7.py (never built; aimed at the older v10 ruins review) is
not used or edited; this tool forks the verified v10 tool instead.

Targets the Codex visual review of the real v10 640x360 four-person outskirts capture (2026-10-17): the heroine reads too
small / detail-poor next to the approved exploration identity, and her lower body reads warm / orange.
  lower body warm / orange     -> the orange leather ramp (v8 'b' #845436, 'B' #bb7c50) is removed from the palette.
                                  Boots, pack and belt use a deep, low-saturation brown (d #45342e, D #6f5a4c) with the
                                  v8 dark leather (L, l) and v8 pale-beige straps (P, p). The coat hem trim and belt are
                                  dark leather or slate, not lit orange. Trousers stay v8 spruce (T, t) over deep slate (C)
  detail-poor at 0.65          -> denser hand-placed detail inside the same silhouette budget: darker tied hair with a
                                  pale hair tie, a face-framing side lock and fringe strands, a 2x2 eye with brow and
                                  blush, rolled pale sleeve cuff over a bare forearm, a fingerless dark glove with skin
                                  knuckles, a teal shoulder insignia, a grey-brown canvas pack with strap and buckle, a
                                  cool grey knee pad, strapped boots: dark shafts over the paving, lit low-saturation
                                  brown feet in the arena's contact shadow (values picked from the measured rows)
  silhouette vs neighbours     -> leftmost texel stays >= x15 (10 screen px gap to Liang Xu at 640x360); nothing is added
                                  in front of the blade tip, so the gap to the sentry is unchanged

Hand-authored pixel art: each layer is an ASCII block typed below ('.' = transparent). The blade is placed by a 1:1
pixel-line helper (the texels a line tool lays). No resampling, filtering, gradients, dithering, quantizing, image
generation or upscaling. Binary alpha. Fixed palette (<= 32 colours).

Editable source: a layered Pixelorama .pxo (pxo_version 7) and an .ora with the same layers plus a hidden, locked
'guides' layer. The candidate PNG is the Pixelorama 1.2.3 headless flat export of the .pxo (byte-compared to this
tool's render); Pixelorama runs with APPDATA redirected to a fresh temp dir so the real config is never touched.

Modes
  preview <dir> [nosprite.png ...]
                  inspection PNGs in <dir> (outside the repo), one subject per file; with no-sprite captures (1280x720
                  or 640x360), also the exact game-scale composite (texture origin 536,408 at 2x / 268,204 at 1x)
  build           export via Pixelorama, write PNG + .pxo + .ora + manifest (never overwrites a different file)
  check           technical gates on the built files incl. Pixelorama flat + split-layer round-trips, layer names and
                  palette diff vs v10, silhouette report vs v10, identity / lower-body / boot gates, layer-stack
                  recomposition of the .pxo and .ora; writes nothing

Run with the real Python in isolated mode:  python -I -B <this file> preview <dir> | build | check
"""
import argparse, colorsys, hashlib, io, json, os, shutil, subprocess, sys, tempfile, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
VER = "unapproved-v11"
STAMP = "20261017-023937"
RUN_ID = "c4a17e52"
W, H = 68, 72
PIN = (32, 68)            # same as v03-v10: first transparent row under the soles, between the feet
CROWN_ROW = 7             # same as v03-v10: head crown row; soles end on row 67 -> crown-to-sole 61 rows
SOLE_ROW = 67
HEAD_COLS = (24, 47)      # crown columns are searched here (same as v10)
OUT_DIR_REL = "game/assets/characters/combat-sideview-pilots"
_V10 = "rpg-2-star-ocean-the-second_protagonist-female_sideview-idle-right-static-native0p65_"
V10_LOCKS = {             # v10 (local, hash-pinned in the 1db015e evidence index) is read-only for this tool
    OUT_DIR_REL + "/" + _V10 + "unapproved-v10_20261016-162819-1c891d6d.png":
        "dd7dbc7ac7ffb818b06c00c6af154b12d774b8c5a7f40d64d39454fb3a2eaaf7",
    OUT_DIR_REL + "/" + _V10 + "editable-layers_unapproved-v10_20261016-162819-73e8d4a2.pxo":
        "8aa3a6ea58235f14bcbac0670e58d1256009a9053a14c3a7f40363d8293bbefb",
    OUT_DIR_REL + "/" + _V10 + "editable-layers_unapproved-v10_20261016-162819-d0483645.ora":
        "fd0a685b5ceec29a2ec793af06764873b97eb45021551a7d44ec97e2f6b5fea8",
    OUT_DIR_REL + "/" + _V10 + "manifest_unapproved-v10_20261016-162819-0fb8a88b.json":
        "439af456926463eaebee5cc5b42f26b853f335a274feec78e52eed9e728ea5ab",
}
V10_PNG_REL, V10_PXO_REL, V10_ORA_REL, V10_MANIFEST_REL = list(V10_LOCKS)
V8_SOUTH_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
                "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
CHARACTER_SHEET_REL = "outputs/rpg-2-star-ocean-the-second_protagonist_character-sheet_female_20261013-153316-8fa4d0c3.png"
PIXELORAMA_REL = "work/tooling/pixelorama-1-2-3/Pixelorama-Windows-64bit/Pixelorama.exe"
PIXELORAMA_VERSION = "v1.2.3-stable"
GUIDE_RGB = (255, 0, 255)
CAPTURE_ORIGIN = {1280: (536, 408), 640: (268, 204)}   # screen px of texel (0, 0): hero x 300, floor 272, k = W / 640
BOOT_CONTACT_ROWS = (62, 65)                           # rows standing in the arena's contact shadow
LOWER_BODY_ROW = 38                                    # belt and everything below it


def fid(role):
    return hashlib.sha256(f"{RUN_ID}:{role}".encode()).hexdigest()[:8]


SUBJECT = "protagonist-female_sideview-idle-right-static-native0p65"
PNG_NAME = f"{SLUG}_{SUBJECT}_{VER}_{STAMP}-{fid('png')}.png"
PXO_NAME = f"{SLUG}_{SUBJECT}_editable-layers_{VER}_{STAMP}-{fid('pxo')}.pxo"
ORA_NAME = f"{SLUG}_{SUBJECT}_editable-layers_{VER}_{STAMP}-{fid('ora')}.ora"
MANIFEST_NAME = f"{SLUG}_{SUBJECT}_manifest_{VER}_{STAMP}-{fid('manifest')}.json"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))

PALETTE = {               # v10's 30 keys minus the orange leather pair (b, B), plus a deep low-saturation brown pair (d, D)
    "K": "#16141a",                                                                  # outline
    "1": "#231816", "2": "#3d2a22", "3": "#5c3e2c", "4": "#82593b", "h": "#a8794f",  # hair dark -> sheen
    "S": "#fbd5b0", "s": "#e7a67c", "x": "#b36f50", "E": "#1d1214",                  # skin light/mid/shadow, eye/brow
    "C": "#222839", "c": "#3a4560", "o": "#5e6e8c",                                  # v8 storm-slate coat C3/C2/C1
    "T": "#324542", "t": "#4a625c",                                                  # v8 spruce trousers T2/T1
    "W": "#f3ead9", "w": "#c6b59d",                                                  # shirt / shadowed white
    "P": "#d7c0a8", "p": "#b09986",                                                  # v8 pale beige: cuff, buckle, strap
    "L": "#2e1c14", "l": "#533626",                                                  # v8 dark leather
    "d": "#45342e", "D": "#6f5a4c",                                                  # deep boot / pack brown (new)
    "Q": "#0a323b", "q": "#1a767b", "g": "#249b98", "G": "#6cc9bc",                  # teal (v8 scarf + one light)
    "m": "#5a6470", "M": "#a9b5bd", "Z": "#eef4f5",                                  # steel / grey knee pad
}
REMOVED_KEYS_VS_V10 = ["B", "b"]                  # sorted() order
ADDED_KEYS_VS_V10 = ["D", "d"]

LAYERS = []


def block(name, x0, y0, text):
    """One layer from an ASCII block: row i of text is canvas row y0+i, column j is canvas x0+j."""
    rows = [r for r in text.strip("\n").split("\n")]
    LAYERS.append((name, [(x0 + j, y0 + i, ch) for i, r in enumerate(rows) for j, ch in enumerate(r.strip())
                          if ch != "."]))


def block_px(name, texels):
    LAYERS.append((name, list(texels)))


# ===================================================================================================== layers
# bottom -> top.  Column rulers in comments are absolute canvas x.

# far (back) leg braced back onto the ball of the foot (v10 outline). Trouser: v8 trouser deep slate (C) with a spruce
# (T) crease. Boot values are picked against the measured arena rows (v11 capture pass): over the paving (rows 58-61,
# L ~75-110) a dark turned-down cuff (l) and deep-brown shaft (d, L 55) with a pale strap (p); in the contact shadow
# (rows 62-67, L ~45-70) a lit low-saturation brown foot (D, L 93, not orange) with a pale toe glint, dark heel and sole
# (L)
#                x16       x26
block("far-leg", 16, 42, """
...........KCCCCK.
...........KCCTCK.
..........KCCTCK..
..........KCCTCK..
.........KCCTCK...
.........KCCTCK...
........KCCTCK....
........KCCTCK....
.......KCCTCK.....
.......KCTCK......
.......KCTCK......
......KCCTK.......
......KCCTK.......
......KCCTK.......
.....KCCTK........
.....KCCTK........
....KKKKKKK.......
....KlllldK.......
...KddddddK.......
...KdppddddK......
..KLDDDDDDDdK.....
..KLDDDDDDDDDK....
.KLLDDDDDDDDpDK...
.KKLLDDDDDDDDDDK..
...KKLLLLLLLLLLLK.
.....KKKKKKKKKKKK.
""")

# v8's teal back-hip cloth hung BEHIND the coat skirt (v10 drawing, unchanged)
#                   x15       x25
block("hip-drape", 15, 41, """
.....KgqqK.
.....KgqqK.
....KgqqqK.
....KgqqQK.
...KgqqQqK.
...KgqQqqK.
...KgqQqqK.
..KgqqQqK..
..KgqQqqK..
..KgqQqK...
.KgqqQqK...
.KgqQqqK...
KgqqQqK....
KgqQKqK....
KgqK.KqK...
KqK..KK....
.K.........
""")

# grey-brown canvas pack on the upper back (sheet colours, not v10's tan): lit flap top (D), dark flap edge (L), deep
# body (d) with one dark-leather strap (l) carrying a pale buckle (P); the coat draws over its right edge
#               x17       x26
block("pack", 17, 28, """
.KKKKKKKKK
KDDDDDDDDK
KDDDDDDDdK
KdDDDDDDdK
KLLLLLLLLK
KdDlDDDDdK
KdDPDDDDdK
KdDlDDDDdK
KddlddddLK
KLdldddLLK
.KKKKKKKK.
""")

# teal blanket roll strapped along the pack's top edge (v10 drawing); the strap is now pale beige (p) over dark leather
# (L) instead of lit orange leather
#               x15      x24
block("bedroll", 15, 22, """
..KKKKKKK.
.KgQgGGpGK
KQgQQggpgK
KQQgQggpgK
KqQqQqqLqK
.KqqQqqLK.
..KKKKKK..
""")

# high tied ponytail, darker than v10 (dark body 1/2, mid strands 3, one sheen line 4/h): rises up-back from the pale
# hair tie, falls behind the head and ends in two split locks above the roll
#               x18
block("ponytail", 16, 1, """
........KKKKK...
.......K22333K..
.....K1223344hK.
....K112233443K.
...K1122233432K.
..K1122223332K..
..K11222K.K22K..
.K11222K..K2....
.K11223K..KK....
.K11232K........
K11223K.........
K11232K.........
K12223K.........
K1122K..........
K12K1K..........
.K1K1K..........
..K.K...........
""")

# near (front) leg: spruce thigh (T body, t front edge, C back) to a bent knee with a cool grey knee pad (m/M over C)
# on a dark strap (L/l), spruce shin, boot as the far one (dark cuff and shaft over the paving, lit foot in the contact
# shadow) with the light pale strap (P)
#                x32       x42
block("near-leg", 32, 41, """
.KCTTtK...........
.KCTTtK...........
..KCTTtK..........
..KCTTttK.........
...KCTTtK.........
...KCTTttK........
....KCTTtK........
....KCTTttK.......
.....KCTTtK.......
.....KCTTttK......
......KCmmMMK.....
......KCCmmmK.....
.......KLlllK.....
.......KCTTtK.....
.......KCTTtK.....
.......KCTTtK.....
.......KCTTtK.....
......KKKKKKKK....
......KllllldK....
......KddddddK....
......KdPPdddK....
......KLDDDDDDK...
......KLDDDDDDDK..
......KLDDDDDDPDK.
......KLLDDDDDDDK.
......KLLLLLLLLLK.
.......KKKKKKKKKK.
""")

# coat torso + belt, leaning (v10 outline and value planes: deep back C, mid band c, lit front o); one back seam (c) for
# fabric structure; the belt is dark leather (l over L) with a pale buckle (P/p) instead of a lit orange top row
#                x24       x34
block("coat", 24, 22, """
.......KKKKK.....
.....KKCcoooK....
....KCCCcoooo....
....KCCCCcoooo...
...KCCCCCcoooo...
...KCCCCCcooooo..
...KCCCCCCcooooo.
...KCCCCCCcoooooo
..KCCCCCCcoooooo.
..KCCCCCCcoooooo.
..KCCCCCCcoooooo.
..KCCCCCCcoooooo.
.KCCCCCCcoooooo..
.KCCCCCCcooooooo.
.KCCCCCCcooooooo.
KCCCCCCcooooooo..
KlllllllllPPlll.
KLLLLLLLLLLppLLL.
""")

# coat skirt (v10 outline): deep back tail (C), mid band (c), lit front panel (o) with one fold line (c) and a mid hem
# band (c); the hem trim is deep slate (C) / dark leather (l) instead of lit orange leather
#                  x17       x27       x37
block("coat-skirt", 17, 40, """
......KCCCCCCcoooooooooooK.
.....KCCCCCCcoCoooocooooooK
.....KCCCCCCcoCKoooocoooooK
....KCCCCCCcoCCKoooocooocCK
....KCCCCCCcoCCKoooccccclK.
...KCCCCCCcoCCCKccccccllK..
...KCCCCCCcoCCK.KclllKKK...
...KCCCCCcoCCK...KKKK......
..KCCCCCCcolK..............
..KCCCCCcllK...............
..KCCCcllK.................
.KCClllK...................
.KllKK.....................
.KKK.......................
""")

# open coat front over the white shirt, lit lapel edge (v10 drawing)
#                    x35
block("shirt-lapel", 35, 23, """
.ooKWWK
.oooKWWK
..ooKWWWK
.ooKwWWWK
..oKwWWWK
..oKwWWWK
..oKwWWWK
..KwWWWK
..KwWWWK
..KwWWWK
..KwWWK
.KwWWK
.KwWWK
.KwWWK
KwWWK
""")

# near arm reaching forward, sleeve rolled to the elbow (v8 identity): lit slate upper arm (o top, C underside), bulky
# pale-beige rolled cuff (P/p) at the elbow, bare forearm (S lit top, s, x underside) level to the wrist
#                 x28       x38
block("near-arm", 28, 23, """
...KKKKK........
..KooooooK......
..KCoooooK......
...KCoooooK.....
...KCCooooK.....
....KCCooooK....
....KCCoooPKKKKK
....KCCcoPPPSSSK
.....KCCpPpsSssK
......KCKppxxxxK
.......KKKKKKKKK
""")

# teal insignia patch on the upper sleeve (the character sheet's teal diamond): a 3x3 diamond, light core (G) with a mid
# teal (g) rim; at 1x it is a colour placement, not a readable emblem
#                 x33
block("insignia", 33, 24, """
.g.
gGg
.g.
""")


# ordinary short sword raised forward at 45 degrees (v10 blade, unchanged): each row is outline, edge light (Z), steel
# (M), outline, one texel further forward per row up; short tapered tip
def blade_segments(y0=26, y1=18):
    segs = []
    for y in range(y1, y0 + 1):
        x = 76 - y                       # edge-light column on row y
        segs += [(x - 1, y, "K"), (x, y, "Z"), (x + 1, y, "M"), (x + 2, y, "K")]
    x = 76 - (y1 - 1)
    segs += [(x - 1, y1 - 1, "K"), (x, y1 - 1, "Z"), (x + 1, y1 - 1, "K"), (x, y1 - 2, "K")]
    return segs


block_px("sword-blade", blade_segments())

# small steel crossguard square to the blade, at the top-front of the fist (v10 drawing)
block("sword-guard", 47, 25, """
KK...
KMK..
.KMK.
..KMK
...KK
""")

# fingerless dark glove closed round the grip: dark leather back of the hand and wrist (l/L), bare finger knuckles and
# thumb at the front (S lit, s, x shadow); the grip end shows under the little finger
block("fist", 43, 27, """
.KKKK..
KlSSSK.
KllSSsK
KLlsSsK
KLlssxK
.KLKKK.
..K....
""")

# head: v10 outline; darker hair (1/2 body, 3 strands, 4/h sheen arc), fringe strands over the brow, a side lock framing
# the face in front of the ear, 2x2 eye under a dark brow, blush, nose step, mouth
#            x28
block("head", 28, 7, """
.....KKKKKKK.......
...KK11222334KK....
..K11122223443KK...
.K111222233h432K...
.K11122222334322K..
.K1112222322S2S2K..
.K112222212SSEEESK.
.K112222121SSSEESK.
.K112222121sSSEWSSK
.K112221121sssSSSK.
.K112211112ssSSxSK.
.K112111K1xssSSSK..
..K1111K.K1xsKKK...
""")

# pale-beige hair tie knotted on the crown-back, where the ponytail leaves the head
block("hair-tie", 28, 7, """
.KK.
KPpK
KpPK
.KK.
""")

# raised coat collar standing behind the nape (v10 drawing)
block("collar", 28, 16, """
.KK..
KooK.
KoooK
KoooK
KCooK
KCcoK
""")

# scarf at the neck: thick wrap, knot and short front tail (v10 drawing)
block("scarf-neck", 29, 20, """
.KqggGGggggGgK.
KQqqgggqqggGGgK
KQQqqqqQqqggGgK
KQQQqqQQqqggqK.
.KKKKKKKQqgGqK.
........KqgGK..
........KQqgK..
.........KqK...
..........K....
""")

# front half of the raised collar over the scarf's front edge (v10 drawing)
block("collar-front", 42, 20, """
.KK.
KooK
KooK
KcoK
KcoK
.KK.
""")

LAYER_NAMES = [n for n, _ in LAYERS] + ["guides"]
V10_LAYER_NAMES_PLUS = ["insignia"]          # v11 = v10's 18 layer names + this one (+ guides)


# ===================================================================================================== raster
def hex_rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def guides_rgba(comp):
    g = np.zeros((H, W, 4), np.uint8)
    pts = set()
    pts.update((x, 0) for x in range(W)); pts.update((x, H - 1) for x in range(W))
    pts.update((0, y) for y in range(H)); pts.update((W - 1, y) for y in range(H))
    for y in (CROWN_ROW, SOLE_ROW):
        pts.update((x, y) for x in list(range(1, 4)) + list(range(W - 4, W - 1)))
    pts.add(PIN)
    for x, y in pts:
        g[y, x, :3] = GUIDE_RGB
        g[y, x, 3] = 255
    if (comp[..., 3][g[..., 3] > 0] != 0).any():
        raise SystemExit("a guide texel overlaps an opaque art texel")
    return g


def render():
    """Returns ({layer name: RGBA}, composite RGBA). Alpha is binary, so 'over' is a plain copy."""
    blobs = {}
    comp = np.zeros((H, W, 4), np.uint8)
    for name, texels in LAYERS:
        a = np.zeros((H, W, 4), np.uint8)
        for x, y, ch in texels:
            if ch not in PALETTE:
                raise SystemExit(f"{name}: unknown key {ch!r} at x{x} y{y}")
            if not (0 <= x < W and 0 <= y < H):
                raise SystemExit(f"{name}: texel ({x},{y}) outside the {W}x{H} cell")
            a[y, x, :3] = hex_rgb(PALETTE[ch])
            a[y, x, 3] = 255
        blobs[name] = a
        m = a[..., 3] == 255
        comp[m] = a[m]
    blobs["guides"] = guides_rgba(comp)
    return blobs, comp


def png_bytes(rgba):
    buf = io.BytesIO()
    Image.fromarray(rgba, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


# ===================================================================================================== paths / hashes
WIN_MAX_PATH = 259
WIN_LONG_PREFIX = "\\\\?\\"


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > WIN_MAX_PATH - 12 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def repo_path(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(path):
    with open(_fs(path), "rb") as f:
        return f.read()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def lock_hash(rel):
    """sha256-bytes for binaries; sha256-text-lf-v1 (CRLF -> LF) for the .json lock, so a core.autocrlf=true checkout
    still matches. The v10 manifest is LF on disk, so both algorithms give the same locked value."""
    data = read_bytes(repo_path(rel))
    return sha256_bytes(data.replace(b"\r\n", b"\n") if rel.endswith(".json") else data)


def v10_lock():
    files = {rel: lock_hash(rel) for rel in V10_LOCKS}
    return {"files": files, "unchanged": all(files[rel] == want for rel, want in V10_LOCKS.items())}


def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


# ===================================================================================================== v10 comparison
def v10_reference():
    """v10's flat PNG, its per-layer RGBA from the locked .ora, and its manifest palette (all read-only)."""
    png = decode(read_bytes(repo_path(V10_PNG_REL)))[2]
    with zipfile.ZipFile(io.BytesIO(read_bytes(repo_path(V10_ORA_REL)))) as z:
        names = [n[len("data/"):-len(".png")] for n in z.namelist() if n.startswith("data/") and n.endswith(".png")]
        layers = {n: decode(z.read(f"data/{n}.png"))[2] for n in names}
    man = json.loads(read_bytes(repo_path(V10_MANIFEST_REL)))
    order = [l["name"] for l in man["layers_bottom_to_top"]]
    return png, layers, order, man["palette"]


def bbox(alpha):
    ys, xs = np.nonzero(alpha)
    return None if len(xs) == 0 else [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]


def visible_masks(blobs):
    """Per layer: texels where that layer is the top-most opaque layer (what the viewer actually sees of it)."""
    owner = np.full((H, W), -1, np.int16)
    for i, name in enumerate(LAYER_NAMES[:-1]):
        owner[blobs[name][..., 3] == 255] = i
    return {name: owner == i for i, name in enumerate(LAYER_NAMES[:-1])}


def silhouette_report(comp, blobs):
    """How v11 differs from v10: whole-sprite alpha silhouette, composite texels, per layer, palette and layer names."""
    v10_png, v10_layers, v10_order, v10_pal = v10_reference()
    a11, a10 = comp[..., 3] > 0, v10_png[..., 3] > 0
    inter, union = int((a11 & a10).sum()), int((a11 | a10).sum())
    layers = {}
    for name in LAYER_NAMES[:-1]:
        mine = blobs[name][..., 3] > 0
        theirs = v10_layers[name][..., 3] > 0 if name in v10_layers else None
        same_px = theirs is not None and np.array_equal(blobs[name], v10_layers[name])
        layers[name] = {"texels_v10": None if theirs is None else int(theirs.sum()), "texels_v11": int(mine.sum()),
                        "bbox_v10": None if theirs is None else bbox(theirs), "bbox_v11": bbox(mine),
                        "byte_identical_to_v10": bool(same_px),
                        "changed_texels": None if theirs is None else int((blobs[name] != v10_layers[name]).any(-1).sum())}
    v10_names = [n for n in v10_order if n != "guides"]
    pal10 = {k: v.lower() for k, v in v10_pal.items()}
    pal11 = {k: v.lower() for k, v in PALETTE.items()}
    return {
        "silhouette_texels_v10": int(a10.sum()), "silhouette_texels_v11": int(a11.sum()),
        "silhouette_iou": round(inter / union, 4), "silhouette_added_texels": int((a11 & ~a10).sum()),
        "silhouette_removed_texels": int((a10 & ~a11).sum()),
        "silhouette_bbox_v10": bbox(a10), "silhouette_bbox_v11": bbox(a11),
        "composite_changed_texels": int((comp != v10_png).any(-1).sum()),
        "layers": layers,
        "byte_identical_layers": [n for n in LAYER_NAMES[:-1] if layers[n]["byte_identical_to_v10"]],
        "layers_added_vs_v10": [n for n in LAYER_NAMES[:-1] if n not in v10_names],
        "layers_removed_vs_v10": [n for n in v10_names if n not in LAYER_NAMES],
        "layer_order_v10": v10_order,
        "palette_keys_removed_vs_v10": sorted(set(pal10) - set(pal11)),
        "palette_keys_added_vs_v10": sorted(set(pal11) - set(pal10)),
        "palette_shared_keys_same_colour": all(pal10[k] == pal11[k] for k in set(pal10) & set(pal11)),
    }


# ===================================================================================================== identity gates
def lum(rgb):
    rgb = np.asarray(rgb, float)
    return 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]


def warm_orange_mask(rgba):
    """Opaque texels whose colour is a saturated orange/tan: hue 10-50 deg, HSV saturation >= 0.45, value >= 0.40."""
    m = np.zeros(rgba.shape[:2], bool)
    for y, x in zip(*np.nonzero(rgba[..., 3] > 0)):
        r, g, b = (int(v) / 255 for v in rgba[y, x, :3])
        h, s, v = colorsys.rgb_to_hsv(r, g, b)
        m[y, x] = 10 / 360 <= h <= 50 / 360 and s >= 0.45 and v >= 0.40
    return m


def lower_body_report(rgba):
    """Belt row and everything below it: share of saturated orange texels and of cool (blue/green/teal-ish) texels."""
    op = rgba[..., 3] > 0
    op[:LOWER_BODY_ROW] = False
    warm = warm_orange_mask(rgba) & op
    rgb = rgba[..., :3].astype(int)
    cool = op & (rgb[..., 2] >= rgb[..., 0]) & ~(rgb == np.array(hex_rgb(PALETTE["K"]))).all(-1)
    n = int(op.sum())
    return {"opaque_texels": n, "warm_orange_texels": int(warm.sum()),
            "warm_orange_share": round(int(warm.sum()) / max(1, n), 4),
            "cool_texels_blue_ge_red_excl_outline": int(cool.sum()),
            "cool_share": round(int(cool.sum()) / max(1, n), 4),
            "mean_L_excl_outline": round(float(lum(rgba[op & ~(rgb == np.array(hex_rgb(PALETTE["K"]))).all(-1)][:, :3])
                                               .mean()), 1)}


def keycount(rgba, mask, keys):
    rgb = rgba[..., :3]
    return int(sum((mask & (rgb == np.array(hex_rgb(PALETTE[k]), np.uint8)).all(-1)).sum() for k in keys))


def boot_report(comp, blobs):
    """Each boot: lit top-plane texels (D, P, p) on the contact-shadow rows, deep texels (d, L) on the shaft rows."""
    vis = visible_masks(blobs)
    out = {}
    for leg in ("far-leg", "near-leg"):
        contact = vis[leg].copy()
        contact[:BOOT_CONTACT_ROWS[0]] = False
        contact[BOOT_CONTACT_ROWS[1] + 1:] = False
        shaft = vis[leg].copy()
        shaft[:58] = False
        shaft[BOOT_CONTACT_ROWS[0]:] = False
        out[leg] = {"contact_rows_lit_top_plane_D_P_p": keycount(comp, contact, "DPp"),
                    "contact_rows_deep_d_L": keycount(comp, contact, "dL"),
                    "shaft_rows_deep_d_L": keycount(comp, shaft, "dL"),
                    "shaft_rows_light_anchor_D_P_p": keycount(comp, shaft, "DPp"),
                    "orange_texels": int((warm_orange_mask(comp) & vis[leg]).sum())}
    return out


def identity_report(comp, blobs):
    vis = visible_masks(blobs)
    head, fist, arm = vis["head"], vis["fist"], vis["near-arm"]
    tie = blobs["hair-tie"][..., 3] > 0
    pony = blobs["ponytail"][..., 3] > 0
    roll = blobs["bedroll"][..., 3] > 0
    # transparent texels between the ponytail's lowest locks and the roll, per column (ponytail tail rows only)
    gap = None
    for x in range(W):
        py = np.nonzero(pony[:, x])[0]
        ry = np.nonzero(roll[:, x])[0]
        if len(py) and len(ry):
            g = int(ry.min() - py.max() - 1)
            gap = g if gap is None else min(gap, g)
    return {
        "face_skin_texels_S_s_x": keycount(comp, head, "Ssx"),
        "eye_brow_texels_E": keycount(comp, head, "E"),
        "eye_catch_texels_W": keycount(comp, head, "W"),
        "hair_texels_head_1_2_3_4_h": {k: keycount(comp, head | vis["ponytail"], k) for k in "1234h"},
        "hair_dark_share_1_2": round(keycount(comp, head | vis["ponytail"], "12")
                                     / max(1, keycount(comp, head | vis["ponytail"], "1234h")), 3),
        "hair_tie_visible_pale_texels": keycount(comp, vis["hair-tie"], "Pp"),
        "hair_tie_bbox": bbox(tie),
        "ponytail_to_roll_min_vertical_gap_rows": gap,
        "fist_skin_texels": keycount(comp, fist, "Ssx"),
        "fist_glove_texels": keycount(comp, fist, "lL"),
        "forearm_skin_texels": keycount(comp, arm, "Ssx"),
        "sleeve_rolled_cuff_texels_P_p": keycount(comp, arm, "Pp"),
        "teal_texels_visible": {n: keycount(comp, vis[n], "QqgG") for n in ("scarf-neck", "bedroll", "insignia",
                                                                            "hip-drape")},
        "pack_visible_texels": int(vis["pack"].sum()),
        "pack_bbox": bbox(blobs["pack"][..., 3] > 0),
    }


def pose_report(comp, blobs):
    return {"identity": identity_report(comp, blobs), "boots": boot_report(comp, blobs),
            "lower_body_v11": lower_body_report(comp), "lower_body_v10": lower_body_report(v10_reference()[0])}


def pose_gates(p):
    idn, boots, lb11, lb10 = p["identity"], p["boots"], p["lower_body_v11"], p["lower_body_v10"]
    return {
        "lower_body_orange_le_10pct_of_v10": lb11["warm_orange_texels"] <= 0.10 * lb10["warm_orange_texels"],
        "lower_body_cool_share_higher_than_v10": lb11["cool_share"] > lb10["cool_share"],
        "boots_no_orange": all(b["orange_texels"] == 0 for b in boots.values()),
        "boots_lit_top_plane_in_contact_rows_ge_8": all(b["contact_rows_lit_top_plane_D_P_p"] >= 8
                                                        for b in boots.values()),
        "boot_shafts_mostly_deep": all(b["shaft_rows_deep_d_L"] > b["shaft_rows_light_anchor_D_P_p"]
                                       for b in boots.values()),
        "eye_2x2_plus_brow": idn["eye_brow_texels_E"] >= 6 and idn["eye_catch_texels_W"] >= 1,
        "hair_mostly_dark": idn["hair_dark_share_1_2"] >= 0.6,
        "hair_tie_visible": idn["hair_tie_visible_pale_texels"] >= 3,
        "ponytail_clear_of_roll": idn["ponytail_to_roll_min_vertical_gap_rows"] is None
        or idn["ponytail_to_roll_min_vertical_gap_rows"] >= 2,
        "hand_shows_skin_and_glove": idn["fist_skin_texels"] >= 6 and idn["fist_glove_texels"] >= 4,
        "bare_forearm_and_rolled_cuff": idn["forearm_skin_texels"] >= 8 and idn["sleeve_rolled_cuff_texels_P_p"] >= 6,
        "teal_scarf_roll_insignia_present": all(idn["teal_texels_visible"][n] > 0
                                                for n in ("scarf-neck", "bedroll", "insignia")),
    }


# ===================================================================================================== metrics
def isolated_texels(comp):
    rgb = comp[..., :3].astype(np.int32)
    key = (rgb[..., 0] << 16) | (rgb[..., 1] << 8) | rgb[..., 2]
    op = comp[..., 3] > 0
    line = key == int(PALETTE["K"][1:], 16)
    n = 0
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            if not op[y, x] or line[y, x]:
                continue
            if not any(op[y + dy, x + dx] and key[y + dy, x + dx] == key[y, x]
                       for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                n += 1
    return n


def stats(comp):
    m = comp[..., 3] > 0
    ys, xs = np.nonzero(m)
    cols = {"#%02x%02x%02x" % tuple(int(c) for c in px) for px in comp[m][:, :3]}
    pal = {v.lower() for v in PALETTE.values()}
    crown_cols = [x for x in range(HEAD_COLS[0], HEAD_COLS[1] + 1) if m[CROWN_ROW, x] and not m[:CROWN_ROW, x].any()]
    head_top = min(int(np.nonzero(m[:, x])[0].min()) for x in crown_cols) if crown_cols else None
    return {
        "size": [W, H], "pin": list(PIN), "opaque_texels": int(m.sum()), "colours": len(cols),
        "colours_outside_palette": sorted(cols - pal),
        "alpha_values": sorted({int(v) for v in np.unique(comp[..., 3])}),
        "alpha_bounds_inclusive": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
        "top_row": int(ys.min()), "sole_row": int(ys.max()), "crown_row_measured": head_top,
        "crown_columns": crown_cols, "crown_to_sole_rows": SOLE_ROW - CROWN_ROW + 1,
        "with_ponytail_rows": int(ys.max() - ys.min() + 1),
        "pin_row_clear": bool(not m[PIN[1]:, :].any()),
        "isolated_single_texels": isolated_texels(comp),
    }


def region_counts(comp):
    """Texel counts per material group."""
    groups = {"teal": "QqgG", "steel": "mMZ", "skin": "Ssx", "eye-brow": "E", "hair": "1234h",
              "slate (coat, sleeve, far trouser, leg back edges)": "Cco", "shirt": "Ww",
              "pale beige (cuff, buckle, strap, hair tie)": "Pp", "trousers": "Tt", "dark leather": "Ll",
              "deep brown (boots, pack)": "dD"}
    rgb = comp[..., :3]
    m = comp[..., 3] > 0
    out = {}
    for g, keys in groups.items():
        out[g] = sum(int((m & (rgb == np.array(hex_rgb(PALETTE[k]), np.uint8)).all(-1)).sum()) for k in keys)
    return out


# ===================================================================================================== preview
def on_bg(rgba, bg, zoom):
    im = Image.new("RGBA", (rgba.shape[1], rgba.shape[0]), tuple(bg) + (255,))
    im.alpha_composite(Image.fromarray(rgba, "RGBA"))
    return im.resize((im.width * zoom, im.height * zoom), Image.NEAREST)


def game_scale(rgba, nosprite):
    """The party capture as Godot draws it: each texel a k x k block at the texture origin over the no-sprite frame."""
    im = Image.open(nosprite).convert("RGBA")
    k = im.width // 640
    big = Image.fromarray(rgba, "RGBA").resize((W * k, H * k), Image.NEAREST)
    im.alpha_composite(big, CAPTURE_ORIGIN[im.width])
    return im


def preview(out_dir, nosprites=()):
    """Separate inspection images (one subject each, no sheets), written outside the repo."""
    blobs, comp = render()
    os.makedirs(out_dir, exist_ok=True)
    for tag, bg in (("floor-mid", (88, 84, 80)), ("floor-light", (150, 140, 124)), ("dark", (40, 42, 48))):
        on_bg(comp, bg, 8).save(os.path.join(out_dir, f"v11_x8_{tag}.png"))
    for path in nosprites:
        tag = os.path.splitext(os.path.basename(path))[0]
        full = game_scale(comp, path)
        k = full.width // 640
        full.save(os.path.join(out_dir, f"v11_game-scale_{tag}.png"))
        full.crop((120 * k, 180 * k, 360 * k, 300 * k)).save(os.path.join(out_dir, f"v11_game-scale-crop-1x_{tag}.png"))
        crop = full.crop((240 * k, 190 * k, 340 * k, 280 * k))
        z = 8 // k
        crop.resize((crop.width * z, crop.height * z), Image.NEAREST).save(
            os.path.join(out_dir, f"v11_game-scale-crop-x{z}_{tag}.png"))
    p = pose_report(comp, blobs)
    print(json.dumps({**stats(comp), "material_texels_v11": region_counts(comp), "pose": p,
                      "pose_gates": pose_gates(p), "silhouette_vs_v10": silhouette_report(comp, blobs)}))


# ===================================================================================================== editable files
def make_pxo(png, blobs):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in LAYER_NAMES]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYER_NAMES], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps("sideview-idle-right-static-unapproved-v11"),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": len(LAYER_NAMES) - 2,
            "export_profile": export_profile, "fps": 6.0, "frames": frames_json, "guides": [],
            "layers": layer_json, "license": "", "metadata": {}, "next_keyframe_id": 0, "palettes": [],
            "pixelorama_version": PIXELORAMA_VERSION, "project_current_palette_name": "", "pxo_version": 7,
            "reference_images": [], "size_x": W, "size_y": H, "symmetry_points": [W - 1.0, H - 1.0], "tags": [],
            "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0, "tile_mode_y_basis_x": 0,
            "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "", "vanishing_points": []}
    buf = io.BytesIO()
    dt = (2026, 10, 17, 2, 39, 36)     # fixed (zip needs even seconds) -> byte-identical rebuilds
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def put(name, payload):
            z.writestr(zipfile.ZipInfo(name, dt), payload, zipfile.ZIP_DEFLATED)
        put("data.json", json.dumps(data, separators=(",", ":")))
        put("mimetype", "application/x-pixelorama")
        put("preview.png", png)
        put("image_data/frames/1/", b"")
        for li, name in enumerate(LAYER_NAMES, start=1):
            put(f"image_data/frames/1/layer_{li}", np.ascontiguousarray(blobs[name]).tobytes())
            put(f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_ora(png, blobs):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.3" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for name in reversed(LAYER_NAMES):                      # ORA lists the top layer first
        vis = "hidden" if name == "guides" else "visible"
        stack.append(f'<layer name="{name}" src="data/{name}.png" x="0" y="0" opacity="1.0" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>"]
    buf = io.BytesIO()
    dt = (2026, 10, 17, 2, 39, 36)
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype", dt), "image/openraster", zipfile.ZIP_STORED)
        z.writestr(zipfile.ZipInfo("stack.xml", dt), "\n".join(stack) + "\n", zipfile.ZIP_DEFLATED)
        for name in LAYER_NAMES:
            z.writestr(zipfile.ZipInfo(f"data/{name}.png", dt), png_bytes(blobs[name]), zipfile.ZIP_DEFLATED)
        z.writestr(zipfile.ZipInfo("mergedimage.png", dt), png, zipfile.ZIP_DEFLATED)
        z.writestr(zipfile.ZipInfo("Thumbnails/thumbnail.png", dt), png, zipfile.ZIP_DEFLATED)
    return buf.getvalue()


def recompose(layer_rgba):
    """Plain 'over' of binary-alpha layers in order (guides are hidden and skipped)."""
    comp = np.zeros((H, W, 4), np.uint8)
    for name in LAYER_NAMES[:-1]:
        a = layer_rgba[name]
        m = a[..., 3] == 255
        comp[m] = a[m]
    return comp


# ===================================================================================================== Pixelorama
def appdata_snapshot():
    root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    snap = {}
    if os.path.isdir(root):
        for d, _, files in os.walk(root):
            for f in files:
                p = os.path.join(d, f)
                rel = os.path.relpath(p, root).replace("\\", "/")
                if rel == ".running":          # an open GUI's 15 s heartbeat; not ours
                    continue
                try:
                    snap[rel] = sha256_bytes(read_bytes(p))
                except OSError:
                    snap[rel] = "unreadable"
    return snap


def pixelorama_export(exe, src, out_dir, split):
    """Headless export with APPDATA redirected to a fresh temp dir (never touches the real config)."""
    env = dict(os.environ)
    env["APPDATA"] = tempfile.mkdtemp(prefix="wb-pxappdata-")
    args = [exe, "--headless", "--quit", "--", "--export"] + (["--split-layers"] if split else []) + \
           ["-o", os.path.join(out_dir, "f.png"), src]
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=240, env=env)
    finally:
        shutil.rmtree(env["APPDATA"], ignore_errors=True)
    files = sorted(f for f in os.listdir(out_dir) if f.lower().endswith(".png"))
    return p.returncode, {f: read_bytes(os.path.join(out_dir, f)) for f in files}


def pixelorama_roundtrips(exe, pxo, ora, blobs, comp):
    snap0 = appdata_snapshot()
    tmp = tempfile.mkdtemp(prefix="wb-fv11-")
    px, flat_png = {}, None
    try:
        for kind, data_ in (("pxo", pxo), ("ora", ora)):
            src = os.path.join(tmp, f"cand.{kind}")
            with open(src, "wb") as f:
                f.write(data_)
            for split in (False, True):
                od = os.path.join(tmp, f"{kind}-{'split' if split else 'flat'}")
                os.makedirs(od)
                rc, outs = pixelorama_export(exe, src, od, split)
                key = f"{kind}_{'split' if split else 'flat'}"
                arrs = {f: decode(b)[2] for f, b in outs.items()}
                if split:
                    want = {n: blobs[n].tobytes() for n in LAYER_NAMES[:-1]}
                    matched = {n for n, b in want.items() if any(o.tobytes() == b for o in arrs.values())}
                    guide_leak = any(o.tobytes() == blobs["guides"].tobytes() for o in arrs.values())
                    px[key] = {"exit": rc, "pngs": len(outs), "visible_layers_matched": len(matched),
                               "visible_layers": len(want), "guides_exported": guide_leak,
                               "pass": rc == 0 and len(matched) == len(want) and not guide_leak
                               and len(outs) == len(want)}
                else:
                    ok = rc == 0 and len(outs) == 1 and next(iter(arrs.values())).tobytes() == comp.tobytes()
                    px[key] = {"exit": rc, "pngs": len(outs), "rgba_equals_tool_render": ok, "pass": ok}
                    if kind == "pxo" and ok:
                        flat_png = next(iter(outs.values()))
                with open(src, "rb") as f:
                    px[key]["input_copy_unchanged"] = f.read() == data_
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    px["real_appdata_pixelorama_untouched_except_heartbeat"] = snap0 == appdata_snapshot()
    return px, flat_png


# ===================================================================================================== build / check
LAYER_NOTES = {
    "far-leg": "far leg braced back onto the ball of the foot (v10 outline): deep slate trouser (C) with a spruce crease (T); boot with a dark turned-down cuff (l) and deep-brown shaft (d) with a pale strap (p) over the paving, lit low-saturation brown foot (D) with a pale toe glint, dark heel and sole (L) in the contact shadow",
    "hip-drape": "v8 teal back-hip cloth hung behind the coat skirt (v10 drawing, unchanged)",
    "pack": "grey-brown canvas pack on the upper back (character-sheet colours, replaces v10's tan): lit flap top (D), dark flap edge (L), deep body (d), one dark-leather strap (l) with a pale buckle (P)",
    "bedroll": "teal blanket roll on the pack's top edge (v10 drawing), strap re-keyed to pale beige over dark leather",
    "ponytail": "high tied ponytail, darker hair ramp use (1/2 body, 3 strands, 4/h sheen), rises from the hair tie and ends in two split locks above the roll",
    "near-leg": "near leg forward (v10 outline): spruce thigh/shin (T, t edge, C back), cool grey knee pad (m/M over C) on a dark strap, boot as the far one (dark cuff/shaft over the paving, lit brown foot in the contact shadow) with the light pale strap (P)",
    "coat": "v8 storm-slate coat torso (v10 outline and planes) with a mid back seam; belt dark leather (l over L) with a pale buckle (P/p)",
    "coat-skirt": "split coat skirt (v10 outline): deep back tail, mid band, lit front panel; hem trim deep slate / dark leather instead of lit orange",
    "shirt-lapel": "white shirt under the open coat front, lit slate lapel edge (v10 drawing)",
    "near-arm": "sword arm reaching forward with the sleeve rolled to the elbow: lit slate upper arm, pale-beige rolled cuff, bare forearm (S/s/x)",
    "insignia": "teal 3x3 diamond on the upper sleeve (character-sheet insignia colour placement; not a legible emblem at 1x)",
    "sword-blade": "ordinary short sword blade raised forward at 45 degrees (v10, unchanged)",
    "sword-guard": "small steel crossguard square to the blade (v10, unchanged)",
    "fist": "fingerless dark glove (l/L back of hand and wrist) with bare skin knuckles and thumb (S/s/x) round the grip",
    "head": "v10 outline; darker hair, fringe strands, face-framing side lock in front of the ear, dark brow over a 2x2 eye (lash + iris + white catch), blush, nose step, mouth",
    "hair-tie": "pale-beige hair tie knotted on the crown-back where the ponytail leaves the head",
    "collar": "raised coat collar standing behind the nape (v10)",
    "scarf-neck": "teal scarf neck wrap, knot and short front tail (v10)",
    "collar-front": "front point of the raised coat collar over the scarf's front edge (v10)",
    "guides": f"hidden + locked #ff00ff: cell border, ticks on crown row {CROWN_ROW} and sole row {SOLE_ROW}, pin {list(PIN)}",
}


def make_manifest(png, pxo, ora, comp, flat_from_pixelorama):
    blobs = render()[0]
    st = stats(comp)
    pose = pose_report(comp, blobs)
    m = {
        "project": SLUG,
        "subject": "female protagonist side-view battle idle, facing right, ONE static frame (native 0.65 on-screen size)",
        "version": VER, "status": "UNAPPROVED, NONRUNTIME test-only candidate", "art_approved": False,
        "runtime_integrated": False, "game_bible_or_acceptance_counters_changed": False, "animation": False,
        "sprite_acceptance_count": "0/52 (unchanged)",
        "node_scale_intended": 1.0, "display_proportion_equivalent": 0.65,
        "refines": {"files": V10_LOCKS,
                    "hash_algorithm": "sha256-bytes for .png/.pxo/.ora; sha256-text-lf-v1 for the .json manifest",
                    "relationship": "same cell/pin/sole/crown rows as v10; v10 outline kept for head, legs, coat, "
                                    "skirt, arm, roll, ponytail root; re-keyed lower body (no orange leather), new "
                                    "face/hair/hand/forearm/pack detail, new insignia layer; v10 left untouched",
                    "interrupted_v11_tool_not_used": "tools/rpg-2-star-ocean-the-second_protagonist-female_sideview-"
                                                     "battle-idle-right-native-0p65-author_unapproved-v11_20261016-"
                                                     "175823-e1e2a4b7.py",
                    "silhouette_vs_v10": silhouette_report(comp, blobs)},
        "pose": pose,
        "pose_gates": pose_gates(pose),
        "identity_references": {"character_sheet": CHARACTER_SHEET_REL, "v8_south_static": V8_SOUTH_REL},
        "codex_review_addressed": "Codex visual review of the real v10 640x360 four-person outskirts capture "
                                  "(...party-capture-outskirts-640_unapproved-v10_20261016-162819-7829fd0b.png): too "
                                  "small / detail-poor relative to the approved exploration identity; lower body "
                                  "overly warm / orange",
        "author_tool": TOOL_REL,
        "png_source": ("Pixelorama 1.2.3 headless flat export of the .pxo (byte-compared to the tool render)"
                       if flat_from_pixelorama else "tool render"),
        "files": {
            "png": {"file": f"{OUT_DIR_REL}/{PNG_NAME}", "sha256": sha256_bytes(png), "hash_algorithm": "sha256-bytes"},
            "pxo": {"file": f"{OUT_DIR_REL}/{PXO_NAME}", "sha256": sha256_bytes(pxo), "hash_algorithm": "sha256-bytes",
                    "format": f"Pixelorama pxo_version 7 ({PIXELORAMA_VERSION}), color_mode 5 (RGBA8), 1 frame x "
                              f"{len(LAYER_NAMES)} layers"},
            "ora": {"file": f"{OUT_DIR_REL}/{ORA_NAME}", "sha256": sha256_bytes(ora), "hash_algorithm": "sha256-bytes"},
        },
        "layers_bottom_to_top": [{"name": n, "note": LAYER_NOTES.get(n, "")} for n in LAYER_NAMES],
        "palette": PALETTE,
        "metrics": {**st, "material_texels": region_counts(comp)},
    }
    return (json.dumps(m, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def static_gates(a, st):
    return {
        "binary_alpha": st["alpha_values"] == [0, 255],
        "no_off_palette_colour": not st["colours_outside_palette"],
        "colours_le_32": st["colours"] <= 32,
        "sole_on_row_67_same_as_v10": st["sole_row"] == SOLE_ROW,
        "crown_on_row_7_same_as_v10_0p65_proportion": st["crown_row_measured"] == CROWN_ROW,
        "leftmost_texel_ge_x15_liang_gap_kept": st["alpha_bounds_inclusive"][0] >= 15,
        "rightmost_texel_le_v10_sentry_gap_kept": st["alpha_bounds_inclusive"][2] <= 62,
        "nothing_at_or_below_pin_row": st["pin_row_clear"],
        "both_boots_touch_sole_row": bool((a[SOLE_ROW, 20:PIN[0], 3] > 0).any() and (a[SOLE_ROW, PIN[0]:, 3] > 0).any()),
        "transparent_border": bool(not a[0, :, 3].any() and not a[-1, :, 3].any()
                                   and not a[:, 0, 3].any() and not a[:, -1, 3].any()),
    }


def structure_ok(sil):
    return (sil["layers_added_vs_v10"] == V10_LAYER_NAMES_PLUS and sil["layers_removed_vs_v10"] == []
            and sil["palette_keys_removed_vs_v10"] == REMOVED_KEYS_VS_V10
            and sil["palette_keys_added_vs_v10"] == ADDED_KEYS_VS_V10 and sil["palette_shared_keys_same_colour"])


def build(exe):
    lock = v10_lock()
    if not lock["unchanged"]:
        raise SystemExit(f"v10 changed: {lock}")
    blobs, comp = render()
    st = stats(comp)
    sg = static_gates(comp, st)
    pg = pose_gates(pose_report(comp, blobs))
    sil = silhouette_report(comp, blobs)
    if not all(sg.values()) or not all(pg.values()) or not structure_ok(sil):
        raise SystemExit(f"static/identity gate failed: {json.dumps({'static': sg, 'identity': pg})}")
    tool_png = png_bytes(comp)
    pxo, ora = make_pxo(tool_png, blobs), make_ora(tool_png, blobs)
    if make_pxo(tool_png, blobs) != pxo or make_ora(tool_png, blobs) != ora:
        raise SystemExit("editable build is not deterministic")
    px, flat = pixelorama_roundtrips(exe, pxo, ora, blobs, comp)
    if flat is None or not all(v["pass"] for v in px.values() if isinstance(v, dict)):
        raise SystemExit(f"Pixelorama round-trip failed: {json.dumps(px)}")
    png = flat                         # the delivered PNG is Pixelorama's export of the layered .pxo
    out = repo_path(OUT_DIR_REL)
    for name, data in ((PNG_NAME, png), (PXO_NAME, pxo), (ORA_NAME, ora),
                       (MANIFEST_NAME, make_manifest(png, pxo, ora, comp, True))):
        print(write_new(os.path.join(out, name), data), f"{OUT_DIR_REL}/{name}", sha256_bytes(data))
    print(json.dumps({"pixelorama": px}))
    if not v10_lock()["unchanged"]:
        raise SystemExit("v10 changed during build")


def check(exe):
    report = {"status": "UNAPPROVED, NONRUNTIME test-only candidate", "v10_lock_before": v10_lock()}
    blobs, comp = render()
    out = repo_path(OUT_DIR_REL)
    png = read_bytes(os.path.join(out, PNG_NAME))
    pxo = read_bytes(os.path.join(out, PXO_NAME))
    ora = read_bytes(os.path.join(out, ORA_NAME))
    man = json.loads(read_bytes(os.path.join(out, MANIFEST_NAME)))
    mode, size, a = decode(png)
    st = stats(a)
    g = {"png_rgba_68x72": mode == "RGBA" and size == (W, H), "png_equals_tool_render": a.tobytes() == comp.tobytes()}
    g.update(static_gates(a, st))
    g.update({
        "manifest_hashes_match": (man["files"]["png"]["sha256"] == sha256_bytes(png)
                                  and man["files"]["pxo"]["sha256"] == sha256_bytes(pxo)
                                  and man["files"]["ora"]["sha256"] == sha256_bytes(ora)),
        "manifest_unapproved_flags": (man["art_approved"] is False and man["runtime_integrated"] is False
                                      and man["game_bible_or_acceptance_counters_changed"] is False),
        "rebuild_editables_byte_identical": make_pxo(png_bytes(comp), blobs) == pxo
                                            and make_ora(png_bytes(comp), blobs) == ora,
    })
    with zipfile.ZipFile(io.BytesIO(pxo)) as z:
        data = json.loads(z.read("data.json"))
        names = [l["name"] for l in data["layers"]]
        g["pxo_layers_match"] = names == LAYER_NAMES and all(
            z.read(f"image_data/frames/1/layer_{i + 1}") == blobs[n].tobytes() for i, n in enumerate(names))
        pxo_layers = {n: np.frombuffer(z.read(f"image_data/frames/1/layer_{i + 1}"), np.uint8).reshape(H, W, 4)
                      for i, n in enumerate(names)}
        g["pxo_layer_stack_recomposes_png"] = recompose(pxo_layers).tobytes() == a.tobytes()
        g["pxo_guides_hidden_locked"] = [(l["visible"], l["locked"]) for l in data["layers"]][-1] == (False, True)
    with zipfile.ZipFile(io.BytesIO(ora)) as z:
        g["ora_mimetype_first_stored"] = z.infolist()[0].filename == "mimetype" and z.infolist()[0].compress_type == 0
        ora_layers = {n: decode(z.read(f"data/{n}.png"))[2] for n in LAYER_NAMES}
        g["ora_layers_match"] = all(ora_layers[n].tobytes() == blobs[n].tobytes() for n in LAYER_NAMES)
        g["ora_layer_stack_recomposes_png"] = recompose(ora_layers).tobytes() == a.tobytes()
        g["ora_mergedimage_equals_png"] = decode(z.read("mergedimage.png"))[2].tobytes() == a.tobytes()
    sil = silhouette_report(a, blobs)
    report["silhouette_vs_v10"] = sil
    g["layers_and_palette_vs_v10_as_declared"] = structure_ok(sil)
    g["manifest_silhouette_matches_fresh"] = man["refines"]["silhouette_vs_v10"] == json.loads(json.dumps(sil))
    pose = pose_report(a, blobs)
    report["pose"] = pose
    pg = pose_gates(pose)
    g.update(pg)
    g["manifest_pose_matches_fresh"] = man["pose"] == json.loads(json.dumps(pose)) and man["pose_gates"] == pg
    if exe:
        px, flat = pixelorama_roundtrips(exe, pxo, ora, blobs, comp)
        report["pixelorama_1_2_3_headless"] = px
        g["pixelorama_roundtrips"] = all(v["pass"] for v in px.values() if isinstance(v, dict)) and \
            px["real_appdata_pixelorama_untouched_except_heartbeat"]
        g["png_equals_fresh_pixelorama_flat_export"] = flat == png
    report["metrics"] = {**st, "material_texels": region_counts(a)}
    report["v10_lock_after"] = v10_lock()
    g["v10_unchanged"] = report["v10_lock_before"]["unchanged"] and report["v10_lock_after"]["unchanged"]
    report["gates"] = g
    report["gates_passed"] = f"{sum(bool(v) for v in g.values())}/{len(g)}"
    report["result"] = "PASS" if all(g.values()) else "FAIL"
    print(json.dumps(report, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    return 0 if report["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("out", nargs="?")
    ap.add_argument("nosprite", nargs="*", help="preview only: no-sprite party captures (1280x720 and/or 640x360)")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--pixelorama", default=repo_path(PIXELORAMA_REL))
    args = ap.parse_args()
    if args.mode == "preview":
        if not args.out:
            raise SystemExit("preview needs an output dir outside the repo")
        preview(args.out, args.nosprite)
        return 0
    exe = None if args.no_pixelorama else os.path.abspath(args.pixelorama)
    if args.mode == "build":
        if not exe or not os.path.isfile(exe):
            raise SystemExit("build needs Pixelorama (the PNG is its export)")
        build(exe)
        return 0
    if exe and not os.path.isfile(exe):
        raise SystemExit(f"Pixelorama not found: {exe}")
    return check(exe)


if __name__ == "__main__":
    sys.exit(main())
