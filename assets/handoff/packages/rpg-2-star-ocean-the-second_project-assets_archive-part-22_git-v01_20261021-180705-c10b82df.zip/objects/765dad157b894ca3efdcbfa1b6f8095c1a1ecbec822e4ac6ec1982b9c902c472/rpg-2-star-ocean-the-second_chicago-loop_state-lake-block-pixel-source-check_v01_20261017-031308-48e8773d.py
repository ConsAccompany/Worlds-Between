"""Pixel, source and Pixelorama checks for the Chicago Loop State/Lake block candidate v01 (UNAPPROVED).

Usage: python -I <this file> [--pixelorama <exe>] [--report <json path>]
Reads the manifest written by the author tool, the runtime scene script and the real Godot captures
in outputs/chicago-loop-state-lake-v01/{before,after}. Pixelorama runs use a fresh temp APPDATA and
the real %APPDATA%/pixelorama dir is snapshotted before and after.
"""

from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
AUTHOR = ROOT / "tools/rpg-2-star-ocean-the-second_chicago-loop_state-lake-block-pixel-author_unapproved-v01_20261017-031308-26d71e3c.py"
SCENE_SCRIPT = ROOT / "game/scripts/rpg-2-star-ocean-the-second_chicago-loop_district-placeholder-scene_m2-v02_20261015-185645-a7d62ba0.gd"
CAPTURES = ROOT / "outputs/chicago-loop-state-lake-v01"
CAPTURE_STAMP = "20261017-031308-509a5e64"
# Runtime label boxes (with outline) and the arrival hero box, excluded from render parity.
LABEL_BOXES = [(8, 158, 120, 178), (348, 297, 452, 318), (461, 61, 524, 82)]
HERO_BOX = (320 - 17, 290 - 45, 320 + 17, 290 + 6)


def load_author():
    spec = spec_from_file_location("chicago_author", AUTHOR)
    mod = module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rgba(path_or_bytes):
    src = io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, bytes) else path_or_bytes
    return np.array(Image.open(src).convert("RGBA"))


def gd_geometry():
    """Parse the runtime constants that must match the author tool."""
    text = SCENE_SCRIPT.read_text(encoding="utf-8")
    def rects(block):
        return [tuple(int(float(v)) for v in m) for m in re.findall(r"Rect2\(([-\d.]+), ([-\d.]+), ([-\d.]+), ([-\d.]+)\)", block)]
    walk = rects(re.search(r"const WALK := (Rect2\([^)]*\))", text).group(1))[0]
    blocks = rects(re.search(r"const BLOCKS := \[(.*?)\n\]", text, re.S).group(1))
    vec = lambda name: tuple(int(float(v)) for v in re.search(rf"const {name} := Vector2\(([-\d.]+), ([-\d.]+)\)", text).groups())
    pivots = [float(v) for v in re.findall(r"\.png\"\), ([\d.]+)\]", text)]
    layer_files = re.findall(r"state-lake_(ysort-[a-z-]+)_unapproved", text)
    scalar = lambda name: float(re.search(rf"const {name} := ([\d.]+)", text).group(1))
    return {"walk": walk, "blocks": blocks, "kiosk": vec("KIOSK"), "spawn": vec("SPAWN"), "pivots": pivots,
            "layer_files": layer_files, "walk_top": scalar("WALK_TOP"), "deck_bottom": scalar("DECK_BOTTOM")}


def source_checks(author, manifest):
    r = {}
    files = manifest["files"]
    r["hashes_match_manifest"] = all(sha((ROOT / v["file"]).read_bytes()) == v["sha256"] for v in files.values())
    layers = author.build_layers()
    guide = author.walkmask()
    names = [n for n, _ in author.LAYERS]
    runtime = {n: rgba(ROOT / files[n]["file"]) for n in names}
    r["runtime_layers_equal_rebuild"] = all(runtime[n].tobytes() == np.array(layers[n]).tobytes() for n in names)
    r["sizes_640x360"] = all(a.shape == (360, 640, 4) for a in runtime.values())
    r["ground_opaque"] = bool((runtime["ground-far"][:, :, 3] == 255).all())
    r["ysort_binary_alpha"] = all(set(np.unique(runtime[n][:, :, 3]).tolist()) <= {0, 255} for n in names[1:])
    flat = runtime["ground-far"].copy()
    for n in names[1:]:
        a = runtime[n][:, :, 3:4] == 255
        flat = np.where(a, runtime[n], flat)
    r["merged_preview_equals_layers"] = rgba(ROOT / files["merged-preview"]["file"]).tobytes() == flat.tobytes()
    palette = {tuple(int(v[i:i + 2], 16) for i in (1, 3, 5)) for v in author.C.values()}
    used = {tuple(p) for a in runtime.values() for p in a[a[:, :, 3] == 255][:, :3].tolist()}
    r["colours_used"] = len(used)
    r["all_colours_in_named_palette"] = used <= palette
    # Walk guide equals the geometry rule, and the runtime script uses identical numbers.
    mask = rgba(ROOT / files["walkmask-guide"]["file"])
    r["guide_equals_rebuild"] = mask.tobytes() == np.array(guide).tobytes()
    gd = gd_geometry()
    r["gd_walk_blocks_match_author"] = gd["walk"] == tuple(author.WALK) and sorted(gd["blocks"]) == sorted(tuple(b) for b in author.BLOCKS)
    r["gd_kiosk_matches_author"] = gd["kiosk"] == tuple(author.KIOSK)
    r["gd_pivots_match_author"] = gd["pivots"] == [p for _, p in author.LAYERS[1:]] and gd["layer_files"] == names[1:]
    r["spawn_walkable"] = author.walkable(*gd["spawn"])
    r["head_clear_of_deck"] = gd["walk_top"] - 44 >= gd["deck_bottom"] - 2 and gd["deck_bottom"] == author.DECK_BOTTOM
    # Every y-sort layer pivot sits at or below the bottom of its own walkable-blocking footprint region,
    # so no walkable foot row ever lands exactly on a pivot (no y-sort ties).
    r["pivots_fractional"] = all(p % 1 == 0.5 for p in gd["pivots"])
    # OpenRaster: 7 layers top-first, guide hidden, every layer pixel-exact.
    ora = zipfile.ZipFile(ROOT / files["openraster"]["file"])
    r["ora_mimetype_first_stored"] = ora.infolist()[0].filename == "mimetype" and ora.infolist()[0].compress_type == zipfile.ZIP_STORED
    stack = ET.fromstring(ora.read("stack.xml"))
    entries = list(reversed(stack.find("stack").findall("layer")))
    r["ora_layer_names"] = [e.get("name") for e in entries]
    expect = {**{n: np.array(layers[n]) for n in names}, author.GUIDE: np.array(guide)}
    r["ora_layers_exact"] = r["ora_layer_names"] == names + [author.GUIDE] and all(
        rgba(ora.read(e.get("src"))).tobytes() == expect[e.get("name")].tobytes() for e in entries)
    r["ora_guide_hidden"] = entries[-1].get("visibility") == "hidden"
    # Pixelorama .pxo: pxo_version 7, raw RGBA cels equal the layers, guide hidden + locked.
    pxo = zipfile.ZipFile(ROOT / files["pixelorama"]["file"])
    data = json.loads(pxo.read("data.json"))
    r["pxo_version"] = data["pxo_version"]
    r["pxo_layer_names"] = [l["name"] for l in data["layers"]]
    r["pxo_layers_exact"] = r["pxo_layer_names"] == names + [author.GUIDE] and all(
        pxo.read(f"image_data/frames/1/layer_{i}") == expect[n].tobytes() for i, n in enumerate(r["pxo_layer_names"], start=1))
    r["pxo_guide_hidden_locked"] = data["layers"][-1]["visible"] is False and data["layers"][-1]["locked"] is True
    # Determinism: a rebuild into temp dirs is byte-identical.
    tmp = tempfile.mkdtemp(prefix="wb-chi-v01-")
    try:
        rebuilt = author.build(out=Path(tmp) / "o", runtime=Path(tmp) / "r")
        r["rebuild_deterministic"] = all(rebuilt["files"][k]["sha256"] == v["sha256"] for k, v in files.items())
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # Flat-fill guard on the visible art rows of the merged image.
    vis = flat[62:318, :, :3].reshape(-1, 3)
    _, counts = np.unique(vis, axis=0, return_counts=True)
    r["visible_largest_single_colour_share"] = round(float(counts.max() / counts.sum()), 4)
    return r, flat


def capture_checks(flat):
    r = {}
    after = CAPTURES / "after"
    before = CAPTURES / "before"
    arrival = rgba(after / f"rpg-2-star-ocean-the-second_chicago-loop_state-lake-godot-zh-arrival-640x360_v01_{CAPTURE_STAMP}.png")
    keep = np.zeros((360, 640), bool)
    keep[62:318, :] = True
    for x0, y0, x1, y1 in LABEL_BOXES + [HERO_BOX]:
        keep[y0:y1, x0:x1] = False
    diff = (arrival[:, :, :3] != flat[:, :, :3]).any(axis=2) & keep
    r["godot_arrival_matches_layers_outside_hero_and_labels"] = int(diff.sum())
    r["godot_arrival_pixels_compared"] = int(keep.sum())
    for tag, folder, name in (("before", before, "before-placeholder-godot-zh-arrival"), ("after", after, "state-lake-godot-zh-arrival")):
        img = rgba(folder / f"rpg-2-star-ocean-the-second_chicago-loop_{name}-640x360_v01_{CAPTURE_STAMP}.png")[62:318, :, :3].reshape(-1, 3)
        colours, counts = np.unique(img, axis=0, return_counts=True)
        r[f"{tag}_visible_colours"] = int(len(colours))
        r[f"{tag}_visible_largest_single_colour_share"] = round(float(counts.max() / counts.sum()), 4)
    r["captures_present"] = sorted(p.name for p in after.glob("*.png"))
    return r


def run_pixelorama(exe, args, appdata):
    env = dict(os.environ)
    env["APPDATA"] = appdata
    return subprocess.run([exe, "--headless", "--quit", "--"] + args, capture_output=True, text=True, timeout=240, env=env)


def real_pixelorama_snapshot():
    root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    snap = {}
    if os.path.isdir(root):
        for d, _, fs in os.walk(root):
            for f in fs:
                rel = os.path.relpath(os.path.join(d, f), root).replace("\\", "/")
                if rel != ".running":
                    snap[rel] = sha(open(os.path.join(d, f), "rb").read())
    return snap


def pixelorama_checks(exe, author, manifest):
    rep = {}
    before = real_pixelorama_snapshot()
    names = [n for n, _ in author.LAYERS]
    tmp = tempfile.mkdtemp(prefix="wb-chi-pxo-")
    try:
        layers = author.build_layers()
        for ext, key in (("pxo", "pixelorama"), ("ora", "openraster")):
            src = os.path.join(tmp, f"chi.{ext}")
            shutil.copyfile(ROOT / manifest["files"][key]["file"], src)
            appdata = os.path.join(tmp, f"app-{ext}")
            od = os.path.join(tmp, f"out-{ext}")
            os.makedirs(appdata)
            os.makedirs(od)
            p = run_pixelorama(exe, ["--export", "--split-layers", "-o", os.path.join(od, "f.png"), src], appdata)
            outs = sorted(os.listdir(od))
            exact = {}
            for n in names:
                hit = [o for o in outs if f"({n})" in o]
                exact[n] = len(hit) == 1 and rgba(Path(od) / hit[0]).tobytes() == np.array(layers[n]).tobytes()
            rep[ext] = {"exit": p.returncode, "pngs": len(outs), "visible_layers_exact": exact,
                        "hidden_guide_not_exported": not any(f"({author.GUIDE})" in o for o in outs),
                        "source_unchanged_by_cli": open(src, "rb").read() == (ROOT / manifest["files"][key]["file"]).read_bytes()}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    after = real_pixelorama_snapshot()
    changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
    gui = [k for k in changed if k.startswith("backups/") and "/(untitled backup)-" in k]
    rep["real_appdata_gui_autosave_changes_excluded"] = gui
    rep["real_appdata_pixelorama_changed"] = [k for k in changed if k not in gui]
    return rep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pixelorama", default=str(ROOT / "work/tooling/pixelorama-1-2-3/Pixelorama-Windows-64bit/Pixelorama.exe"))
    ap.add_argument("--report", default="")
    a = ap.parse_args()
    author = load_author()
    manifest = json.loads((author.OUT / f"{author.PREFIX}_layer-manifest_unapproved-v01_{author.STAMP}.json").read_text(encoding="utf-8"))
    s, flat = source_checks(author, manifest)
    c = capture_checks(flat)
    p = pixelorama_checks(a.pixelorama, author, manifest) if os.path.isfile(a.pixelorama) else None
    gates = {
        "S1_hashes_and_rebuild_exact": s["hashes_match_manifest"] and s["runtime_layers_equal_rebuild"] and s["rebuild_deterministic"] and s["merged_preview_equals_layers"],
        "S2_canvas_alpha_palette": s["sizes_640x360"] and s["ground_opaque"] and s["ysort_binary_alpha"] and s["all_colours_in_named_palette"],
        "S3_openraster_exact": s["ora_mimetype_first_stored"] and s["ora_layers_exact"] and s["ora_guide_hidden"],
        "S4_pxo_exact": s["pxo_version"] == 7 and s["pxo_layers_exact"] and s["pxo_guide_hidden_locked"],
        "G1_walk_guide_and_runtime_geometry_match": s["guide_equals_rebuild"] and s["gd_walk_blocks_match_author"] and s["gd_kiosk_matches_author"] and s["gd_pivots_match_author"],
        "G2_spawn_head_clearance_pivots": s["spawn_walkable"] and s["head_clear_of_deck"] and s["pivots_fractional"],
        "A1_no_large_flat_fill": s["visible_largest_single_colour_share"] < 0.12,
        "C1_godot_native_render_exact": c["godot_arrival_matches_layers_outside_hero_and_labels"] == 0 and c["godot_arrival_pixels_compared"] > 150000,
        "C2_after_less_flat_than_before": c["after_visible_largest_single_colour_share"] < c["before_visible_largest_single_colour_share"] and c["after_visible_colours"] > c["before_visible_colours"],
        "C3_captures_present": len(c["captures_present"]) == 6,
    }
    if p is not None:
        gates["P1_pixelorama_cli_split_layers_exact"] = all(p[e]["exit"] == 0 and all(p[e]["visible_layers_exact"].values()) and p[e]["hidden_guide_not_exported"] and p[e]["source_unchanged_by_cli"] for e in ("pxo", "ora"))
        gates["P2_real_pixelorama_appdata_untouched"] = not p["real_appdata_pixelorama_changed"]
    report = {"gates": gates, "passed": sum(gates.values()), "total": len(gates), "sources": s, "captures": c, "pixelorama_cli": p}
    text = json.dumps(report, indent=2, ensure_ascii=False, default=str)
    if a.report:
        Path(a.report).write_text(text + "\n", encoding="utf-8")
    for k, v in gates.items():
        print(("PASS " if v else "FAIL ") + k)
    print(f"CHICAGO_LOOP_PIXEL_SOURCE_CHECK {report['passed']}/{report['total']}")
    return 0 if report["passed"] == report["total"] else 1


if __name__ == "__main__":
    sys.exit(main())
