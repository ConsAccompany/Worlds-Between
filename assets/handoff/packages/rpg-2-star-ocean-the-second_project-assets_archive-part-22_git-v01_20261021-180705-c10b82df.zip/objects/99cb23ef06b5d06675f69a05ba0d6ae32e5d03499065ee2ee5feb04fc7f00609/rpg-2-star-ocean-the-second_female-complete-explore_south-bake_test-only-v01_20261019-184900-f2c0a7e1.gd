extends SceneTree

# Build-time SOUTH resolver for the female complete-exploration pilot (unapproved, opt-in). Runs the unchanged v10r1
# capture tool's own hash-pinned _prepare() ONCE here, writes the merged runtime contract it resolved to a game JSON,
# then proves the extracted runtime classes (game/scripts/fexp/*south-model*) rebuilt from that JSON alone compose
# every v10r1 keyframe, every per-px steady composite and the neutral v8 rest exactly like the tool, and that the
# extracted Loco10r1 ticks identically to the tool's for run / stop / re-press at 30, 60 and mixed frame times.
#   Godot --headless --path <checkout>/game -s <abs this file> -- --out=<abs res json path> --report=<abs json>

const SOUTH_TOOL := preload("rpg-2-star-ocean-the-second_female-south-run-v10r1-godot-capture_m8-w14_20261018-142136-249dbf66.gd")
const SOUTH := preload("res://scripts/fexp/rpg-2-star-ocean-the-second_female-complete-explore_south-model_extracted-v01_20261019-184500-f2c0a7e1.gd")


func _initialize() -> void:
	var out := ""
	var report_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.substr(6)
		elif arg.begins_with("--report="):
			report_path = arg.substr(9)
	var report := {"tool": "female-complete-explore south bake v01", "checks": {}}
	var tool = SOUTH_TOOL.new()
	var t0 := Time.get_ticks_usec()
	var err: String = tool._prepare()
	report["tool_prepare_ms"] = (Time.get_ticks_usec() - t0) / 1000.0
	if err != "":
		_finish(report, report_path, "prepare: " + err, tool)
		return
	var runtime := {
		"schema": "worlds-between.female-complete-explore-south-runtime.v1", "approved": false,
		"resolved_by": "v10r1 capture tool _prepare() (hash-pinned chain v06/v07/v09/v10 tools + manifests + every part PNG + v8)",
		"manifest": tool.manifest, "art_amendment": tool.m9["art_amendment"], "leg_rule": tool.m10["leg_rule"],
		"island_max_texels": int(tool.m10["island_max_texels"]), "stagger": tool.stagger_on, "shadow_alpha": tool.shadow_alpha,
		"part_lists": [[tool.manifest["parts"], tool.ASSET_DIR], [tool.m9["parts_new"], tool.V09_DIR], [tool.m10["parts_new"], tool.V10_DIR]],
		"v8_path": tool.V8_PATH, "v8_sha256": tool.V8_SHA256, "v10r1_manifest": String(tool.m10["_file"]),
		"v10r1_manifest_sha256_text_lf_v1": String(tool.m10["_sha256_text_lf_v1"])}
	var file := FileAccess.open(out, FileAccess.WRITE)
	file.store_string(JSON.stringify(runtime, " ", false))
	file.close()
	# Rebuild from the written JSON only.
	var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(out))
	var t1 := Time.get_ticks_usec()
	var comp = SOUTH.Comp10.new()
	for pair in data["part_lists"]:
		err = comp.load_parts(pair[0], String(pair[1]), data["manifest"]["rig"])
		if err != "":
			break
	if err == "":
		comp.setup9(data["art_amendment"])
		comp.setup10(data["leg_rule"], int(data["island_max_texels"]))
	report["runtime_attach_ms"] = (Time.get_ticks_usec() - t1) / 1000.0
	if err != "":
		_finish(report, report_path, "runtime load: " + err, tool)
		return
	var bad := 0
	var rows := 0
	for row in tool.m10["metrics"]["nominal_per_px"]:
		rows += 1
		var a: Dictionary = tool.comp.compose(row)
		var b: Dictionary = comp.compose(row)
		if (a["image"] as Image).get_data() != (b["image"] as Image).get_data() or (a["shadow"] as Image).get_data() != (b["shadow"] as Image).get_data():
			bad += 1
	for k in tool.m10["keyframes"]:
		rows += 1
		var a: Dictionary = tool.comp.compose(k["state"])
		var b: Dictionary = comp.compose(k["state"])
		if (a["image"] as Image).get_data() != (b["image"] as Image).get_data() or (a["shadow"] as Image).get_data() != (b["shadow"] as Image).get_data():
			bad += 1
	report["checks"]["compose_parity"] = {"rows": rows, "mismatch": bad, "pass": bad == 0 and rows > 100}
	# Loco parity: same frame-time plans through the tool's Loco10r1 and the extracted one.
	var plans := {"60": [], "30": [], "mixed": []}
	var rng := RandomNumberGenerator.new()
	rng.seed = 6061
	for key in plans:
		var y := 400.0
		for t in 240:
			var dt: float = 1.0 / 60.0 if key == "60" else (1.0 / 30.0 if key == "30" else [1.0 / 60.0, 1.0 / 30.0, 1.0 / 144.0, 0.021][rng.randi() % 4])
			var moving := (t < 70) or (t >= 90 and t < 100) or (t >= 150 and t < 200)
			if moving:
				y += 140.0 * dt * 2.0
			plans[key].append([moving, dt, int(round(y))])
	var loco_bad := 0
	var ticks := 0
	for key in plans:
		var la = tool._new_loco()
		var lb = SOUTH.Loco10r1.new()
		lb.stagger = bool(data["stagger"])
		la.setup(tool.manifest, 400)
		lb.setup(data["manifest"], 400)
		for p in plans[key]:
			ticks += 1
			var ra: Dictionary = la.tick(p[0], p[1], p[2])
			var rb: Dictionary = lb.tick(p[0], p[1], p[2])
			if var_to_str(ra) != var_to_str(rb):
				loco_bad += 1
	report["checks"]["loco_parity"] = {"ticks": ticks, "mismatch": loco_bad, "pass": loco_bad == 0}
	var v8 := Image.load_from_file(ProjectSettings.globalize_path(String(data["v8_path"])))
	v8.convert(Image.FORMAT_RGBA8)
	var neutral := {"bob": 0, "hdy": 0, "sx": 0, "csx": 0, "arms": {"R": "N", "L": "N"},
		"feet": {"vl": {"o": 0, "lift": 0, "view": "v8", "kin": 0}, "vr": {"o": 0, "lift": 0, "view": "v8", "kin": 0}}}
	var nc: Dictionary = comp.compose(neutral)
	var pad := Image.create_empty(80, 120, false, Image.FORMAT_RGBA8)
	pad.blit_rect(v8, Rect2i(0, 0, 80, 112), Vector2i.ZERO)
	report["checks"]["neutral_equals_v8"] = {"pass": (nc["image"] as Image).get_data() == pad.get_data()}
	report["checks"]["v8_sha256"] = {"pass": FileAccess.get_sha256(ProjectSettings.globalize_path(String(data["v8_path"]))) == String(data["v8_sha256"])}
	var fail := ""
	for name in report["checks"]:
		if not bool(report["checks"][name]["pass"]):
			fail += name + " "
	_finish(report, report_path, fail, tool)


func _finish(report: Dictionary, path: String, fail: String, tool) -> void:
	report["fail"] = fail
	var text := JSON.stringify(report, "  ")
	print(text)
	if path != "":
		var f := FileAccess.open(path, FileAccess.WRITE)
		f.store_string(text)
		f.close()
	tool.free()
	print("FCX_SOUTH_BAKE_OK" if fail == "" else "FCX_SOUTH_BAKE_FAIL")
	quit(0 if fail == "" else 1)
