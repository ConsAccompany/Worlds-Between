"""TEST-ONLY 3-layer Washington (U.S. Capitol west grounds) Pixelorama round-trip probe.

This is NOT scene art. It writes a flat-colour schematic blockout (no shading, no texture, no
detail) whose only job is to prove that a multi-layer 1280x720 project survives Pixelorama 1.2.3
desktop with its layers separate and its pixels exact. Nothing here is accepted art, and nothing
is used by the game runtime.

Modes
  build  write <out>/...ora, <out>/...pxo, the expected per-layer PNGs, the expected composite PNG
         and a manifest. Refuses to overwrite a different existing file.
  check  copy the .ora and .pxo into a fresh %LOCALAPPDATA%\\Temp dir and run Pixelorama headless:
           A  <pxo> --export                 (flattened)      x2, byte-compare the two runs
           B  <pxo> --export --split-layers  (one PNG / layer)
           C  <ora> --export                 (flattened)
           D  <ora> --export --split-layers
           E  <ora> --export -o x.pxo        (experiment: does the CLI write a native .pxo?)
           F  --size / --framecount on both
         Pass = every flattened export equals the expected composite and every split-layer export
         equals its source layer, RGBA byte for byte (outside the one deliberate semi-alpha probe
         patch, which is reported separately). config.ini is backed up and restored after each run.
         --write-report writes the JSON report next to the artefacts (never overwrites).

Layers, bottom -> top (all 1280x720, all visible):
  1 `ground`        opaque: lawn, west-front terrace band + stair notch, axial walk, two curved walks
  2 `survey-post`   binary alpha: post footprint, mast, accent light
  3 `fg-occlusion`  binary alpha: two canopy discs (one covers the post base -> stacking test),
                    plus a 16x16 alpha=128 probe patch at (40,40) that is info-only

Run: python -I -B <this file> build | check [--write-report] [--pixelorama <exe>]
"""
import argparse, hashlib, io, json, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image, ImageDraw

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
STAMP = "20261015-174500"
RUN_ID = "9c41e7a2"
W, H = 1280, 720
OUT_REL = f"outputs/wdc-pxo-rt-v01_{STAMP}-{RUN_ID}"
BASE = "wdc-3layer-test-only"
PIXELORAMA_DEFAULT = ("C:/Users/hkzha/AppData/Local/Programs/Pixelorama-1.2.3/"
                      "Pixelorama-Windows-64bit/Pixelorama.exe")
PIXELORAMA_VERSION = "v1.2.3-stable"
LAYERS = ["ground", "survey-post", "fg-occlusion"]          # bottom -> top
PROBE = (40, 40, 16, 16)                                     # x, y, w, h of the alpha=128 patch

PAL = {  # flat schematic colours only; not a production palette
    "lawn": (74, 107, 53), "terrace": (184, 178, 164), "terrace_edge": (120, 116, 106),
    "walk": (168, 152, 120), "post_base": (60, 65, 72), "post_mast": (92, 98, 108),
    "accent": (70, 180, 180), "canopy": (38, 70, 40), "probe": (220, 40, 200),
}
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))
WIN_LONG_PREFIX = "\\\\?\\"


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > 247 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def rp(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(p):
    with open(_fs(p), "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha_text(b):
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


# ============================================================================ layer content
def rgba(c, a=255):
    return tuple(c) + (a,)


def layer_ground():
    im = Image.new("RGBA", (W, H), rgba(PAL["lawn"]))
    d = ImageDraw.Draw(im)
    # Camera faces east: the top band is the west-front terrace, the lawn falls away to the bottom (west).
    d.rectangle([0, 0, W - 1, 139], fill=rgba(PAL["terrace"]))
    d.rectangle([0, 140, W - 1, 147], fill=rgba(PAL["terrace_edge"]))          # terrace wall lip
    d.rectangle([560, 140, 719, 179], fill=rgba(PAL["terrace"]))               # stair notch
    d.rectangle([616, 180, 663, H - 1], fill=rgba(PAL["walk"]))                # axial walk
    for box in ([180, 200, 1100, 1180], [380, 230, 900, 980]):                 # two curved walks
        d.arc(box, start=180, end=360, fill=rgba(PAL["walk"]), width=24)
    a = np.array(im)
    a[..., 3] = 255
    return a


def layer_post():
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rectangle([896, 400, 927, 415], fill=rgba(PAL["post_base"]))              # 32x16 footprint
    d.rectangle([908, 336, 915, 399], fill=rgba(PAL["post_mast"]))              # 8x64 mast
    d.rectangle([910, 330, 913, 333], fill=rgba(PAL["accent"]))                 # 4x4 light
    return np.array(im)


def layer_fg():
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse([0, 580, 240, 820], fill=rgba(PAL["canopy"]))                     # corner canopy
    d.ellipse([890, 404, 990, 504], fill=rgba(PAL["canopy"]))                   # covers post base
    a = np.array(im)
    a[..., 3] = np.where(a[..., 3] > 0, 255, 0).astype(np.uint8)               # force binary alpha
    x, y, w, h = PROBE
    a[y:y + h, x:x + w] = rgba(PAL["probe"], 128)
    return a


def layers():
    return {"ground": layer_ground(), "survey-post": layer_post(), "fg-occlusion": layer_fg()}


def composite(ls):
    out = Image.fromarray(ls[LAYERS[0]], "RGBA")
    for n in LAYERS[1:]:
        out = Image.alpha_composite(out, Image.fromarray(ls[n], "RGBA"))
    return np.array(out)


def probe_mask():
    m = np.zeros((H, W), bool)
    x, y, w, h = PROBE
    m[y:y + h, x:x + w] = True
    return m


# ============================================================================ containers
DT = (2026, 10, 15, 17, 45, 0)


def zput(z, name, payload, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, DT)
    zi.compress_type = method
    z.writestr(zi, payload)


def make_ora(ls, comp_png):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.5" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for n in reversed(LAYERS):                                                # ORA lists top first
        stack.append(f'<layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.000" '
                     f'visibility="visible" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>", ""]
    thumb = Image.fromarray(composite(ls), "RGBA").resize((256, 144), Image.NEAREST)
    tb = io.BytesIO(); thumb.save(tb, "PNG")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "mimetype", b"image/openraster", zipfile.ZIP_STORED)          # must be first, stored
        zput(z, "stack.xml", "\n".join(stack).encode())
        for n in LAYERS:
            zput(z, f"data/{n}.png", png_bytes(ls[n]))
        zput(z, "mergedimage.png", comp_png)
        zput(z, "Thumbnails/thumbnail.png", tb.getvalue())
    return buf.getvalue()


def make_pxo(ls, comp_png):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": False, "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": True} for n in LAYERS]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYERS], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(BASE), "frame_current_tag": "0",
                      "include_tag_in_filename": "false", "interpolation": "0", "lines_count": "1",
                      "new_dir_for_each_frame_tag": "false", "number_of_digits": "4", "number_of_frames": "1",
                      "orientation": "0", "repeat_count": "0", "resize": "100", "save_quality": "0.75",
                      "separator_character": "\"_\"", "sheet_layers_as_separate_files": "false",
                      "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": 0, "export_profile": export_profile,
            "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json, "license": "", "metadata": {},
            "next_keyframe_id": 0, "palettes": [], "pixelorama_version": PIXELORAMA_VERSION,
            "project_current_palette_name": "", "pxo_version": 7, "reference_images": [], "size_x": W, "size_y": H,
            "symmetry_points": [W - 1.0, H - 1.0], "tags": [], "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0,
            "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "",
            "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "data.json", json.dumps(data, separators=(",", ":")))
        zput(z, "mimetype", "application/x-pixelorama")
        zput(z, "preview.png", comp_png)
        zput(z, "image_data/frames/1/", b"")
        for li, n in enumerate(LAYERS, start=1):
            zput(z, f"image_data/frames/1/layer_{li}", np.ascontiguousarray(ls[n]).tobytes())
            zput(z, f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def names():
    return {"ora": f"{BASE}.ora", "pxo": f"{BASE}.pxo", "composite": f"{BASE}_expected-composite.png",
            "manifest": f"{BASE}_manifest.json", "report": f"{BASE}_roundtrip-report.json",
            **{f"layer:{n}": f"{BASE}_expected-layer-{i}-{n}.png" for i, n in enumerate(LAYERS, 1)}}


def artefacts():
    ls = layers()
    comp = composite(ls)
    comp_png = png_bytes(comp)
    files = {"ora": make_ora(ls, comp_png), "pxo": make_pxo(ls, comp_png), "composite": comp_png}
    for n in LAYERS:
        files[f"layer:{n}"] = png_bytes(ls[n])
    return ls, comp, files


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def build():
    ls, comp, files = artefacts()
    if artefacts()[2] != files:
        raise SystemExit("build is not deterministic")
    out = rp(OUT_REL)
    os.makedirs(_fs(out), exist_ok=True)
    nm = names()
    hashes = {}
    for k, data in files.items():
        print(write_new(os.path.join(out, nm[k]), data), nm[k])
        hashes[nm[k]] = sha(data)
    man = {
        "project": SLUG, "area": "washington-capitol",
        "purpose": "TEST-ONLY multi-layer Pixelorama round-trip probe (ORA and native PXO). Flat schematic "
                   "blockout, not scene art.",
        "status": "test-only; not art; not a candidate; not runtime-integrated", "art_approved": False,
        "runtime_integrated": False, "authorship": "Deterministic Python tool authored and run by Claude (Claude Code).",
        "canvas": {"w": W, "h": H, "orientation": "camera faces east: top band = west-front terrace, bottom = west"},
        "layers_bottom_to_top": [
            {"name": n, "opaque_texels": int((ls[n][..., 3] == 255).sum()),
             "semi_alpha_texels": int(((ls[n][..., 3] > 0) & (ls[n][..., 3] < 255)).sum()),
             "file": nm[f"layer:{n}"]} for n in LAYERS],
        "probe_patch_alpha128": {"xywh": list(PROBE), "layer": "fg-occlusion", "pass_criterion": False},
        "files_sha256_bytes": hashes,
        "tool": {"file": TOOL_REL, "sha256_text_lf_v1": sha_text(read_bytes(os.path.abspath(__file__))),
                 "python": sys.version.split()[0], "pillow": Image.__version__, "numpy": np.__version__},
    }
    mb = (json.dumps(man, indent=2) + "\n").encode()
    print(write_new(os.path.join(out, nm["manifest"]), mb), nm["manifest"])


# ============================================================================ check
def cfg_path():
    a = os.environ.get("APPDATA")
    return os.path.join(a, "pixelorama", "config.ini") if a else None


def snapshot(cfg):
    root = os.path.dirname(cfg) if cfg else None
    snap = {}
    if root and os.path.isdir(root):
        for d, _, fs in os.walk(root):
            for f in fs:
                p = os.path.join(d, f)
                b = read_bytes(p)
                snap[os.path.relpath(p, root).replace("\\", "/")] = (len(b), sha(b))
    return snap


def run_cli(exe, args, cfg, cfg_backup):
    before = read_bytes(cfg) if cfg and os.path.isfile(cfg) else None
    t0 = time.time()
    try:
        p = subprocess.run([exe, "--headless", "--quit", "--"] + args, capture_output=True, text=True,
                           timeout=240, encoding="utf-8", errors="replace")
    finally:
        changed = False
        if before is not None:
            now = read_bytes(cfg) if os.path.isfile(cfg) else None
            changed = now != before
            if changed:
                shutil.copy2(cfg_backup, cfg)
                if read_bytes(cfg) != before:
                    raise SystemExit(f"could not restore {cfg}; backup at {cfg_backup}")
    noise = ("shader_compiler", "custom_samplers", "Condition \"!actions")
    tail = [l for l in p.stdout.splitlines() + p.stderr.splitlines() if l.strip() and not any(s in l for s in noise)]
    return {"args": args, "exit_code": p.returncode, "seconds": round(time.time() - t0, 1),
            "config_ini_changed_and_restored": changed, "output_tail": tail[-6:]}


def cmp_arr(got, exp, mask_out=None):
    if got.shape != exp.shape:
        return {"shape_ok": False, "got_shape": list(got.shape)}
    diff = (got != exp).any(axis=2)
    r = {"shape_ok": True, "differing_texels": int(diff.sum())}
    if mask_out is not None:
        r["differing_outside_probe"] = int((diff & ~mask_out).sum())
        pd = np.abs(got[mask_out].astype(int) - exp[mask_out].astype(int))
        r["probe_max_channel_delta"] = int(pd.max())
        r["probe_sample_got_vs_expected"] = [got[PROBE[1], PROBE[0]].tolist(), exp[PROBE[1], PROBE[0]].tolist()]
    return r


def list_pngs(d):
    return sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))


def split_match(d, ls):
    """Match each split-layer PNG to a source layer by content; report the name Pixelorama gave it."""
    out = []
    for f in list_pngs(d):
        mode, size, a = decode(read_bytes(os.path.join(d, f)))
        hit = [n for n in LAYERS if a.shape == ls[n].shape and a.tobytes() == ls[n].tobytes()]
        best = None
        if not hit:
            best = {n: int((a != ls[n]).any(axis=2).sum()) for n in LAYERS if a.shape == ls[n].shape}
        out.append({"file": f, "mode": mode, "size": list(size), "exact_layer_match": hit, "diff_per_layer": best})
    return out


def zip_listing(b):
    try:
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            info = {"entries": z.namelist()}
            if "data.json" in info["entries"]:
                dj = json.loads(z.read("data.json"))
                info["layers"] = [{"name": l.get("name"), "visible": l.get("visible")} for l in dj.get("layers", [])]
                info["pxo_version"] = dj.get("pxo_version")
            return info
    except zipfile.BadZipFile:
        return {"zip": False, "head": b[:8].hex()}


def check(exe, write_report):
    ls, comp, files = artefacts()
    nm = names()
    out = rp(OUT_REL)
    for k in ("ora", "pxo", "composite"):
        if read_bytes(os.path.join(out, nm[k])) != files[k]:
            raise SystemExit(f"{nm[k]} on disk differs from a fresh rebuild")
    pm = probe_mask()
    cfg = cfg_path()
    snap0 = snapshot(cfg)
    rep = {"pixelorama": exe, "pixelorama_sha256": sha(read_bytes(exe)), "steps": {}}
    tmp = tempfile.mkdtemp(prefix="wb-wdc3l-")
    try:
        bak = None
        if cfg and os.path.isfile(cfg):
            bak = os.path.join(tmp, "config.ini.bak"); shutil.copy2(cfg, bak)
            rep["config_ini_sha256_before"] = sha(read_bytes(cfg))
        src = {}
        for k in ("ora", "pxo"):
            src[k] = os.path.join(tmp, f"src.{k}")
            with open(src[k], "wb") as f:
                f.write(files[k])

        def fresh(name):
            d = os.path.join(tmp, name); os.makedirs(d); return d

        flat_bytes = []
        for label, k, rep_i in (("A1_pxo_flat", "pxo", 1), ("A2_pxo_flat", "pxo", 2), ("C_ora_flat", "ora", 1)):
            d = fresh(label)
            r = run_cli(exe, ["--export", "-o", os.path.join(d, "f.png"), src[k]], cfg, bak)
            pngs = list_pngs(d); r["pngs"] = pngs
            if len(pngs) == 1:
                b = read_bytes(os.path.join(d, pngs[0]))
                r["png_sha256"] = sha(b)
                r["compare_to_expected_composite"] = cmp_arr(decode(b)[2], comp, pm)
                if k == "pxo":
                    flat_bytes.append(b)
                if label == "A1_pxo_flat":
                    rep["_flat_png_for_copy"] = b
            r["source_copy_unchanged"] = read_bytes(src[k]) == files[k]
            rep["steps"][label] = r
        rep["steps"]["A_runs_byte_identical"] = len(flat_bytes) == 2 and flat_bytes[0] == flat_bytes[1]

        for label, k in (("B_pxo_split", "pxo"), ("D_ora_split", "ora")):
            d = fresh(label)
            r = run_cli(exe, ["--export", "--split-layers", "-o", os.path.join(d, "f.png"), src[k]], cfg, bak)
            r["split"] = split_match(d, ls)
            r["all_layers_exact"] = sorted(sum((s["exact_layer_match"] for s in r["split"]), [])) == sorted(LAYERS)
            rep["steps"][label] = r

        d = fresh("E_ora_to_pxo")
        r = run_cli(exe, ["--export", "-o", os.path.join(d, "conv.pxo"), src["ora"]], cfg, bak)
        r["files"] = sorted(os.listdir(d))
        r["outputs"] = {f: zip_listing(read_bytes(os.path.join(d, f))) for f in r["files"]}
        rep["steps"]["E_ora_export_to_pxo_name"] = r

        for k in ("pxo", "ora"):
            rep["steps"][f"F_{k}_size_framecount"] = run_cli(exe, ["--size", "--framecount", src[k]], cfg, bak)
        if cfg:
            rep["config_ini_sha256_after"] = sha(read_bytes(cfg))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    snap1 = snapshot(cfg)
    rep["appdata_pixelorama_other_changes"] = {
        "added": sorted(set(snap1) - set(snap0)), "removed": sorted(set(snap0) - set(snap1)),
        "modified": sorted(k for k in set(snap0) & set(snap1) if snap0[k] != snap1[k])}
    s = rep["steps"]

    def flat_ok(x):
        c = x.get("compare_to_expected_composite", {})
        return x["exit_code"] == 0 and c.get("shape_ok") and c.get("differing_outside_probe") == 0

    rep["verdicts"] = {
        "pxo_flat_exact_outside_probe": flat_ok(s["A1_pxo_flat"]) and flat_ok(s["A2_pxo_flat"]),
        "pxo_flat_deterministic": s["A_runs_byte_identical"],
        "pxo_split_layers_exact": s["B_pxo_split"]["all_layers_exact"],
        "ora_flat_exact_outside_probe": flat_ok(s["C_ora_flat"]),
        "ora_split_layers_exact": s["D_ora_split"]["all_layers_exact"],
        "config_ini_restored": (not cfg) or rep["config_ini_sha256_after"] == rep["config_ini_sha256_before"],
        "sources_unchanged": all(s[k]["source_copy_unchanged"] for k in ("A1_pxo_flat", "A2_pxo_flat", "C_ora_flat")),
    }
    rep["result"] = "PASS" if all(rep["verdicts"].values()) else "FAIL"
    flat = rep.pop("_flat_png_for_copy", None)
    text = json.dumps(rep, indent=2) + "\n"
    print(text)
    if write_report:
        print(write_new(os.path.join(out, nm["report"]), text.encode()), nm["report"])
        if flat is not None:
            print(write_new(os.path.join(out, f"{BASE}_pixelorama-pxo-flat-export.png"), flat))
    return 0 if rep["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["build", "check"])
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    ap.add_argument("--write-report", action="store_true")
    a = ap.parse_args()
    if a.mode == "build":
        build(); return 0
    if not os.path.isfile(a.pixelorama):
        raise SystemExit(f"Pixelorama not found: {a.pixelorama}")
    return check(os.path.abspath(a.pixelorama), a.write_report)


if __name__ == "__main__":
    sys.exit(main())
