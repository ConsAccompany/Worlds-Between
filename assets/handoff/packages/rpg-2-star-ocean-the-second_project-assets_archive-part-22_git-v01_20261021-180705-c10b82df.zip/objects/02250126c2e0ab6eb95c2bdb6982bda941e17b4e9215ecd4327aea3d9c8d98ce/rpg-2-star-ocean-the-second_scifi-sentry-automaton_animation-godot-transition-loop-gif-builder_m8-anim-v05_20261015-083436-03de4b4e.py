"""Assemble the real Godot-render transition loop recorded by the v5 feasibility check into review GIFs.

The frames are 560x250 crops of 1280x720 viewport renders saved on EVERY 60 fps step by
  game/tests/rpg-2-star-ocean-the-second_sentry-automaton-animation-candidate_battle-check-capture_m8-anim-v05_20261015-083436-4c9eabf7.gd
when SENTRY_V5_SCRATCH is set (<scratch>/loop/<version>/f0000.png ...). Two GIFs per version, each a separate file (no
contact sheet or collage):
  - real speed: every 3rd step at 50 ms (60 fps / 3 = 20 GIF frames per second);
  - 1/3 speed: every step at 50 ms, so one-step pops and per-step slides are visible.
Nothing is redrawn, resized or retimed beyond that frame selection; frames are only palettised (one shared 255-colour
palette, no dithering). A note JSON records sources and hashes.

Usage (bundled Python/Pillow runtime, run with -I):
  python <this file> --frames <scratch>/loop --out OUTPUTS_DIR [--versions v4 v2]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import uuid
from datetime import datetime
from pathlib import Path

from PIL import Image

SLUG = "rpg-2-star-ocean-the-second"
TAG = "m8-anim-v05"
FRAME_MS = 50
LABEL = {"v4": "godot-transition-loop-v4-retained-candidate", "v2": "godot-transition-loop-v2-runtime-default-compare"}
SPEEDS = {"real-speed": 3, "third-speed": 1}


def build(files: list, path: Path) -> dict:
    frames = [Image.open(f).convert("RGB") for f in files]
    sizes = {f.size for f in frames}
    assert len(sizes) == 1, sizes
    w, h = frames[0].size
    sample = frames[::8]
    atlas = Image.new("RGB", (w, h * len(sample)))
    for i, f in enumerate(sample):
        atlas.paste(f, (0, i * h))
    palette = atlas.quantize(colors=255, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    pal = [f.quantize(palette=palette, dither=Image.Dither.NONE) for f in frames]
    assert not path.exists(), path
    pal[0].save(path, save_all=True, append_images=pal[1:], duration=FRAME_MS, loop=0, disposal=1, optimize=True)
    return {"frames": len(files), "size": [w, h], "frameMs": FRAME_MS,
            "sourceFrameSha256": hashlib.sha256(b"".join(hashlib.sha256(f.read_bytes()).digest() for f in files)).hexdigest()}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--versions", nargs="+", default=["v4", "v2"])
    args = ap.parse_args()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    note = {"project": SLUG, "revision": TAG, "status": "review_preview_only", "artAcceptanceCount": 0,
            "method": "real Godot 4.7.2 1280x720 renders of real combat calls, cropped to the fight, palettised only. Scenario: the sentry walks in; the hero strikes it on gait frame 6 (move->hit, the v4 worst-case sole offset); the party steps back so the sentry walks through its flinch (hit slide, hit->move); stop at 53 px (move->idle); strike at 53 px (strike->idle); the party backs off to 69 px during the next wind-up; strike at 69 px while the sentry walks on through its strike pose (strike slide, strike->move)",
            "builderScript": str(Path(__file__).resolve().relative_to(args.out.resolve().parent)).replace("\\", "/"),
            "gifs": []}
    for version in args.versions:
        files = sorted((args.frames / version).glob("f*.png"))
        assert len(files) > 200, (version, len(files))
        for speed, every in SPEEDS.items():
            path = args.out / f"{SLUG}_scifi-sentry-automaton-animation-candidate_{LABEL[version]}-{speed}_{TAG}_{stamp}-{uuid.uuid4().hex[:8]}.gif"
            info = build(files[::every], path)
            info.update({"version": version, "speed": speed, "stepsPerGifFrame": every, "file": "outputs/" + path.name,
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size})
            note["gifs"].append(info)
            print(path, info["frames"], info["bytes"])
    npath = args.out / f"{SLUG}_scifi-sentry-automaton-animation-candidate_godot-transition-loop-note_{TAG}_{stamp}-{uuid.uuid4().hex[:8]}.json"
    assert not npath.exists()
    npath.write_text(json.dumps(note, indent=2) + "\n", encoding="utf-8")
    print(npath)


if __name__ == "__main__":
    main()
