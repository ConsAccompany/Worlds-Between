"""UNAPPROVED candidate v05: NYC City Hall Park (Lower Manhattan, 2537 science hub), one native 640x360 gameplay scene.

A NEW, deliberately bounded author tool. It replaces the interrupted v05 fork
(tools/...walkable-pilot-640x360_pixelorama-build_unapproved-v05_20261016-220852-74330a19.py, 4,553 lines, never run,
left untouched). That fork kept v04's composition (City Hall in rows 10-165, mostly under the runtime's 62-px header)
and v04's flat, even material language, which the creator rejected on 2026-10-16 as unlike the science-city scenes.
Reused from it: the .pxo (pxo_version 7) / .ora container writers, the PNG helpers, write-once file output and the
isolated Pixelorama round-trip idea. Nothing else.

Visual target: the accepted NYC public-facilities rooms and the existing science-city view -- warm golden key light on
pale masonry, cool blue-green shadow planes, dense small-scale stone and leaf texture with bright tops and dark
undersides, dark contact shading at object bases, and teal 2537 technology light confined to small emitters (pavement
inlays, bollard rings, lamp collars, a public-works stair kiosk, terminals). Palette ramps were picked by hand, with a
28-colour summary of the science-city plate and the Room 1 capture as a value/hue guide. No pixel of any plate or of the
AI-generated nonruntime reference is copied, traced or sampled into the art.

Composition is built for the real game frame: header covers rows 0-61 and footer rows 318-359, so City Hall (cupola top
row ~63) and the whole playable park sit inside rows 62-317. Real-landmark cues kept large-scale (NYC DCAS description):
central pavilion with a two-storey columned portico and broad stair, two projecting wings, roof balustrade, central
cupola with clock and Justice figure; restored Mould fountain (round granite basin, central bowl, candelabra lamps);
central walk, lawns and trees; low hoop fences. Scale is forced perspective: City Hall sits beyond a hero-scale iron
fence and gate piers, across a receding forecourt.

Determinism: numpy Generator(PCG64) with fixed per-element seeds drives slab tones, leaf clumps and wear marks. The
build is byte-deterministic (`check` rebuilds and compares).

Modes:  preview <dir outside repo> | build | check [--no-pixelorama] [--write-report]
Run with: <python> -I -B <this file> <mode> ...
"""
import argparse, hashlib, io, json, math, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image, ImageDraw

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG, AREA = "rpg-2-star-ocean-the-second", "nyc-city-hall-park"
VER, STAMP, RUN_ID = "unapproved-v05", "20261017-015916", "23a7984f"
RUN = f"nyc-chp-v05_{STAMP}-{RUN_ID}"
CAND_REL = f"game/assets/environments/candidates/{RUN}"
OUT_REL = f"outputs/{RUN}"
HEROINE_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
               "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
PIXELORAMA_DEFAULT = "C:/Users/hkzha/AppData/Local/Programs/Pixelorama-1.2.3/Pixelorama-Windows-64bit/Pixelorama.exe"
W, H = 640, 360
UI_TOP, UI_BOTTOM = 62, 318          # runtime header / footer bars (scifi_exploration_area.gd)
WIN_LONG_PREFIX = "\\\\?\\"


def fname(purpose, ext):
    return f"{SLUG}_{AREA}_{purpose}_{VER}_{STAMP}-{RUN_ID}.{ext}"


# ============================================================================ palette (hand-picked ramps, dark -> light)
RAMPS = {
    "ink":   ["0d1416", "182325", "243130"],
    "sky":   ["7f97a0", "a3b2ac", "c8c4a8", "e3d3a6", "f1e2b8"],
    "far":   ["5a5a58", "6c6a63", "807a6e", "958b7a", "aa9d86", "bfae92"],
    "brick": ["5c4a42", "6f5649", "83634f", "977459"],
    "glassf": ["4e6466", "64807e", "86a19a"],
    "mar":   ["5f625f", "767669", "8e8b7a", "a7a08b", "beb49b", "d3c8ac", "e4d9bc", "f0e8cf"],
    "roof":  ["34413f", "45544f", "586860", "6b7b6f"],
    "cop":   ["3f5a52", "557466", "6f8f7b", "8eab93"],
    "gilt":  ["7a5a26", "a5803a", "cfa850", "ecd283"],
    "win":   ["3a2b22", "6a4526", "a06a2c", "d59c42", "f3c76c", "ffe7a6"],
    "glass": ["1b2a33", "2a3d47", "3b545c"],
    "pave":  ["3b3833", "524c43", "6a6052", "817461", "988871", "ad9b80", "c2ae8f", "d6c29f"],
    "gran":  ["34383a", "484c4c", "5f625e", "777870", "8f8e83", "a6a397"],
    "tpave": ["4a6560", "5f7d74", "799689", "93ad9d"],
    "grass": ["1a3324", "26452b", "345a31", "457036", "59863b", "6f9a40", "88ad4c", "a3bf5e"],
    "leaf":  ["0f241f", "173426", "21452c", "2e5a31", "3e6f35", "538639", "6c9c3d", "8ab447", "a9c85a", "c6d877"],
    "elm":   ["11262a", "1a3934", "264c3c", "345f44", "46744b", "5d8a54", "79a163", "98b876"],
    "bark":  ["211a17", "332820", "48392d", "5e4b3b", "765f4b"],
    "iron":  ["141d20", "1d2a2f", "28393f", "354c53", "4a6369"],
    "teal":  ["1d4f53", "2a7a78", "3fa9a1", "6fd6c8", "b4f2e6", "e8fff9"],
    "water": ["183a47", "214d5d", "2c6375", "3c7d8f", "5b9fae", "8cc6cc", "c3e6e2"],
    "warm":  ["8a5a2c", "c18a3e", "e9b75e", "fbdc8e", "fff3c8"],
    "soil":  ["2f241d", "433328", "5a4535"],
    "wood":  ["3e2b1f", "5a3e29", "7a5636", "9a7046"],
    "navy":  ["1b2540", "26355a", "354a78"],
    "fl":    ["9c3f36", "cf6a44", "e3b14a", "f0e3c8", "b9a6cf", "7d4f8c", "d78c9a"],
}
PALETTE = [(f"{r}{k}", h) for r, hs in RAMPS.items() for k, h in enumerate(hs)]
I = {n: i for i, (n, _) in enumerate(PALETTE)}
RGB = np.array([[int(h[j:j + 2], 16) for j in (0, 2, 4)] for _, h in PALETTE], np.int32)
FAMILY = np.array([n.rstrip("0123456789") for n, _ in PALETTE])
STEP = np.array([int(n[len(n.rstrip("0123456789")):]) for n, _ in PALETTE])


def R(name):
    return [I[f"{name}{k}"] for k in range(len(RAMPS[name]))]


def _shift_lut(d):
    """Within-ramp value step (hue-shifted ramps make a darker step cooler, a lighter step warmer)."""
    lut = np.arange(len(PALETTE))
    for i, (n, _) in enumerate(PALETTE):
        f = FAMILY[i]
        k = int(np.clip(STEP[i] + d, 0, len(RAMPS[f]) - 1))
        lut[i] = I[f"{f}{k}"]
    return lut


SHADE1, SHADE2, LIFT1 = _shift_lut(-1), _shift_lut(-2), _shift_lut(1)
# cast shadow: one ramp step down, and stone/grass get an extra cool step so the shadow plane reads blue-green
SHADOW = SHADE1.copy()
for f in ("pave", "mar", "grass", "gran", "tpave"):
    for k in range(len(RAMPS[f])):
        SHADOW[I[f"{f}{k}"]] = I[f"{f}{max(0, k - 2)}"]
# teal technology light on stone: map warm paving onto the teal-tinted paving ramp by value
TEALIT = LIFT1.copy()
for k in range(len(RAMPS["pave"])):
    TEALIT[I[f"pave{k}"]] = I[f"tpave{min(3, max(0, k - 3))}"]
for k in range(len(RAMPS["gran"])):
    TEALIT[I[f"gran{k}"]] = I[f"tpave{min(3, max(0, k - 2))}"]

# ============================================================================ helpers
YY, XX = np.mgrid[0:H, 0:W]
BAYER = np.array([[0, 2], [3, 1]]) / 4.0
DITHER = np.tile(BAYER, (H // 2, W // 2))


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > 247 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def rp(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(p):
    with open(_fs(p), "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha_text(b):
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def new():
    return np.full((H, W), -1, np.int16)


def rng(*key):
    return np.random.Generator(np.random.PCG64(int.from_bytes(hashlib.sha256(repr(key).encode()).digest()[:8], "little")))


def ell(cx, cy, rx, ry):
    return ((XX - cx) / rx) ** 2 + ((YY - cy) / ry) ** 2 <= 1.0


def box(x0, y0, x1, y1):
    """Half-open box mask [x0, x1) x [y0, y1)."""
    return (XX >= x0) & (XX < x1) & (YY >= y0) & (YY < y1)


def poly(pts):
    im = Image.new("1", (W, H), 0)
    ImageDraw.Draw(im).polygon([tuple(p) for p in pts], fill=1)
    return np.array(im, bool)


def thick_line(p, q, w):
    im = Image.new("1", (W, H), 0)
    ImageDraw.Draw(im).line([tuple(p), tuple(q)], fill=1, width=w)
    return np.array(im, bool)


def rect(L, x0, y0, x1, y1, c):
    """Inclusive rectangle."""
    x0, x1 = max(0, x0), min(W - 1, x1)
    y0, y1 = max(0, y0), min(H - 1, y1)
    if x1 >= x0 and y1 >= y0:
        L[y0:y1 + 1, x0:x1 + 1] = I[c] if isinstance(c, str) else c


def px(L, x, y, c):
    if 0 <= x < W and 0 <= y < H:
        L[y, x] = I[c] if isinstance(c, str) else c


def shift(m, dx, dy):
    out = np.zeros_like(m)
    ys = slice(max(0, dy), H + min(0, dy)); yd = slice(max(0, -dy), H + min(0, -dy))
    xs = slice(max(0, dx), W + min(0, dx)); xd = slice(max(0, -dx), W + min(0, -dx))
    out[ys, xs] = m[yd, xd]
    return out


def dilate(m, rx=1, ry=1):
    out = m.copy()
    for dy in range(-ry, ry + 1):
        for dx in range(-rx, rx + 1):
            out |= shift(m, dx, dy)
    return out


def erode_box(m, x0, x1, y0, y1):
    """Keep p only if m holds on every offset (dx in [x0, x1], dy in [y0, y1]) -- the actor footprint test."""
    out = m.copy()
    for dy in range(y0, y1 + 1):
        for dx in range(x0, x1 + 1):
            out &= shift(m, -dx, -dy)
    return out


def edge(m):
    return m & ~(shift(m, 1, 0) & shift(m, -1, 0) & shift(m, 0, 1) & shift(m, 0, -1))


def apply_lut(L, mask, lut):
    m = mask & (L >= 0)
    L[m] = lut[L[m]]


def dither_mask(strength):
    """strength in [0,1] per pixel -> ordered 2x2 dither decision (only for 1-3 px transition bands)."""
    return strength > DITHER


_CLUSTER = np.random.Generator(np.random.PCG64(2537)).random((H // 2 + 1, W // 2 + 1))
CLUSTER = (_CLUSTER.repeat(2, 0).repeat(2, 1)[:H, :W] * 0.7 +
           np.random.Generator(np.random.PCG64(1811)).random((H, W)) * 0.3)


def falloff(strength, solid=0.62):
    """Organic light/wear falloff: solid core, clustered 2-px speckle toward the rim (no checkerboard)."""
    return (strength >= solid) | (strength > CLUSTER * solid)


def low_freq(key, scale=24, amp=1.0):
    """Smooth large-scale value field in [-amp, amp] (bilinear upsampled coarse random grid)."""
    g = rng("lowfreq", key)
    gh, gw = H // scale + 2, W // scale + 2
    c = g.random((gh, gw)) * 2 - 1
    fy, fx = YY / scale, XX / scale
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    v = (c[y0, x0] * (1 - tx) * (1 - ty) + c[y0, x0 + 1] * tx * (1 - ty) + c[y0 + 1, x0] * (1 - tx) * ty +
         c[y0 + 1, x0 + 1] * tx * ty)
    return v * amp


# ============================================================================ materials
def pavers(L, mask, key, ph, widths, ramp="pave", base=(3, 4, 5), weights=(0.3, 0.45, 0.25), oy=0, chips=0.03,
           crack=0.05, joint_drop=2, patch=0.9):
    """Irregular setts/flags: each course has its own random stone widths; per-stone tone (+ a smooth large-scale
    patch field so the plaza is not one even value), a lit top edge, a shaded bottom edge, joints only two ramp steps
    darker than the stone (ground, not brick wall), worn chips and the odd crack."""
    g = rng("pavers", key)
    Rm = np.array(R(ramp))
    n = len(Rm)
    sid = np.zeros((H, W), np.int64)
    lx = np.zeros((H, W), np.int64)
    wid = np.zeros((H, W), np.int64)
    row = (YY - oy) // ph
    ly = (YY - oy) % ph
    for r in range(int(row.min()), int(row.max()) + 1):
        xs, x, k = np.zeros(W, np.int64), -int(g.integers(0, max(widths))), 0
        lxs, ws = np.zeros(W, np.int64), np.zeros(W, np.int64)
        while x < W:
            w = int(g.choice(widths))
            a, b = max(0, x), max(0, min(W, x + w))
            if b > a:
                xs[a:b] = k; lxs[a:b] = np.arange(a, b) - x; ws[a:b] = w
            x += w; k += 1
        rows = row[:, 0] == r
        sid[rows] = xs + (r - row.min()) * 1000
        lx[rows] = lxs; wid[rows] = ws
    tones = g.choice(base, size=int(sid.max()) + 1, p=np.array(weights) / sum(weights))
    cracked = g.random(int(sid.max()) + 1) < crack
    t = tones[sid] + np.round(low_freq(key, amp=patch)).astype(int)
    t = np.clip(t, joint_drop, n - 2)
    out = Rm[t]
    out = np.where((ly == 1) & (lx > 0) & (lx < wid - 1), Rm[np.minimum(t + 1, n - 1)], out)
    out = np.where(ly == ph - 1, Rm[np.maximum(t - 1, 0)], out)
    jt = np.maximum(t - joint_drop, 0)
    out = np.where((lx == 0) | (ly == 0), Rm[jt], out)
    chip = g.random((H, W)) < chips
    out = np.where(chip & (lx > 0) & (ly > 1), Rm[np.maximum(t - 1, 0)], out)
    ck = cracked[sid] & (lx == (ly * 2 + 1) % np.maximum(wid, 1)) & (ly > 0)
    out = np.where(ck, Rm[np.maximum(t - 2, 0)], out)
    L[mask] = out[mask]


def hex_pavers(L, mask, key, sx=7, sy=4, ramp="pave", base=(3, 4, 5), weights=(0.28, 0.47, 0.25), patch=0.9):
    """NYC-park hexagonal pavers seen in 3/4: honeycomb cells (rows offset by half a cell), joints one-two steps
    darker, a lit upper-left lip and a shaded lower-right lip per cell, plus a smooth large-scale tone field."""
    g = rng("hex", key)
    Rm = np.array(R(ramp))
    n = len(Rm)
    r0 = np.round(YY / sy).astype(int)
    best = np.full((H, W), 1e9); second = np.full((H, W), 1e9)
    bid = np.zeros((H, W), np.int64); bdx = np.zeros((H, W)); bdy = np.zeros((H, W))
    for dr in (-1, 0, 1):
        r = r0 + dr
        off = (r % 2) * (sx / 2.0)
        c0 = np.round((XX - off) / sx).astype(int)
        for dc in (-1, 0, 1):
            c = c0 + dc
            cxp, cyp = c * sx + off, r * sy
            dx, dy = XX - cxp, (YY - cyp) * (sx / (sy * 1.732))
            d = np.maximum(np.abs(dx) * 0.866 + np.abs(dy) * 0.5, np.abs(dy))      # hex metric
            nb = d < best
            second = np.where(nb, best, np.minimum(second, d))
            best = np.where(nb, d, best)
            bid = np.where(nb, (r + 200) * 1000 + (c + 200), bid)
            bdx = np.where(nb, dx, bdx); bdy = np.where(nb, dy, bdy)
    uniq, inv = np.unique(bid, return_inverse=True)
    tones = g.choice(base, size=len(uniq), p=np.array(weights) / sum(weights))
    t = tones[inv.reshape(H, W)] + np.round(low_freq(("hex", key), amp=patch)).astype(int)
    t = np.clip(t, 2, n - 2)
    out = Rm[t]
    lit = (bdy < -0.9) & (bdx < 0.5) & (g.random(len(uniq))[inv.reshape(H, W)] < 0.55)   # not every cell glints
    out = np.where(lit, Rm[np.minimum(t + 1, n - 1)], out)
    out = np.where((bdy > 1.2) & (bdx > 0.0), Rm[np.maximum(t - 1, 0)], out)
    deep = low_freq(("hexjoint", key), scale=18) > 0.15                                    # joints silt up in patches
    out = np.where(second - best < 0.75, Rm[np.maximum(t - np.where(deep, 2, 1), 0)], out)
    chip = g.random((H, W)) < 0.02
    out = np.where(chip, Rm[np.maximum(t - 1, 0)], out)
    L[mask] = out[mask]


def ring_pavers(L, mask, key, cx, cy, ring=5, seg=9, ramp="pave", base=(3, 4, 5), sy=0.56):
    """Concentric slabs around a centre (fountain plaza), seen in 3/4 (y squashed by sy)."""
    g = rng("ring", key)
    Rm = np.array(R(ramp))
    dx, dy = XX - cx, (YY - cy) / sy
    r = np.hypot(dx, dy)
    th = np.arctan2(dy, dx)
    ri = (r // ring).astype(int)
    circ = np.maximum(1.0, 2 * np.pi * (ri + 0.5) * ring)
    nseg = np.maximum(6, (circ // seg)).astype(int)
    si = (((th + np.pi) / (2 * np.pi)) * nseg + ri * 0.37).astype(int) % nseg
    tone_tab = g.choice(base, size=(200, 400))
    t = tone_tab[np.clip(ri, 0, 199), np.clip(si, 0, 399)]
    frac_r = (r % ring)
    frac_s = (((th + np.pi) / (2 * np.pi)) * nseg + ri * 0.37) % 1.0
    t = np.clip(t + np.round(low_freq(("ring", key), amp=0.8)).astype(int), 2, len(Rm) - 2)
    out = Rm[t]
    jt = Rm[np.maximum(t - 2, 0)]
    out = np.where(frac_r < 1.0, jt, out)
    out = np.where((frac_r >= 1.0) & (frac_r < 2.0) & (dy < 0), Rm[np.minimum(t + 1, len(Rm) - 1)], out)
    out = np.where(frac_s * (2 * np.pi * r / nseg) < 1.0, jt, out)
    chip = g.random((H, W)) < 0.03
    out = np.where(chip, Rm[np.maximum(t - 1, 0)], out)
    L[mask] = out[mask]


def lawn(L, mask, key, base=4):
    """Mown turf: two-tone mowing bands, blade ticks (dark under, light tip), clover/dry flecks, darker north rim."""
    g = rng("lawn", key)
    Rg = np.array(R("grass"))
    band = (((XX + YY // 2) // 9) % 2) * (g.random((H, W)) < 0.45)
    t = np.full((H, W), base) - band + np.round(low_freq(("lawn", key), scale=30, amp=0.7)).astype(int)
    blades = g.random((H, W))
    t = np.where(blades < 0.13, t - 1, t)
    t = np.where((blades > 0.13) & (blades < 0.21) & shift(blades < 0.13, 0, 1), t + 2, t)  # light tip above a tick
    t = np.where((blades > 0.985), t + 2, t)
    north_rim = mask & ~shift(mask, 0, 1)
    rim = mask & (shift(north_rim, 0, 1) | north_rim | shift(north_rim, 0, 2))
    t = np.where(rim, t - 2, t)
    t = np.clip(t, 0, len(Rg) - 1)
    L[mask] = Rg[t][mask]


def canopy(L, cx, cy, rx, ry, key, ramp="leaf", n=None, rmin=4.0, rmax=7.5, light=(-0.62, -0.78), gain=0.0,
           top_bias=0.42, clip=None):
    """Tree crown from overlapping leaf clumps drawn top-first; each clump lit from the upper left, bright tops,
    dark undersides, a dark rim where it overlaps the clump below, 2-px leaf texture and a dark outer outline.
    Returns the crown mask."""
    g = rng("canopy", key)
    Rl = np.array(R(ramp))
    n = n or int(rx * ry / 8.5)
    pts = []
    for _ in range(n):
        a = g.uniform(0, 2 * np.pi)
        rr = math.sqrt(g.uniform(0.0, 1.0)) ** 0.8
        x = cx + math.cos(a) * rr * (rx - rmin)
        y = cy + math.sin(a) * rr * (ry - rmin)
        pts.append((y, x, g.uniform(rmin, rmax), g.uniform(0, 6.3)))
    pts.sort()
    val = np.full((H, W), -9.0)
    cov = np.zeros((H, W), bool)
    lx, ly = light
    for (y, x, r, ph) in pts:
        x0, x1 = int(max(0, x - r - 2)), int(min(W, x + r + 3))
        y0, y1 = int(max(0, y - r - 2)), int(min(H, y + r + 3))
        if x1 <= x0 or y1 <= y0:
            continue
        X, Y = XX[y0:y1, x0:x1], YY[y0:y1, x0:x1]
        dx, dy = (X - x) / r, (Y - y) / (r * 0.86)
        th = np.arctan2(dy, dx)
        reff = 1.0 + 0.16 * np.sin(5 * th + ph) + 0.08 * np.sin(9 * th + 2 * ph)
        d2 = (dx * dx + dy * dy) / (reff * reff)
        m = d2 <= 1.0
        nz = np.sqrt(np.clip(1 - d2, 0, 1))
        lam = -(dx * lx + dy * ly) * 0.55 + nz * 0.45
        glob = (cy - Y) / ry * top_bias
        v = 0.42 + 0.5 * lam + glob + gain
        rim = (d2 > 0.62) & ((dx * lx + dy * ly) > 0.05)
        v = np.where(rim, v - 0.32, v)
        sub = val[y0:y1, x0:x1]
        sub[m] = v[m]
        cov[y0:y1, x0:x1] |= m
    if clip is not None:
        cov &= clip
    tex = g.random((H // 2 + 1, W // 2 + 1)).repeat(2, 0).repeat(2, 1)[:H, :W]
    tex = np.roll(tex, (1, 0), (0, 1)) * 0.5 + tex * 0.5
    v = val + (tex - 0.5) * 0.30 + (DITHER - 0.375) * 0.10
    k = np.clip(np.round(v * (len(Rl) - 1)), 0, len(Rl) - 1).astype(int)
    out = Rl[k]
    # outer outline: darkest on the lower/right side, one step lighter on the upper/left side
    e = edge(cov)
    lower = e & ~(shift(cov, 0, -1) & shift(cov, -1, 0))
    out = np.where(e, Rl[np.maximum(k - 3, 1)], out)
    out = np.where(lower, Rl[0], out)
    sparkle = (g.random((H, W)) < 0.05) & (k >= len(Rl) - 3)
    out = np.where(sparkle, Rl[-1], out)
    L[cov] = out[cov]
    return cov


def trunk(L, x, ybase, h, w0, w1, key, lean=0.0, ramp="bark"):
    """Tapered trunk with a lit west side, a dark east side, bark ticks and a root flare."""
    g = rng("trunk", key)
    Rb = R(ramp)
    m = np.zeros((H, W), bool)
    for j in range(h):
        y = ybase - j
        f = j / max(1, h - 1)
        w = w0 + (w1 - w0) * f + (2.5 if j < 3 else 0) * (3 - j) / 3
        xc = x + lean * j
        a, b = int(round(xc - w / 2)), int(round(xc + w / 2))
        for xx in range(a, b + 1):
            if 0 <= xx < W and 0 <= y < H:
                u = (xx - a) / max(1, b - a)
                c = Rb[3] if u < 0.3 else Rb[2] if u < 0.65 else Rb[1]
                if xx in (a, b):
                    c = Rb[0]
                if g.random() < 0.12 and a < xx < b:
                    c = Rb[max(0, Rb.index(c) - 1)]
                L[y, xx] = c
                m[y, xx] = True
    return m


def limb(L, p, q, w, ramp="bark"):
    Rb = R(ramp)
    m = thick_line(p, q, w)
    L[m] = Rb[2]
    L[m & ~shift(m, 0, -1)] = Rb[0]
    L[m & ~shift(m, 0, 1)] = Rb[3]
    return m


# ============================================================================ skyline and sky (rows 0-110)
def paint_sky():
    L = new()
    Rs = R("sky")
    for y in range(0, 112):
        t = y / 111
        k = 4 if t > 0.72 else 3 if t > 0.48 else 2 if t > 0.25 else 1
        L[y, :] = Rs[k]
    L[112:FENCE_Y + 2, :] = I["grass2"]          # ground under the forecourt (keeps the base opaque)
    # dither the band boundaries
    for yb, k in ((28, 1), (53, 2), (80, 3)):
        m = box(0, yb - 2, W, yb + 2) & dither_mask(np.clip((YY - (yb - 2)) / 4.0, 0, 1))
        L[m] = Rs[k + 1]
    Rf, Rk, Rgf = R("far"), R("brick"), R("glassf")

    def block(x0, x1, top, bot, ramp, lit=3, wins=True, key=0, cap=None):
        g = rng("block", key)
        rr = R(ramp)
        rect(L, x0, top, x1, bot, rr[min(lit, len(rr) - 1)])
        rect(L, x1 - max(2, (x1 - x0) // 5), top, x1, bot, rr[max(0, lit - 1)])   # east face in shade
        rect(L, x0, top, x1, top, rr[min(lit + 1, len(rr) - 1)])
        if cap:
            rect(L, x0 - 1, top - 1, x1 + 1, top, rr[max(0, lit - 2)])
        if wins:
            for yy in range(top + 3, bot - 1, 4):
                for xx in range(x0 + 2, x1 - 2, 3):
                    if g.random() < 0.8:
                        c = "win3" if g.random() < 0.18 else rr[max(0, lit - 2)]
                        px(L, xx, yy, c)
                        px(L, xx, yy + 1, c if isinstance(c, str) else rr[max(0, lit - 2)])
    # Municipal Building (NE, behind right): limestone mass with colonnade base and stepped crown
    block(452, 560, 34, 112, "far", lit=4, key=1, cap=True)
    for xx in range(456, 556, 6):
        rect(L, xx, 96, xx + 1, 111, Rf[2])
    rect(L, 488, 14, 524, 34, Rf[4]); rect(L, 518, 14, 524, 34, Rf[3])
    rect(L, 496, 2, 516, 14, Rf[5]); rect(L, 503, 0, 509, 2, I["gilt2"])
    # Tweed-courthouse-like low block directly behind, and Broadway brick fronts to the west
    block(236, 404, 78, 112, "far", lit=3, key=2, cap=True)
    block(96, 168, 50, 112, "brick", lit=2, key=3, cap=True)
    block(28, 96, 64, 112, "far", lit=2, key=4)
    block(168, 230, 70, 112, "brick", lit=3, key=5, cap=True)
    block(560, 640, 58, 112, "brick", lit=2, key=6, cap=True)
    block(0, 28, 44, 112, "brick", lit=1, key=7)
    # water tanks
    for (x, y) in ((120, 44), (196, 64), (590, 52)):
        rect(L, x - 3, y - 6, x + 3, y, Rk[0]); rect(L, x - 4, y - 8, x + 4, y - 7, Rk[1])
        rect(L, x - 2, y + 1, x - 2, y + 4, Rk[0]); rect(L, x + 2, y + 1, x + 2, y + 4, Rk[0])
    # one slim 2537 glass tower far behind, faint teal seam
    rect(L, 372, 20, 392, 80, Rgf[1]); rect(L, 386, 20, 392, 80, Rgf[0]); rect(L, 372, 20, 392, 21, Rgf[2])
    rect(L, 381, 22, 381, 78, I["teal2"])
    return L


# ============================================================================ City Hall (background scale)
CH = dict(x0=196, x1=444, base=152, cornice=106, mid=128, cx=320)


def paint_city_hall():
    L = new()
    Rm = R("mar")
    x0, x1, base, cor, mid, cx = CH["x0"], CH["x1"], CH["base"], CH["cornice"], CH["mid"], CH["cx"]
    wing = 40              # projecting wing width (each end)
    pav0, pav1 = cx - 34, cx + 34     # central pavilion
    # roof (slate) seen above the balustrade, hipped back
    rect(L, x0 + 6, cor - 14, x1 - 6, cor - 5, I["roof1"])
    rect(L, x0 + 10, cor - 16, x1 - 10, cor - 14, I["roof2"])
    for xx in range(x0 + 8, x1 - 8, 5):
        px(L, xx, cor - 12, I["roof0"]); px(L, xx + 2, cor - 9, I["roof3"])
    # main walls: recessed links (set back: base 2 rows higher) then wings and pavilion forward
    rect(L, x0, cor, x1, base - 2, Rm[4])
    for (a, b, bb) in ((x0, x0 + wing, base), (x1 - wing, x1, base), (pav0, pav1, base - 1)):
        rect(L, a, cor - 2, b, bb, Rm[5])
        rect(L, b - 2, cor - 2, b, bb, Rm[3])                   # east return in shade
        rect(L, a, cor - 2, a, bb, Rm[6])                         # west arris catches light
    # storey band, cornice, balustrade
    rect(L, x0, mid - 1, x1, mid, Rm[6]); rect(L, x0, mid + 1, x1, mid + 1, Rm[2])
    rect(L, x0 - 1, cor - 3, x1 + 1, cor - 2, Rm[7]); rect(L, x0 - 1, cor - 1, x1 + 1, cor, Rm[2])
    rect(L, x0 - 1, cor + 1, x1 + 1, cor + 1, Rm[1])            # deep shadow under the cornice
    rect(L, x0, cor - 8, x1, cor - 7, Rm[6]); rect(L, x0, cor - 4, x1, cor - 4, Rm[5])
    for xx in range(x0 + 1, x1, 2):                              # balusters
        rect(L, xx, cor - 6, xx, cor - 5, Rm[3])
    for xx in list(range(x0, x1 + 1, 24)) + [x1 - 2]:            # balustrade pedestals with urns
        rect(L, xx, cor - 9, xx + 2, cor - 4, Rm[6]); rect(L, xx + 2, cor - 9, xx + 2, cor - 4, Rm[4])
        px(L, xx + 1, cor - 10, Rm[5])
    # rusticated ground storey: horizontal joints
    for yy in range(mid + 4, base - 2, 3):
        rect(L, x0, yy, x1, yy, Rm[3])
    # windows
    def window(x, top, h, arched, lit):
        rect(L, x - 1, top - 1, x + 4, top + h, Rm[2])              # reveal shadow frame
        c_in = "win3" if lit == 2 else "win2" if lit == 1 else "glass1"
        rect(L, x, top, x + 3, top + h - 1, I[c_in])
        rect(L, x + 1, top, x + 1, top + h - 1, I["win1" if lit else "glass0"])   # mullion
        rect(L, x, top + h // 2, x + 3, top + h // 2, I["win1" if lit else "glass0"])
        if lit == 2:
            px(L, x + 2, top + 1, I["win4"]); px(L, x, top + h - 2, I["win4"])
        if arched:
            px(L, x - 1, top - 1, Rm[5]); px(L, x + 4, top - 1, Rm[5]); rect(L, x, top - 2, x + 3, top - 2, Rm[2])
            rect(L, x + 1, top - 3, x + 2, top - 3, Rm[6])          # keystone
        else:
            rect(L, x - 2, top - 3, x + 5, top - 2, Rm[6]); rect(L, x - 1, top - 2, x + 4, top - 2, Rm[3])  # hood
        rect(L, x - 1, top + h, x + 4, top + h, Rm[6])              # sill
    g = rng("windows")
    bays = [x for x in range(x0 + 6, x1 - 6, 9) if not (pav0 - 2 < x < pav1 - 2)]
    for x in bays:
        lit_u = 2 if g.random() < 0.35 else 1 if g.random() < 0.5 else 0
        lit_l = 2 if g.random() < 0.45 else 1 if g.random() < 0.4 else 0
        window(x, cor + 7, 10, False, lit_u)
        window(x, mid + 6, 13, True, lit_l)
    # pilasters at the wing corners
    for xx in (x0 + 1, x0 + wing - 4, x1 - wing + 1, x1 - 4):
        rect(L, xx, cor + 1, xx + 2, base - 1, Rm[6]); rect(L, xx + 2, cor + 1, xx + 2, base - 1, Rm[3])
    # central pavilion: two-storey portico (paired columns), entablature, attic with segmental pediment
    rect(L, pav0 + 2, cor + 2, pav1 - 2, base - 2, Rm[1])        # deep loggia shadow
    for yy in range(cor + 3, base - 2):
        for xx in range(pav0 + 4, pav1 - 4, 9):
            if yy > mid + 3:
                px(L, xx + 3, yy, I["win2"] if (yy - mid) % 9 < 6 else Rm[0])   # lit doors deep in the loggia
    cols = list(range(pav0 + 3, pav1 - 2, 8))
    for xx in cols:
        rect(L, xx, cor + 3, xx + 2, mid - 1, Rm[6]); rect(L, xx + 2, cor + 3, xx + 2, mid - 1, Rm[3])
        rect(L, xx, mid + 2, xx + 2, base - 3, Rm[6]); rect(L, xx + 2, mid + 2, xx + 2, base - 3, Rm[3])
        rect(L, xx - 1, cor + 2, xx + 3, cor + 2, Rm[7]); rect(L, xx - 1, mid + 1, xx + 3, mid + 1, Rm[7])
    rect(L, pav0, mid - 1, pav1, mid + 1, Rm[6]); rect(L, pav0, mid + 1, pav1, mid + 1, Rm[2])
    rect(L, pav0 - 1, cor - 11, pav1 + 1, cor - 3, Rm[5]); rect(L, pav1 - 2, cor - 11, pav1 + 1, cor - 3, Rm[3])
    rect(L, pav0 + 6, cor - 14, pav1 - 6, cor - 12, Rm[6])
    for xx in range(pav0, pav1 + 1, 3):
        rect(L, xx, cor - 10, xx, cor - 8, Rm[3])
    # cupola: square clock stage, columned drum, dome, lantern, Justice
    # (all cupola rows are relative to the cornice; Justice's head stays below the 62-row runtime header)
    ck = cor - 17
    rect(L, cx - 12, cor - 21, cx + 12, cor - 14, Rm[6]); rect(L, cx + 9, cor - 21, cx + 12, cor - 14, Rm[4])
    rect(L, cx - 13, cor - 22, cx + 13, cor - 22, Rm[7]); rect(L, cx - 13, cor - 21, cx + 13, cor - 21, Rm[3])
    for (dx, dy) in [(a, b) for a in range(-3, 4) for b in range(-3, 4) if a * a + b * b <= 10]:
        px(L, cx + dx, ck + dy, I["mar7"] if a_in(dx, dy) else I["mar2"])
    px(L, cx, ck - 1, I["ink0"]); px(L, cx, ck - 2, I["ink0"]); px(L, cx + 1, ck, I["ink0"])
    d0, d1 = cor - 30, cor - 23                                      # columned drum
    rect(L, cx - 10, d0, cx + 10, d1, Rm[2])
    for xx in range(cx - 10, cx + 11, 4):
        rect(L, xx, d0, xx + 1, d1, Rm[6]); px(L, xx + 1, d0, Rm[4])
    rect(L, cx - 11, d0 - 1, cx + 11, d0 - 1, Rm[7]); rect(L, cx - 11, d1, cx + 11, d1, Rm[5])
    for j, w in enumerate((10, 9, 9, 8, 6, 4)):                       # dome
        y = d0 - 2 - j
        rect(L, cx - w, y, cx + w, y, I["cop2"]); rect(L, cx + w - max(1, w // 3), y, cx + w, y, I["cop1"])
        px(L, cx - w, y, I["cop3"])
    t0 = d0 - 8
    rect(L, cx - 2, t0 - 2, cx + 2, t0, Rm[6]); rect(L, cx + 1, t0 - 2, cx + 2, t0, Rm[4])   # lantern
    rect(L, cx - 1, t0 - 6, cx, t0 - 3, I["gilt2"]); px(L, cx + 1, t0 - 5, I["gilt1"]); px(L, cx - 2, t0 - 5, I["gilt3"])
    # entrance stair (broad, recessed) spilling into the forecourt
    for j in range(5):
        y = base - 1 + j
        w = 30 + j * 4
        rect(L, cx - w, y, cx + w, y, Rm[6] if j % 2 == 0 else Rm[4])
    # flags on the two front corners of the pavilion (US and NYC) -- small, hazed
    for (fx, cols_) in ((pav0 - 4, ("navy1", "fl3", "fl0")), (pav1 + 4, ("navy1", "fl1", "fl3"))):
        rect(L, fx, cor - 26, fx, cor - 3, I["iron2"])
        for j in range(5):
            rect(L, fx + 1, cor - 25 + j, fx + 7, cor - 25 + j, I[cols_[0] if j < 2 and fx < cx else cols_[1 + (j % 2)]])
    # warm sunlit grime / weathering: soft streaks below sills on the links
    g2 = rng("streaks")
    for x in bays:
        if g2.random() < 0.5:
            rect(L, x + 1, cor + 18, x + 1, cor + 21, Rm[3])
    return L


def a_in(dx, dy):
    return dx * dx + dy * dy <= 5


# ============================================================================ forecourt (between City Hall and fence)
FENCE_Y = 168          # curb line of the hero-scale iron fence (park side)


def paint_forecourt():
    L = new()
    cx, base = CH["cx"], CH["base"]
    # plaza paving receding: courses thin toward the building
    yy = base + 4
    h = 2
    rows = []
    while yy < FENCE_Y:
        rows.append((yy, h)); yy += h + 1; h = min(5, h + 1)
    g = rng("fcourt")
    Rp = R("pave")
    plaza = box(196, base + 4, 444, FENCE_Y)
    L[plaza] = Rp[4]
    for (y0, hh) in rows:
        L[box(196, y0 + hh, 444, y0 + hh + 1)] = Rp[3]
        sl = 8 + hh * 2
        off = int(g.integers(0, sl))
        for x in range(196 - off, 444, sl):
            rect(L, x, y0, x, y0 + hh - 1, Rp[3])
            if g.random() < 0.5:
                rect(L, x + 1, y0, x + sl - 2, y0, Rp[5])
    # lawn panels each side of the forecourt, with low clipped shrubs
    lawn(L, box(0, 108, 196, FENCE_Y), "fc-w", base=3)
    lawn(L, box(444, 108, W, FENCE_Y), "fc-e", base=3)
    lawn(L, box(196, base, 444, base + 4) & ~box(cx - 50, base, cx + 50, base + 4), "fc-n", base=3)
    for (x, y, r) in ((206, 158, 5), (230, 160, 4), (410, 160, 4), (434, 158, 5), (176, 156, 6), (464, 156, 6)):
        canopy(L, x, y, r + 2, r, ("shrub", x), ramp="elm", n=6, rmin=2.5, rmax=4.0, top_bias=0.3)
    # clipped hedge running behind the park fence (breaks the long railing; the bars are drawn in front of it)
    for (x0, x1) in ((0, 262), (378, W)):
        hedge = box(x0, 150, x1, FENCE_Y - 1)
        canopy(L, (x0 + x1) / 2, 160, (x1 - x0) / 2 + 6, 9, ("fhedge", x0), ramp="elm", rmin=2.5, rmax=4.5,
               top_bias=0.55, clip=hedge, n=int((x1 - x0) * 1.1))
    # the forecourt's own little lamps (small: distance)
    for x in (cx - 58, cx + 58):
        rect(L, x, base + 2, x, base + 13, I["iron1"]); rect(L, x - 1, base + 1, x + 1, base + 1, I["warm2"])
        px(L, x, base, I["warm3"])
    return L


# ============================================================================ park ground plan (feet plane)
PROM = (36, 170, 604, 199)        # north promenade, x0 y0 x1 y1 (half-open)
AXIS = (296, 170, 344, 360)
CROSS = (36, 236, 604, 277)
FOUNT = (152, 256)                # fountain centre
BASIN = (44, 21)                  # basin rx, ry (outer rim)
FPLAZA = (80, 46)
NE_PATH = ((470, 240), (540, 197))   # survey kiosk -> report terminal diagonal
KIOSK = (560, 166)       # survey entrance (public-works stair to the old City Hall loop level)
KIOSK_GAP = (538, 583)   # fence opening in front of the kiosk (inclusive x range)
KIOSK_APRON = box(KIOSK_GAP[0], 158, KIOSK_GAP[1] + 1, 172)


def ground_masks():
    prom = box(*PROM)
    axis = box(*AXIS)
    cross = box(*CROSS)
    fpl = ell(FOUNT[0], FOUNT[1], *FPLAZA)
    ne = thick_line(NE_PATH[0], NE_PATH[1], 30)
    paved = prom | axis | cross | fpl | ne
    paved &= YY >= PROM[1]
    paved &= (XX >= 36) & (XX < 604)
    exits = box(0, CROSS[1], 36, CROSS[3]) | box(604, CROSS[1], W, CROSS[3]) | box(0, PROM[1], 36, PROM[3]) | \
        box(604, PROM[1], W, PROM[3])
    paved |= exits
    # survey entrance apron: the fence opens into the stair kiosk, so the runtime survey point (558, 166) is a
    # standable foot position, as on the existing city plate
    paved |= KIOSK_APRON
    lawns = (YY >= PROM[3]) & ~paved
    basin = ell(FOUNT[0], FOUNT[1], *BASIN)
    return dict(prom=prom, axis=axis, cross=cross, fpl=fpl, ne=ne, paved=paved, lawns=lawns, basin=basin)


def paint_park_ground(gm):
    L = new()
    # warm sett paving everywhere paved, larger flags on the central axis, ring slabs at the fountain
    hex_pavers(L, gm["paved"], "walks")
    pavers(L, gm["axis"] & gm["paved"], "axis", 6, (9, 11, 12, 14), base=(4, 5, 6), weights=(0.3, 0.45, 0.25),
           oy=170, chips=0.02, crack=0.10)
    ring_pavers(L, gm["fpl"] & ~gm["axis"], "fplaza", *FOUNT)
    # granite curb on every paved/lawn border (2 px) and a soldier course framing the axis
    lawns = gm["lawns"]
    curb = gm["paved"] & dilate(lawns, 1, 1)
    L[curb] = I["gran3"]
    L[curb & shift(lawns, 0, 1)] = I["gran4"]          # curb top lit where lawn lies south (north curb face)
    L[curb & shift(lawns, 0, -1)] = I["gran1"]         # curb shadowed where lawn lies north
    for x in (296, 297, 342, 343):
        col = box(x, 199, x + 1, 360) & gm["paved"] & ~gm["cross"]
        L[col] = I["gran2"] if x in (296, 343) else I["gran4"]
    # lawns
    lawn(L, lawns & (XX < 296), "w", base=4)
    lawn(L, lawns & (XX >= 344), "e", base=4)
    lawn(L, box(0, 0, W, H) & (YY >= 168) & (YY < 170), "rim", base=2)
    return L


# ============================================================================ ground detail: beds, wear, drains, tech
def flower_bed(L, cx, cy, rx, ry, key, palette=("fl0", "fl2", "fl3")):
    g = rng("bed", key)
    m = ell(cx, cy, rx, ry)
    L[m] = I["soil1"]
    canopy(L, cx, cy - 1, rx, ry, ("bedleaf", key), ramp="grass", n=int(rx * ry / 3), rmin=1.8, rmax=3.2,
           top_bias=0.2, clip=m | ell(cx, cy - 1, rx, ry + 1))
    ys, xs = np.nonzero(m)
    for _ in range(int(len(xs) * 0.16)):
        j = int(g.integers(0, len(xs)))
        c = palette[int(g.integers(0, len(palette)))]
        px(L, xs[j], ys[j], I[c]); px(L, xs[j] + 1, ys[j], I[c])
        px(L, xs[j], ys[j] - 1, LIFT1[I[c]])
    L[edge(m) & (YY > cy)] = I["soil0"]


def paint_ground_detail(gm):
    L = new()
    g = rng("wear")
    paved = gm["paved"]
    # worn, polished centre lane on the axis and footfall darkening at junctions
    for (x, y, rx, ry) in ((320, 256, 30, 16), (320, 186, 26, 9), (152, 216, 22, 6), (470, 256, 26, 10)):
        s = np.clip(1 - ((XX - x) / rx) ** 2 - ((YY - y) / ry) ** 2, 0, 1)
        m = paved & (s > CLUSTER * 1.6) & (s > 0)
        L[m] = I["pave6"]
    # stains, lichen, moss in joints near lawns
    near_lawn = paved & dilate(gm["lawns"], 3, 3) & ~dilate(gm["lawns"], 1, 1)
    moss = near_lawn & (g.random((H, W)) < 0.10)
    L[moss] = I["grass2"]
    for _ in range(26):
        x, y = int(g.integers(40, 600)), int(g.integers(172, 316))
        m = ell(x, y, g.uniform(2, 5), g.uniform(1, 2.5)) & paved & (g.random((H, W)) < 0.7)
        L[m] = I["pave2"]
    # drains
    for (x, y) in ((250, 270), (390, 270), (330, 300), (98, 192), (590, 192)):
        rect(L, x - 3, y - 1, x + 3, y + 1, I["iron1"])
        for xx in range(x - 2, x + 3, 2):
            px(L, xx, y, I["iron0"])
    # 2537: teal light inlays -- a dashed line along each side of the axis, two crossing utility lines
    # (repair line teal, storage line amber) meeting at trace 1 (285, 267); the old sign stands there
    for x in (300, 339):
        for y in range(204, 316, 8):
            if not (236 <= y < 278):
                rect(L, x, y, x, y + 3, I["teal3"])
    rep = thick_line((236, 262), (285, 262), 1) | thick_line((285, 262), (285, 274), 1)
    sto = thick_line((250, 270), (296, 270), 1)
    L[rep & paved] = I["teal2"]
    L[sto & paved] = I["warm1"]
    rect(L, 283, 260, 287, 264, I["iron1"]); rect(L, 284, 261, 286, 263, I["teal4"])
    # wayfinding medallion in the crossing (bronze ring with teal core)
    m = ell(320, 256, 9, 5); L[m & ~ell(320, 256, 7, 3.6)] = I["gilt1"]; L[ell(320, 256, 7, 3.6)] = I["pave3"]
    L[ell(320, 256, 3, 1.6)] = I["teal3"]; px(L, 320, 256, I["teal5"])
    for (dx, dy) in ((0, -4), (0, 4), (-8, 0), (8, 0)):
        px(L, 320 + dx, 256 + dy, I["gilt3"])
    # flower beds on lawns (muted, irregular)
    for (x, y, rx, ry, k) in ((250, 216, 22, 8, "b1"), (392, 290, 20, 7, "b2"), (566, 222, 18, 7, "b3"),
                              (62, 290, 14, 6, "b4"), (250, 300, 16, 6, "b5")):
        flower_bed(L, x, y, rx, ry, k, palette=("fl0", "fl2", "fl3") if k in ("b1", "b4") else ("fl4", "fl3", "fl6"))
    # low hoop fences on lawn edges (cast iron hoops): row of arcs just inside each lawn border
    lawns = gm["lawns"]
    rim_n = lawns & shift(gm["paved"], 0, 2) & ~shift(gm["paved"], 0, 1) if False else None
    border = lawns & dilate(gm["paved"], 2, 2) & ~dilate(gm["paved"], 1, 1)
    hoops = border & (((XX // 3) % 2 == 0) | ((YY // 3) % 2 == 0)) if False else border
    L[hoops & ((XX + YY) % 4 == 0)] = I["iron1"]
    L[hoops & ((XX + YY) % 4 == 2)] = I["iron3"]
    return L


# ============================================================================ fountain (restored Mould fountain)
def paint_fountain_basin():
    L = new()
    fx, fy = FOUNT
    rx, ry = BASIN
    outer = ell(fx, fy, rx, ry)
    inner = ell(fx, fy, rx - 4, ry - 3)
    L[outer] = I["gran4"]
    L[outer & (YY > fy)] = I["gran3"]
    L[outer & ~ell(fx, fy, rx - 1, ry - 1) & (YY > fy)] = I["gran1"]        # outer rim face, near side in shade
    L[outer & ~ell(fx, fy - 1, rx - 1, ry - 1) & (YY <= fy)] = I["gran5"]    # far rim top catches light
    L[edge(outer) & (YY >= fy + ry - 3)] = I["ink1"]
    # water: deep centre, lighter rim, inner shadow under the far lip, ripples and sky reflections
    Rw = R("water")
    d = ((XX - fx) / (rx - 4)) ** 2 + ((YY - fy) / (ry - 3)) ** 2
    k = np.clip((3.6 - d * 2.4 + (YY - fy) / (ry - 3) * 0.8).round(), 1, 5).astype(int)
    out = np.array(Rw)[k]
    L[inner] = out[inner]
    lip = inner & ~shift(inner, 0, 2)
    L[lip] = Rw[0]
    g = rng("ripples")
    for _ in range(46):
        x, y = int(g.integers(fx - rx + 6, fx + rx - 6)), int(g.integers(fy - ry + 4, fy + ry - 3))
        if inner[y, x]:
            for j in range(int(g.integers(2, 5))):
                if inner[y, x + j]:
                    L[y, x + j] = Rw[6] if g.random() < 0.3 else Rw[5]
    # teal lights under the water (2537)
    for a in np.linspace(0, 2 * np.pi, 9)[:-1]:
        x, y = int(round(fx + math.cos(a) * (rx - 8))), int(round(fy + math.sin(a) * (ry - 6)))
        rect(L, x - 1, y, x + 1, y, I["teal3"]); px(L, x, y, I["teal5"])
    return L


def paint_fountain_centre():
    """Central pedestal, wide bowl with overflow, jet; Y-sorted at the basin centre."""
    L = new()
    fx, fy = FOUNT
    Rg = R("gran")
    # pedestal
    for j in range(0, 14):
        y = fy + 4 - j
        w = 5 if j < 3 else 3 if j < 10 else 4
        rect(L, fx - w, y, fx + w, y, Rg[4]); rect(L, fx + w - 1, y, fx + w, y, Rg[2]); px(L, fx - w, y, Rg[5])
    # bowl (seen from slightly above): rim ellipse + body
    bowl = ell(fx, fy - 12, 15, 4)
    L[bowl] = I["water4"]
    L[bowl & ~ell(fx, fy - 12, 13, 3)] = Rg[5]
    L[bowl & ~ell(fx, fy - 12, 13, 3) & (YY > fy - 12)] = Rg[3]
    body = ell(fx, fy - 9, 13, 4) & (YY > fy - 11)
    L[body] = Rg[3]
    L[body & (XX > fx + 6)] = Rg[1]
    L[body & (XX < fx - 8)] = Rg[4]
    L[edge(body) & (YY > fy - 9)] = I["ink1"]
    # overflow falls: 2-px sheets breaking into drops
    for x in (fx - 12, fx - 4, fx + 5, fx + 11):
        for y in range(fy - 8, fy + 2):
            if (y - fy) % 3 != 0 or y < fy - 4:
                rect(L, x, y, x + 1, y, I["water5"] if y < fy - 4 else I["water6"])
    # central jet and finial
    rect(L, fx - 1, fy - 26, fx + 1, fy - 15, I["water5"]); rect(L, fx, fy - 30, fx, fy - 15, I["water6"])
    for (dx, dy) in ((-3, -27), (3, -26), (-2, -30), (2, -31), (-5, -22), (5, -21)):
        px(L, fx + dx, fy + dy, I["water6"])
    rect(L, fx - 2, fy - 15, fx + 2, fy - 14, Rg[4])
    return L


def candelabra(L, x, base):
    """Mould-fountain style cast-iron lamp: fluted post, three globes; teal collar (2537)."""
    Ri = R("iron")
    rect(L, x - 2, base - 3, x + 2, base, Ri[2]); rect(L, x + 1, base - 3, x + 2, base, Ri[0])
    rect(L, x - 1, base - 26, x + 1, base - 4, Ri[2]); rect(L, x + 1, base - 26, x + 1, base - 4, Ri[0])
    px(L, x - 1, base - 20, Ri[4]); px(L, x - 1, base - 12, Ri[4])
    rect(L, x - 1, base - 9, x + 1, base - 9, I["teal3"])
    rect(L, x - 5, base - 27, x + 5, base - 27, Ri[2])
    for dx in (-5, 0, 5):
        rect(L, x + dx - 1, base - 31, x + dx + 1, base - 28, I["warm3"])
        px(L, x + dx, base - 32, I["warm4"]); px(L, x + dx + 1, base - 28, I["warm1"])


def lamp_post(L, x, base, tall=46):
    """City Hall Park style lantern on a fluted cast-iron post; warm lantern, small teal collar ring (2537)."""
    Ri = R("iron")
    rect(L, x - 3, base - 4, x + 3, base, Ri[2]); rect(L, x + 2, base - 4, x + 3, base, Ri[0])
    rect(L, x - 3, base - 4, x - 3, base, Ri[4])
    rect(L, x - 2, base - 7, x + 2, base - 5, Ri[3])
    rect(L, x - 1, base - tall + 8, x + 1, base - 8, Ri[2]); rect(L, x + 1, base - tall + 8, x + 1, base - 8, Ri[0])
    px(L, x - 1, base - tall + 14, Ri[4]); px(L, x - 1, base - 20, Ri[4])
    rect(L, x - 2, base - 16, x + 2, base - 15, I["teal3"]); px(L, x - 2, base - 16, I["teal4"])
    t = base - tall
    rect(L, x - 2, t + 6, x + 2, t + 7, Ri[3])
    rect(L, x - 3, t + 1, x + 3, t + 5, I["warm3"]); rect(L, x + 2, t + 1, x + 3, t + 5, I["warm2"])
    rect(L, x - 2, t + 2, x - 1, t + 3, I["warm4"])
    rect(L, x - 4, t, x + 4, t, Ri[2]); rect(L, x - 2, t - 1, x + 2, t - 1, Ri[3]); px(L, x, t - 2, Ri[4])
    for yy in range(t + 1, t + 6):
        px(L, x - 4, yy, Ri[1]); px(L, x + 4, yy, Ri[0])


def bollard(L, x, base):
    Ri = R("iron")
    rect(L, x - 2, base - 9, x + 2, base, Ri[2]); rect(L, x + 1, base - 9, x + 2, base, Ri[0])
    rect(L, x - 2, base - 7, x + 2, base - 6, I["teal3"]); px(L, x - 2, base - 7, I["teal5"])
    rect(L, x - 1, base - 10, x + 1, base - 10, Ri[3])


def banner(L, x, base, flip=False):
    """Navy civic banner on a bracket (as on the science-city lamp posts): gold emblem, teal hem."""
    s = -1 if flip else 1
    y0 = base - 38
    for k in range(1, 9):
        px(L, x + s * k, y0 - 1, I["iron2"])
    a, b = (x + 2, x + 8) if not flip else (x - 8, x - 2)
    rect(L, a, y0, b, y0 + 13, I["navy1"]); rect(L, a, y0, a, y0 + 13, I["navy2"]); rect(L, b, y0, b, y0 + 13, I["navy0"])
    rect(L, a, y0 + 12, b, y0 + 13, I["teal2"])
    px(L, (a + b) // 2, y0 + 4, I["gilt2"]); px(L, (a + b) // 2 - 1, y0 + 5, I["gilt1"]); px(L, (a + b) // 2 + 1, y0 + 5, I["gilt1"])
    px(L, (a + b) // 2, y0 + 6, I["gilt2"]); px(L, (a + b) // 2, y0 + 8, I["gilt3"])
    px(L, a, y0 + 14, I["navy0"]); px(L, b, y0 + 14, I["navy0"]); px(L, (a + b) // 2, y0 + 15, I["navy0"])


def urn(L, x, base):
    """Granite planter urn with spilling flowers."""
    Rg = R("gran")
    rect(L, x - 4, base - 3, x + 4, base, Rg[3]); rect(L, x + 2, base - 3, x + 4, base, Rg[1])
    rect(L, x - 2, base - 6, x + 2, base - 4, Rg[2])
    rect(L, x - 7, base - 11, x + 7, base - 7, Rg[4]); rect(L, x + 4, base - 11, x + 7, base - 7, Rg[2])
    rect(L, x - 7, base - 11, x + 7, base - 11, Rg[5]); rect(L, x - 6, base - 7, x + 6, base - 7, Rg[1])
    canopy(L, x, base - 15, 9, 6, ("urn", x), ramp="grass", n=9, rmin=2.5, rmax=3.6, top_bias=0.4)
    g = rng("urnfl", x)
    for _ in range(9):
        fx_, fy_ = x + int(g.integers(-7, 8)), base - 15 + int(g.integers(-5, 4))
        c = ("fl0", "fl1", "fl2", "fl3")[int(g.integers(0, 4))]
        px(L, fx_, fy_, I[c]); px(L, fx_ + 1, fy_, I[c])


def bench(L, x, base, w=22):
    Rw = R("wood"); Ri = R("iron")
    rect(L, x, base - 10, x + w, base - 9, Rw[3]); rect(L, x, base - 8, x + w, base - 8, Rw[1])
    rect(L, x, base - 6, x + w, base - 5, Rw[2]); rect(L, x, base - 4, x + w, base - 4, Rw[0])
    for xx in (x + 1, x + w - 2):
        rect(L, xx, base - 10, xx + 1, base, Ri[1])


# ============================================================================ street furniture (always behind the actor)
LEDGER = (120, 187)      # allocation ledger board
INSPECT = (378, 181)     # inspection post (trace 2)
REPORT = (470, 247)      # field report interaction point (runtime marker; unchanged)
REPORT_ART_X = 446       # terminal object stands just west of the marker, clear of the NE path


def paint_fence():
    """Hero-scale iron fence on a granite curb along the park's north edge, granite gate piers with lanterns at the
    axis, closed ornamental gates (City Hall stair visible through the bars)."""
    L = new()
    Ri, Rg = R("iron"), R("gran")
    y = FENCE_Y
    rect(L, 0, y - 1, W - 1, y + 1, Rg[4]); rect(L, 0, y + 1, W - 1, y + 1, Rg[2]); rect(L, 0, y - 2, W - 1, y - 2, Rg[5])
    for x in range(0, W, 4):
        rect(L, x, y - 17, x, y - 2, Ri[1])
        px(L, x, y - 18, Ri[3]); px(L, x, y - 19, Ri[2])
    rect(L, 0, y - 15, W - 1, y - 15, Ri[2]); rect(L, 0, y - 5, W - 1, y - 5, Ri[2])
    rect(L, 0, y - 14, W - 1, y - 14, Ri[0])
    # gate piers (rusticated granite) with lanterns, teal scanner slot
    for px0 in (268, 362):
        rect(L, px0, y - 34, px0 + 10, y + 1, Rg[4]); rect(L, px0 + 8, y - 34, px0 + 10, y + 1, Rg[2])
        rect(L, px0, y - 34, px0, y + 1, Rg[5])
        for yy in range(y - 30, y, 5):
            rect(L, px0, yy, px0 + 10, yy, Rg[2])
        rect(L, px0 - 1, y - 37, px0 + 11, y - 35, Rg[5]); rect(L, px0 - 1, y - 35, px0 + 11, y - 35, Rg[3])
        rect(L, px0 + 3, y - 18, px0 + 6, y - 17, I["teal3"]); px(L, px0 + 3, y - 18, I["teal5"])
        lx = px0 + 5
        rect(L, lx - 1, y - 40, lx + 1, y - 38, Ri[2])
        rect(L, lx - 3, y - 47, lx + 3, y - 41, I["warm3"]); rect(L, lx + 2, y - 47, lx + 3, y - 41, I["warm2"])
        rect(L, lx - 2, y - 46, lx - 1, y - 44, I["warm4"])
        rect(L, lx - 4, y - 48, lx + 4, y - 48, Ri[2]); px(L, lx, y - 49, Ri[3])
        for yy in range(y - 47, y - 40):
            px(L, lx - 4, yy, Ri[1]); px(L, lx + 4, yy, Ri[0])
    # closed gate leaves: taller bars, arched top, gilt finials
    for x in range(279, 362, 3):
        top = y - 24 + int(6 * ((x - 320) / 41) ** 2)
        rect(L, x, top, x, y - 2, Ri[1])
        px(L, x, top - 1, I["gilt2"])
    rect(L, 279, y - 9, 361, y - 9, Ri[2]); rect(L, 279, y - 16, 361, y - 16, Ri[2])
    for x in (300, 340):
        e = ell(x, y - 12, 4, 3) & ~ell(x, y - 12, 2.5, 1.6)
        L[e] = I["gilt1"]
    # fence opening into the survey kiosk: no curb, bars or rails; granite end posts frame the gap
    g0, g1 = KIOSK_GAP
    L[box(g0, y - 20, g1 + 1, y + 2)] = -1
    for x in (g0 - 3, g1 + 1):
        rect(L, x, y - 22, x + 2, y + 1, Rg[4]); rect(L, x + 2, y - 22, x + 2, y + 1, Rg[2]); rect(L, x - 1, y - 23, x + 3, y - 23, Rg[5])
    return L


def paint_furniture():
    L = new()
    Ri, Rg = R("iron"), R("gran")
    # survey entrance: public-works stair kiosk (glass and cast iron canopy, teal-lit stair going down)
    kx, ky = KIOSK
    rect(L, kx - 26, ky - 30, kx + 26, ky - 4, Ri[1])
    rect(L, kx - 24, ky - 26, kx + 24, ky - 6, I["glass1"])
    for x in range(kx - 24, kx + 25, 6):
        rect(L, x, ky - 26, x, ky - 6, Ri[2])
    rect(L, kx - 28, ky - 34, kx + 28, ky - 31, I["cop2"]); rect(L, kx - 28, ky - 31, kx + 28, ky - 31, I["cop0"])
    rect(L, kx - 24, ky - 38, kx + 24, ky - 35, I["cop1"]); rect(L, kx - 10, ky - 41, kx + 10, ky - 39, I["cop2"])
    # stair going down into a teal-lit passage: treads darken and shorten with depth, lit nosings, handrails
    rect(L, kx - 12, ky - 22, kx + 12, ky - 4, I["teal0"])
    y, h, k = ky - 5, 4, 0
    for tone, nose in (("gran3", "teal4"), ("gran2", "teal3"), ("tpave0", "teal3"), ("teal1", "teal2"),
                       ("teal0", "teal2"), ("ink2", "teal1")):
        if y - h < ky - 22:
            break
        rect(L, kx - 11 + k, y - h + 1, kx + 11 - k, y, I[tone])
        rect(L, kx - 11 + k, y - h + 1, kx + 11 - k, y - h + 1, I[nose])
        y -= h; h = max(2, h - 1); k += 1
    rect(L, kx - 12, ky - 20, kx - 12, ky - 4, Ri[3]); rect(L, kx + 12, ky - 20, kx + 12, ky - 4, Ri[3])
    rect(L, kx - 4, ky - 30, kx + 4, ky - 27, I["navy1"]); rect(L, kx - 3, ky - 29, kx + 3, ky - 28, I["teal4"])
    # side plinths only: the stair mouth (kx-12..kx+12) opens onto the paved apron
    for (a, b) in ((kx - 26, kx - 13), (kx + 13, kx + 26)):
        rect(L, a, ky - 8, b, ky - 4, Rg[4]); rect(L, a, ky - 4, b, ky - 4, Rg[2])
    rect(L, kx - 12, ky - 4, kx + 12, ky - 4, I["teal4"])                     # lit top step / threshold
    for x in (kx - 26, kx + 25):
        rect(L, x, ky - 30, x + 1, ky - 3, Ri[0])
        rect(L, x, ky - 44, x + 1, ky - 35, Ri[1]); rect(L, x - 1, ky - 48, x + 2, ky - 45, I["warm3"])
    # allocation ledger board (west): framed civic notice board with a teal data strip
    lx, ly = LEDGER
    b = ly - 17                                   # legs stand in the fence line
    rect(L, lx - 14, b - 24, lx + 14, b - 6, Ri[1]); rect(L, lx - 12, b - 22, lx + 12, b - 8, I["pave6"])
    for yy in range(b - 20, b - 9, 3):
        rect(L, lx - 10, yy, lx + rng("ledger", yy).integers(0, 10) - 2, yy, I["pave2"])
    rect(L, lx - 12, b - 9, lx + 12, b - 8, I["teal3"]); px(L, lx + 9, b - 9, I["teal5"])
    rect(L, lx - 15, b - 27, lx + 15, b - 25, I["cop1"])
    for x in (lx - 12, lx + 11):
        rect(L, x, b - 6, x + 1, b, Ri[1])
    # inspection post (trace 2): utility cabinet with a pasted sheet and a stamp mark
    ix, iy = INSPECT
    b = iy - 12
    rect(L, ix - 6, b - 18, ix + 6, b, Ri[2]); rect(L, ix + 4, b - 18, ix + 6, b, Ri[0]); rect(L, ix - 6, b - 18, ix + 6, b - 18, Ri[4])
    rect(L, ix - 4, b - 15, ix + 1, b - 8, I["pave7"]); px(L, ix - 2, b - 11, I["fl0"]); px(L, ix - 1, b - 11, I["fl0"])
    rect(L, ix - 4, b - 6, ix + 3, b - 6, I["teal3"])
    # benches along the north promenade (backs to the fence)
    for x in (60, 150, 196, 404, 452, 486):
        bench(L, x, 170)                              # set into the fence line
    # bins
    for x in (90, 246, 430):
        rect(L, x - 3, 161, x + 3, 170, Ri[2]); rect(L, x + 2, 161, x + 3, 170, Ri[0]); rect(L, x - 4, 160, x + 4, 160, Ri[3])
    return L


# ============================================================================ trees
TREES = {
    # name: trunk x, trunk base y (pivot), trunk h, crown cx, cy, rx, ry, ramp
    "tree-nw": dict(x=196, base=226, h=40, cx=190, cy=170, rx=58, ry=40, ramp="leaf", w=(7, 4)),
    "tree-ne": dict(x=470, base=224, h=36, cx=478, cy=170, rx=52, ry=36, ramp="elm", w=(6, 4)),
    "tree-se": dict(x=540, base=312, h=44, cx=536, cy=246, rx=66, ry=44, ramp="leaf", w=(8, 5)),
    "tree-sw": dict(x=28, base=316, h=42, cx=40, cy=256, rx=56, ry=42, ramp="elm", w=(8, 5)),
}


def paint_tree(name):
    t = TREES[name]
    L = new()
    trunk(L, t["x"], t["base"], t["h"], t["w"][0], t["w"][1], name)
    top = t["base"] - t["h"]
    limb(L, (t["x"], top + 6), (t["x"] - 14, top - 6), 3)
    limb(L, (t["x"], top + 4), (t["x"] + 16, top - 8), 3)
    wood = L >= 0
    cov = canopy(L, t["cx"], t["cy"], t["rx"], t["ry"], name, ramp=t["ramp"])
    # the crown shades the top of the trunk: wood within 6 rows below the crown's lower edge is darkened
    under = np.zeros((H, W), bool)
    for d in range(1, 7):
        under |= shift(cov, 0, d)
    apply_lut(L, wood & ~cov & under, SHADE1)
    return L, cov


def paint_civic_trees():
    """Trees around City Hall behind the fence (no collision; they frame the wings and hide the skyline edges)."""
    L = new()
    specs = [(40, 120, 48, 40, "leaf"), (122, 128, 40, 30, "elm"), (178, 134, 26, 20, "leaf"),
             (596, 118, 50, 42, "elm"), (522, 128, 40, 30, "leaf"), (462, 136, 26, 20, "elm")]
    for (x, y, rx, ry, rp_) in specs:
        trunk(L, x, y + ry - 2, 14, 4, 3, ("civic", x))
        canopy(L, x, y, rx, ry, ("civic", x), ramp=rp_, gain=-0.06)
    return L


# ============================================================================ Y-sorted street items
def paint_ysort_items():
    """Returns {layer_name: (L, pivot)} for street items whose pivot rows group them."""
    out = {}
    fx, fy = FOUNT
    rx, ry = BASIN
    L = new(); candelabra(L, fx - 30, fy - 14); candelabra(L, fx + 30, fy - 14)
    out["fountain-lamps-n"] = (L, fy - 14)
    L = new(); candelabra(L, fx - 30, fy + 16); candelabra(L, fx + 30, fy + 16)
    out["fountain-lamps-s"] = (L, fy + 16)
    out["fountain-centre"] = (paint_fountain_centre(), fy + 4)
    # lamps on the south edge of the cross band and along the axis
    L = new()
    for x in (240, 380, 600):
        lamp_post(L, x, 282)
    bollard(L, 352, 282); bollard(L, 288, 282)
    out["lamps-cross-s"] = (L, 282)
    L = new()
    for x in (240, 400):
        lamp_post(L, x, 232)
        banner(L, x, 232, flip=x > 320)
    bollard(L, 288, 232); bollard(L, 352, 232)
    out["lamps-cross-n"] = (L, 232)
    # planter urns at the head of the axis (on the lawn corners)
    L = new()
    for x in (285, 355):
        urn(L, x, 208)
    out["urns-axis"] = (L, 208)
    # field report terminal: slim civic pylon with a teal screen and a reading ledge
    L = new()
    x, b = REPORT_ART_X, REPORT[1] - 13
    Ri = R("iron")
    rect(L, x - 7, b - 2, x + 7, b, Ri[2]); rect(L, x - 5, b - 30, x + 5, b - 3, Ri[2])
    rect(L, x + 3, b - 30, x + 5, b - 3, Ri[0]); rect(L, x - 5, b - 30, x - 5, b - 3, Ri[4])
    rect(L, x - 4, b - 27, x + 2, b - 14, I["teal1"]); rect(L, x - 3, b - 26, x + 1, b - 15, I["teal2"])
    for yy in range(b - 25, b - 15, 2):
        rect(L, x - 3, yy, x - 3 + (yy * 7) % 4 + 1, yy, I["teal4"])
    rect(L, x - 7, b - 12, x + 7, b - 11, I["cop2"]); rect(L, x - 6, b - 32, x + 6, b - 31, I["cop1"])
    out["report-terminal"] = (L, b)
    # old double-numbered street sign at trace 1 (285, 267): post south of the marker
    L = new()
    sx, sb = 270, 281
    rect(L, sx, sb - 30, sx + 1, sb, Ri[1])
    rect(L, sx - 9, sb - 30, sx + 10, sb - 26, I["navy1"]); rect(L, sx - 8, sb - 29, sx + 9, sb - 27, I["navy2"])
    rect(L, sx - 6, sb - 28, sx - 2, sb - 28, I["fl3"]); rect(L, sx + 2, sb - 28, sx + 7, sb - 28, I["warm2"])
    out["sign-trace"] = (L, sb)
    return out


# ============================================================================ light: cast shadows and glows
def shadow_masks(gm, tree_covs):
    """Cast shadows fall to the right and slightly down (light from the upper left, matching the city plate)."""
    sh = np.zeros((H, W), bool)
    for name, t in TREES.items():
        cov = tree_covs[name]
        # crown shadow: the crown squashed onto the ground plane and pushed right/down, rounded sun flecks
        ys, xs = np.nonzero(cov)
        s = np.zeros((H, W), bool)
        gy = (t["base"] + 4 + (ys - t["base"]) * 0.42).astype(int)
        gx = (xs + 16 + (t["base"] - ys) * 0.18).astype(int)
        ok = (gy >= 0) & (gy < H) & (gx >= 0) & (gx < W)
        s[gy[ok], gx[ok]] = True
        s = dilate(s, 1, 1)
        g = rng("dapple", name)
        for _ in range(14):
            fy_, fx_ = int(g.choice(ys)), int(g.choice(xs))
            s &= ~ell(fx_ + 16, t["base"] + (fy_ - t["base"]) * 0.42 + 4, g.uniform(1.5, 3.5), g.uniform(1.0, 1.8))
        rim = s & ~erode_box(s, -1, 1, -1, 1)
        sh |= s & ~(rim & (CLUSTER < 0.4))
        sh |= ell(t["x"] + 6, t["base"], 12, 4)
    fx, fy = FOUNT
    sh |= ell(fx + 10, fy + 8, BASIN[0], BASIN[1] - 2) & ~ell(fx, fy, *BASIN)
    for (x, b) in ((240, 282), (380, 282), (600, 282), (240, 232), (400, 232), (REPORT_ART_X, REPORT[1] - 13)):
        sh |= thick_line((x + 2, b), (x + 14, b + 3), 2) | ell(x + 2, b + 1, 4, 1.5)
    sh |= box(0, FENCE_Y + 2, W, FENCE_Y + 5) & dither_mask(np.clip((FENCE_Y + 5 - YY) / 3.0, 0, 1))
    return sh


def glow_masks():
    warm = np.zeros((H, W), float)
    teal = np.zeros((H, W), float)
    for (x, y, r) in ((240, 238, 16), (380, 238, 16), (600, 238, 14), (240, 188, 14), (400, 188, 14),
                      (273, 124, 12), (367, 124, 12)):
        d = np.hypot((XX - x) / r, (YY - y) / (r * 0.6))
        warm = np.maximum(warm, np.clip(1 - d, 0, 1))
    for (x, y, r) in ((KIOSK[0], KIOSK[1] + 4, 22), (REPORT_ART_X, REPORT[1] - 6, 14), (320, 256, 16)):
        d = np.hypot((XX - x) / r, (YY - y) / (r * 0.55))
        teal = np.maximum(teal, np.clip(1 - d, 0, 1))
    for x in (300, 339):
        for y in range(204, 316, 8):
            if not (236 <= y < 278):
                d = np.hypot((XX - x) / 4.0, (YY - y - 1.5) / 3.0)
                teal = np.maximum(teal, np.clip(1 - d, 0, 1) * 0.9)
    return falloff(warm, 0.55), falloff(teal, 0.5)


# ============================================================================ actor, walkability
def heroine_48():
    a = np.array(Image.open(_fs(rp(HEROINE_REL))).convert("RGBA"))
    small = a[1::2, 1::2]
    ys, xs = np.nonzero(small[..., 3] > 0)
    spr = small[ys.min():ys.max() + 1, xs.min():xs.max() + 1].copy()
    spr[..., 3] = np.where(spr[..., 3] > 127, 255, 0)
    return spr


def walkable(gm, obstacles):
    """Feet positions (Godot hero.position) where the footprint x in [-6, 6], y in [-2, +4] stays on paving and clear of
    every solid base. Obstacles are object footprints (bases, basin, trunks are on lawns anyway)."""
    free = gm["paved"] & ~obstacles
    free &= (YY >= FENCE_Y + 4) | KIOSK_APRON
    free &= YY <= 310                       # feet stay above the 318 footer (sprite bottom = feet + 4)
    return erode_box(free, -6, 6, -2, 4)


def obstacle_mask(gm):
    ob = gm["basin"] | ell(FOUNT[0], FOUNT[1], BASIN[0] + 1, BASIN[1] + 1)
    for (x, b) in ((240, 282), (380, 282), (600, 282), (240, 232), (400, 232)):
        ob |= box(x - 4, b - 4, x + 5, b + 1)
    for (x, b) in ((352, 282), (288, 282), (288, 232), (352, 232)):
        ob |= box(x - 3, b - 3, x + 4, b + 1)
    ob |= box(REPORT_ART_X - 8, REPORT[1] - 16, REPORT_ART_X + 9, REPORT[1] - 12)
    ob |= box(268, 278, 274, 282)
    # benches and bins against the fence: solid
    for x in (60, 150, 196, 404, 452, 486):
        ob |= box(x - 1, 160, x + 24, 170)
    for x in (90, 246, 430):
        ob |= box(x - 4, 160, x + 5, 170)
    ob |= box(LEDGER[0] - 15, 160, LEDGER[0] + 16, 170)
    ob |= box(KIOSK[0] - 27, 150, KIOSK[0] - 12, 163) | box(KIOSK[0] + 13, 150, KIOSK[0] + 28, 163)   # plinths
    ob |= box(KIOSK_GAP[0] - 4, 150, KIOSK_GAP[0], 170) | box(KIOSK_GAP[1] + 1, 150, KIOSK_GAP[1] + 5, 170)
    ob |= box(INSPECT[0] - 7, 168, INSPECT[0] + 8, 170)
    return ob


def flood(mask, start):
    seen = np.zeros_like(mask)
    if not mask[start[1], start[0]]:
        return seen
    stack = [start]
    seen[start[1], start[0]] = True
    while stack:
        x, y = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and mask[ny, nx] and not seen[ny, nx]:
                seen[ny, nx] = True
                stack.append((nx, ny))
    return seen


# ============================================================================ scene assembly
BASE_LAYERS = ["sky-skyline", "city-hall", "forecourt", "civic-trees", "park-ground", "ground-detail",
               "fountain-basin", "cast-shadows", "light-glow", "north-fence", "furniture"]
HOTSPOTS = {"spawn": (340, 253), "liang_xu": (282, 180), "trace_0": (285, 267), "trace_1": (378, 181),
            "assist": (120, 187), "survey": (558, 166), "report": (470, 247)}
INTERACT_RADIUS = {"liang_xu": 50, "trace_0": 34, "trace_1": 34, "assist": 40, "survey": 43, "report": 50}


def scene():
    gm = ground_masks()
    layers = {}
    layers["sky-skyline"] = paint_sky()
    layers["city-hall"] = paint_city_hall()
    layers["forecourt"] = paint_forecourt()
    layers["civic-trees"] = paint_civic_trees()
    layers["park-ground"] = paint_park_ground(gm)
    layers["ground-detail"] = paint_ground_detail(gm)
    layers["fountain-basin"] = paint_fountain_basin()
    trees, covs = {}, {}
    for n in TREES:
        trees[n], covs[n] = paint_tree(n)
    # shadows and glows act on the merged ground below them (stored as separate editable layers)
    ground = composite_idx(layers, BASE_LAYERS[:7])
    sh = shadow_masks(gm, covs) & (YY >= FENCE_Y - 2)
    cs = new(); cs[sh] = SHADOW[ground[sh]]
    layers["cast-shadows"] = cs
    g2 = ground.copy(); g2[sh] = cs[sh]
    warm, teal = glow_masks()
    gl = new()
    wm = warm & (g2 >= 0) & (YY >= 100); gl[wm] = LIFT1[g2[wm]]
    tm = teal & (g2 >= 0); gl[tm] = TEALIT[g2[tm]]
    layers["light-glow"] = gl
    layers["north-fence"] = paint_fence()
    layers["furniture"] = paint_furniture()
    ys = paint_ysort_items()
    ysort = {}
    for n, (L, pv) in ys.items():
        layers[n] = L; ysort[n] = pv
    for n in TREES:
        layers[n] = trees[n]; ysort[n] = TREES[n]["base"]
    # foreground frame: low hedge at the very bottom (under the footer, peeks above it)
    fg = new()
    hedge = box(0, 312, 296, H) | box(344, 312, W, H)
    canopy(fg, 150, 324, 160, 12, "hedge-w", ramp="elm", rmin=3, rmax=5, top_bias=0.5, clip=hedge)
    canopy(fg, 492, 324, 160, 12, "hedge-e", ramp="elm", rmin=3, rmax=5, top_bias=0.5, clip=hedge)
    layers["fg-frame"] = fg
    ob = obstacle_mask(gm)
    walk = walkable(gm, ob)
    ysort_names = sorted(ysort, key=lambda n: (ysort[n], n))
    order = BASE_LAYERS + ysort_names + ["fg-frame", "guides"]
    layers["guides"] = guides(walk)
    return dict(layers=layers, order=order, ysort=ysort, walk=walk, gm=gm, obstacles=ob, covs=covs)


def composite_idx(layers, names):
    out = new()
    for n in names:
        m = layers[n] >= 0
        out[m] = layers[n][m]
    return out


def guides(walk):
    L = new()
    L[edge(walk)] = I["fl0"]
    for (x, y) in HOTSPOTS.values():
        rect(L, x - 2, y, x + 2, y, I["teal5"]); rect(L, x, y - 2, x, y + 2, I["teal5"])
    L[UI_TOP - 1, :] = I["fl2"]; L[UI_BOTTOM, :] = I["fl2"]
    return L


# ============================================================================ raster output
def to_rgba(idx):
    a = np.zeros((H, W, 4), np.uint8)
    m = idx >= 0
    a[m, :3] = RGB[idx[m]]
    a[m, 3] = 255
    return a


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def decode(png):
    im = Image.open(io.BytesIO(png))
    return np.array(im.convert("RGBA"))


def composite_rgba(rgba, names):
    out = rgba[names[0]].copy()
    for n in names[1:]:
        m = rgba[n][..., 3] == 255
        out[m] = rgba[n][m]
    return out


def paste(dst, spr, x, ybase):
    """Godot hero anchor: sprite bottom row at ybase + 3 (offset -20 on a 48-row frame); x centred."""
    h, w = spr.shape[:2]
    x0, y0 = x - w // 2, ybase + 4 - h
    for j in range(h):
        for i in range(w):
            if spr[j, i, 3] and 0 <= x0 + i < W and 0 <= y0 + j < H:
                dst[y0 + j, x0 + i] = spr[j, i]


def still(rgba, sc, spr, foot):
    out = composite_rgba(rgba, BASE_LAYERS)
    placed = False
    for n in sorted(sc["ysort"], key=lambda n: (sc["ysort"][n], n)):
        if not placed and foot[1] < sc["ysort"][n]:
            paste(out, spr, *foot); placed = True
        m = rgba[n][..., 3] == 255
        out[m] = rgba[n][m]
    if not placed:
        paste(out, spr, *foot)
    m = rgba["fg-frame"][..., 3] == 255
    out[m] = rgba["fg-frame"][m]
    return out


# ============================================================================ containers (reused from the v05 fork)
DT = (2026, 10, 17, 1, 59, 16)


def zput(z, name, payload, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, DT)
    zi.compress_type = method
    z.writestr(zi, payload)


def make_ora(order, rgba, comp_png):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.5" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for n in reversed(order):
        vis = "hidden" if n == "guides" else "visible"
        stack.append(f'<layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.000" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>", ""]
    thumb = Image.open(io.BytesIO(comp_png)).convert("RGBA").resize((256, 144), Image.NEAREST)
    tb = io.BytesIO(); thumb.save(tb, "PNG")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "mimetype", b"image/openraster", zipfile.ZIP_STORED)
        zput(z, "stack.xml", "\n".join(stack).encode())
        for n in order:
            zput(z, f"data/{n}.png", png_bytes(rgba[n]))
        zput(z, "mergedimage.png", comp_png)
        zput(z, "Thumbnails/thumbnail.png", tb.getvalue())
    return buf.getvalue()


def make_pxo(order, rgba, comp_png):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in order]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in order], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(f"{SLUG}_{AREA}_export_{VER}_{STAMP}-{RUN_ID}"),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": 0, "export_profile": export_profile,
            "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json, "license": "", "metadata": {},
            "next_keyframe_id": 0, "palettes": [], "pixelorama_version": "v1.2.3-stable",
            "project_current_palette_name": "", "pxo_version": 7, "reference_images": [], "size_x": W, "size_y": H,
            "symmetry_points": [W - 1.0, H - 1.0], "tags": [], "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0,
            "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "",
            "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "data.json", json.dumps(data, separators=(",", ":")))
        zput(z, "mimetype", "application/x-pixelorama")
        zput(z, "preview.png", comp_png)
        zput(z, "image_data/frames/1/", b"")
        for li, n in enumerate(order, start=1):
            zput(z, f"image_data/frames/1/layer_{li}", np.ascontiguousarray(rgba[n]).tobytes())
            zput(z, f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_gpl():
    lines = ["GIMP Palette", f"Name: {SLUG}_{AREA}_palette_{VER}", "Columns: 8", "#"]
    for n, h in PALETTE:
        r, g, b = (int(h[j:j + 2], 16) for j in (0, 2, 4))
        lines.append(f"{r:3d} {g:3d} {b:3d}\t{n}")
    return ("\n".join(lines) + "\n").encode()


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


# ============================================================================ artefacts
RT_NAMES = {"base": "rt-base", "fg-frame": "rt-fg", "fountain-lamps-n": "rt-y-fount-ln", "fountain-lamps-s":
            "rt-y-fount-ls", "fountain-centre": "rt-y-fount-c", "lamps-cross-s": "rt-y-lamps-s",
            "lamps-cross-n": "rt-y-lamps-n", "report-terminal": "rt-y-report", "sign-trace": "rt-y-sign",
            "urns-axis": "rt-y-urns", "tree-nw": "rt-y-tree-nw", "tree-ne": "rt-y-tree-ne", "tree-se": "rt-y-tree-se", "tree-sw": "rt-y-tree-sw"}
CANOPY_LAYERS = ["tree-nw", "tree-ne", "tree-se", "tree-sw"]


def artefacts(sc):
    order = sc["order"]
    rgba = {n: to_rgba(sc["layers"][n]) for n in order}
    art = [n for n in order if n != "guides"]
    flat = composite_rgba(rgba, art)
    flat_png = png_bytes(flat)
    files = {}
    files["pxo"] = make_pxo(order, rgba, flat_png)
    files["ora"] = make_ora(order, rgba, flat_png)
    files["flat"] = flat_png
    files["gpl"] = make_gpl()
    wm = np.zeros((H, W, 4), np.uint8); wm[sc["walk"]] = 255
    files["walkmask"] = png_bytes(wm)
    files["rt-base"] = png_bytes(composite_rgba(rgba, BASE_LAYERS))
    for n in list(sc["ysort"]) + ["fg-frame"]:
        files[RT_NAMES[n]] = png_bytes(rgba[n])
    nm = names()
    sj = {"run": RUN, "status": "UNAPPROVED candidate; scene art not accepted (science scenes stay 3/12)",
          "canvas": [W, H], "ui_rows": {"header_end": UI_TOP, "footer_start": UI_BOTTOM},
          "base": nm["rt-base"], "fg": nm["rt-fg"], "walkmask": nm["walkmask"],
          "feet_footprint": {"x": [-6, 6], "y": [-2, 4]},
          "ysort": [{"name": n, "png": nm[RT_NAMES[n]], "pivot": int(sc["ysort"][n]), "canopy": n in CANOPY_LAYERS}
                    for n in sorted(sc["ysort"], key=lambda n: (sc["ysort"][n], n))],
          "hotspots": {k: list(v) for k, v in HOTSPOTS.items()},
          "palette_colours": len(PALETTE)}
    files["scene"] = (json.dumps(sj, indent=2) + "\n").encode()
    return rgba, flat, files


def names():
    nm = {"pxo": fname("scene-layers", "pxo"), "ora": fname("scene-layers", "ora"), "flat": fname("flat", "png"),
          "gpl": fname("palette", "gpl"), "walkmask": fname("walkmask", "png"), "scene": fname("scene", "json"),
          "manifest": fname("manifest", "json"), "report": fname("check-report", "json")}
    for v in RT_NAMES.values():
        nm[v] = fname(v, "png")
    return nm


# ============================================================================ checks (static)
def static_checks(sc, rgba, flat):
    v, m = {}, {}
    order = sc["order"]
    walk = sc["walk"]
    v["layers_are_640x360_binary_alpha"] = all(rgba[n].shape == (H, W, 4) and set(np.unique(rgba[n][..., 3])) <=
                                               {0, 255} for n in order)
    v["base_is_opaque"] = bool((composite_rgba(rgba, BASE_LAYERS)[..., 3] == 255).all())
    pal = {tuple(c) for c in RGB.tolist()}
    used = {tuple(c) for c in flat[..., :3].reshape(-1, 3).tolist()}
    v["flat_uses_palette_colours_only"] = used <= pal
    m["palette_colours_used"] = len(used)
    # hotspots: every one reachable from spawn within its interaction radius
    reach = flood(walk, HOTSPOTS["spawn"])
    m["walkable_texels"] = int(walk.sum()); m["reachable_texels"] = int(reach.sum())
    ys, xs = np.nonzero(reach)
    hs = {}
    for k, (x, y) in HOTSPOTS.items():
        if k == "spawn":
            hs[k] = bool(reach[y, x]); continue
        d = np.hypot(xs - x, ys - y)
        hs[k] = round(float(d.min()), 1)
    m["hotspot_nearest_reachable_px"] = hs
    v["spawn_walkable"] = hs["spawn"]
    v["every_hotspot_reachable_within_interaction_radius"] = all(hs[k] < INTERACT_RADIUS[k] - 6 for k in INTERACT_RADIUS)
    v["walk_inside_visible_band"] = bool((~walk[:UI_TOP + 48]).all() and (~walk[UI_BOTTOM:]).all())
    v["no_walkable_feet_in_basin"] = not bool((walk & sc["gm"]["basin"]).any())
    v["no_walkable_feet_on_lawn"] = not bool((walk & sc["gm"]["lawns"]).any())
    # occlusion: an actor standing just north of each Y-sort item's pivot is drawn under it (behind)
    spr = heroine_48()
    m["heroine_height_px"] = int(spr.shape[0])
    v["heroine_48px"] = spr.shape[0] == 48
    behind = {}
    for n in sc["ysort"]:
        pv = sc["ysort"][n]
        a = rgba[n][..., 3] == 255
        cols = np.nonzero(a.any(axis=0))[0]
        best = None
        for y in range(pv - 1, pv - 80, -1):
            for x in cols[::3]:
                if walk[y, x]:
                    body = np.zeros((H, W), bool)
                    body[max(0, y - 44):y + 4, max(0, x - 8):x + 9] = True
                    cover = (a & body).sum()
                    if cover > 6 and (best is None or cover > best[2]):
                        best = (int(x), int(y), int(cover))
            if best:
                break
        behind[n] = best
    m["behind_case_per_ysort_layer"] = behind
    v["trees_have_walkable_behind_case"] = all(behind[n] is not None for n in CANOPY_LAYERS if n in ("tree-se", "tree-nw"))
    m["ysort_pivots"] = {n: int(p) for n, p in sc["ysort"].items()}
    return v, m


def preview(outdir):
    os.makedirs(outdir, exist_ok=True)
    sc = scene()
    rgba, flat, files = artefacts(sc)
    spr = heroine_48()
    Image.fromarray(flat).save(os.path.join(outdir, "flat.png"))
    Image.fromarray(flat).resize((W * 2, H * 2), Image.NEAREST).save(os.path.join(outdir, "flat-2x.png"))
    ui = flat.copy(); ui[:UI_TOP, :, :3] = (13, 23, 35); ui[UI_BOTTOM:, :, :3] = (13, 23, 35)
    for k, foot in (("spawn", (340, 253)), ("behind-se", (522, 266)), ("north", (300, 186)), ("fount", (190, 226))):
        s = still(rgba, sc, spr, foot)
        s[:UI_TOP, :, :3] = (13, 23, 35); s[UI_BOTTOM:, :, :3] = (13, 23, 35)
        Image.fromarray(s).save(os.path.join(outdir, f"still-{k}.png"))
    g = composite_rgba(rgba, [n for n in sc["order"]])
    Image.fromarray(g).save(os.path.join(outdir, "guides.png"))
    rt = os.path.join(outdir, "rt")                    # runtime files for `--chp-dir=` Godot dev runs
    os.makedirs(rt, exist_ok=True)
    nm = names()
    for k, b in files.items():
        with open(_fs(os.path.join(rt, nm[k])), "wb") as f:
            f.write(b)
    v, m = static_checks(sc, rgba, flat)
    print(json.dumps({"verdicts": v, "metrics": m}, indent=1, default=str))


def manifest(files, nm):
    return {
        "run": RUN, "status": "UNAPPROVED candidate (scene environment not accepted; science scenes stay 3/12)",
        "author": "Claude Code (Opus 5.5) on the signed-in claude.ai Max subscription; no API key, no image model",
        "tool": "tools/" + os.path.basename(os.path.abspath(__file__)),
        "supersedes_unrun_tool": "tools/rpg-2-star-ocean-the-second_nyc-city-hall-park_walkable-pilot-640x360_"
                                 "pixelorama-build_unapproved-v05_20261016-220852-74330a19.py (never run, untouched)",
        "canvas": [W, H], "runtime_ui_rows": [UI_TOP, UI_BOTTOM],
        "layers_bottom_to_top": scene_order_cache[0],
        "hotspots_unchanged_from_runtime": {k: list(v) for k, v in HOTSPOTS.items()},
        "files": {k: {"name": nm[k], "sha256": sha_text(b) if k in ("gpl", "scene") else sha(b),
                      "hash": "sha256-text-lf-v1" if k in ("gpl", "scene") else "sha256-bytes"}
                  for k, b in sorted(files.items())},
        "reference_use": "Palette value/hue guide: 28-colour summaries of the science-city plate and the Room 1 "
                         "capture; landmark cues from the NYC DCAS City Hall description and NYC Parks history. "
                         "No pixels copied, traced or sampled from any image.",
    }


scene_order_cache = [None]


def build():
    sc = scene()
    scene_order_cache[0] = sc["order"]
    rgba, flat, files = artefacts(sc)
    nm = names()
    cand = rp(CAND_REL)
    os.makedirs(_fs(cand), exist_ok=True)
    longest = 0
    for k, b in files.items():
        p = os.path.join(cand, nm[k])
        longest = max(longest, len(os.path.abspath(p)) + len(".import"))
        print(write_new(p, b), nm[k])
    mb = (json.dumps(manifest(files, nm), indent=2) + "\n").encode()
    print(write_new(os.path.join(cand, nm["manifest"]), mb), nm["manifest"])
    print("longest path incl. .import:", longest)


def run_pixelorama(exe, args, fake_appdata):
    env = dict(os.environ)
    env["APPDATA"] = fake_appdata
    t0 = time.time()
    p = subprocess.run([exe, "--headless", "--quit", "--"] + args, env=env, capture_output=True, timeout=180)
    return {"rc": p.returncode, "seconds": round(time.time() - t0, 2)}


def snapshot(root):
    out = {}
    if os.path.isdir(root):
        for dp, _, fs in os.walk(root):
            for f in fs:
                q = os.path.join(dp, f)
                try:
                    out[os.path.relpath(q, root)] = os.path.getmtime(q)
                except OSError:
                    pass
    return out


def pixelorama_gate(exe, files, rgba, flat, order):
    real = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    before = snapshot(real)
    tmp = tempfile.mkdtemp(prefix="wb-chp5-")
    rep = {"pixelorama_sha256": sha(read_bytes(exe)), "steps": {}}
    try:
        for k in ("pxo", "ora"):
            src = os.path.join(tmp, f"src.{k}")
            with open(src, "wb") as f:
                f.write(files[k])
            for split in (False, True):
                label = f"{k}_{'split' if split else 'flat'}"
                d = os.path.join(tmp, label); os.makedirs(d)
                fake = os.path.join(tmp, "appdata_" + label); os.makedirs(fake)
                r = run_pixelorama(exe, ["--export"] + (["--split-layers"] if split else []) +
                                   ["-o", os.path.join(d, "f.png"), src], fake)
                pngs = sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))
                r["pngs"] = len(pngs)
                r["source_unchanged"] = read_bytes(src) == files[k]
                if not split:
                    a = decode(read_bytes(os.path.join(d, pngs[0]))) if pngs else None
                    r["flat_exact"] = a is not None and a.shape == flat.shape and bool((a == flat).all())
                else:
                    hits = set()
                    for f in pngs:
                        a = decode(read_bytes(os.path.join(d, f)))
                        hits |= {n for n in order if a.tobytes() == rgba[n].tobytes()}
                    r["art_layers_exact"] = all(n in hits for n in order if n != "guides")
                    r["guides_exported"] = "guides" in hits
                rep["steps"][label] = r
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    after = snapshot(real)
    changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k) and
                     not k.endswith(".running"))
    rep["real_appdata_changed_except_running"] = changed
    st = rep["steps"]
    rep["verdicts"] = {
        "pixelorama_pxo_flat_exact": st["pxo_flat"].get("flat_exact", False),
        "pixelorama_ora_flat_exact": st["ora_flat"].get("flat_exact", False),
        "pixelorama_pxo_split_layers_exact": st["pxo_split"].get("art_layers_exact", False),
        "pixelorama_ora_split_layers_exact": st["ora_split"].get("art_layers_exact", False),
        "pixelorama_hidden_guides_not_exported": not st["pxo_split"].get("guides_exported", True) and
                                                 not st["ora_split"].get("guides_exported", True),
        "pixelorama_sources_unchanged": all(v["source_unchanged"] for v in st.values()),
        "pixelorama_real_appdata_untouched": not changed,
    }
    return rep


def check(exe, write_report, use_pixelorama):
    sc = scene()
    scene_order_cache[0] = sc["order"]
    rgba, flat, files = artefacts(sc)
    nm = names()
    cand = rp(CAND_REL)
    rep = {"run": RUN, "gates": {}, "metrics": {}}
    on_disk = {}
    for k, b in files.items():
        disk = read_bytes(os.path.join(cand, nm[k]))
        on_disk[k] = (sha_text(disk) == sha_text(b)) if k in ("gpl", "scene") else (disk == b)
    rep["gates"]["candidate_files_equal_fresh_rebuild"] = all(on_disk.values())
    rep["gates"]["build_deterministic"] = artefacts(scene())[2] == files
    v, m = static_checks(sc, rgba, flat)
    rep["gates"].update(v); rep["metrics"].update(m)
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        dj = json.loads(z.read("data.json"))
    rep["gates"]["pxo_lists_named_layers_guides_hidden"] = [l["name"] for l in dj["layers"]] == sc["order"] and \
        [l["visible"] for l in dj["layers"]] == [n != "guides" for n in sc["order"]]
    rep["metrics"]["layer_count"] = len(sc["order"])
    if use_pixelorama:
        rep["pixelorama"] = pixelorama_gate(exe, files, rgba, flat, sc["order"])
        rep["gates"].update(rep["pixelorama"]["verdicts"])
    rep["result"] = "PASS" if all(rep["gates"].values()) else "FAIL"
    rep["note"] = "Technical gates only; passing them is not art acceptance."
    print(json.dumps({"result": rep["result"], "gates": rep["gates"]}, indent=1))
    if write_report:
        out = rp(OUT_REL)
        os.makedirs(_fs(out), exist_ok=True)
        print(write_new(os.path.join(out, nm["report"]), (json.dumps(rep, indent=2, default=str) + "\n").encode()))
    return 0 if rep["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("dir", nargs="?")
    ap.add_argument("--write-report", action="store_true")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    a = ap.parse_args()
    if a.mode == "preview":
        if not a.dir or os.path.abspath(a.dir).startswith(REPO):
            raise SystemExit("preview needs a directory outside the repo")
        preview(a.dir)
    elif a.mode == "build":
        build()
    else:
        sys.exit(check(a.pixelorama, a.write_report, not a.no_pixelorama))


if __name__ == "__main__":
    main()
