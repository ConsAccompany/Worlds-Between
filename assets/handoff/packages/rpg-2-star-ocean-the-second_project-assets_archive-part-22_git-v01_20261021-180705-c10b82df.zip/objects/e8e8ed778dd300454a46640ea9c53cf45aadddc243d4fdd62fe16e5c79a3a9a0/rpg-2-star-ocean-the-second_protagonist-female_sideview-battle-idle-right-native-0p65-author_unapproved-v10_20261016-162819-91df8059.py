"""UNAPPROVED, test-only pilot v10: female protagonist side-view battle idle, facing right, ONE static frame.

Static-frame pose pass over v09 (no motion, no batch, no runtime swap). Same cell (68x72), same pin (32, 68), same sole
row 67, same crown row 7, same 18 layer names + guides and the same 30-key palette, so the owner-approved 0.65 battle
display proportion (crown-to-sole 61 logical px at node scale 1.0) and the foot baseline are unchanged. v09's files are
read (hash-gated) and never written.

Targets what Codex saw in the real v09 1280x720 / 640x360 ruins party captures:
  upright, stiff torso          -> ready lean: hips stay where they were, the back leans forward one texel every ~4 rows
                                   (coat back edge x24 at the belt -> x28 at the shoulder), head, collar and scarf move
                                   4 texels toward the enemy; the sword arm reaches forward (elbow in front of the chest,
                                   fist 6 texels further forward than v09), so the raised blade sits clear of the face
  teal coil reads as a knob     -> a 9x9 end-on blanket roll (v09: 7x7) with a lit outer ring, a two-turn dark spiral
                                   and a lit core, sitting on the pack's top edge; >= 2 transparent columns to the coat
                                   on every roll row, and nowhere near the hip cloth or the scarf
  hip drape dominates the coat  -> the teal drape now hangs BEHIND the coat skirt (layer moved under the coat): the deep
  back / reads as a skirt          slate coat tail is fully visible again, and only a narrow shadowed teal tail (q body,
                                   g rim, Q fold, split end) shows behind and below it
  boots / far leg merge with    -> values picked against the measured floors (paving L ~80-95 above row 62, contact
  the floor at 640                 shadow L ~45-58 on rows 62-67), no mid value left over the paving: the far trouser is
                                   all v8 trouser deep (C), the near shin drops its lit spruce edge (t), both boot shafts
                                   are dark leather (L) carrying a pale strap (P near, p far) under a lit turned-down
                                   cuff (B, L 134); the feet in the shadow stay mid leather (b) with a lit (B) instep

Hand-authored pixel art: each layer is an ASCII block typed below ('.' = transparent). The blade is placed by a 1:1
pixel-line helper (the texels a line tool lays). No resampling, filtering, gradients, dithering, quantizing, image
generation or upscaling. Binary alpha. Fixed palette (<= 32 colours).

Editable source: a layered Pixelorama .pxo (pxo_version 7) and an .ora with the same layers plus a hidden, locked
'guides' layer. The candidate PNG is the Pixelorama 1.2.3 headless flat export of the .pxo (byte-compared to this
tool's render); Pixelorama runs with APPDATA redirected to a fresh temp dir so the real config is never touched.

Modes
  preview <dir> [nosprite.png ...]
                  inspection PNGs in <dir> (outside the repo), one subject per file; with no-sprite captures (1280x720
                  or 640x360), also the exact game-scale composite (texture origin 536,408 at 2x / 268,204 at 1x)
  build           export via Pixelorama, write PNG + .pxo + .ora + manifest (never overwrites a different file)
  check           technical gates on the built files incl. Pixelorama flat + split-layer round-trips, palette and layer
                  names vs v09, silhouette report vs v09, lean / roll / drape / boot gates, layer-stack recomposition
                  of the .pxo and .ora; writes nothing

Run with the real Python in isolated mode:  python -I -B <this file> preview <dir> | build | check
"""
import argparse, hashlib, io, json, os, shutil, subprocess, sys, tempfile, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
VER = "unapproved-v10"
STAMP = "20261016-162819"
RUN_ID = "91df8059"
W, H = 68, 72
PIN = (32, 68)            # same as v03-v09: first transparent row under the soles, between the feet
CROWN_ROW = 7             # same as v03-v09: head crown row; soles end on row 67 -> crown-to-sole 61 rows
SOLE_ROW = 67
HEAD_COLS = (24, 47)      # crown columns are searched here (the head moved 4 texels right of v09's 24-41)
OUT_DIR_REL = "game/assets/characters/combat-sideview-pilots"
_V09 = "rpg-2-star-ocean-the-second_protagonist-female_sideview-idle-right-static-native0p65_"
V09_LOCKS = {             # v09 (committed in 30cb82e) is read-only for this tool: checked before and after every build/check
    OUT_DIR_REL + "/" + _V09 + "unapproved-v09_20261016-135202-07e7f74a.png":
        "7e9d7ef257f72f0105cb2b16facb4cd1416cb5eecc594eb10bee55bc3a55dfed",
    OUT_DIR_REL + "/" + _V09 + "editable-layers_unapproved-v09_20261016-135202-34faf685.pxo":
        "ef5adb2ac6233cd423b2d047f7eb825095e5c8d25c5e7cbf1cd3b4b054c59fb4",
    OUT_DIR_REL + "/" + _V09 + "editable-layers_unapproved-v09_20261016-135202-51c824c2.ora":
        "1940e7cb25a28b235abdaff8f24fd12cccbbf391365db32e129368de42cc20eb",
    OUT_DIR_REL + "/" + _V09 + "manifest_unapproved-v09_20261016-135202-0bea0fc8.json":
        "2505eead75fe4cd96f0354d08bdee1822bbea3e0659388e5cf14af854fe63e88",
}
V09_PNG_REL, V09_PXO_REL, V09_ORA_REL, V09_MANIFEST_REL = list(V09_LOCKS)
V8_SOUTH_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
                "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
PIXELORAMA_REL = "work/tooling/pixelorama-1-2-3/Pixelorama-Windows-64bit/Pixelorama.exe"
PIXELORAMA_VERSION = "v1.2.3-stable"
GUIDE_RGB = (255, 0, 255)
CAPTURE_ORIGIN = {1280: (536, 408), 640: (268, 204)}   # screen px of texel (0, 0): hero x 300, floor 272, k = W / 640
BOOT_CONTACT_ROWS = (62, 65)                           # rows standing in the arena's contact shadow (floor L ~45-58)
LEAN_ROWS = (24, 37)                                   # coat back edge is measured on these rows (shoulder, waist)


def fid(role):
    return hashlib.sha256(f"{RUN_ID}:{role}".encode()).hexdigest()[:8]


SUBJECT = "protagonist-female_sideview-idle-right-static-native0p65"
PNG_NAME = f"{SLUG}_{SUBJECT}_{VER}_{STAMP}-{fid('png')}.png"
PXO_NAME = f"{SLUG}_{SUBJECT}_editable-layers_{VER}_{STAMP}-{fid('pxo')}.pxo"
ORA_NAME = f"{SLUG}_{SUBJECT}_editable-layers_{VER}_{STAMP}-{fid('ora')}.ora"
MANIFEST_NAME = f"{SLUG}_{SUBJECT}_manifest_{VER}_{STAMP}-{fid('manifest')}.json"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))

PALETTE = {               # identical to v08/v09 (no new colour)
    "K": "#16141a",                                                                  # outline
    "1": "#231816", "2": "#3d2a22", "3": "#5c3e2c", "4": "#82593b", "h": "#a8794f",  # hair dark -> sheen
    "S": "#fbd5b0", "s": "#e7a67c", "x": "#b36f50", "E": "#1d1214",                  # skin light/mid/shadow, eye/brow
    "C": "#222839", "c": "#3a4560", "o": "#5e6e8c",                                  # v8 storm-slate coat C3/C2/C1
    "T": "#324542", "t": "#4a625c",                                                  # v8 spruce trousers T2/T1
    "W": "#f3ead9", "w": "#c6b59d",                                                  # shirt / shadowed white
    "P": "#d7c0a8", "p": "#b09986",                                                  # v8 pale beige: cuff, buckle, strap
    "L": "#2e1c14", "l": "#533626", "b": "#845436", "B": "#bb7c50",                  # leather (v8 warm ramp)
    "Q": "#0a323b", "q": "#1a767b", "g": "#249b98", "G": "#6cc9bc",                  # teal (v8 scarf + one light)
    "m": "#5a6470", "M": "#a9b5bd", "Z": "#eef4f5",                                  # steel
}

LAYERS = []


def block(name, x0, y0, text):
    """One layer from an ASCII block: row i of text is canvas row y0+i, column j is canvas x0+j."""
    rows = [r for r in text.strip("\n").split("\n")]
    LAYERS.append((name, [(x0 + j, y0 + i, ch) for i, r in enumerate(rows) for j, ch in enumerate(r.strip())
                          if ch != "."]))


def block_px(name, texels):
    LAYERS.append((name, list(texels)))


# ===================================================================================================== layers
# bottom -> top.  Column rulers in comments are absolute canvas x.

# far (back) leg braced back onto the ball of the foot (v09 shape). Trouser: all v8 trouser deep (C, v09's spruce T
# front edge sat within 20 L of the paving), ~45 L under it. Boot, re-valued for v10: a lit turned-down cuff (B) and a
# dark shaft (L) with a darker pale-beige strap (p) over the paving, mid-leather foot (b) with a lit (B) instep edge in
# the contact shadow; heel back and sole band stay L
#                x16       x26       x36
block("far-leg", 16, 42, """
...........KCCCCK.
...........KCCCCK.
..........KCCCCK..
..........KCCCCK..
.........KCCCCK...
.........KCCCCK...
........KCCCCK....
........KCCCCK....
.......KCCCCK.....
.......KCCCK......
.......KCCCK......
......KCCCK.......
......KCCCK.......
......KCCCK.......
.....KCCCK........
.....KCCCK........
....KKKKKKK.......
....KBBBBBK.......
...KLLLLLlK.......
...KLLppLLlK......
..KLbbbbbbbBK.....
..KLbbbbbbbbBK....
.KLLbbbbbbbbbBK...
.KKLLbbbbbbbbbBK..
...KKLLLLLLLLLLLK.
.....KKKKKKKKKKKK.
""")

# v8's teal back-hip cloth, now hung BEHIND the coat skirt (it is drawn under coat + coat-skirt): only a one-texel mid
# rim (g) shows along the slate coat tail's back edge, then a narrow tail below the hem. Shadowed body (q) because it
# sits behind the coat, one dark fold (Q) that opens into a split end. It stays left of the far leg's back edge.
#                   x15       x25
block("hip-drape", 15, 41, """
.....KgqqK.
.....KgqqK.
....KgqqqK.
....KgqqQK.
...KgqqQqK.
...KgqQqqK.
...KgqQqqK.
..KgqqQqK..
..KgqQqqK..
..KgqQqK...
.KgqqQqK...
.KgqQqqK...
KgqqQqK....
KgqQKqK....
KgqK.KqK...
KqK..KK....
.K.........
""")

# tan leather pack on the upper back (v09 drawing), moved 2 texels forward with the leaning back; the coat draws over
# its right edge
block("pack", 18, 28, """
KKKKKKKKK
KBBBBBBBK
KBBBBBBbK
KbbbbbbbK
KBBBPBBbK
KBBBpBBbK
KBBBBBBbK
KbBBBBbbK
KlbbbbblK
.KKKKKKK.
""")

# teal blanket roll strapped along the pack's top edge: a 10x7 cylinder, lit top (G), body (g), shadowed underside (q),
# its rear end cap showing the rolled layers (dark Q spiral round a mid core), one leather strap (lit B over L) round
# its middle. It ends at x24; the coat/collar on these rows start at x27-28, so >= 2 columns of floor show between them.
#               x15      x24
block("bedroll", 15, 22, """
..KKKKKKK.
.KgQgGGBGK
KQgQQggBgK
KQQgQggBgK
KqQqQqqLqK
.KqqQqqLK.
..KKKKKK..
""")

# single tapering ponytail (v07 drawing) moved with the head, its tail closed one row earlier so it ends above the roll
block("ponytail", 18, 1, """
..........KK...
........KK4K...
......KK344hK..
.....K23344hhK.
....K123344h4K.
...K1223344334K
..K1223344433K.
..K12223343KK..
.K1122233K.....
.K112223K......
.K11223K.......
.K11223K.......
.K1122K........
.K1122K........
..K112K........
..K112K........
..K11K.........
...K11K........
....KK.........
""")

# near (front) leg: thigh forward to a bent knee over the instep (knee pad), shin down to a flat boot. Spruce body (T),
# lit front edge (t) on the thigh only (the shin's t sat on the paving's value), deep slate back edge (C). Boot as the far
# one but with the light pale strap (P): lit cuff and dark shaft over the paving, mid-leather foot in the contact shadow,
# lit instep and toe edge
#                x32       x42
block("near-leg", 32, 41, """
.KCTTtK...........
.KCTTtK...........
..KCTTtK..........
..KCTTttK.........
...KCTTtK.........
...KCTTttK........
....KCTTtK........
....KCTTttK.......
.....KCTTtK.......
.....KCTTttK......
......KLLlbBK.....
......KLLlbBK.....
.......KLlbBK.....
.......KCTTTK.....
.......KCTTTK.....
.......KCTTTK.....
.......KCTTTK.....
......KKKKKKKK....
......KBBBBBBK....
......KLLLLLLK....
......KLLPPLlK....
......KlbbbbBBK...
......KlbbbbbBBK..
......KlbbbbbbbBK.
......KLlbbbbbbBK.
......KLLLLLLLLLK.
.......KKKKKKKKKK.
""")

# coat torso + belt, leaning: the deep back half (C), a thin mid band (c) and the lit front plane (o) step one texel
# toward the enemy about every four rows (back edge x24 at the waist -> x28 at the shoulder); belt top row lit (B)
#                x24       x34
block("coat", 24, 22, """
.......KKKKK.....
.....KKCcoooK....
....KCCCcoooo....
....KCCCCcoooo...
...KCCCCCcoooo...
...KCCCCCcooooo..
...KCCCCCCcooooo.
...KCCCCCCcoooooo
..KCCCCCCcoooooo.
..KCCCCCCcoooooo.
..KCCCCCCcoooooo.
..KCCCCCCcoooooo.
.KCCCCCCcoooooo..
.KCCCCCCcooooooo.
.KCCCCCCcooooooo.
KCCCCCCcooooooo..
KBBBBBBBBBBBBBBB.
KLLLLLLLLLLLLLLL.
""")

# coat skirt (v09 drawing, hips unchanged): deep back tail (C) over the far thigh, one-texel mid band (c), lit front
# panel (o) over the near thigh, lit leather hem trim (B); with the drape behind it the whole slate tail reads again
#                  x17       x27       x37
block("coat-skirt", 17, 40, """
......KCCCCCCcoooooooooooK.
.....KCCCCCCcoCoooooooooooK
.....KCCCCCCcoCKooooooooooK
....KCCCCCCcoCCKoooooooooBK
....KCCCCCCcoCCKooooooooBK.
...KCCCCCCcoCCCKoooooBBBK..
...KCCCCCCcoCCK.KBBBBKKK...
...KCCCCCcoCCK...KKKK......
..KCCCCCCcoBK..............
..KCCCCCcBBK...............
..KCCCcBBK.................
.KCCBBBK...................
.KBBKK.....................
.KKK.......................
""")

# open coat front over the white shirt, lit lapel edge; the chest leans forward with the coat (front x43 at the chest,
# x39 at the belt)
#                    x35
block("shirt-lapel", 35, 23, """
.ooKWWK
.oooKWWK
..ooKWWWK
.ooKwWWWK
..oKwWWWK
..oKwWWWK
..oKwWWWK
..KwWWWK
..KwWWWK
..KwWWWK
..KwWWK
.KwWWK
.KwWWK
.KwWWK
KwWWK
""")

# near arm reaching forward: lit slate sleeve top over a deep underside, the upper arm angles forward from the shoulder
# so the elbow sits in front of the chest, forearm level to the fist (top o, mid c, underside C), pale-beige cuff
#                 x28       x38
block("near-arm", 28, 23, """
...KKKKK........
..KooooooK......
..KCoooooK......
...KCoooooK.....
...KCCooooK.....
....KCCooooK....
....KCCooooKKKKK
....KCCooooooPPK
.....KCCcccccPpK
......KCCCCCCppK
.......KKKKKKKKK
""")


# ordinary short sword raised forward at 45 degrees (v09 blade, carried 6 texels forward with the fist): each row is
# outline, edge light (Z), steel (M), outline, one texel further forward per row up; short tapered tip
def blade_segments(y0=26, y1=18):
    segs = []
    for y in range(y1, y0 + 1):
        x = 76 - y                       # edge-light column on row y
        segs += [(x - 1, y, "K"), (x, y, "Z"), (x + 1, y, "M"), (x + 2, y, "K")]
    x = 76 - (y1 - 1)
    segs += [(x - 1, y1 - 1, "K"), (x, y1 - 1, "Z"), (x + 1, y1 - 1, "K"), (x, y1 - 2, "K")]
    return segs


block_px("sword-blade", blade_segments())

# small steel crossguard square to the blade, at the top-front of the fist
block("sword-guard", 47, 25, """
KK...
KMK..
.KMK.
..KMK
...KK
""")

# light tan glove closed round the grip, held forward at chest height; leather grip end under the little finger
block("fist", 43, 27, """
.KKKK..
KBBBBK.
KBBBbbK
KbBbbbK
KbbbblK
.KLKKK.
..K....
""")

# head: v05 drawing, carried 4 texels forward with the lean
block("head", 28, 7, """
.....KKKKKKK.......
...KK2334hh43KK....
..K22334hh4433KK...
.K1223344h44333K...
.K12233443443333K..
.K1223343321SSS3K..
.K122332232SSSEESK.
.K1223222sSSSSESSK.
.K1122221xssSSESSSK
.K1122211ssSSSSSSK.
.K1122111sSSSSSxSK.
.K112111KxssSSSSK..
..K1111K.KxssKKK...
""")

# leather hair tie knotted on the crown-back, where the ponytail leaves the head
block("hair-tie", 28, 7, """
.KK.
KbBK
KLbK
.KK.
""")

# raised coat collar standing behind the nape (v06 drawing, moved with the head)
block("collar", 28, 16, """
.KK..
KooK.
KoooK
KoooK
KCooK
KCcoK
""")

# scarf at the neck: thick wrap, knot and short front tail (v05 drawing, moved with the head)
block("scarf-neck", 29, 20, """
.KqggGGggggGgK.
KQqqgggqqggGGgK
KQQqqqqQqqggGgK
KQQQqqQQqqggqK.
.KKKKKKKQqgGqK.
........KqgGK..
........KQqgK..
.........KqK...
..........K....
""")

# front half of the raised collar over the scarf's front edge (v07 drawing, moved with the head)
block("collar-front", 42, 20, """
.KK.
KooK
KooK
KcoK
KcoK
.KK.
""")

LAYER_NAMES = [n for n, _ in LAYERS] + ["guides"]
TEAL_KEYS = "QqgG"


# ===================================================================================================== raster
def hex_rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def guides_rgba(comp):
    g = np.zeros((H, W, 4), np.uint8)
    pts = set()
    pts.update((x, 0) for x in range(W)); pts.update((x, H - 1) for x in range(W))
    pts.update((0, y) for y in range(H)); pts.update((W - 1, y) for y in range(H))
    for y in (CROWN_ROW, SOLE_ROW):
        pts.update((x, y) for x in list(range(1, 4)) + list(range(W - 4, W - 1)))
    pts.add(PIN)
    for x, y in pts:
        g[y, x, :3] = GUIDE_RGB
        g[y, x, 3] = 255
    if (comp[..., 3][g[..., 3] > 0] != 0).any():
        raise SystemExit("a guide texel overlaps an opaque art texel")
    return g


def render():
    """Returns ({layer name: RGBA}, composite RGBA). Alpha is binary, so 'over' is a plain copy."""
    blobs = {}
    comp = np.zeros((H, W, 4), np.uint8)
    for name, texels in LAYERS:
        a = np.zeros((H, W, 4), np.uint8)
        for x, y, ch in texels:
            if ch not in PALETTE:
                raise SystemExit(f"{name}: unknown key {ch!r} at x{x} y{y}")
            if not (0 <= x < W and 0 <= y < H):
                raise SystemExit(f"{name}: texel ({x},{y}) outside the {W}x{H} cell")
            a[y, x, :3] = hex_rgb(PALETTE[ch])
            a[y, x, 3] = 255
        blobs[name] = a
        m = a[..., 3] == 255
        comp[m] = a[m]
    blobs["guides"] = guides_rgba(comp)
    return blobs, comp


def png_bytes(rgba):
    buf = io.BytesIO()
    Image.fromarray(rgba, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


# ===================================================================================================== paths / hashes
WIN_MAX_PATH = 259
WIN_LONG_PREFIX = "\\\\?\\"


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > WIN_MAX_PATH - 12 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def repo_path(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(path):
    with open(_fs(path), "rb") as f:
        return f.read()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def lock_hash(rel):
    """sha256-bytes for binaries; sha256-text-lf-v1 (CRLF -> LF) for the .json lock, so a core.autocrlf=true clone of
    the LF blob still matches. The committed v09 manifest is LF, so both algorithms give the same locked value."""
    data = read_bytes(repo_path(rel))
    return sha256_bytes(data.replace(b"\r\n", b"\n") if rel.endswith(".json") else data)


def v09_lock():
    files = {rel: lock_hash(rel) for rel in V09_LOCKS}
    return {"files": files, "unchanged": all(files[rel] == want for rel, want in V09_LOCKS.items())}


def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


# ===================================================================================================== v09 comparison
def v09_reference():
    """v09's flat PNG, its per-layer RGBA from the locked .ora, and its manifest palette (all read-only)."""
    png = decode(read_bytes(repo_path(V09_PNG_REL)))[2]
    with zipfile.ZipFile(io.BytesIO(read_bytes(repo_path(V09_ORA_REL)))) as z:
        names = [n[len("data/"):-len(".png")] for n in z.namelist() if n.startswith("data/") and n.endswith(".png")]
        layers = {n: decode(z.read(f"data/{n}.png"))[2] for n in names}
    man = json.loads(read_bytes(repo_path(V09_MANIFEST_REL)))
    order = [l["name"] for l in man["layers_bottom_to_top"]]
    return png, layers, order, man["palette"]


def bbox(alpha):
    ys, xs = np.nonzero(alpha)
    return None if len(xs) == 0 else [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]


def visible_masks(blobs):
    """Per layer: texels where that layer is the top-most opaque layer (what the viewer actually sees of it)."""
    owner = np.full((H, W), -1, np.int16)
    for i, name in enumerate(LAYER_NAMES[:-1]):
        owner[blobs[name][..., 3] == 255] = i
    return {name: owner == i for i, name in enumerate(LAYER_NAMES[:-1])}


def silhouette_report(comp, blobs):
    """How v10 differs from v09: whole-sprite alpha silhouette, composite texels, and per layer (count + bbox move)."""
    v09_png, v09_layers, v09_order, v09_pal = v09_reference()
    a10, a09 = comp[..., 3] > 0, v09_png[..., 3] > 0
    inter, union = int((a10 & a09).sum()), int((a10 | a09).sum())
    layers = {}
    for name in LAYER_NAMES[:-1]:
        mine, theirs = blobs[name][..., 3] > 0, v09_layers[name][..., 3] > 0 if name in v09_layers else None
        same_px = theirs is not None and np.array_equal(blobs[name], v09_layers[name])
        layers[name] = {"texels_v09": None if theirs is None else int(theirs.sum()), "texels_v10": int(mine.sum()),
                        "bbox_v09": None if theirs is None else bbox(theirs), "bbox_v10": bbox(mine),
                        "byte_identical_to_v09": bool(same_px),
                        "changed_texels": None if theirs is None else int((blobs[name] != v09_layers[name]).any(-1).sum())}
    return {
        "silhouette_texels_v09": int(a09.sum()), "silhouette_texels_v10": int(a10.sum()),
        "silhouette_iou": round(inter / union, 4), "silhouette_added_texels": int((a10 & ~a09).sum()),
        "silhouette_removed_texels": int((a09 & ~a10).sum()),
        "silhouette_bbox_v09": bbox(a09), "silhouette_bbox_v10": bbox(a10),
        "composite_changed_texels": int((comp != v09_png).any(-1).sum()),
        "composite_changed_outside_cell": 0,            # both are the same 68x72 cell drawn at the same pin
        "layers": layers,
        "byte_identical_layers": [n for n in LAYER_NAMES[:-1] if layers[n]["byte_identical_to_v09"]],
        "layer_names_same_set_as_v09": sorted(LAYER_NAMES) == sorted(v09_order + (["guides"] if "guides" not in
                                                                                    v09_order else [])),
        "layer_order_v09": v09_order,
        "palette_same_as_v09": {k: v.lower() for k, v in PALETTE.items()} == {k: v.lower() for k, v in v09_pal.items()},
    }


# ===================================================================================================== pose / shape gates
def lum(rgb):
    rgb = np.asarray(rgb, float)
    return 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]


def lean(comp):
    """Coat back edge (first opaque coat/torso texel right of the pack/roll) on the shoulder and waist rows."""
    blobs = render()[0]
    coat = blobs["coat"][..., 3] > 0
    xs = {y: int(np.nonzero(coat[y])[0].min()) for y in range(LEAN_ROWS[0], LEAN_ROWS[1] + 1)}
    return {"coat_back_edge_x_by_row": xs, "lean_texels": xs[LEAN_ROWS[0]] - xs[LEAN_ROWS[1]],
            "head_bbox": bbox(blobs["head"][..., 3] > 0), "fist_bbox": bbox(blobs["fist"][..., 3] > 0)}


def roll_report(comp, blobs):
    """Roll size, transparent columns to its right on every roll row, and distance to the other teal cloth."""
    op = comp[..., 3] > 0
    roll = blobs["bedroll"][..., 3] > 0
    bb = bbox(roll)
    gaps = {}
    for y in range(bb[1], bb[3] + 1):
        right = max(x for x in range(W) if roll[y, x])
        nxt = next((x for x in range(right + 1, W) if op[y, x] and not roll[y, x]), None)
        if y < 28:                                       # rows above the pack top: the gap is to coat/collar/scarf
            gaps[y] = None if nxt is None else nxt - right - 1
    ry, rx = np.nonzero(roll)
    dist = {}
    for other in ("scarf-neck", "hip-drape", "collar", "coat"):
        oy, ox = np.nonzero(blobs[other][..., 3] > 0)
        dist[other] = int(min(max(abs(int(a) - int(b)), abs(int(c) - int(d)))
                              for a, c in zip(rx, ry) for b, d in zip(ox, oy)))
    return {"bbox": bb, "size": [bb[2] - bb[0] + 1, bb[3] - bb[1] + 1],
            "transparent_columns_right_by_row": gaps, "chebyshev_distance_to": dist}


def drape_report(blobs):
    vis = visible_masks(blobs)
    return {"hip_drape_visible_texels": int(vis["hip-drape"].sum()),
            "coat_skirt_visible_texels": int(vis["coat-skirt"].sum()),
            "hip_drape_below_coat_and_skirt": LAYER_NAMES.index("hip-drape") < LAYER_NAMES.index("coat")
            < LAYER_NAMES.index("coat-skirt"),
            "hip_drape_bbox": bbox(blobs["hip-drape"][..., 3] > 0),
            "hip_drape_visible_bbox": bbox(vis["hip-drape"])}


def boot_report(comp, blobs):
    """Boot interiors (non-outline) on the contact-shadow rows and the light anchors (cuff/strap) above them."""
    vis = visible_masks(blobs)
    rgb = comp[..., :3]
    k = np.array(hex_rgb(PALETTE["K"]), np.uint8)
    out = {}
    for leg in ("far-leg", "near-leg"):
        m = vis[leg].copy()
        m[:BOOT_CONTACT_ROWS[0]] = False
        m[BOOT_CONTACT_ROWS[1] + 1:] = False
        m &= ~(rgb == k).all(-1)
        L = lum(rgb[m])
        strap = {key: int((vis[leg] & (rgb == np.array(hex_rgb(PALETTE[key]), np.uint8)).all(-1)).sum())
                 for key in "PpB"}
        out[leg] = {"contact_rows_interior_texels": int(m.sum()),
                    "contact_rows_interior_share_L_ge_85": round(float((L >= 85).mean()), 3),
                    "contact_rows_interior_mean_L": round(float(L.mean()), 1),
                    "light_anchor_texels_P_p_B": strap}
    return out


# ===================================================================================================== metrics
def isolated_texels(comp):
    rgb = comp[..., :3].astype(np.int32)
    key = (rgb[..., 0] << 16) | (rgb[..., 1] << 8) | rgb[..., 2]
    op = comp[..., 3] > 0
    line = key == int(PALETTE["K"][1:], 16)
    n = 0
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            if not op[y, x] or line[y, x]:
                continue
            if not any(op[y + dy, x + dx] and key[y + dy, x + dx] == key[y, x]
                       for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                n += 1
    return n


def stats(comp):
    m = comp[..., 3] > 0
    ys, xs = np.nonzero(m)
    cols = {"#%02x%02x%02x" % tuple(int(c) for c in px) for px in comp[m][:, :3]}
    pal = {v.lower() for v in PALETTE.values()}
    crown_cols = [x for x in range(HEAD_COLS[0], HEAD_COLS[1] + 1) if m[CROWN_ROW, x] and not m[:CROWN_ROW, x].any()]
    head_top = min(int(np.nonzero(m[:, x])[0].min()) for x in crown_cols) if crown_cols else None
    return {
        "size": [W, H], "pin": list(PIN), "opaque_texels": int(m.sum()), "colours": len(cols),
        "colours_outside_palette": sorted(cols - pal),
        "alpha_values": sorted({int(v) for v in np.unique(comp[..., 3])}),
        "alpha_bounds_inclusive": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
        "top_row": int(ys.min()), "sole_row": int(ys.max()), "crown_row_measured": head_top,
        "crown_columns": crown_cols, "crown_to_sole_rows": SOLE_ROW - CROWN_ROW + 1,
        "with_ponytail_rows": int(ys.max() - ys.min() + 1),
        "pin_row_clear": bool(not m[PIN[1]:, :].any()),
        "isolated_single_texels": isolated_texels(comp),
    }


def region_counts(comp):
    """Texel counts per material group."""
    groups = {"teal": "QqgG", "steel": "mMZ", "skin": "Ssx", "eye-brow": "E", "hair": "1234h",
              "slate (coat, sleeve, near-leg back edge)": "Cco", "shirt": "Ww", "pale beige (cuff, buckle, strap)": "Pp",
              "trousers": "Tt", "leather": "LlbB"}
    rgb = comp[..., :3]
    m = comp[..., 3] > 0
    out = {}
    for g, keys in groups.items():
        n = 0
        for k in keys:
            n += int((m & (rgb == np.array(hex_rgb(PALETTE[k]), np.uint8)).all(-1)).sum())
        out[g] = n
    return out


def pose_report(comp, blobs):
    return {"lean": lean(comp), "roll": roll_report(comp, blobs), "drape": drape_report(blobs),
            "boots": boot_report(comp, blobs)}


def pose_gates(p):
    roll, drape, boots = p["roll"], p["drape"], p["boots"]
    return {
        "torso_lean_ge_3_texels": p["lean"]["lean_texels"] >= 3,
        "roll_larger_than_v09_7x7": roll["size"][0] * roll["size"][1] > 49 and roll["size"][0] >= 9,
        "roll_ge_2_transparent_columns_to_coat_every_roll_row": all(v is not None and v >= 2 for v in
                                                                    roll["transparent_columns_right_by_row"].values()),
        "roll_ge_3_texels_from_scarf_and_hip_drape": roll["chebyshev_distance_to"]["scarf-neck"] >= 3
        and roll["chebyshev_distance_to"]["hip-drape"] >= 3,
        "hip_drape_behind_coat_skirt": drape["hip_drape_below_coat_and_skirt"],
        "coat_skirt_visible_ge_2x_hip_drape_visible": drape["coat_skirt_visible_texels"]
        >= 2 * drape["hip_drape_visible_texels"],
        "boot_contact_rows_mostly_light_and_anchored": all(
            b["contact_rows_interior_share_L_ge_85"] >= 0.6 and b["light_anchor_texels_P_p_B"]["B"] >= 5
            and (b["light_anchor_texels_P_p_B"]["P"] + b["light_anchor_texels_P_p_B"]["p"]) >= 2
            for b in boots.values()),
    }


# ===================================================================================================== preview
def on_bg(rgba, bg, zoom):
    im = Image.new("RGBA", (rgba.shape[1], rgba.shape[0]), tuple(bg) + (255,))
    im.alpha_composite(Image.fromarray(rgba, "RGBA"))
    return im.resize((im.width * zoom, im.height * zoom), Image.NEAREST)


def game_scale(rgba, nosprite):
    """The party capture as Godot draws it: each texel a k x k block at the texture origin over the no-sprite frame."""
    im = Image.open(nosprite).convert("RGBA")
    k = im.width // 640
    big = Image.fromarray(rgba, "RGBA").resize((W * k, H * k), Image.NEAREST)
    im.alpha_composite(big, CAPTURE_ORIGIN[im.width])
    return im


def preview(out_dir, nosprites=()):
    """Separate inspection images (one subject each, no sheets), written outside the repo."""
    blobs, comp = render()
    os.makedirs(out_dir, exist_ok=True)
    for tag, bg in (("floor-mid", (88, 84, 80)), ("floor-light", (150, 140, 124)), ("dark", (40, 42, 48))):
        on_bg(comp, bg, 8).save(os.path.join(out_dir, f"v10_x8_{tag}.png"))
    for path in nosprites:
        tag = ("ruins" if "ruins" in os.path.basename(path) else "outskirts")
        full = game_scale(comp, path)
        k = full.width // 640
        tag += f"-{full.width}"
        full.save(os.path.join(out_dir, f"v10_game-scale_{tag}.png"))
        full.crop((120 * k, 180 * k, 360 * k, 300 * k)).save(os.path.join(out_dir, f"v10_game-scale-crop-1x_{tag}.png"))
        crop = full.crop((240 * k, 190 * k, 340 * k, 280 * k))
        z = 8 // k
        crop.resize((crop.width * z, crop.height * z), Image.NEAREST).save(
            os.path.join(out_dir, f"v10_game-scale-crop-x{z}_{tag}.png"))
    print(json.dumps({**stats(comp), "material_texels_v10": region_counts(comp), "pose": pose_report(comp, blobs),
                      "pose_gates": pose_gates(pose_report(comp, blobs)),
                      "silhouette_vs_v09": silhouette_report(comp, blobs)}))


# ===================================================================================================== editable files
def make_pxo(png, blobs):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in LAYER_NAMES]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYER_NAMES], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps("sideview-idle-right-static-unapproved-v10"),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": len(LAYER_NAMES) - 2,
            "export_profile": export_profile, "fps": 6.0, "frames": frames_json, "guides": [],
            "layers": layer_json, "license": "", "metadata": {}, "next_keyframe_id": 0, "palettes": [],
            "pixelorama_version": PIXELORAMA_VERSION, "project_current_palette_name": "", "pxo_version": 7,
            "reference_images": [], "size_x": W, "size_y": H, "symmetry_points": [W - 1.0, H - 1.0], "tags": [],
            "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0, "tile_mode_y_basis_x": 0,
            "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "", "vanishing_points": []}
    buf = io.BytesIO()
    dt = (2026, 10, 16, 16, 28, 18)    # fixed (zip needs even seconds) -> byte-identical rebuilds
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def put(name, payload):
            z.writestr(zipfile.ZipInfo(name, dt), payload, zipfile.ZIP_DEFLATED)
        put("data.json", json.dumps(data, separators=(",", ":")))
        put("mimetype", "application/x-pixelorama")
        put("preview.png", png)
        put("image_data/frames/1/", b"")
        for li, name in enumerate(LAYER_NAMES, start=1):
            put(f"image_data/frames/1/layer_{li}", np.ascontiguousarray(blobs[name]).tobytes())
            put(f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_ora(png, blobs):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.3" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for name in reversed(LAYER_NAMES):                      # ORA lists the top layer first
        vis = "hidden" if name == "guides" else "visible"
        stack.append(f'<layer name="{name}" src="data/{name}.png" x="0" y="0" opacity="1.0" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>"]
    buf = io.BytesIO()
    dt = (2026, 10, 16, 16, 28, 18)
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype", dt), "image/openraster", zipfile.ZIP_STORED)
        z.writestr(zipfile.ZipInfo("stack.xml", dt), "\n".join(stack) + "\n", zipfile.ZIP_DEFLATED)
        for name in LAYER_NAMES:
            z.writestr(zipfile.ZipInfo(f"data/{name}.png", dt), png_bytes(blobs[name]), zipfile.ZIP_DEFLATED)
        z.writestr(zipfile.ZipInfo("mergedimage.png", dt), png, zipfile.ZIP_DEFLATED)
        z.writestr(zipfile.ZipInfo("Thumbnails/thumbnail.png", dt), png, zipfile.ZIP_DEFLATED)
    return buf.getvalue()


def recompose(layer_rgba):
    """Plain 'over' of binary-alpha layers in order (guides are hidden and skipped)."""
    comp = np.zeros((H, W, 4), np.uint8)
    for name in LAYER_NAMES[:-1]:
        a = layer_rgba[name]
        m = a[..., 3] == 255
        comp[m] = a[m]
    return comp


# ===================================================================================================== Pixelorama
def appdata_snapshot():
    root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    snap = {}
    if os.path.isdir(root):
        for d, _, files in os.walk(root):
            for f in files:
                p = os.path.join(d, f)
                rel = os.path.relpath(p, root).replace("\\", "/")
                if rel == ".running":          # an open GUI's 15 s heartbeat; not ours
                    continue
                try:
                    snap[rel] = sha256_bytes(read_bytes(p))
                except OSError:
                    snap[rel] = "unreadable"
    return snap


def pixelorama_export(exe, src, out_dir, split):
    """Headless export with APPDATA redirected to a fresh temp dir (never touches the real config)."""
    env = dict(os.environ)
    env["APPDATA"] = tempfile.mkdtemp(prefix="wb-pxappdata-")
    args = [exe, "--headless", "--quit", "--", "--export"] + (["--split-layers"] if split else []) + \
           ["-o", os.path.join(out_dir, "f.png"), src]
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=240, env=env)
    finally:
        shutil.rmtree(env["APPDATA"], ignore_errors=True)
    files = sorted(f for f in os.listdir(out_dir) if f.lower().endswith(".png"))
    return p.returncode, {f: read_bytes(os.path.join(out_dir, f)) for f in files}


def pixelorama_roundtrips(exe, pxo, ora, blobs, comp):
    snap0 = appdata_snapshot()
    tmp = tempfile.mkdtemp(prefix="wb-fv10-")
    px, flat_png = {}, None
    try:
        for kind, data_ in (("pxo", pxo), ("ora", ora)):
            src = os.path.join(tmp, f"cand.{kind}")
            with open(src, "wb") as f:
                f.write(data_)
            for split in (False, True):
                od = os.path.join(tmp, f"{kind}-{'split' if split else 'flat'}")
                os.makedirs(od)
                rc, outs = pixelorama_export(exe, src, od, split)
                key = f"{kind}_{'split' if split else 'flat'}"
                arrs = {f: decode(b)[2] for f, b in outs.items()}
                if split:
                    want = {n: blobs[n].tobytes() for n in LAYER_NAMES[:-1]}
                    matched = {n for n, b in want.items() if any(o.tobytes() == b for o in arrs.values())}
                    guide_leak = any(o.tobytes() == blobs["guides"].tobytes() for o in arrs.values())
                    px[key] = {"exit": rc, "pngs": len(outs), "visible_layers_matched": len(matched),
                               "visible_layers": len(want), "guides_exported": guide_leak,
                               "pass": rc == 0 and len(matched) == len(want) and not guide_leak
                               and len(outs) == len(want)}
                else:
                    ok = rc == 0 and len(outs) == 1 and next(iter(arrs.values())).tobytes() == comp.tobytes()
                    px[key] = {"exit": rc, "pngs": len(outs), "rgba_equals_tool_render": ok, "pass": ok}
                    if kind == "pxo" and ok:
                        flat_png = next(iter(outs.values()))
                with open(src, "rb") as f:
                    px[key]["input_copy_unchanged"] = f.read() == data_
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    px["real_appdata_pixelorama_untouched_except_heartbeat"] = snap0 == appdata_snapshot()
    return px, flat_png


# ===================================================================================================== build / check
LAYER_NOTES = {
    "far-leg": "far leg braced back onto the ball of the foot (v09 shape): all v8 trouser deep (C); boot with a lit turned-down cuff (B), dark shaft (L) with a pale-beige strap (p), mid-leather foot (b) with a lit (B) instep edge in the contact shadow, dark heel and sole band",
    "hip-drape": "v8 teal back-hip cloth hung behind the coat skirt: only a narrow shadowed tail (q body, g rim, Q fold, split end) shows behind and below the slate coat tail; clear of the far leg",
    "pack": "tan leather pack on the upper back (v09 drawing, 2 texels forward with the lean): plain lit block, shadowed flap edge, one pale-beige buckle, darker base",
    "bedroll": "teal blanket roll seen end-on on the pack's top edge: 9x9, lit outer ring, two-turn dark spiral into a lit core, shadowed underside; >= 3 floor columns to the coat",
    "ponytail": "high ponytail: v07's tall plume, carried with the head, tail closed one row earlier above the roll",
    "near-leg": "near leg forward: thigh to a bent knee with a leather knee pad, spruce shin without a lit edge, boot with lit cuff (B), dark shaft (L) with a pale-beige strap (P), mid-leather foot, lit instep and toe edge",
    "coat": "v8 storm-slate coat torso leaning forward (back edge x24 at the belt -> x28 at the shoulder): deep back half, thin mid band, lit front plane; belt with a lit top row",
    "coat-skirt": "split coat skirt (v09 drawing): deep back tail over the far thigh, one-texel mid band, lit front panel, lit leather hem trim",
    "shirt-lapel": "white shirt under the open coat front, lit slate lapel edge, leaning with the chest",
    "near-arm": "near arm reaching forward: upper arm angled forward from the shoulder, elbow in front of the chest, level forearm to the fist, pale-beige cuff",
    "sword-blade": "ordinary short sword blade raised forward at 45 degrees: edge light + steel core one texel step per row, tapered tip",
    "sword-guard": "small steel crossguard square to the blade",
    "fist": "light tan glove closed round the grip, held forward at chest height, leather grip end under the little finger",
    "head": "hair mass with crown sheen, pulled-back fringe, wide skin plane, brow + 1x2 eye, nose step, mouth, jaw shadow (v05 drawing, 4 texels forward)",
    "hair-tie": "leather hair tie knotted on the crown-back",
    "collar": "raised coat collar standing behind the nape (lit slate face, deep inner edge)",
    "scarf-neck": "teal scarf neck wrap, knot and short front tail",
    "collar-front": "front point of the raised coat collar, standing up under the jaw over the scarf's front edge",
    "guides": f"hidden + locked #ff00ff: cell border, ticks on crown row {CROWN_ROW} and sole row {SOLE_ROW}, pin {list(PIN)}",
}


def make_manifest(png, pxo, ora, comp, flat_from_pixelorama):
    blobs = render()[0]
    st = stats(comp)
    pose = pose_report(comp, blobs)
    m = {
        "project": SLUG,
        "subject": "female protagonist side-view battle idle, facing right, ONE static frame (native 0.65 on-screen size)",
        "version": VER, "status": "UNAPPROVED test-only candidate", "art_approved": False,
        "runtime_integrated": False, "game_bible_or_acceptance_counters_changed": False, "animation": False,
        "node_scale_intended": 1.0, "display_proportion_equivalent": 0.65,
        "refines": {"files": V09_LOCKS,
                    "hash_algorithm": "sha256-bytes for .png/.pxo/.ora; sha256-text-lf-v1 for the .json manifest",
                    "relationship": "same cell/pin/sole/crown rows, layer names and palette as v09; new ready-stance "
                                    "pose (lean, reach), larger roll, drape behind the coat, re-valued boots; "
                                    "v09 left untouched",
                    "silhouette_vs_v09": silhouette_report(comp, blobs)},
        "pose": pose,
        "pose_gates": pose_gates(pose),
        "coat_reference": {"file": V8_SOUTH_REL, "note": "owner-approved v8 south exploration idle; coat/trouser "
                           "ramps copied from it (C1/C2/C3, T1/T2); its teal hip drape, roll and pale boot laces are "
                           "the references for the drape/roll/boot straps"},
        "codex_review_addressed": "Codex inspection of the v09 1280x720 and 640x360 ruins party captures (2026-10-16): "
                                  "stiff upright torso, coil reads as a knob, hip drape dominates the coat back / reads "
                                  "as a skirt, boots and far leg merge with the dark floor at 640",
        "author_tool": TOOL_REL,
        "png_source": ("Pixelorama 1.2.3 headless flat export of the .pxo (byte-compared to the tool render)"
                       if flat_from_pixelorama else "tool render"),
        "files": {
            "png": {"file": f"{OUT_DIR_REL}/{PNG_NAME}", "sha256": sha256_bytes(png), "hash_algorithm": "sha256-bytes"},
            "pxo": {"file": f"{OUT_DIR_REL}/{PXO_NAME}", "sha256": sha256_bytes(pxo), "hash_algorithm": "sha256-bytes",
                    "format": f"Pixelorama pxo_version 7 ({PIXELORAMA_VERSION}), color_mode 5 (RGBA8), 1 frame x "
                              f"{len(LAYER_NAMES)} layers"},
            "ora": {"file": f"{OUT_DIR_REL}/{ORA_NAME}", "sha256": sha256_bytes(ora), "hash_algorithm": "sha256-bytes"},
        },
        "layers_bottom_to_top": [{"name": n, "note": LAYER_NOTES.get(n, "")} for n in LAYER_NAMES],
        "palette": PALETTE,
        "metrics": {**st, "material_texels": region_counts(comp)},
    }
    return (json.dumps(m, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def static_gates(a, st):
    return {
        "binary_alpha": st["alpha_values"] == [0, 255],
        "no_off_palette_colour": not st["colours_outside_palette"],
        "colours_le_32": st["colours"] <= 32,
        "sole_on_row_67_same_as_v09": st["sole_row"] == SOLE_ROW,
        "crown_on_row_7_same_as_v09_0p65_proportion": st["crown_row_measured"] == CROWN_ROW,
        "leftmost_texel_ge_x15_liang_gap_kept": st["alpha_bounds_inclusive"][0] >= 15,
        "nothing_at_or_below_pin_row": st["pin_row_clear"],
        "both_boots_touch_sole_row": bool((a[SOLE_ROW, 20:PIN[0], 3] > 0).any() and (a[SOLE_ROW, PIN[0]:, 3] > 0).any()),
        "transparent_border": bool(not a[0, :, 3].any() and not a[-1, :, 3].any()
                                   and not a[:, 0, 3].any() and not a[:, -1, 3].any()),
    }


def build(exe):
    lock = v09_lock()
    if not lock["unchanged"]:
        raise SystemExit(f"v09 changed: {lock}")
    blobs, comp = render()
    st = stats(comp)
    sg = static_gates(comp, st)
    pg = pose_gates(pose_report(comp, blobs))
    sil = silhouette_report(comp, blobs)
    if not all(sg.values()) or not all(pg.values()) or not sil["palette_same_as_v09"] \
            or not sil["layer_names_same_set_as_v09"]:
        raise SystemExit(f"static/pose gate failed: {json.dumps({'static': sg, 'pose': pg})}")
    tool_png = png_bytes(comp)
    pxo, ora = make_pxo(tool_png, blobs), make_ora(tool_png, blobs)
    if make_pxo(tool_png, blobs) != pxo or make_ora(tool_png, blobs) != ora:
        raise SystemExit("editable build is not deterministic")
    px, flat = pixelorama_roundtrips(exe, pxo, ora, blobs, comp)
    if flat is None or not all(v["pass"] for v in px.values() if isinstance(v, dict)):
        raise SystemExit(f"Pixelorama round-trip failed: {json.dumps(px)}")
    png = flat                         # the delivered PNG is Pixelorama's export of the layered .pxo
    out = repo_path(OUT_DIR_REL)
    for name, data in ((PNG_NAME, png), (PXO_NAME, pxo), (ORA_NAME, ora),
                       (MANIFEST_NAME, make_manifest(png, pxo, ora, comp, True))):
        print(write_new(os.path.join(out, name), data), f"{OUT_DIR_REL}/{name}", sha256_bytes(data))
    print(json.dumps({"pixelorama": px}))
    if not v09_lock()["unchanged"]:
        raise SystemExit("v09 changed during build")


def check(exe):
    report = {"status": "UNAPPROVED test-only candidate", "v09_lock_before": v09_lock()}
    blobs, comp = render()
    out = repo_path(OUT_DIR_REL)
    png = read_bytes(os.path.join(out, PNG_NAME))
    pxo = read_bytes(os.path.join(out, PXO_NAME))
    ora = read_bytes(os.path.join(out, ORA_NAME))
    man = json.loads(read_bytes(os.path.join(out, MANIFEST_NAME)))
    mode, size, a = decode(png)
    st = stats(a)
    g = {"png_rgba_68x72": mode == "RGBA" and size == (W, H), "png_equals_tool_render": a.tobytes() == comp.tobytes()}
    g.update(static_gates(a, st))
    g.update({
        "manifest_hashes_match": (man["files"]["png"]["sha256"] == sha256_bytes(png)
                                  and man["files"]["pxo"]["sha256"] == sha256_bytes(pxo)
                                  and man["files"]["ora"]["sha256"] == sha256_bytes(ora)),
        "manifest_unapproved_flags": (man["art_approved"] is False and man["runtime_integrated"] is False
                                      and man["game_bible_or_acceptance_counters_changed"] is False),
        "rebuild_editables_byte_identical": make_pxo(png_bytes(comp), blobs) == pxo
                                            and make_ora(png_bytes(comp), blobs) == ora,
    })
    with zipfile.ZipFile(io.BytesIO(pxo)) as z:
        data = json.loads(z.read("data.json"))
        names = [l["name"] for l in data["layers"]]
        g["pxo_layers_match"] = names == LAYER_NAMES and all(
            z.read(f"image_data/frames/1/layer_{i + 1}") == blobs[n].tobytes() for i, n in enumerate(names))
        pxo_layers = {n: np.frombuffer(z.read(f"image_data/frames/1/layer_{i + 1}"), np.uint8).reshape(H, W, 4)
                      for i, n in enumerate(names)}
        g["pxo_layer_stack_recomposes_png"] = recompose(pxo_layers).tobytes() == a.tobytes()
        g["pxo_guides_hidden_locked"] = [(l["visible"], l["locked"]) for l in data["layers"]][-1] == (False, True)
    with zipfile.ZipFile(io.BytesIO(ora)) as z:
        g["ora_mimetype_first_stored"] = z.infolist()[0].filename == "mimetype" and z.infolist()[0].compress_type == 0
        ora_layers = {n: decode(z.read(f"data/{n}.png"))[2] for n in LAYER_NAMES}
        g["ora_layers_match"] = all(ora_layers[n].tobytes() == blobs[n].tobytes() for n in LAYER_NAMES)
        g["ora_layer_stack_recomposes_png"] = recompose(ora_layers).tobytes() == a.tobytes()
        g["ora_mergedimage_equals_png"] = decode(z.read("mergedimage.png"))[2].tobytes() == a.tobytes()
    sil = silhouette_report(a, blobs)
    report["silhouette_vs_v09"] = sil
    g["palette_same_as_v09"] = sil["palette_same_as_v09"]
    g["layer_names_same_set_as_v09"] = sil["layer_names_same_set_as_v09"]
    g["manifest_silhouette_matches_fresh"] = man["refines"]["silhouette_vs_v09"] == json.loads(json.dumps(sil))
    pose = pose_report(a, blobs)
    report["pose"] = pose
    pg = pose_gates(pose)
    g.update(pg)
    g["manifest_pose_matches_fresh"] = man["pose"] == json.loads(json.dumps(pose)) and man["pose_gates"] == pg
    if exe:
        px, flat = pixelorama_roundtrips(exe, pxo, ora, blobs, comp)
        report["pixelorama_1_2_3_headless"] = px
        g["pixelorama_roundtrips"] = all(v["pass"] for v in px.values() if isinstance(v, dict)) and \
            px["real_appdata_pixelorama_untouched_except_heartbeat"]
        g["png_equals_fresh_pixelorama_flat_export"] = flat == png
    report["metrics"] = {**st, "material_texels": region_counts(a)}
    report["v09_lock_after"] = v09_lock()
    g["v09_unchanged"] = report["v09_lock_before"]["unchanged"] and report["v09_lock_after"]["unchanged"]
    report["gates"] = g
    report["gates_passed"] = f"{sum(bool(v) for v in g.values())}/{len(g)}"
    report["result"] = "PASS" if all(g.values()) else "FAIL"
    print(json.dumps(report, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    return 0 if report["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("out", nargs="?")
    ap.add_argument("nosprite", nargs="*", help="preview only: no-sprite party captures (1280x720 and/or 640x360)")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--pixelorama", default=repo_path(PIXELORAMA_REL))
    args = ap.parse_args()
    if args.mode == "preview":
        if not args.out:
            raise SystemExit("preview needs an output dir outside the repo")
        preview(args.out, args.nosprite)
        return 0
    exe = None if args.no_pixelorama else os.path.abspath(args.pixelorama)
    if args.mode == "build":
        if not exe or not os.path.isfile(exe):
            raise SystemExit("build needs Pixelorama (the PNG is its export)")
        build(exe)
        return 0
    if exe and not os.path.isfile(exe):
        raise SystemExit(f"Pixelorama not found: {exe}")
    return check(exe)


if __name__ == "__main__":
    sys.exit(main())
