"""UNAPPROVED candidate v07: NYC City Hall Park (Lower Manhattan, 2537 science hub), native 640x360 scene REBUILD.

ONE bounded pass after Codex rejected v06 (run nyc-chp-v06_20261017-165253-4519dffe): about 80% of v06's visible
pixels derive from an AI-generated nonruntime reference, which the style-alignment direction note forbids. v06 stays
untouched as the audit baseline and is used here ONLY as a geometry/interaction study (hotspot coordinates, the
legacy-save rule and the integration-smoke route are runtime canon; walk shapes are re-authored below as curves).

SOURCE. Every visible pixel is authored by THIS FILE from a hand-written palette (PALETTE below) and deterministic
drawing primitives: hand-placed coordinates for architecture, hand-placed lobe lists for crowns, coursed/hex/ring
paving brushes, and seeded jitter only for leaf clumps, grass tufts and stone tone choice. The scene builder opens
NO image file (the check proves this with a Python audit hook). No generated image, no v06 pixel, no palette sample,
no k-means, no paste, no downsample, no trace. It is code-authored pixel art, NOT hand-painted in a GUI; it must
never be described as hand-painted.

Modes:  preview <dir outside repo> | build | check [--no-pixelorama] [--write-report]
Run with: <python> -I -B <this file> <mode> ...
"""
import argparse, hashlib, io, json, math, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG, AREA = "rpg-2-star-ocean-the-second", "nyc-city-hall-park"
VER, STAMP, RUN_ID = "unapproved-v07", "20261017-175900", "018b7734"
RUN = f"nyc-chp-v07_{STAMP}-{RUN_ID}"
CAND_REL = f"game/assets/environments/candidates/{RUN}"
OUT_REL = f"outputs/{RUN}"
# Audit-only inputs (read by `check` AFTER the scene is built, never by the builder):
REF_REL = ("outputs/rpg-2-star-ocean-the-second_nyc-city-hall-park_style-alignment-reference_nonruntime-v01_"
           "20261016-225515-5ee8060c.png")
REF_SHA = "4a029b723174212db0ea2fd1dc02c6b3d0801c70479bbbab23067762c780e01c"
V06_DIR_REL = "game/assets/environments/candidates/nyc-chp-v06_20261017-165253-4519dffe"
V06_TAG = "unapproved-v06_20261017-165253-4519dffe"
HEROINE_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
               "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
PIXELORAMA_DEFAULT = "C:/Users/hkzha/AppData/Local/Programs/Pixelorama-1.2.3/Pixelorama-Windows-64bit/Pixelorama.exe"
W, H = 640, 360
UI_TOP, UI_BOTTOM = 62, 318
WIN_LONG_PREFIX = "\\\\?\\"
YY, XX = np.mgrid[0:H, 0:W]
BAYER4 = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0
BAY = BAYER4[YY % 4, XX % 4]


def fname(purpose, ext):
    return f"{SLUG}_{AREA}_{purpose}_{VER}_{STAMP}-{RUN_ID}.{ext}"


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > 247 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def rp(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(p):
    with open(_fs(p), "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha_text(b):
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def rng(*key):
    return np.random.Generator(np.random.PCG64(int.from_bytes(hashlib.sha256(repr(key).encode()).digest()[:8], "little")))


def hval(*key):
    """Deterministic scalar in [0,1) for a key (stone tone choice etc.)."""
    return int.from_bytes(hashlib.sha256(repr(key).encode()).digest()[:4], "little") / 2 ** 32


# ============================================================================ hand-written palette (no sampling)
PALETTE = [
    # ink / outlines
    ("ink", "0e1118"), ("ink2", "191d27"),
    # cool shadow planes
    ("sh0", "252a39"), ("sh1", "333849"), ("sh2", "454a5c"), ("cs1", "626574"), ("cs2", "80828f"),
    # warm limestone / marble facade ramp
    ("st0", "5a5558"), ("st1", "776f6b"), ("st2", "958a7e"), ("st3", "b2a58f"), ("st4", "cbbea2"),
    ("st5", "e0d3b6"), ("st6", "f2e9d0"),
    # lead roof
    ("rf0", "393b45"), ("rf1", "4f515b"), ("rf2", "686a72"), ("rf3", "84868b"),
    # copper verdigris
    ("cu0", "1c3735"), ("cu1", "2a524d"), ("cu2", "3d7365"), ("cu3", "5a9a82"), ("cu4", "8cc4a5"),
    # gilt / bronze
    ("gd0", "5a4219"), ("gd1", "8c6928"), ("gd2", "c1993e"), ("gd3", "eac86b"), ("gd4", "fff0b2"),
    # glass
    ("gl0", "131b29"), ("gl1", "1e2b3f"), ("gl2", "2d435e"), ("gl3", "4a6b88"), ("gl4", "7a9cb4"),
    # warm interior / lamp light
    ("wl0", "8f5422"), ("wl1", "cf8936"), ("wl2", "f3bb5b"), ("wl3", "ffe39b"), ("wl4", "fff6d8"),
    # foliage (lit) ramp
    ("fo0", "0f2119"), ("fo1", "16321f"), ("fo2", "204626"), ("fo3", "2c5d2b"), ("fo4", "3c7733"),
    ("fo5", "53913b"), ("fo6", "73ab47"), ("fo7", "9bc75b"), ("fo8", "c6e17c"),
    # foliage cool undersides / back trees
    ("fc0", "132c36"), ("fc1", "1b4044"), ("fc2", "275650"),
    ("fb0", "1d3530"), ("fb1", "29493e"), ("fb2", "375f4c"), ("fb3", "4b775b"), ("fb4", "658f6b"), ("fb5", "86a983"),
    # lawn
    ("ln0", "223f1f"), ("ln1", "2e5327"), ("ln2", "3c692e"), ("ln3", "4e7f34"), ("ln4", "65963c"), ("ln5", "83ad4b"),
    # warm granite paving
    ("pv0", "3d302b"), ("pv1", "58453b"), ("pv2", "745f4d"), ("pv3", "907861"), ("pv4", "ab9275"),
    ("pv5", "c4ab8a"), ("pv6", "dac5a0"), ("pv7", "ebdfbf"),
    # bluestone / hex pavers (cool grey)
    ("bs0", "2d333d"), ("bs1", "424a55"), ("bs2", "59626b"), ("bs3", "727b81"), ("bs4", "8e9599"), ("bs5", "a9afaf"),
    # wrought iron
    ("ir0", "11141a"), ("ir1", "1e222b"), ("ir2", "2f343e"), ("ir3", "494f59"), ("ir4", "6b7179"),
    # teal civic technology
    ("tl0", "0c3135"), ("tl1", "144f57"), ("tl2", "1e797b"), ("tl3", "33a9a3"), ("tl4", "6ddbcf"), ("tl5", "c3fff1"),
    # amber
    ("am0", "793d17"), ("am1", "b76729"), ("am2", "e7993f"), ("am3", "ffc769"),
    # water
    ("wa0", "0e2935"), ("wa1", "173f4d"), ("wa2", "235d6b"), ("wa3", "39858f"), ("wa4", "6bb7bb"), ("wa5", "beeae9"),
    # flowers
    ("fr0", "862128"), ("fr1", "c43d33"), ("fr2", "eb6b4b"), ("fp1", "d76f99"), ("fy1", "e7c33f"), ("fy2", "fae589"),
    ("fw1", "edeadb"), ("fv1", "6d579f"),
    # bark
    ("bk0", "1d1511"), ("bk1", "32251b"), ("bk2", "4b3929"), ("bk3", "69533f"),
    # sky and atmospheric distance
    ("sk0", "6b7b8f"), ("sk1", "8595a7"), ("sk2", "a1afbb"), ("sk3", "bbc5cb"), ("sk4", "d3d7d3"), ("sk5", "e5e1d3"),
    ("hz0", "3b4557"), ("hz1", "4d596b"), ("hz2", "636f7d"), ("hz3", "7b8591"), ("hz4", "949ca4"),
    ("hc1", "9da1a5"), ("hc2", "bcbbb3"), ("hc3", "d5d1c3"), ("hu1", "5e8b83"), ("hu2", "7ea79b"),
    # wood
    ("wd0", "492d1d"), ("wd1", "6d4327"), ("wd2", "936137"),
    # flags
    ("fl1", "2b4b8b"), ("fl2", "4a6fb3"),
]
PAL_NAMES = [n for n, _ in PALETTE]
PAL_RGB = np.array([[int(h[i:i + 2], 16) for i in (0, 2, 4)] for _, h in PALETTE], np.float64)
P = {n: i for i, n in enumerate(PAL_NAMES)}

RAMP = {
    "st": ["st0", "st1", "st2", "st3", "st4", "st5", "st6"],
    "fo": ["fo0", "fo1", "fo2", "fo3", "fo4", "fo5", "fo6", "fo7", "fo8"],
    "fb": ["fb0", "fb1", "fb2", "fb3", "fb4", "fb5"],
    "ln": ["ln0", "ln1", "ln2", "ln3", "ln4", "ln5"],
    "pv": ["pv0", "pv1", "pv2", "pv3", "pv4", "pv5", "pv6", "pv7"],
    "bs": ["bs0", "bs1", "bs2", "bs3", "bs4", "bs5"],
    "sk": ["sk0", "sk1", "sk2", "sk3", "sk4", "sk5"],
    "hz": ["hz0", "hz1", "hz2", "hz3", "hz4"],
    "cu": ["cu0", "cu1", "cu2", "cu3", "cu4"],
    "wa": ["wa0", "wa1", "wa2", "wa3", "wa4", "wa5"],
    "ir": ["ir0", "ir1", "ir2", "ir3", "ir4"],
    "rf": ["rf0", "rf1", "rf2", "rf3"],
    "gd": ["gd0", "gd1", "gd2", "gd3", "gd4"],
    "bk": ["bk0", "bk1", "bk2", "bk3"],
    "tl": ["tl0", "tl1", "tl2", "tl3", "tl4", "tl5"],
}
# shadow map: each colour -> the colour it becomes inside a cast shadow (two steps down, cooler for stone)
SHADE = {}
for _r in RAMP.values():
    for _i, _c in enumerate(_r):
        SHADE.setdefault(_c, _r[max(0, _i - 2)])
SHADE.update({"fo0": "fc0", "fo1": "fc0", "fo2": "fc1", "ln0": "fc0", "ln1": "fc0", "pv0": "sh0", "pv1": "sh0",
              "pv2": "sh1", "bs0": "sh0", "bs1": "sh0", "st0": "sh1", "st1": "sh2", "st2": "cs1", "st3": "cs1",
              "wa0": "wa0", "wa1": "wa0", "tl3": "tl2", "tl4": "tl3", "tl5": "tl4", "am3": "am2", "am2": "am1",
              "fr1": "fr0", "fr2": "fr1", "fy1": "gd1", "fy2": "fy1", "fw1": "st3", "fp1": "fr0", "fv1": "sh2",
              "wd2": "wd1", "wd1": "wd0", "wd0": "bk0", "fc2": "fc1", "fc1": "fc0", "fc0": "fc0", "sh0": "ink2",
              "sh1": "sh0", "sh2": "sh1", "cs1": "sh2", "cs2": "cs1"})
SHADE_LUT = np.array([P[SHADE.get(n, n)] for n in PAL_NAMES], np.int16)


# ============================================================================ geometry primitives
def new():
    return np.full((H, W), -1, np.int16)


def ell(cx, cy, rx, ry):
    return ((XX + 0.5 - cx) / rx) ** 2 + ((YY + 0.5 - cy) / ry) ** 2 <= 1.0


def box(x0, y0, x1, y1):
    """Half-open box: x0 <= x < x1, y0 <= y < y1."""
    return (XX >= x0) & (XX < x1) & (YY >= y0) & (YY < y1)


def poly_mask(pts):
    """Even-odd point-in-polygon on pixel centres (pure numpy, deterministic)."""
    px, py = XX + 0.5, YY + 0.5
    inside = np.zeros((H, W), bool)
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        if y1 == y2:
            continue
        cond = (py >= min(y1, y2)) & (py < max(y1, y2))
        xint = x1 + (py - y1) * (x2 - x1) / (y2 - y1)
        inside ^= cond & (px < xint)
    return inside


def curve(pts, n=48):
    """Catmull-Rom through hand-placed points -> dense polyline."""
    pts = [pts[0]] + list(pts) + [pts[-1]]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = (np.array(p, float) for p in pts[i - 1:i + 3])
        for t in np.linspace(0, 1, n, endpoint=False):
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t +
                              (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
    out.append(np.array(pts[-2], float))
    return np.array(out)


def stroke(pts, hw):
    """Pixels whose centre lies within hw of the curve through pts (round caps)."""
    poly = curve(pts)
    d = np.full((H, W), np.inf)
    for (x1, y1), (x2, y2) in zip(poly[:-1], poly[1:]):
        x0b, x1b = int(max(0, min(x1, x2) - hw - 1)), int(min(W, max(x1, x2) + hw + 2))
        y0b, y1b = int(max(0, min(y1, y2) - hw - 1)), int(min(H, max(y1, y2) + hw + 2))
        px, py = XX[y0b:y1b, x0b:x1b] + 0.5, YY[y0b:y1b, x0b:x1b] + 0.5
        vx, vy = x2 - x1, y2 - y1
        L2 = vx * vx + vy * vy or 1e-9
        t = np.clip(((px - x1) * vx + (py - y1) * vy) / L2, 0, 1)
        dd = np.hypot(px - (x1 + t * vx), py - (y1 + t * vy))
        d[y0b:y1b, x0b:x1b] = np.minimum(d[y0b:y1b, x0b:x1b], dd)
    return d <= hw


def shift(m, dx, dy, fill=False):
    out = np.full_like(m, fill)
    ys = slice(max(0, dy), H + min(0, dy)); yd = slice(max(0, -dy), H + min(0, -dy))
    xs = slice(max(0, dx), W + min(0, dx)); xd = slice(max(0, -dx), W + min(0, -dx))
    out[ys, xs] = m[yd, xd]
    return out


def dilate(m, r=1):
    out = m.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            out |= shift(m, dx, dy)
    return out


def erode(m, r=1):
    return ~dilate(~m, r)


def edge(m):
    return m & ~erode(m, 1)


def lowfreq(key, scale):
    """Smooth deterministic noise in [0,1] (bilinear grid)."""
    gw, gh = W // scale + 2, H // scale + 2
    g = rng("lowfreq", key, scale).random((gh, gw))
    fx, fy = XX / scale, YY / scale
    x0, y0 = fx.astype(int), fy.astype(int)
    tx, ty = fx - x0, fy - y0
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return a * (1 - ty) + b * ty


# ============================================================================ painting primitives (palette names only)
def fillm(a, m, c):
    a[m] = P[c]


def rect(a, x0, y0, x1, y1, c):
    a[max(0, y0):max(0, y1), max(0, x0):max(0, x1)] = P[c]


def hline(a, x0, x1, y, c):
    if 0 <= y < H:
        a[y, max(0, x0):max(0, x1)] = P[c]


def vline(a, x, y0, y1, c):
    if 0 <= x < W:
        a[max(0, y0):max(0, y1), x] = P[c]


def pset(a, x, y, c):
    x, y = int(x), int(y)
    if 0 <= x < W and 0 <= y < H:
        a[y, x] = P[c]


def line(a, x0, y0, x1, y1, c):
    x0, y0, x1, y1 = int(x0), int(y0), int(x1), int(y1)
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while True:
        pset(a, x0, y0, c)
        if x0 == x1 and y0 == y1:
            return
        e2 = 2 * err
        if e2 >= dy:
            err += dy; x0 += sx
        if e2 <= dx:
            err += dx; y0 += sy


def paint_val(a, m, val, ramp, dith=0.0, lo=0, hi=None):
    """Quantise a value field onto a named ramp; optional ordered (Bayer 4x4) dither at band edges."""
    r = RAMP[ramp] if isinstance(ramp, str) else ramp
    hi = len(r) - 1 if hi is None else hi
    q = val * (len(r) - 1) + (BAY - 0.47) * dith
    idx = np.clip(np.round(q), lo, hi).astype(int)
    lut = np.array([P[c] for c in r], np.int16)
    a[m] = lut[idx[m]]


def step(name, k):
    """Move k steps along the ramp that holds colour `name`."""
    for r in RAMP.values():
        if name in r:
            return r[int(np.clip(r.index(name) + k, 0, len(r) - 1))]
    return name


def apply_lut(a, m, lut):
    sel = m & (a >= 0)
    a[sel] = lut[a[sel]]


def shade_lut(k=1):
    """Index -> index darkening by k ramp steps (cast shadows, recess shading)."""
    out = np.arange(len(PAL_NAMES), dtype=np.int16)
    for i, n in enumerate(PAL_NAMES):
        out[i] = P[step(n, -k)] if any(n in r for r in RAMP.values()) else SHADE_LUT[i]
    return out


LUT_SH1, LUT_SH2 = shade_lut(1), shade_lut(2)


# ============================================================================ material brushes
LDIR = np.array([-0.6, -0.8])          # toward the light: upper-left (afternoon sun behind the viewer's left)


def crown(a, lobes, key, ramp="fo", lo=1, hi=None, spacing=5.5, rmin=2.8, rmax=5.2, bias=0.0, contrast=1.0,
          under="fc", outline="fo0", hi_clumps=True, clip=None, sub=9.0):
    """Leaf mass in three tiers. Hand-placed lobes give the silhouette; each lobe is split into sub-lobes that are
    shaded as separate volumes (lit upper-left, dark separation where they sit in front of the mass behind);
    small clumps then scallop the lit side and the outline without flattening those volumes. Cool undersides,
    and a dark outline only on the shadow side."""
    r_ = RAMP[ramp]
    hi = len(r_) - 1 if hi is None else hi
    S = np.zeros((H, W), bool)
    for (cx, cy, rx, ry) in lobes:
        S |= ell(cx, cy, rx, ry)
    if clip is not None:
        S &= clip
    ys, xs = np.nonzero(S)
    if len(ys) == 0:
        return S
    cx0, cy0 = (xs.min() + xs.max() + 1) / 2, (ys.min() + ys.max() + 1) / 2
    rx0, ry0 = max(4, (xs.max() - xs.min() + 1) / 2), max(4, (ys.max() - ys.min() + 1) / 2)
    gfield = 0.5 + 0.40 * contrast * (((XX + 0.5 - cx0) / rx0) * LDIR[0] + ((YY + 0.5 - cy0) / ry0) * LDIR[1]) + bias
    val = np.full((H, W), np.nan)
    R = rng("crown", key)
    # tier 1: sub-lobes inside every hand lobe
    subs = []
    for (cx, cy, rx, ry) in lobes:
        r = min(sub, max(rx, ry) * 0.6)
        n = max(1, int(round(rx * ry / (r * r * 0.9))))
        for _ in range(n):
            for _try in range(12):
                px, py = cx + R.uniform(-1, 1) * rx * 0.8, cy + R.uniform(-1, 1) * ry * 0.8
                if ((px - cx) / rx) ** 2 + ((py - cy) / ry) ** 2 <= 0.7:
                    break
            rr = r * R.uniform(0.75, 1.15)
            subs.append((px, py, rr, rr * 0.8))
    grown = dilate(S, 1)
    for (cx, cy, rx, ry) in sorted(lobes, key=lambda l: l[1] + l[3]) + sorted(subs, key=lambda l: l[1] + l[3]):
        y0, y1 = int(max(0, cy - ry - 1)), int(min(H, cy + ry + 2))
        x0, x1 = int(max(0, cx - rx - 1)), int(min(W, cx + rx + 2))
        dx, dy = (XX[y0:y1, x0:x1] + 0.5 - cx) / rx, (YY[y0:y1, x0:x1] + 0.5 - cy) / ry
        d2 = dx * dx + dy * dy
        m = (d2 <= 1.0) & S[y0:y1, x0:x1]
        l = dx * LDIR[0] + dy * LDIR[1]
        v = 0.5 * gfield[y0:y1, x0:x1] + 0.5 * (0.5 + 0.5 * l) - 0.12 * np.clip(d2 - 0.6, 0, 1)
        sep = m & (d2 > 0.72) & (l < -0.15)
        v = np.where(sep, v - 0.2, v)
        sv = val[y0:y1, x0:x1]
        sv[m] = v[m]
    # tier 2: clumps scallop the lit side and the silhouette (they modulate, not replace)
    pts = []
    for y in np.arange(ys.min() + 1, ys.max() + 1, spacing * 0.8):
        for x in np.arange(xs.min() + 1, xs.max() + 1, spacing):
            jx = x + R.uniform(-0.45, 0.45) * spacing + (spacing / 2 if int(y / spacing) % 2 else 0)
            jy = y + R.uniform(-0.4, 0.4) * spacing
            if 0 <= int(jx) < W and 0 <= int(jy) < H and S[int(jy), int(jx)]:
                pts.append((jx, jy, R.uniform(rmin, rmax)))
    pts.sort(key=lambda p: p[1])
    for (cx, cy, r) in pts:
        y0, y1 = int(max(0, cy - r - 1)), int(min(H, cy + r + 2))
        x0, x1 = int(max(0, cx - r - 1)), int(min(W, cx + r + 2))
        dx, dy = (XX[y0:y1, x0:x1] + 0.5 - cx) / r, (YY[y0:y1, x0:x1] + 0.5 - cy) / (r * 0.82)
        d2 = dx * dx + dy * dy
        m = (d2 <= 1.0) & grown[y0:y1, x0:x1]
        sv = val[y0:y1, x0:x1]
        base = np.where(np.isnan(sv), np.nanmean(sv) if np.isfinite(sv).any() else 0.4, sv)
        under_v = float(np.nanmean(sv[m])) if np.isfinite(sv[m]).any() else 0.4
        if under_v < 0.38:          # clumps only scallop the lit and mid parts; shadow masses stay quiet
            continue
        l = dx * LDIR[0] + dy * LDIR[1]
        v = base + 0.10 * l
        v = np.where((d2 > 0.6) & (l < -0.5), v - 0.09, v)
        sv[m] = v[m]
        if hi_clumps and under_v > 0.6 and r > 3.2:
            hx, hy = int(cx - 0.35 * r), int(cy - 0.4 * r)
            for (ox, oy) in (((0, 0), (1, 0), (0, 1)) if R.random() < 0.6 else ((0, 0), (1, 0))):
                if 0 <= hy + oy < H and 0 <= hx + ox < W and not np.isnan(val[hy + oy, hx + ox]):
                    val[hy + oy, hx + ox] += 0.13
    filled = ~np.isnan(val)
    n = len(r_) - 1
    idx = np.clip(np.round(np.nan_to_num(val) * n), lo, hi).astype(int)
    lut = np.array([P[c] for c in r_], np.int16)
    out = np.where(filled, lut[idx], -1).astype(np.int16)
    if under:
        rel = (YY + 0.5 - cy0) / ry0
        u = filled & (rel > 0.3) & (idx <= lo + 2)
        um = {r_[lo]: "fc0", r_[min(lo + 1, n)]: "fc1", r_[min(lo + 2, n)]: "fc2"}
        for src, dst in um.items():
            out[u & (out == P[src])] = P[dst]
    if outline:
        below_out = filled & ~shift(filled, 0, -1)
        right_out = filled & ~shift(filled, -1, 0)
        out[(below_out | (right_out & (gfield < 0.5)))] = P[outline]
    a[filled] = out[filled]
    return filled


def cell_hash(cid, seed):
    h = (cid.astype(np.uint64) * np.uint64(2654435761) + np.uint64(seed * 40503 + 977)) % np.uint64(2 ** 32)
    h = ((h ^ (h >> np.uint64(13))) * np.uint64(1274126177)) % np.uint64(2 ** 32)
    return (h % np.uint64(10007)).astype(np.float64) / 10007.0


def cells(a, m, cid, seed, ramp, tones, mortar, lit=1, lit_share=0.6, wear=0.06, chip=0.05, fleck=0.0,
          corner_lit=False):
    """Render a paving/stone field from a cell-id map: per-cell tone, joints on right/bottom edges (absolute
    ramp index, or relative to the cell tone when `mortar` is negative), lit lip on the top edge of most cells,
    rare worn cells, chipped corners and optional single granite flecks (one per few cells, never noise)."""
    r_ = RAMP[ramp]
    hv = cell_hash(cid, seed)
    tone = np.array(tones)[np.minimum((hv * len(tones)).astype(int), len(tones) - 1)]
    tone = np.where(cell_hash(cid, seed + 7) < wear, tone - 1, tone)
    ri = np.zeros_like(cid, dtype=bool); ri[:, :-1] = cid[:, :-1] != cid[:, 1:]
    bo = np.zeros_like(cid, dtype=bool); bo[:-1, :] = cid[:-1, :] != cid[1:, :]
    to = np.zeros_like(cid, dtype=bool); to[1:, :] = cid[1:, :] != cid[:-1, :]
    le = np.zeros_like(cid, dtype=bool); le[:, 1:] = cid[:, 1:] != cid[:, :-1]
    t = tone.copy()
    if corner_lit:      # rounded sett: only the upper-left corner catches the light, lower-right turns away
        le2 = np.zeros_like(le); le2[:, 1:] = le[:, :-1]
        t = np.where(to & (le | le2) & (cell_hash(cid, seed + 3) < lit_share), t + lit, t)
        bo2 = np.zeros_like(bo); bo2[:-1, :] = bo[1:, :]
        ri2 = np.zeros_like(ri); ri2[:, :-1] = ri[:, 1:]
        t = np.where(bo2 & ri2, t - 1, t)
    else:
        t = np.where(to & (cell_hash(cid, seed + 3) < lit_share), t + lit, t)
        t = np.where(le & to, t + lit, t)
    mt = tone + mortar if mortar < 0 else np.full_like(tone, mortar)
    corner = to & le & (cell_hash(cid, seed + 11) < chip)
    t = np.where(corner, mt, t)
    t = np.where(ri | bo, mt, t)
    if fleck > 0:
        fl = (cell_hash(cid * 131 + (YY * 7 + XX * 3) % 23, seed + 17) < fleck) & ~(ri | bo | to | le)
        t = np.where(fl, tone - 1, t)
    t = np.clip(t, 0, len(r_) - 1)
    lut = np.array([P[c] for c in r_], np.int16)
    a[m] = lut[t[m]]


def course_ids(y0, y1, heights, widths, key, x_off=0):
    """Running-bond courses: row band k from heights (perspective: thicker toward the camera)."""
    cid = np.zeros((H, W), np.int64)
    y, k = y0, 0
    R = rng("courses", key)
    while y < y1:
        h = heights[min(k, len(heights) - 1)]
        wmin, wmax = widths[min(k, len(widths) - 1)]
        xs = [-int(R.integers(0, wmax)) + x_off]
        while xs[-1] < W:
            xs.append(xs[-1] + int(R.integers(wmin, wmax + 1)))
        col = np.searchsorted(np.array(xs), np.arange(W), side="right")
        cid[y:min(y + h, H), :] = (k + 1) * 100000 + col[None, :]
        y += h
        k += 1
    return cid


def grid_ids(y0, y1, heights, x_edges, key, merge=0.18):
    """Floor flags on a shared column grid (reads as ground, not as a bonded wall); some neighbouring flags
    merge into long slabs, rows thicken toward the camera."""
    cid = np.zeros((H, W), np.int64)
    R = rng("grid", key)
    y, k = y0, 0
    edges = list(x_edges)
    while y < y1:
        h = heights[min(k, len(heights) - 1)]
        col = np.searchsorted(np.array(edges), np.arange(W), side="right")
        ids = col.copy()
        for c in range(1, len(edges) + 1):
            if R.random() < merge:
                ids[col == c] = c - 1 if c > 0 else c
        cid[y:min(y + h, H), :] = (k + 1) * 100000 + ids[None, :]
        y += h
        k += 1
    return cid


def cobble_ids(gx, gy, key, jitter=0.42):
    """Irregular cobbles: nearest jittered grid point (y weighted for the 3/4 view), so joints never run as long
    straight courses the way a bonded wall's do."""
    R = rng("cobbles", key)
    nx, ny = W // gx + 3, H // gy + 3
    jx = (np.arange(nx)[None, :] + 0.5 + R.uniform(-jitter, jitter, (ny, nx))) * gx
    jy = (np.arange(ny)[:, None] + 0.5 + R.uniform(-jitter, jitter, (ny, nx))) * gy
    jx = jx + np.where(np.arange(ny)[:, None] % 2 == 1, gx / 2, 0)
    gi, gj = (XX // gx).astype(int), (YY // gy).astype(int)
    best = np.full((H, W), np.inf); cid = np.zeros((H, W), np.int64)
    for dj in (-1, 0, 1):
        for di in (-1, 0, 1):
            i, j = np.clip(gi + di, 0, nx - 1), np.clip(gj + dj, 0, ny - 1)
            d = ((XX + 0.5 - jx[j, i]) / gx) ** 2 + ((YY + 0.5 - jy[j, i]) / gy) ** 2
            better = d < best
            best = np.where(better, d, best)
            cid = np.where(better, j * 10000 + i, cid)
    return cid


def hex_ids(cw=6, ch=4, ox=0, oy=0):
    """Hexagonal asphalt pavers (the NYC park path block) as staggered cells with chamfered corners."""
    row = (YY + oy) // ch
    off = (row % 2) * (cw // 2)
    col = (XX + ox + off) // cw
    cid = row.astype(np.int64) * 10000 + col
    lx, ly = (XX + ox + off) % cw, (YY + oy) % ch
    corner = (ly == 0) & ((lx == 0) | (lx == cw - 1))
    return np.where(corner, cid + 5000000, cid)    # corners read as joint -> hex silhouette


def ring_ids(cx, cy, sy, r0, ring_w, seg_px, rot=0.0):
    dx, dy = XX + 0.5 - cx, (YY + 0.5 - cy) / sy
    r = np.hypot(dx, dy)
    th = np.arctan2(dy, dx) + math.pi + rot
    ring = np.floor((r - r0) / ring_w).astype(np.int64)
    nseg = np.maximum(6, np.round(2 * math.pi * (r0 + (ring + 0.5) * ring_w) / seg_px)).astype(np.int64)
    sid = np.floor(th / (2 * math.pi) * nseg).astype(np.int64) % nseg
    return ring * 1000 + sid, ring


def lawn(a, m, key, lo=1, hi=4, base=0.5, amp=0.26):
    """Lawn: broad low-frequency patches (no per-pixel noise), sparse two-tone tufts."""
    v = base + (lowfreq((key, 1), 26) - 0.5) * amp + (lowfreq((key, 2), 9) - 0.5) * amp * 0.45
    paint_val(a, m, v, "ln", dith=0.55, lo=lo, hi=hi)
    R = rng("tufts", key)
    ys, xs = np.nonzero(m)
    if len(ys) == 0:
        return
    sel = R.random(len(ys)) < 0.035
    coin = R.random(len(ys))
    for y, x, c2 in zip(ys[sel], xs[sel], coin[sel]):
        c = PAL_NAMES[a[y, x]]
        if not c.startswith("ln"):
            continue
        if y + 1 < H and m[y + 1, x]:
            a[y + 1, x] = P[step(c, -1)]
        a[y, x] = P[step(c, 1)]
        if x + 1 < W and y - 1 >= 0 and m[y - 1, x + 1] and c2 < 0.5:
            a[y - 1, x + 1] = P[step(c, 1)]


# ============================================================================ scene geometry (screen pixels; feet = actor foot anchor)
HOTSPOTS = {"spawn": (340, 253), "liang_xu": (282, 180), "trace_0": (285, 267), "trace_1": (378, 181),
            "assist": (120, 187), "survey": (558, 166), "report": (470, 247)}
INTERACT_RADIUS = {"liang_xu": 50, "trace_0": 34, "trace_1": 34, "assist": 40, "survey": 43, "report": 50}
LEGACY_SPAWN = (82, 260)          # pre-navigation generic SPAWN still found in old city saves
LEGACY_LANDING = (82, 203.5)      # where the old plate's recovery put it; kept standable (west apron)
FOUNT = (170, 265)                # Mould fountain basin centre
BASIN_WATER, BASIN_COPING = (50, 23), (55, 27)
PLAZA_R = (478, 260)
ELM = (404, 302)                  # SE elm trunk base
REVEAL = {"radius": [15, 27], "lift": 22, "max_hole": 0.85}

CURVES = {   # hand-placed centre lines of the side paths (curved, not rectangular blocks)
    "fountain-link": [(186, 202), (178, 214), (168, 229)],
    "west-link": [(234, 262), (262, 267), (301, 263)],
    "terrace-walk": [(343, 259), (372, 264), (410, 265), (447, 261)],
    "report-link": [(461, 205), (465, 224), (474, 243)],
}


def paving_shapes():
    p = {}
    p["promenade"] = box(46, 177, 608, 208) | ((ell(252, 207, 24, 9) | ell(388, 207, 24, 9)) & (YY >= 200))
    p["west-apron"] = poly_mask([(46, 177), (108, 177), (108, 207), (101, 215), (90, 219), (46, 219)])
    p["kiosk-apron"] = box(534, 155, 584, 181)
    p["fountain-link"] = stroke(CURVES["fountain-link"], 16)
    p["fountain-plaza"] = ell(FOUNT[0], FOUNT[1], 84, 44)
    p["west-link"] = stroke(CURVES["west-link"], 15)
    p["axis"] = box(294, 204, 347, H)
    p["terrace-walk"] = stroke(CURVES["terrace-walk"], 12.5)
    p["report-plaza"] = ell(PLAZA_R[0], PLAZA_R[1], 42, 22)
    p["report-link"] = stroke(CURVES["report-link"], 16)
    return p


def feet_shapes():
    f = {}
    f["promenade"] = box(54, 180, 601, 204)
    f["west-apron"] = box(54, 180, 101, 213)
    f["kiosk-apron"] = box(541, 158, 578, 181)
    f["fountain-link"] = stroke(CURVES["fountain-link"], 12)
    f["fountain-plaza"] = ell(FOUNT[0], FOUNT[1], 78, 38)
    f["west-link"] = stroke(CURVES["west-link"], 11)
    f["axis"] = box(299, 204, 342, H)
    f["terrace-walk"] = stroke(CURVES["terrace-walk"], 8.5)
    f["report-plaza"] = ell(PLAZA_R[0], PLAZA_R[1], 35, 16)
    f["report-link"] = stroke(CURVES["report-link"], 12)
    return f


OBSTACLES = {"fountain-basin": ell(FOUNT[0], FOUNT[1], 57, 28), "report-terminal": box(497, 254, 515, 268)}


def walk_mask():
    m = np.zeros((H, W), bool)
    for v in feet_shapes().values():
        m |= v
    for v in OBSTACLES.values():
        m &= ~v
    m[:UI_TOP + 48] = False
    m[UI_BOTTOM - 11:] = False
    return m


# ============================================================================ sky + distant Lower Manhattan
def tower(a, x0, x1, top, bot, key, body="hz2", lit="hz3", shade="hz1", side=3, win="hz1", lit_win=0.04,
          wstep=(2, 3)):
    rect(a, x0, top, x1, bot, body)
    vline(a, x0, top, bot, lit)
    rect(a, x1 - side, top, x1, bot, shade)
    hline(a, x0, x1, top, lit)
    for y in range(top + 3, bot, wstep[1]):
        for x in range(x0 + 2, x1 - side - 1, wstep[0]):
            pset(a, x, y, "wl1" if hval(key, x, y) < lit_win else win)


def draw_sky_skyline(a):
    t = np.clip((YY - 56) / 56.0, 0, 1)
    paint_val(a, np.ones((H, W), bool), 0.12 + 0.62 * t, "sk", dith=0.7, lo=0, hi=4)
    # low far blocks along the horizon (cool, low contrast)
    for i, (x0, x1, top) in enumerate([(0, 40, 104), (36, 60, 96), (150, 196, 100), (232, 280, 98), (360, 410, 98),
                                       (440, 474, 96), (500, 552, 100), (604, 640, 104)]):
        tower(a, x0, x1, top, 190, ("far", i), body="hz3", lit="hz4", shade="hz2", side=2, win="hz2", lit_win=0.03)
    # 19th/20th-century mid-rises around the park (cornices, window grids), hazed by distance
    for i, (x0, x1, top) in enumerate([(0, 30, 82), (28, 58, 90), (100, 126, 88), (118, 152, 84), (152, 206, 94),
                                       (196, 236, 98), (236, 270, 92), (372, 404, 94), (404, 446, 96),
                                       (436, 470, 88), (466, 502, 82), (498, 552, 84), (550, 572, 90),
                                       (606, 640, 80)]):
        rect(a, x0, top, x1, 190, "hc2" if i % 2 else "hz4")
        hline(a, x0, x1, top, "hc3"); hline(a, x0, x1, top + 1, "hz3")
        vline(a, x0, top, 190, "hc3"); rect(a, x1 - 3, top, x1, 190, "hz3")
        for y in range(top + 4, 190, 4):
            for x in range(x0 + 2, x1 - 4, 3):
                pset(a, x, y, "wl1" if hval("mid", i, x, y) < 0.05 else "hz2")
                pset(a, x, y + 1, "hz2")
    # 2537 slim towers: glass bodies, one teal light line each, kept away from the cupola silhouette
    for i, (x0, x1, top, tx) in enumerate([(128, 150, 72, 139), (206, 232, 86, 219), (408, 432, 82, 420),
                                           (470, 498, 90, 484)]):
        tower(a, x0, x1, top, 190, ("t2537", i), body="hz2", lit="hz3", shade="hz1", side=3, win="hz1", lit_win=0.06)
        vline(a, tx, top + 2, 190, "tl2")
        pset(a, tx, top - 1, "tl4")
        vline(a, tx, top - 6, top - 1, "hz1")
    # Woolworth Building (west, Broadway): cream terra-cotta shaft, setbacks, copper pyramid crown
    for (x0, x1, top) in [(56, 100, 104), (63, 93, 90), (68, 88, 78)]:
        rect(a, x0, top, x1, 190, "hc2")
        rect(a, x1 - 4, top, x1, 190, "hz3")
        vline(a, x0, top, 190, "hc3")
        hline(a, x0, x1, top, "hc3")
        for x in range(x0 + 2, x1 - 4, 3):            # gothic piers between window strips
            vline(a, x, top + 2, 190, "hc3")
            vline(a, x + 1, top + 2, 190, "hz3")
        for x in (x0, x1 - 1):                        # corner pinnacles
            vline(a, x, top - 3, top, "hc3")
    for y in range(64, 78):
        hw = (y - 63) * 0.62
        for x in range(int(78 - hw), int(78 + hw) + 1):
            pset(a, x, y, "hu2" if x < 78 else "hu1")
    vline(a, 78, 61, 64, "hc3")
    for y in range(68, 78, 3):                        # dormer ticks in the crown
        pset(a, 76, y, "hc2"); pset(a, 80, y, "hz2")
    # Municipal Building (north-east): colonnaded crown tiers, small cupola, Civic Fame
    tower(a, 548, 640, 100, 190, "muni", body="hc2", lit="hc3", shade="hz3", side=5, win="hz3", lit_win=0.05)
    rect(a, 568, 86, 630, 100, "hz3")
    for x in range(569, 629, 3):
        vline(a, x, 87, 99, "hc3")
    hline(a, 566, 632, 86, "hc3"); hline(a, 566, 632, 99, "hc2")
    rect(a, 584, 76, 616, 86, "hc2")
    for x in range(585, 615, 3):
        vline(a, x, 77, 85, "hc3")
    hline(a, 583, 617, 76, "hc3")
    rect(a, 594, 68, 606, 76, "hc2"); vline(a, 594, 68, 76, "hc3"); vline(a, 605, 68, 76, "hz3")
    for y in range(64, 68):
        hw = (y - 63) * 1.5
        hline(a, int(600 - hw), int(600 + hw) + 1, y, "hu2")
    vline(a, 600, 61, 64, "gd1")
    for x0 in (550, 628):                             # flank pavilions
        rect(a, x0, 92, x0 + 10, 100, "hc2"); hline(a, x0, x0 + 10, 92, "hc3")
        hline(a, x0 + 2, x0 + 8, 91, "hu2")


def draw_trees_back(a):
    crown(a, [(214, 104, 16, 9), (246, 100, 14, 8), (196, 110, 12, 9)], "back-w", ramp="fb", lo=0, hi=5,
          spacing=4.5, rmin=2.2, rmax=3.8, under=None, outline="fb0")
    crown(a, [(394, 100, 14, 8), (426, 104, 16, 9), (446, 110, 12, 9)], "back-e", ramp="fb", lo=0, hi=5,
          spacing=4.5, rmin=2.2, rmax=3.8, under=None, outline="fb0")


# ============================================================================ City Hall (1812): wings, links, portico, cupola
def pilaster(a, x, y0, y1):
    vline(a, x, y0, y1, "st5"); vline(a, x + 1, y0, y1, "st4"); vline(a, x + 2, y0, y1, "st2")
    hline(a, x - 1, x + 4, y0, "st6"); hline(a, x, x + 3, y0 + 1, "st3")
    hline(a, x - 1, x + 4, y1 - 1, "st5")


def win_glass(a, x, y0, y1, w, key, lit):
    rect(a, x, y0, x + w, y1, "gl1")
    vline(a, x, y0, y1, "cs1")                        # shadowed left reveal
    vline(a, x + w - 1, y0, y1, "st5")                # lit right reveal
    hline(a, x + 1, x + w - 1, y0, "gl0")             # under the lintel
    mid = (y0 + y1) // 2
    hline(a, x + 1, x + w - 1, mid, "st3")            # white sash
    vline(a, x + w // 2, y0 + 1, y1, "gl0")
    pset(a, x + w - 2, y0 + 1, "gl3"); pset(a, x + w - 2, y0 + 2, "gl2"); pset(a, x + w - 3, y0 + 1, "gl2")
    if lit:
        rect(a, x + 1, mid + 1, x + w - 1, y1, "wl0")
        hline(a, x + 1, x + w - 1, y1 - 1, "wl1")
        pset(a, x + 1, mid + 1, "wl2")


def win_rect(a, x, y0, y1, key, lit=False, w=7):
    hline(a, x - 1, x + w + 1, y0 - 2, "st6"); hline(a, x - 1, x + w + 1, y0 - 1, "st2")
    win_glass(a, x, y0, y1, w, key, lit)
    hline(a, x - 1, x + w + 1, y1, "st5"); hline(a, x, x + w, y1 + 1, "st2")


def win_arch(a, x, y0, y1, key, lit=False, w=7):
    win_glass(a, x, y0, y1, w, key, lit)
    for dx in (0, 1, w - 2, w - 1):                   # round head
        pset(a, x + dx, y0, "st4")
    pset(a, x, y0 + 1, "st4"); pset(a, x + w - 1, y0 + 1, "st4")
    hline(a, x + 2, x + w - 2, y0 - 1, "st5")         # archivolt + keystone
    pset(a, x + 1, y0, "st5"); pset(a, x + w - 2, y0, "st3")
    pset(a, x + w // 2, y0 - 1, "st6"); pset(a, x + w // 2, y0 - 2, "st6")
    hline(a, x - 1, x + w + 1, y1, "st5"); hline(a, x, x + w, y1 + 1, "st2")


def balustrade(a, x0, x1, top, piers=()):
    hline(a, x0, x1, top, "st6"); hline(a, x0, x1, top + 1, "st3")
    for x in range(x0, x1):
        k = (x - x0) % 3
        for y in range(top + 2, top + 5):
            pset(a, x, y, "rf1" if k == 2 else ("st5" if k == 0 else "st3"))
    hline(a, x0, x1, top + 5, "st4")
    for p in piers:
        rect(a, p, top - 1, p + 3, top + 6, "st4")
        vline(a, p, top - 1, top + 6, "st5"); vline(a, p + 2, top - 1, top + 6, "st2")
        hline(a, p - 1, p + 4, top - 1, "st6")


def cornice(a, x0, x1, y):
    hline(a, x0 - 1, x1 + 1, y, "st6"); hline(a, x0 - 1, x1 + 1, y + 1, "st4")
    hline(a, x0, x1, y + 2, "st1")
    for x in range(x0, x1):
        pset(a, x, y + 3, "st5" if x % 2 == 0 else "st2")
    hline(a, x0, x1, y + 4, "st4"); hline(a, x0, x1, y + 5, "st3")


def pier_xs(x0, x1, n):
    return [x0 + int(round(i * (x1 - x0 - 3) / n)) for i in range(n + 1)]


def facade(a, x0, x1, top, base, nbay, key, lit_share=0.25):
    """Two-storey ashlar block: cornice, upper rectangular windows, belt, arched ground floor, plinth."""
    rect(a, x0, top, x1, base, "st4")
    for y in range(top + 9, base - 5, 4):             # fine ashlar coursing
        hline(a, x0, x1, y, "st3")
        off = 5 if (y // 4) % 2 else 0
        for x in range(x0 + off, x1, 10):
            pset(a, x, y - 1, "st3"); pset(a, x, y - 2, "st3")
    cornice(a, x0, x1, top)
    hline(a, x0, x1, top + 6, "st3")                  # soffit shadow
    b = top + 21                                      # belt course
    hline(a, x0 - 1, x1 + 1, b, "st6"); hline(a, x0, x1, b + 1, "st4"); hline(a, x0, x1, b + 2, "st2")
    p = base - 5                                      # plinth
    hline(a, x0 - 1, x1 + 1, p, "st5")
    rect(a, x0, p + 1, x1, base, "st3")
    for y in (p + 2,):
        for x in range(x0 + 3, x1, 8):
            vline(a, x, p + 1, base - 1, "st2")
    hline(a, x0, x1, base - 1, "st1")
    piers = pier_xs(x0, x1, nbay)
    for px in piers:
        pilaster(a, px, top + 7, b)
        pilaster(a, px, b + 3, p)
    for i in range(nbay):
        bx0, bx1 = piers[i] + 3, piers[i + 1]
        wx = (bx0 + bx1) // 2 - 3
        win_rect(a, wx, top + 10, top + 19, (key, "u", i), lit=hval(key, "u", i) < lit_share)
        win_arch(a, wx, b + 6, p - 2, (key, "g", i), lit=hval(key, "g", i) < lit_share)
    return piers


def draw_city_hall(a):
    # roofs behind the balustrades (lead grey, lit ridge)
    for (x0, x1, y) in [(198, 244, 100), (396, 442, 100), (248, 288, 96), (352, 392, 96)]:
        rect(a, x0, y, x1, y + 4, "rf1"); hline(a, x0, x1, y, "rf2"); hline(a, x0 + 1, x1 - 1, y + 3, "rf0")
        for x in range(x0 + 4, x1 - 2, 9):            # chimneys / skylight ticks
            vline(a, x, y - 2, y + 1, "st3"); pset(a, x, y - 3, "st5")
    # cupola (behind the pavilion balustrade): attic, clock stage, colonnade, dome, lantern, finial
    rect(a, 300, 90, 340, 103, "st4")
    for x in (300, 337):
        vline(a, x, 90, 103, "st5"); vline(a, x + 1, 90, 103, "st4"); vline(a, x + 2, 90, 103, "st2")
    hline(a, 299, 341, 90, "st6"); hline(a, 300, 340, 91, "st2")
    rect(a, 312, 94, 328, 101, "st3"); hline(a, 312, 328, 94, "st2"); vline(a, 312, 94, 101, "st2")
    for (dx, dy) in [(-1, 0), (0, -1), (1, 0), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)]:
        pset(a, 320 + dx, 97 + dy, "st5")
    pset(a, 320, 97, "gl1"); pset(a, 321, 97, "gl0")
    rect(a, 305, 80, 335, 90, "st4")
    vline(a, 305, 80, 90, "st5"); vline(a, 306, 80, 90, "st5"); vline(a, 333, 80, 90, "st2"); vline(a, 334, 80, 90, "st2")
    hline(a, 304, 336, 79, "st6"); hline(a, 305, 335, 80, "st2"); hline(a, 305, 335, 89, "st3")
    clock = ell(320.5, 85.5, 4.6, 4.6)
    fillm(a, clock & ~ell(320.5, 85.5, 3.6, 3.6), "gd2")
    fillm(a, ell(320.5, 85.5, 3.6, 3.6), "fw1")
    pset(a, 317, 83, "gd3"); pset(a, 318, 82, "gd3")
    vline(a, 320, 83, 86, "ink"); hline(a, 320, 323, 85, "ink")
    for x in (309, 313, 327, 331):                    # clock-stage pilasters
        vline(a, x, 81, 89, "st5"); vline(a, x + 1, 81, 89, "st3")
    rect(a, 309, 72, 332, 79, "sh1")                  # colonnade (round drum)
    hline(a, 308, 333, 78, "st5")
    for i, x in enumerate(range(309, 332, 3)):
        c = "st6" if x < 316 else ("st5" if x < 322 else ("st3" if x < 328 else "st2"))
        vline(a, x, 73, 78, c)
        pset(a, x + 1, 73, "ink2")
    hline(a, 308, 333, 72, "st5"); hline(a, 307, 334, 71, "st6"); hline(a, 309, 332, 70, "st3")
    for y in range(64, 70):                           # copper dome
        hw = 11.5 * math.sqrt(max(0.0, 1 - ((70 - y) / 6.2) ** 2))
        for x in range(int(round(320.5 - hw)), int(round(320.5 + hw))):
            f = (x - (320.5 - hw)) / max(1.0, 2 * hw)
            pset(a, x, y, "cu4" if f < 0.2 else ("cu3" if f < 0.45 else ("cu2" if f < 0.72 else "cu1")))
    for x in (314, 318, 323, 327):
        pset(a, x, 68, "cu1"); pset(a, x, 69, "cu1")
    rect(a, 319, 62, 323, 64, "st5"); pset(a, 322, 62, "st3"); pset(a, 322, 63, "st3")
    pset(a, 320, 61, "gd2"); pset(a, 321, 61, "gd1")
    # links (recessed), then wings (forward), then the pavilion with its portico
    facade(a, 246, 290, 106, 154, 3, "link-w"); balustrade(a, 246, 290, 100, pier_xs(246, 290, 3))
    facade(a, 350, 394, 106, 154, 3, "link-e"); balustrade(a, 350, 394, 100, pier_xs(350, 394, 3))
    facade(a, 196, 246, 110, 158, 3, "wing-w"); balustrade(a, 196, 246, 104, pier_xs(196, 246, 3))
    facade(a, 394, 444, 110, 158, 3, "wing-e"); balustrade(a, 394, 444, 104, pier_xs(394, 444, 3))
    # wing returns seen from the centre: west wing's east face in shadow, east wing's west face lit
    rect(a, 246, 104, 249, 158, "cs1"); rect(a, 246, 110, 249, 116, "sh2"); vline(a, 248, 104, 158, "sh2")
    rect(a, 391, 104, 394, 158, "st5"); rect(a, 391, 110, 394, 116, "st6"); vline(a, 391, 104, 158, "st4")
    # pavilion upper storey: engaged columns, three arched windows, cornice + balustrade with the attic behind
    x0, x1, top = 290, 350, 108
    rect(a, x0, top, x1, 132, "st4")
    for y in range(top + 9, 130, 4):
        hline(a, x0, x1, y, "st3")
    cornice(a, x0, x1, top)
    hline(a, x0, x1, top + 6, "st3")
    for cx in (292, 309, 328, 345):
        pilaster(a, cx, top + 7, 127)
        hline(a, cx - 1, cx + 4, top + 7, "st6"); pset(a, cx - 1, top + 8, "st5"); pset(a, cx + 3, top + 8, "st2")
    win_arch(a, 298, 118, 127, ("pav", 0), lit=False)
    win_arch(a, 315, 116, 127, ("pav", 1), lit=True, w=10)
    win_arch(a, 335, 118, 127, ("pav", 2), lit=False)
    balustrade(a, x0, x1, 102, [290, 306, 331, 347])
    # portico: terrace balustrade, entablature, six columns, shaded loggia with three doors
    balustrade(a, 287, 353, 125, [287, 318, 350])
    hline(a, 286, 354, 131, "st6"); hline(a, 286, 354, 132, "st4"); hline(a, 287, 353, 133, "st5")
    hline(a, 287, 353, 134, "st2")
    rect(a, 288, 135, 352, 156, "cs1")
    rect(a, 288, 135, 352, 139, "sh2")
    for (dx0, dx1, dt) in [(304, 309, 141), (316, 325, 139), (331, 336, 141)]:
        rect(a, dx0 - 1, dt - 1, dx1 + 1, 156, "cs2")
        rect(a, dx0, dt, dx1, 156, "ink2")
        rect(a, dx0, 150, dx1, 156, "wl0"); hline(a, dx0, dx1, 155, "wl1")
        pset(a, dx0 + 1, 151, "wl2")
        pset(a, dx0 - 1, dt - 1, "cs1"); pset(a, dx1, dt - 1, "cs1")
    for cx in (289, 299, 310, 327, 338, 348):
        vline(a, cx, 137, 155, "st6"); vline(a, cx + 1, 137, 155, "st4"); vline(a, cx + 2, 137, 155, "st2")
        hline(a, cx - 1, cx + 4, 135, "st6"); hline(a, cx - 1, cx + 4, 136, "st3")
        pset(a, cx - 1, 136, "st5"); pset(a, cx + 3, 136, "st2")
        hline(a, cx - 1, cx + 4, 155, "st5")
        hline(a, cx + 3, cx + 6, 137, "sh1")          # column shadow on the loggia wall
    hline(a, 286, 354, 156, "st6"); hline(a, 286, 354, 157, "st3")
    # broad entrance stair
    for i in range(5):
        y = 158 + 2 * i
        xa, xb = 284 - 3 * i, 356 + 3 * i
        hline(a, xa, xb, y, "st5"); hline(a, xa, xb, y + 1, "st2")
        pset(a, xa, y, "st6")
    rect(a, 272, 154, 280, 168, "st4")                # cheek blocks; vline(a, 272, 154, 168, "st5"); hline(a, 271, 281, 153, "st6")
    rect(a, 360, 154, 368, 168, "st4"); vline(a, 367, 154, 168, "st2"); hline(a, 359, 369, 153, "st6")
    hline(a, 272, 281, 167, "st1"); hline(a, 359, 368, 167, "st1")
    hline(a, 268, 372, 168, "st1")


def draw_forecourt(a):
    m = box(150, 150, 490, 180)
    cid = course_ids(150, 180, [2, 3, 3, 3, 3, 4, 4, 4, 4], [(6, 9), (7, 10), (7, 11), (8, 12), (9, 13), (10, 14)],
                     "forecourt")
    cells(a, m, cid, 21, "pv", (4, 5, 5, 6), 3, lit_share=0.5)
    side = box(40, 132, 196, 180) | box(444, 132, 540, 180)
    lawn(a, side, "lawn-north", lo=1, hi=3, base=0.45, amp=0.22)


def draw_trees_north(a):
    # west group in front of the Woolworth shaft; one crown overlaps the west wing corner (depth)
    crown(a, [(66, 120, 44, 28), (110, 110, 32, 22), (34, 136, 38, 26), (100, 142, 46, 26), (150, 128, 30, 22),
              (12, 112, 24, 22), (58, 160, 40, 16), (130, 160, 30, 14)], "tree-nw", spacing=5.5, bias=-0.07, hi=7)
    crown(a, [(188, 136, 20, 24), (176, 156, 18, 14), (204, 150, 12, 12)], "tree-nw2", spacing=5.0, bias=-0.02, hi=7)
    # east group behind the survey kiosk; a crown overlaps the east wing corner
    for (x, y0, y1) in [(493, 150, 180), (617, 156, 180)]:
        rect(a, x - 2, y0, x + 3, y1, "bk2"); vline(a, x - 2, y0, y1, "bk3"); vline(a, x + 2, y0, y1, "bk0")
    crown(a, [(494, 114, 34, 22), (538, 106, 36, 24), (578, 118, 30, 24), (470, 136, 28, 20), (522, 138, 40, 22),
              (604, 140, 28, 24), (632, 116, 22, 26)], "tree-ne", spacing=5.5, bias=-0.07, hi=7)
    crown(a, [(452, 132, 18, 24), (440, 150, 12, 12)], "tree-ne2", spacing=5.0, bias=-0.02, hi=7)
    # clipped hedges behind the fence
    crown(a, [(x, 171, 8, 7) for x in range(50, 200, 10)], "hedge-w", lo=1, hi=6, spacing=3.6, rmin=1.8, rmax=3.0)
    crown(a, [(x, 171, 8, 7) for x in range(446, 534, 10)], "hedge-e", lo=1, hi=6, spacing=3.6, rmin=1.8, rmax=3.0)


# ============================================================================ park ground: lawn, paving, planting
def paving_union():
    u = np.zeros((H, W), bool)
    for v in paving_shapes().values():
        u |= v
    return u


def draw_lawn(a):
    base = 0.44 - np.clip((YY - 200) / 118.0, 0, 1) * 0.10
    lawn(a, YY >= 176, "lawn-south", lo=1, hi=4, base=base, amp=0.24)


def draw_paving(a):
    ps = paving_shapes()
    U = paving_union()
    # side paths: NYC park hexagonal pavers, cool charcoal, soft joints
    side = ps["fountain-link"] | ps["west-link"] | ps["terrace-walk"] | ps["report-link"]
    cells(a, side, hex_ids(7, 4), 51, "bs", (2, 2, 3), -1, lit_share=0.55, wear=0.05, chip=0.0)
    # Mould fountain plaza: concentric warm granite setts, bluestone outer band
    sy = 44 / 84
    cid, ring = ring_ids(FOUNT[0], FOUNT[1], sy, 55, 5, 10)
    fp = ps["fountain-plaza"]
    cells(a, fp, cid, 61, "pv", (4, 4, 5), -1, lit_share=0.45, fleck=0.03)
    cells(a, fp & (ring >= 5), cid, 62, "bs", (2, 3, 3), -1)
    # report plaza: rings, teal inlay ring, pale medallion
    sy2 = 22 / 42
    cid2, ring2 = ring_ids(PLAZA_R[0], PLAZA_R[1], sy2, 4, 5, 9)
    rpm = ps["report-plaza"]
    cells(a, rpm, cid2, 71, "pv", (4, 4, 5), -1, lit_share=0.45, fleck=0.03)
    inlay = rpm & (ring2 == 3)
    fillm(a, inlay, "tl1")
    fillm(a, inlay & (cell_hash(cid2, 72) < 0.5) & ~edge(inlay), "tl2")
    fillm(a, rpm & ell(PLAZA_R[0], PLAZA_R[1], 6, 6 * sy2 + 0.5), "pv6")
    # central walk: large bluestone flags on a three-column grid (rows thicken toward the camera), granite borders
    ax = ps["axis"]
    inner = ax & box(299, 204, 342, H)
    cid3 = grid_ids(204, H, [6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13], [299, 313, 328, 342], "axis")
    cells(a, inner, cid3, 81, "bs", (3, 3, 4), -1, lit_share=0.5, fleck=0.04)
    cid4 = course_ids(204, H, [4] * 40, [(5, 7)], "axis-b")
    cells(a, ax & ~inner, cid4, 82, "pv", (5, 5, 6), -1)
    # promenade: square-ish warm granite flags on a shared grid, a worn lighter centre lane, bluestone fence band,
    # granite fan in front of the gate
    pr = ps["promenade"] | ps["west-apron"] | ps["kiosk-apron"]
    cid5 = cobble_ids(6, 4, "prom")
    cells(a, pr, cid5, 91, "pv", (4, 5, 5, 4), -1, lit_share=0.8, wear=0.08, chip=0.0, corner_lit=True)
    lane = pr & (YY >= 188) & (YY < 200) & (lowfreq("prom-wear", 14) > 0.45)
    apply_lut(a, lane & np.isin(a, [P["pv4"], P["pv5"]]), np.array([P[step(n, 1)] if n in ("pv4", "pv5") else i
                                                                     for i, n in enumerate(PAL_NAMES)], np.int16))
    band = pr & (YY >= 177) & (YY < 182) & ~box(534, 150, 584, 182)
    cid7 = course_ids(177, 182, [5], [(14, 20)], "prom-band")
    cells(a, band, cid7, 92, "pv", (3, 4), -1)
    fan = pr & ell(320, 177, 52, 28) & (YY >= 182)
    cid6, ring6 = ring_ids(320, 177, 0.54, 0, 4, 7)
    cells(a, fan, cid6, 93, "pv", (4, 5, 5), -1, lit_share=0.5)
    fillm(a, fan & edge(ell(320, 177, 52, 28)) & (YY >= 182), "pv6")
    # material seams where hex paths meet granite
    main = fp | rpm | ax | pr
    fillm(a, side & ~main & dilate(main, 1), "pv5")
    # kerbs: lit top lip and lit (south-facing) kerb face, soft contact shade on the lawn below
    top_e = U & ~shift(U, 0, 1)
    bot_e = U & ~shift(U, 0, -1)
    left_e = U & ~shift(U, 1, 0)
    right_e = U & ~shift(U, -1, 0)
    fillm(a, left_e, "pv5"); fillm(a, right_e, "pv3")
    fillm(a, top_e, "pv6")
    fillm(a, bot_e, "pv3")
    fillm(a, shift(bot_e, 0, 1) & ~U & ((XX // 2) % 3 != 0), "ln1")
    below2 = np.zeros((H, W), bool)
    fillm(a, below2 & ((XX // 3) % 2 == 0), "ln1")
    # grass creeping over the top/left kerb in a few places
    R = rng("overhang")
    ys, xs = np.nonzero(top_e | left_e)
    pick = R.random(len(ys)) < 0.12
    for y, x in zip(ys[pick], xs[pick]):
        pset(a, x, y, "ln3" if (x + y) % 2 else "ln4")


def bed(a, U, cx, cy, rx, ry, key, flower):
    m = ell(cx, cy, rx, ry) & ~dilate(U, 1)
    rim = m & ~erode(m, 1)
    crown(a, [(cx, cy, rx - 0.5, ry - 0.5)], key, lo=1, hi=5, spacing=3.0, rmin=1.4, rmax=2.4, clip=m, outline="fo1")
    fillm(a, rim & (YY > cy), "bk1")
    cols = {"red": ("fr2", "fr1", "fr0"), "yellow": ("fy2", "fy1", "gd1"), "white": ("fw1", "st4", "st2"),
            "pink": ("fp1", "fr1", "fr0"), "violet": ("fp1", "fv1", "sh2")}[flower]
    inner = erode(m, 1)
    R = rng("bed", key)
    for y in range(int(cy - ry), int(cy + ry) + 1, 3):
        for x in range(int(cx - rx), int(cx + rx) + 1, 4):
            jx, jy = x + int(R.integers(0, 3)), y + int(R.integers(0, 2))
            if 0 <= jy + 1 < H and 0 <= jx + 1 < W and inner[jy, jx] and inner[jy + 1, jx + 1] and R.random() < 0.8:
                pset(a, jx, jy, cols[0]); pset(a, jx + 1, jy, cols[1])
                pset(a, jx, jy + 1, cols[1]); pset(a, jx + 1, jy + 1, cols[2])


def clipped_hedge(a, U, x0, x1, y0, y1, key):
    m = box(x0, y0, x1, y1) & ~dilate(U, 1)
    crown(a, [((x0 + x1) / 2, y, (x1 - x0) / 2 + 1, 4.5) for y in range(y0, y1, 5)], key, lo=2, hi=7,
          spacing=3.0, rmin=1.4, rmax=2.4, clip=m, outline="fo1", contrast=0.6, bias=0.08)


def draw_planting(a):
    U = paving_union()
    clipped_hedge(a, U, 285, 293, 212, 302, "hedge-axis-w")
    clipped_hedge(a, U, 348, 356, 212, 302, "hedge-axis-e")
    for i, (x0, x1) in enumerate([(108, 141), (152, 162), (204, 220), (229, 232), (278, 284), (357, 362),
                                  (421, 450), (492, 496), (505, 534), (590, 606)]):
        clipped_hedge(a, U, x0, x1, 211, 217, ("hedge-prom-s", i))
    for (cx, cy, rx, ry, k) in [(150, 214, 7, 5, "ball-a"), (212, 213, 6, 5, "ball-b"), (444, 213, 6, 5, "ball-c"),
                                (512, 214, 7, 5, "ball-d"), (100, 226, 8, 6, "ball-e"), (238, 246, 6, 4, "ball-f"),
                                (530, 278, 9, 6, "ball-g"), (88, 296, 9, 7, "ball-h"), (262, 288, 6, 5, "ball-i"),
                                (372, 286, 8, 6, "ball-j"), (566, 206, 8, 5, "ball-k")]:
        m = ell(cx, cy, rx, ry) & ~dilate(U, 1)
        crown(a, [(cx, cy, rx, ry)], k, lo=1, hi=7, spacing=3.2, rmin=1.5, rmax=2.6, clip=m)
    lawn_edge = dilate(U, 3) & ~dilate(U, 1) & (YY >= 214) & (YY < 312)
    R = rng("borders")
    ys, xs = np.nonzero(lawn_edge)
    order = R.permutation(len(ys))
    taken = np.zeros((H, W), bool)
    flowers = ("fr2", "fy2", "fw1", "fp1")
    for k in order:
        y, x = int(ys[k]), int(xs[k])
        if taken[y, x] or R.random() > 0.5:
            continue
        r = float(R.uniform(2.6, 4.2))
        m = ell(x, y, r + 0.5, r * 0.8) & ~dilate(U, 1)
        crown(a, [(x, y, r, r * 0.8)], ("border", x, y), lo=1, hi=6, spacing=2.6, rmin=1.2, rmax=2.0, clip=m)
        if R.random() < 0.45:
            c = flowers[int(R.integers(0, len(flowers)))]
            for _ in range(int(R.integers(2, 5))):
                fx, fy = x + int(R.integers(-2, 3)), y + int(R.integers(-2, 1))
                if 0 <= fy < H and 0 <= fx < W and m[fy, fx]:
                    pset(a, fx, fy, c)
        taken |= ell(x, y, 9, 6)
    bed(a, U, 244, 226, 26, 9, "bed-nw", "red")
    bed(a, U, 64, 246, 18, 8, "bed-w", "yellow")
    bed(a, U, 252, 300, 24, 9, "bed-sw", "white")
    bed(a, U, 560, 236, 24, 9, "bed-e", "red")
    bed(a, U, 520, 300, 26, 8, "bed-se", "yellow")
    bed(a, U, 398, 226, 22, 7, "bed-c", "violet")


def draw_ground_shadows(sh, ground, plants):
    """Cast shadows (down-right, sun upper-left) baked as darkened copies of the ground beneath them."""
    m = np.zeros((H, W), bool)
    dap = lowfreq("dapple", 5) > 0.34
    m |= (ell(118, 186, 82, 9) | ell(52, 182, 44, 6)) & dap           # west crowns onto the promenade
    m |= (ell(526, 181, 72, 6) | ell(470, 178, 22, 4)) & dap          # east crowns
    m |= ell(424, 306, 44, 9) & dap                                   # SE elm
    for (x0, x1) in PIERS:                                            # piers
        for k in range(1, 6):
            m |= box(x0 + k + 1, 178 + k, x1 + k + 1, 179 + k)
    for x0, x1 in [(46, 302), (338, 534)]:                            # fence posts and rails
        for x in range(x0, x1, 3):
            m |= box(x + 1, 178, x + 2, 181) | box(x + 2, 181, x + 3, 183)
        m |= box(x0 + 2, 178, x1 + 2, 179)
    for x in LAMPS_PROM + LAMPS_AXIS_X:                               # lamp posts
        by = 208 if x in LAMPS_PROM else 212
        for k in range(1, 8):
            m |= box(x + k, by - 1 + k // 2, x + k + 2, by + k // 2)
    m |= box(293, 214, 297, 302) & ~box(293, 244, 297, 280)            # axis hedge onto the walk edge
    m |= box(356, 214, 359, 302) & ~box(356, 244, 359, 280)
    m |= (shift(plants, 2, 2) | shift(plants, 3, 1)) & ~plants & (YY >= 176)   # shrubs, beds, hedges
    core = m & (ground >= 0)
    pen = core & ~erode(core, 1)
    sh[core] = LUT_SH2[ground[core]]
    sh[pen] = LUT_SH1[ground[pen]]


# ============================================================================ Mould fountain basin (base layer)
def draw_basin(a):
    cx, cy = FOUNT
    outer = ell(cx, cy, *BASIN_COPING)
    water = ell(cx, cy, *BASIN_WATER)
    face = ell(cx, cy + 4, *BASIN_COPING) & ~outer & (YY >= cy)
    fillm(a, face, "pv2")
    fillm(a, face & (XX < cx - 18), "pv3")
    fillm(a, face & ~shift(face, 0, -1), "pv1")
    coping = outer & ~water
    fillm(a, coping, "pv5")
    fillm(a, coping & (XX < cx - 10) & (YY < cy + 4), "pv6")
    fillm(a, coping & ~shift(outer, 0, -1), "pv3")                 # outer lower lip
    th = np.arctan2((YY + 0.5 - cy) / 0.49, XX + 0.5 - cx)
    joints = coping & (np.abs(((th + math.pi) * 36 / (2 * math.pi)) % 1 - 0.5) > 0.46)
    fillm(a, joints, "pv3")
    # water: shaded inner far wall, deep far band, lighter near water, ripple dashes, glints
    v = 0.25 + np.clip((YY - (cy - 23)) / 46.0, 0, 1) * 0.5
    paint_val(a, water, v, "wa", dith=0.6, lo=1, hi=3)
    inner_wall = water & ~ell(cx, cy + 3, *BASIN_WATER) & (YY < cy)
    fillm(a, inner_wall, "pv1")
    fillm(a, inner_wall & ~shift(inner_wall, 0, -1), "wa0")
    R = rng("ripples")
    for _ in range(46):
        x, y = int(R.integers(cx - 44, cx + 44)), int(R.integers(cy - 14, cy + 20))
        if water[y, x] and not inner_wall[y, x] and water[y, min(W - 1, x + 3)]:
            hline(a, x, x + int(R.integers(2, 5)), y, "wa3" if R.random() < 0.7 else "wa4")
    for _ in range(14):
        x, y = int(R.integers(cx - 40, cx + 40)), int(R.integers(cy - 10, cy + 18))
        if water[y, x] and not inner_wall[y, x]:
            pset(a, x, y, "wa5")
    splash = ell(cx, cy - 1, 18, 5) & ~ell(cx, cy - 1, 15, 3.5) & water
    fillm(a, splash & ((XX + YY) % 3 != 0), "wa4")
    fillm(a, splash & ((XX * 7 + YY) % 5 == 0), "wa5")
    for (lx, ly) in FOUNT_LAMPS:                                      # warm lamp reflections
        if ly > cy - 20:
            for k in range(2, 9, 3):
                if water[min(H - 1, ly + k), lx]:
                    hline(a, lx - 1, lx + 1, ly + k, "wl1")


# ============================================================================ fence, piers, gate
PIERS = [(46, 55), (150, 159), (258, 268), (286, 299), (341, 354), (370, 381), (480, 489), (526, 535)]
LAMPS_PROM = [146, 224, 416, 500]
LAMPS_AXIS_X = [290, 350]
FOUNT_LAMPS = [(170, 238), (114, 265), (226, 265), (170, 292)]


def draw_fence(a):
    # stone kerb the fence stands on
    for (x0, x1) in [(46, 302), (338, 534)]:
        hline(a, x0, x1, 175, "st5"); hline(a, x0, x1, 176, "st3"); hline(a, x0, x1, 177, "st2")
        for x in range(x0, x1):
            if (x - x0) % 3 == 0:
                vline(a, x, 160, 175, "ir1")
                pset(a, x, 159, "ir3"); pset(a, x, 158, "ir4")
            elif (x - x0) % 3 == 1:
                pset(a, x, 166, "ir2")
        hline(a, x0, x1, 162, "ir1"); hline(a, x0, x1, 161, "ir3")
        hline(a, x0, x1, 172, "ir1"); hline(a, x0, x1, 171, "ir3")
    for (x0, x1) in PIERS:
        top = 146 if (x0, x1) in [(286, 299), (341, 354)] else 152
        rect(a, x0, top, x1, 178, "st4")
        vline(a, x0, top, 178, "st5"); vline(a, x1 - 2, top, 178, "st2"); vline(a, x1 - 1, top, 178, "st1")
        for y in range(top + 5, 177, 5):
            hline(a, x0 + 1, x1 - 2, y, "st3")
        hline(a, x0 - 1, x1 + 1, top - 3, "st6"); hline(a, x0 - 1, x1 + 1, top - 2, "st4")
        hline(a, x0, x1, top - 1, "st2")
        hline(a, x0, x1, 177, "st1")
        mx = (x0 + x1) // 2
        if top == 150:                                # ball finial
            hline(a, mx - 1, mx + 2, top - 5, "st5"); hline(a, mx - 1, mx + 2, top - 4, "st3"); pset(a, mx, top - 6, "st6")
        else:                                         # gate lanterns (iron, warm glass, teal service ring)
            rect(a, mx - 3, top - 15, mx + 3, top - 4, "ir1")
            rect(a, mx - 2, top - 13, mx + 2, top - 6, "wl3")
            vline(a, mx - 2, top - 13, top - 6, "wl2"); pset(a, mx, top - 11, "wl4")
            hline(a, mx - 3, mx + 3, top - 5, "tl3")
            hline(a, mx - 2, mx + 2, top - 16, "ir2"); pset(a, mx, top - 17, "gd2")
    # open gate leaves folded back against the piers
    for x0 in (300, 337):
        for x in range(x0, x0 + 3):
            vline(a, x, 160, 176, "ir1")
        hline(a, x0, x0 + 3, 163, "ir3"); hline(a, x0, x0 + 3, 172, "ir3")
        pset(a, x0 + 1, 159, "gd2")


# ============================================================================ fixtures (base layer)
def draw_fixtures(a):
    # allocation-ledger board (assist): iron posts, verdigris cap, teal ledger panel with amber rows
    for x in (107, 132):
        vline(a, x, 150, 179, "ir1"); vline(a, x + 1, 150, 179, "ir2")
    rect(a, 104, 148, 137, 171, "ir1")
    rect(a, 105, 149, 136, 170, "ir2")
    rect(a, 106, 151, 135, 169, "tl0")
    for i, y in enumerate(range(153, 168, 2)):
        hline(a, 108, 108 + 8 + (i * 5) % 9, y, "am2" if i % 3 == 0 else "tl3")
        hline(a, 122, 122 + 6 + (i * 3) % 6, y, "tl2")
        pset(a, 131, y, "am3" if i % 2 else "tl4")
    vline(a, 120, 152, 168, "tl1")
    hline(a, 106, 135, 151, "tl2")
    for y in range(144, 149):
        hw = (y - 143) * 3.6
        hline(a, int(120.5 - hw), int(120.5 + hw) + 1, y, "cu2")
        pset(a, int(120.5 - hw), y, "cu4")
    hline(a, 103, 138, 148, "cu1")
    hline(a, 106, 136, 179, "sh1")
    # gate-pier inspection sheet (trace 2) on the pier at x 370-381
    rect(a, 372, 158, 379, 168, "fw1")
    hline(a, 372, 379, 158, "tl3"); hline(a, 372, 379, 159, "tl2")
    for y in (161, 163, 165):
        hline(a, 373, 376 + (y % 3), y, "st2")
    vline(a, 379, 159, 169, "st2"); hline(a, 373, 380, 168, "st2")
    pset(a, 375, 157, "am3")
    # public-works survey stair kiosk (City Hall station kiosk lineage): verdigris + teal glass canopy
    for y in range(106, 121):
        hw = 27 * math.sqrt(max(0.0, 1 - ((121 - y) / 15.0) ** 2))
        for x in range(int(559.5 - hw), int(559.5 + hw)):
            f = (x - (559.5 - hw)) / max(1, 2 * hw)
            c = "tl4" if f < 0.18 else ("tl3" if f < 0.5 else ("tl2" if f < 0.8 else "tl1"))
            if (x - 532) % 7 == 0:
                c = "cu1"
            pset(a, x, y, c)
    for y in range(106, 121):
        hw = 27 * math.sqrt(max(0.0, 1 - ((121 - y) / 15.0) ** 2))
        pset(a, int(559.5 - hw), y, "cu3"); pset(a, int(559.5 + hw), y, "cu0")
    hline(a, 556, 563, 106, "cu3"); pset(a, 559, 104, "gd2"); pset(a, 559, 105, "gd1")
    rect(a, 531, 120, 588, 125, "cu1"); hline(a, 531, 588, 120, "cu3"); hline(a, 531, 588, 124, "cu0")
    hline(a, 536, 583, 122, "tl4"); hline(a, 546, 573, 122, "tl5")
    for x in (534, 581):
        rect(a, x, 125, x + 4, 157, "cu1"); vline(a, x, 125, 157, "cu3"); vline(a, x + 3, 125, 157, "cu0")
        pset(a, x + 1, 128, "gd2")
    for x in (538, 573):
        rect(a, x, 127, x + 8, 151, "tl1")
        vline(a, x, 127, 151, "tl2"); hline(a, x, x + 8, 127, "tl2")
        line(a, x + 2, 141, x + 6, 132, "tl3")
        pset(a, x + 6, 131, "tl4")
    rect(a, 546, 127, 573, 157, "ink2")
    for i, y in enumerate(range(155, 130, -3)):                       # stair descending into the annex
        shade = ["bs3", "bs2", "bs1", "sh2", "sh1", "sh0", "ink2", "ink2", "ink2"][min(i, 8)]
        hline(a, 547 + i, 572 - i, y, shade)
        hline(a, 547 + i, 572 - i, y + 1, "ink2" if i > 2 else "sh0")
    for i in range(0, 26):
        pset(a, 547 + i // 3, 155 - i, "tl3"); pset(a, 572 - i // 3, 155 - i, "tl3")
    rect(a, 556, 131, 564, 135, "tl2"); hline(a, 557, 563, 133, "tl5")
    hline(a, 532, 588, 157, "bs4"); hline(a, 532, 588, 158, "bs2")
    # double-numbered sign (trace 1) on the west-link verge, with its teal/amber pavement lines
    vline(a, 272, 230, 251, "ir1"); vline(a, 273, 230, 251, "ir3")
    rect(a, 265, 230, 281, 236, "tl1"); hline(a, 265, 281, 230, "tl3"); hline(a, 268, 278, 233, "tl4")
    rect(a, 266, 238, 280, 244, "am1"); hline(a, 266, 280, 238, "am3"); hline(a, 269, 277, 241, "am3")
    pset(a, 270, 233, "tl5"); pset(a, 274, 241, "fw1")
    hline(a, 270, 277, 251, "sh1")
    poly = curve(CURVES["west-link"], 30)
    for i, (px, py) in enumerate(poly):
        if i % 4 < 3:
            pset(a, px, py - 5, "tl3")
            pset(a, px, py + 6, "am2")
    # benches facing the walks (wood slats on iron)
    for (x0, y0) in [(244, 209), (380, 209), (122, 222), (520, 252)]:
        rect(a, x0, y0, x0 + 16, y0 + 2, "wd2"); hline(a, x0, x0 + 16, y0 + 1, "wd1")
        rect(a, x0, y0 + 3, x0 + 16, y0 + 5, "wd1"); hline(a, x0, x0 + 16, y0 + 3, "wd2")
        for x in (x0 + 1, x0 + 14):
            vline(a, x, y0 + 5, y0 + 8, "ir1")
        hline(a, x0 + 1, x0 + 17, y0 + 8, "ln0")
    # teal pavement light studs along the promenade (2537 civic lighting)
    for x in range(74, 600, 28):
        for y in (183, 202):
            if not (300 < x < 340):
                pset(a, x, y, "tl4"); pset(a, x + 1, y, "tl2"); pset(a, x - 1, y, "tl2")
    # Broadway and Park Row gates at the promenade ends
    for (x0, x1) in [(36, 46), (608, 618)]:
        rect(a, x0, 152, x1, 210, "st4"); vline(a, x0, 152, 210, "st5"); vline(a, x1 - 1, 152, 210, "st2")
        hline(a, x0 - 1, x1 + 1, 150, "st6"); hline(a, x0, x1, 151, "st2")
        for y in range(156, 210, 5):
            hline(a, x0 + 1, x1 - 1, y, "st3")
    for x in range(18, 36, 3):
        vline(a, x, 186, 212, "ir1"); pset(a, x, 185, "ir4")
    hline(a, 18, 36, 190, "ir3"); hline(a, 18, 36, 206, "ir3")
    for x in range(618, 640, 3):
        vline(a, x, 180, 206, "ir1"); pset(a, x, 179, "ir4")
    hline(a, 618, 640, 184, "ir3"); hline(a, 618, 640, 200, "ir3")


# ============================================================================ Y-sorted occluders
def lamp_post(a, x, base, height=46):
    top = base - height
    rect(a, x - 2, base - 4, x + 3, base, "ir1"); hline(a, x - 2, x + 3, base - 4, "ir3")
    vline(a, x, top + 8, base - 4, "ir1"); vline(a, x - 1, top + 10, base - 4, "ir3")
    hline(a, x - 1, x + 2, top + 22, "ir3")
    hline(a, x - 1, x + 2, base - 18, "tl3")                            # 2537 service ring
    rect(a, x - 2, top + 2, x + 3, top + 8, "wl3")
    vline(a, x - 2, top + 2, top + 8, "wl2"); pset(a, x, top + 4, "wl4")
    hline(a, x - 3, x + 4, top + 8, "ir1"); hline(a, x - 2, x + 3, top + 1, "ir1")
    pset(a, x, top, "ir2")


def candelabra(a, x, base):
    """Mould-style cast-iron candelabrum on the basin coping: pedestal, post, five globes."""
    rect(a, x - 2, base - 5, x + 3, base, "ir1"); hline(a, x - 2, x + 3, base - 5, "ir3"); pset(a, x - 2, base - 3, "ir3")
    vline(a, x, base - 28, base - 5, "ir1"); vline(a, x - 1, base - 26, base - 5, "ir2")
    pset(a, x + 1, base - 14, "gd1"); pset(a, x - 1, base - 14, "gd2")
    hline(a, x - 5, x + 6, base - 25, "ir1")
    for gx, gy in [(x - 5, base - 28), (x + 5, base - 28), (x, base - 32)]:
        rect(a, gx - 1, gy - 1, gx + 2, gy + 2, "wl3"); pset(a, gx - 1, gy - 1, "wl4"); pset(a, gx + 1, gy + 1, "wl2")
        pset(a, gx, gy + 2, "ir1")
    pset(a, x, base - 35, "gd2")


def draw_lamps_prom(a):
    for x in LAMPS_PROM:
        lamp_post(a, x, 208)


def draw_lamps_axis(a):
    for x in LAMPS_AXIS_X:
        lamp_post(a, x, 212, 50)


def draw_fountain_centre(a):
    cx = FOUNT[0]
    rect(a, cx - 5, 254, cx + 6, 266, "cu1")
    vline(a, cx - 5, 254, 266, "cu3"); vline(a, cx + 5, 254, 266, "cu0")
    hline(a, cx - 6, cx + 7, 265, "cu0"); hline(a, cx - 6, cx + 7, 254, "cu2")
    for y in range(248, 254):                                          # lower bowl
        hw = 13 * (1 - (y - 248) / 7.0) + 2
        hline(a, int(cx - hw), int(cx + hw) + 1, y, "cu1")
        pset(a, int(cx - hw), y, "cu3")
    hline(a, cx - 15, cx + 16, 247, "cu3"); hline(a, cx - 13, cx + 14, 246, "wa4"); pset(a, cx - 14, 247, "cu4")
    for x in range(cx - 14, cx + 16, 3):                               # sheet falling from the rim
        vline(a, x, 249, 255 + (x % 5), "wa4")
        pset(a, x, 256 + (x % 5), "wa5")
    vline(a, cx - 1, 232, 247, "cu2"); vline(a, cx, 232, 247, "cu1"); vline(a, cx + 1, 232, 247, "cu0")
    hline(a, cx - 2, cx + 3, 240, "cu3"); hline(a, cx - 2, cx + 3, 241, "cu0")
    for y in range(232, 236):                                          # upper bowl
        hw = 7 * (1 - (y - 232) / 5.0) + 1
        hline(a, int(cx - hw), int(cx + hw) + 1, y, "cu1"); pset(a, int(cx - hw), y, "cu3")
    hline(a, cx - 8, cx + 9, 231, "wa4")
    for x in (cx - 7, cx - 4, cx + 4, cx + 7):
        vline(a, x, 233, 240, "wa4"); pset(a, x, 241, "wa5")
    plume = poly_mask([(cx - 1, 230), (cx - 3, 226), (cx - 2, 220), (cx, 216), (cx + 2, 220), (cx + 3, 226), (cx + 1, 230)])
    fillm(a, plume, "wa4")
    fillm(a, plume & (XX <= cx), "wa5")
    pset(a, cx, 217, "fw1")
    for (dx, dy) in [(-5, 223), (5, 225), (-4, 229), (6, 220)]:
        pset(a, cx + dx, dy, "wa5"); pset(a, cx + dx, dy + 1, "wa4")


def draw_fount_lamp_n(a):
    candelabra(a, *FOUNT_LAMPS[0])


def draw_fount_lamps_ew(a):
    candelabra(a, *FOUNT_LAMPS[1]); candelabra(a, *FOUNT_LAMPS[2])


def draw_fount_lamp_s(a):
    candelabra(a, *FOUNT_LAMPS[3])


def draw_terminal(a):
    x0, x1 = 498, 514
    rect(a, x0 - 1, 262, x1 + 1, 267, "bs2"); hline(a, x0 - 1, x1 + 1, 262, "bs4"); hline(a, x0 - 1, x1 + 1, 266, "bs1")
    rect(a, x0 + 2, 236, x1 - 2, 262, "bs1")
    vline(a, x0 + 2, 236, 262, "bs3"); vline(a, x1 - 3, 236, 262, "bs0")
    rect(a, x0 + 4, 240, x1 - 4, 252, "tl1")
    rect(a, x0 + 5, 241, x1 - 5, 251, "tl2")
    for y in (243, 246, 249):
        hline(a, x0 + 5, x1 - 6, y, "tl4")
    pset(a, x0 + 5, 241, "tl5")
    hline(a, x0 + 1, x1 - 1, 235, "cu3"); hline(a, x0 + 2, x1 - 2, 234, "cu2")
    pset(a, (x0 + x1) // 2, 232, "tl4"); vline(a, (x0 + x1) // 2, 233, 234, "ir2")
    hline(a, x0 + 3, x1 - 3, 256, "am2")


def draw_elm(a):
    tx, base = ELM
    for y in range(240, base):
        w = 5 + (3 if y > base - 6 else 0) + (1 if y > base - 3 else 0)
        hline(a, tx - w, tx + w + 1, y, "bk2")
        pset(a, tx - w, y, "bk3"); pset(a, tx - w + 1, y, "bk3")
        hline(a, tx + w - 2, tx + w + 1, y, "bk0")
        if y % 5 == 0:
            pset(a, tx - 1, y, "bk1"); pset(a, tx + 2, y + 1, "bk1")
    hline(a, tx - 9, tx + 10, base - 1, "bk1")
    line(a, tx - 2, 246, tx - 14, 232, "bk2"); line(a, tx + 3, 244, tx + 16, 230, "bk1")
    crown(a, [(392, 228, 30, 17), (424, 224, 26, 15), (368, 240, 18, 11), (442, 238, 16, 11), (404, 246, 28, 9),
              (410, 218, 20, 8)], "elm-se", spacing=5.0, rmin=2.6, rmax=4.8, bias=-0.05, hi=7)


def draw_foreground(a):
    # low iron hoop fence and dark clipped hedge along the bottom edge (axis and plaza mouths left open)
    open_x = box(290, 0, 352, H)
    m = (YY >= 310) & ~open_x
    crown(a, [(x, 318, 8, 7) for x in range(0, 640, 9)], "fg-hedge", lo=0, hi=4, spacing=3.4, rmin=1.6, rmax=2.8,
          clip=m, bias=-0.12)
    for x in range(0, 640):
        if open_x[0, x]:
            continue
        y = 308 + int(round(2 * abs(math.sin((x % 12) / 12 * math.pi))))
        pset(a, x, y, "ir1")
        if x % 12 == 0:
            vline(a, x, 308, 318, "ir1")
    # corner trees framing the view (cool, dark foreground values)
    crown(a, [(20, 290, 34, 28), (58, 306, 28, 16), (6, 254, 22, 26)], "fg-sw", lo=0, hi=5, bias=-0.14,
          spacing=5.0)
    crown(a, [(622, 282, 32, 32), (592, 306, 28, 16), (636, 242, 18, 28)], "fg-se", lo=0, hi=5, bias=-0.14,
          spacing=5.0)


def draw_guides(a):
    wk = walk_mask()
    fillm(a, edge(wk), "tl4")
    for k, (x, y) in HOTSPOTS.items():
        hline(a, x - 3, x + 4, y, "am3"); vline(a, x, y - 3, y + 4, "am3")
    hline(a, 0, W, UI_TOP, "fr1"); hline(a, 0, W, UI_BOTTOM, "fr1")


# ============================================================================ scene assembly
BASE_LAYERS = [("sky-skyline", draw_sky_skyline), ("trees-back", draw_trees_back), ("forecourt", draw_forecourt),
               ("city-hall", draw_city_hall), ("trees-north", draw_trees_north), ("lawn", draw_lawn),
               ("paving", draw_paving), ("planting", draw_planting)]
POST_LAYERS = [("fountain-basin", draw_basin), ("fence-gate", draw_fence), ("fixtures", draw_fixtures)]
YSORT_LAYERS = [("lamps-promenade-s", draw_lamps_prom, 208), ("lamps-axis", draw_lamps_axis, 212),
                ("fountain-lamp-n", draw_fount_lamp_n, 238), ("fountain-centre", draw_fountain_centre, 266),
                ("fountain-lamps-ew", draw_fount_lamps_ew, 265), ("report-terminal", draw_terminal, 267),
                ("fountain-lamp-s", draw_fount_lamp_s, 292), ("tree-se-elm", draw_elm, ELM[1]),
                ("foreground", draw_foreground, 340)]
CANOPY = ["tree-se-elm"]


def scene():
    L, order = {}, []
    for n, fn in BASE_LAYERS:
        a = new(); fn(a); L[n] = a; order.append(n)
    ground = new()
    for n in ("lawn", "paving", "planting"):
        m = L[n] >= 0
        ground[m] = L[n][m]
    sh = new(); draw_ground_shadows(sh, ground, L["planting"] >= 0); L["ground-shadows"] = sh; order.append("ground-shadows")
    for n, fn in POST_LAYERS:
        a = new(); fn(a); L[n] = a; order.append(n)
    base = list(order)
    ysort = {}
    for n, fn, pv in YSORT_LAYERS:
        a = new(); fn(a); L[n] = a; order.append(n); ysort[n] = pv
    g = new(); draw_guides(g); L["guides"] = g; order.append("guides")
    origin = {n: "native: authored by this tool from the hand-written palette (no imported pixels)" for n in order}
    origin["guides"] = "native: hidden locked guide (walk outline, hotspots, UI rows)"
    return {"layers": L, "order": order, "base": base, "ysort": ysort, "canopy": CANOPY, "walk": walk_mask(),
            "origin": origin}


# ============================================================================ artefacts
def to_rgba(idx):
    a = np.zeros((H, W, 4), np.uint8)
    m = idx >= 0
    a[m, :3] = PAL_RGB[idx[m]].astype(np.uint8)
    a[m, 3] = 255
    return a


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def decode(png):
    return np.array(Image.open(io.BytesIO(png)).convert("RGBA"))


def composite_rgba(rgba, names):
    out = rgba[names[0]].copy()
    for n in names[1:]:
        m = rgba[n][..., 3] == 255
        out[m] = rgba[n][m]
    return out


DT = (2026, 10, 17, 17, 59, 0)


def zput(z, name, payload, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, DT)
    zi.compress_type = method
    z.writestr(zi, payload)


def make_ora(order, rgba, comp_png):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.5" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for n in reversed(order):
        vis = "hidden" if n == "guides" else "visible"
        stack.append(f'<layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.000" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>", ""]
    thumb = Image.open(io.BytesIO(comp_png)).convert("RGBA").resize((256, 144), Image.NEAREST)
    tb = io.BytesIO(); thumb.save(tb, "PNG")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "mimetype", b"image/openraster", zipfile.ZIP_STORED)
        zput(z, "stack.xml", "\n".join(stack).encode())
        for n in order:
            zput(z, f"data/{n}.png", png_bytes(rgba[n]))
        zput(z, "mergedimage.png", comp_png)
        zput(z, "Thumbnails/thumbnail.png", tb.getvalue())
    return buf.getvalue()


def make_pxo(order, rgba, comp_png):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in order]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in order], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(f"{SLUG}_{AREA}_export_{VER}_{STAMP}-{RUN_ID}"),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    palette = {"name": f"{SLUG}_{AREA}_palette_{VER}", "comment": "hand-written native palette (v07)",
               "width": 8, "height": (len(PALETTE) + 7) // 8,
               "colors": [{"color": "(%.6f, %.6f, %.6f, 1.0)" % tuple(c / 255.0 for c in PAL_RGB[i]), "index": i}
                          for i in range(len(PALETTE))]}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": 0, "export_profile": export_profile,
            "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json, "license": "", "metadata": {},
            "next_keyframe_id": 0, "palettes": [palette], "pixelorama_version": "v1.2.3-stable",
            "project_current_palette_name": "", "pxo_version": 7, "reference_images": [], "size_x": W, "size_y": H,
            "symmetry_points": [W - 1.0, H - 1.0], "tags": [], "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0,
            "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "",
            "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "data.json", json.dumps(data, separators=(",", ":")))
        zput(z, "mimetype", "application/x-pixelorama")
        zput(z, "preview.png", comp_png)
        zput(z, "image_data/frames/1/", b"")
        for li, n in enumerate(order, start=1):
            zput(z, f"image_data/frames/1/layer_{li}", np.ascontiguousarray(rgba[n]).tobytes())
            zput(z, f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_gpl():
    lines = ["GIMP Palette", f"Name: {SLUG}_{AREA}_palette_{VER}", "Columns: 8", "#"]
    for n, h in PALETTE:
        r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
        lines.append(f"{r:3d} {g:3d} {b:3d}\t{n}")
    return ("\n".join(lines) + "\n").encode()


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


RT_SHORT = {"lamps-promenade-s": "lamps-pr", "lamps-axis": "lamps-ax", "fountain-lamp-n": "f-lamp-n",
            "fountain-centre": "fount", "fountain-lamps-ew": "f-lamp-ew", "report-terminal": "term",
            "fountain-lamp-s": "f-lamp-s", "tree-se-elm": "elm", "foreground": "fg"}   # short: .import paths < MAX_PATH


def rt_name(layer):
    return "rt-y-" + RT_SHORT[layer]


def scene_data(sc, nm):
    return {
        "run": RUN, "status": "UNAPPROVED candidate; scene art not accepted (science scenes stay 3/12)",
        "source": "native code-authored pixel layers from a hand-written palette; no imported or generated pixels",
        "canvas": [W, H], "ui_rows": {"header_end": UI_TOP, "footer_start": UI_BOTTOM},
        "base": nm["rt-base"], "walkmask": nm["walkmask"],
        "ysort": [{"name": n, "png": nm[rt_name(n)], "pivot": int(sc["ysort"][n]), "canopy": n in sc["canopy"]}
                  for n in sorted(sc["ysort"], key=lambda n: (sc["ysort"][n], n))],
        "hotspots": {k: list(v) for k, v in HOTSPOTS.items()},
        "legacy_positions": [{"from": list(LEGACY_SPAWN), "to": list(LEGACY_LANDING),
                              "why": "pre-navigation generic area SPAWN in old city saves; the old plate recovered it "
                                     "onto the west road at (82,203.5); v07 keeps that exact spot as standable west "
                                     "apron paving, so old saves land where they always did"}],
        "canopy_reveal": REVEAL,
    }


def tres_bytes(sj):
    text = json.dumps(sj, separators=(",", ":"), sort_keys=True)
    esc = text.replace("\\", "\\\\").replace('"', '\\"')
    return ('[gd_resource type="Resource" format=3]\n\n[resource]\nmetadata/scene_json = "' + esc + '"\n').encode()


def names(sc):
    nm = {"pxo": fname("scene-layers", "pxo"), "ora": fname("scene-layers", "ora"), "flat": fname("flat", "png"),
          "gpl": fname("palette", "gpl"), "walkmask": fname("walkmask", "png"), "scene": fname("scene", "json"),
          "tres": fname("scene", "tres"), "rt-base": fname("rt-base", "png"),
          "manifest": fname("manifest", "json"), "report": fname("check-report", "json"),
          "provenance": fname("provenance-report", "json")}
    for n in sc["ysort"]:
        nm[rt_name(n)] = fname(rt_name(n), "png")
    return nm


def artefacts(sc):
    order = sc["order"]
    rgba = {n: to_rgba(sc["layers"][n]) for n in order}
    art = [n for n in order if n != "guides"]
    flat = composite_rgba(rgba, art)
    flat_png = png_bytes(flat)
    nm = names(sc)
    files = {"pxo": make_pxo(order, rgba, flat_png), "ora": make_ora(order, rgba, flat_png), "flat": flat_png,
             "gpl": make_gpl()}
    wm = np.zeros((H, W, 4), np.uint8); wm[sc["walk"]] = 255
    files["walkmask"] = png_bytes(wm)
    files["rt-base"] = png_bytes(composite_rgba(rgba, sc["base"]))
    for n in sc["ysort"]:
        files[rt_name(n)] = png_bytes(rgba[n])
    sj = scene_data(sc, nm)
    files["scene"] = (json.dumps(sj, indent=2) + "\n").encode()
    files["tres"] = tres_bytes(sj)
    return rgba, flat, files, nm


# ============================================================================ walking simulation (mirrors the runtime)
def walkable_at(walk, x, y):
    xi, yi = int(math.floor(x + 0.5)), int(math.floor(y + 0.5))
    return 0 <= xi < W and 0 <= yi < H and bool(walk[yi, xi])


def slide(walk, frm, to):
    pos = list(frm)
    dx, dy = to[0] - frm[0], to[1] - frm[1]
    steps = max(1, math.ceil(math.hypot(dx, dy) / 2.0))
    sx, sy = dx / steps, dy / steps
    for _ in range(steps):
        cx, cy = pos[0] + sx, pos[1] + sy
        if walkable_at(walk, cx, cy):
            pos = [cx, cy]
        elif walkable_at(walk, cx, pos[1]):
            pos[0] = cx
        elif walkable_at(walk, pos[0], cy):
            pos[1] = cy
    return pos


def smoke_walk(walk, start, target, speed=140.0 / 60.0):
    pos = list(start)
    for step_i in range(600):
        if math.hypot(target[0] - pos[0], target[1] - pos[1]) < 2.5:
            return True, pos, step_i
        d = (target[0] - pos[0], target[1] - pos[1])
        n = math.hypot(*d)
        v = (d[0] / n, d[1] / n)
        pos = slide(walk, pos, (pos[0] + v[0] * speed, pos[1] + v[1] * speed))
    return False, pos, 600


def flood(mask, start):
    seen = np.zeros_like(mask)
    x, y = start
    if not mask[y, x]:
        return seen
    seen[y, x] = True
    st = [(y, x)]
    while st:
        cy, cx = st.pop()
        for ny, nx in ((cy + 1, cx), (cy - 1, cx), (cy, cx + 1), (cy, cx - 1)):
            if 0 <= ny < H and 0 <= nx < W and mask[ny, nx] and not seen[ny, nx]:
                seen[ny, nx] = True
                st.append((ny, nx))
    return seen


def heroine_48():
    """Approved v8 south static at the runtime's 0.5 display scale: 48 logical px tall (preview/check only)."""
    a = np.array(Image.open(_fs(rp(HEROINE_REL))).convert("RGBA"))
    small = a[1::2, 1::2]
    ys, xs = np.nonzero(small[..., 3] > 0)
    spr = small[ys.min():ys.max() + 1, xs.min():xs.max() + 1].copy()
    spr[..., 3] = np.where(spr[..., 3] > 127, 255, 0)
    return spr


# ============================================================================ checks
OCCLUDERS_NEEDING_BEHIND_CASE = ["tree-se-elm", "fountain-centre", "fountain-lamp-n", "lamps-promenade-s",
                                 "lamps-axis", "report-terminal"]


def static_checks(sc, rgba, flat):
    v, m = {}, {}
    order, walk = sc["order"], sc["walk"]
    v["layers_are_640x360_binary_alpha"] = all(rgba[n].shape == (H, W, 4) and set(np.unique(rgba[n][..., 3])) <=
                                               {0, 255} for n in order)
    v["base_is_opaque"] = bool((composite_rgba(rgba, sc["base"])[..., 3] == 255).all())
    used = {tuple(c) for c in flat[..., :3].reshape(-1, 3).tolist()}
    v["flat_uses_hand_written_palette_only"] = used <= {tuple(int(x) for x in c) for c in PAL_RGB}
    m["palette_colours"] = len(PALETTE); m["palette_colours_used"] = len(used)
    reach = flood(walk, HOTSPOTS["spawn"])
    m["walkable_texels"] = int(walk.sum()); m["reachable_texels"] = int(reach.sum())
    v["walk_mask_single_component_from_spawn"] = int(reach.sum()) == int(walk.sum())
    hs = {k: bool(walk[y, x]) for k, (x, y) in HOTSPOTS.items()}
    m["hotspot_standable"] = hs
    v["every_hotspot_exactly_standable"] = all(hs.values())
    v["walk_inside_visible_band"] = bool((~walk[:UI_TOP + 48]).all() and (~walk[UI_BOTTOM - 11:]).all())
    v["no_walkable_feet_in_fountain_basin"] = not bool((walk & ell(FOUNT[0], FOUNT[1], *BASIN_COPING)).any())
    lx, ly = LEGACY_SPAWN
    v["legacy_spawn_not_standable"] = not walk[ly, lx]
    v["legacy_landing_standable"] = walkable_at(walk, *LEGACY_LANDING) and bool(reach[204, 82])
    v["legacy_landing_below_assist_blocked_at_204"] = (not walkable_at(walk, 120, 204)) and walkable_at(walk, 120, 203)
    U = paving_union()
    v["walkable_feet_on_paving"] = not bool((walk & ~U).any())
    m["feet_margin_from_paving_edge_min_px"] = int(min(
        np.argmax(~U[y, x::-1]) if (~U[y, x::-1]).any() else 99 for y, x in zip(*np.nonzero(walk))))
    seq = [HOTSPOTS["spawn"], (285, 267), (378, 181), (120, 187), (282, 180), (558, 166), (470, 247), (120, 187)]
    walks_ok, pos = [], seq[0]
    for t in seq[1:]:
        ok, pos, steps = smoke_walk(walk, pos, t)
        walks_ok.append({"to": t, "ok": ok, "steps": steps, "end": [round(pos[0], 1), round(pos[1], 1)]})
        if not ok:
            break
    m["integration_smoke_walks"] = walks_ok
    v["integration_smoke_straight_walks_succeed"] = all(w["ok"] for w in walks_ok) and len(walks_ok) == len(seq) - 1
    end = slide(walk, (120.0, 187.0), (120.0, 187.0 + 140.0))
    m["assist_down_block_y"] = round(end[1], 2)
    v["assist_down_blocked_before_204"] = end[1] < 204.0
    ys = np.zeros((H, W), bool)
    for n in sc["ysort"]:
        ys |= rgba[n][..., 3] == 255
    clear = {k: int((ys & ell(x, y, 11.5, 11.5)).sum()) for k, (x, y) in HOTSPOTS.items()
             if k not in ("spawn", "liang_xu")}
    m["marker_pixels_under_ysort"] = clear
    v["hotspot_markers_not_under_ysort_layers"] = all(c == 0 for c in clear.values())
    spr = heroine_48()
    m["heroine_height_px"] = int(spr.shape[0])
    v["heroine_48px"] = spr.shape[0] == 48
    behind = {}
    for n, pv in sc["ysort"].items():
        a = rgba[n][..., 3] == 255
        best = None
        for y in range(pv - 1, max(UI_TOP + 48, pv - 130), -1):
            xs = np.nonzero(walk[y] & a[max(0, y - 30):y + 1].any(0))[0]
            for x in xs[::2]:
                cover = int(a[max(0, y - 44):y + 3, max(0, x - 7):x + 8].sum())
                if cover > 6 and (best is None or cover > best[2]):
                    best = (int(x), int(y), cover)
            if best:
                break
        behind[n] = best
    m["behind_case_per_ysort_layer"] = behind
    v["occluders_have_a_walkable_behind_case"] = all(behind.get(n) is not None for n in OCCLUDERS_NEEDING_BEHIND_CASE)
    # foreground never sits over walkable feet (it is framing, not an occluder of play)
    fg = rgba["foreground"][..., 3] == 255
    m["foreground_over_feet_px"] = int((fg & dilate(walk, 2)).sum())
    v["foreground_clear_of_walkable_feet"] = m["foreground_over_feet_px"] == 0
    # worst crown cover of the hero body over walkable feet (pre-reveal)
    worst = (0.0, None)
    elm = rgba["tree-se-elm"][..., 3] == 255
    for y, x in zip(*np.nonzero(walk[::2, ::2])):
        y, x = 2 * y, 2 * x
        if y >= sc["ysort"]["tree-se-elm"]:
            continue
        box_ = elm[max(0, y - 44):y + 3:2, max(0, x - 7):x + 8:2]
        c = float(box_.mean()) if box_.size else 0.0
        if c > worst[0]:
            worst = (c, [int(x), int(y)])
    m["se_elm_worst_body_cover"] = {"cover": round(worst[0], 3), "foot": worst[1]}
    m["ysort_pivots"] = {n: int(p) for n, p in sc["ysort"].items()}
    m["layer_origin"] = sc["origin"]
    m["visible_pixel_share_by_origin"] = {"native code-authored": 1.0}
    return v, m


def reveal_hole(foot, strength=1.0):
    """Mirror of the runtime canopy shader: a dithered hole around the hero's body (logical pixels)."""
    rx, ry = REVEAL["radius"]
    d = np.hypot((XX + 0.5 - foot[0]) / rx, (YY + 0.5 - (foot[1] - REVEAL["lift"])) / ry)
    t = strength * (1.0 - np.clip((d - 0.75) / 0.25, 0, 1))
    return BAYER4[YY % 4, XX % 4] < t * REVEAL["max_hole"]


def paste(dst, spr, x, ybase):
    h, w = spr.shape[:2]
    x0, y0 = x - w // 2, ybase + 4 - h
    for j in range(h):
        for i in range(w):
            if spr[j, i, 3] and 0 <= x0 + i < W and 0 <= y0 + j < H:
                dst[y0 + j, x0 + i] = spr[j, i]


def still(rgba, sc, spr, foot, reveal=True):
    out = composite_rgba(rgba, sc["base"])
    placed = False
    for n in sorted(sc["ysort"], key=lambda n: (sc["ysort"][n], n)):
        if not placed and foot[1] < sc["ysort"][n]:
            paste(out, spr, *foot); placed = True
        m = rgba[n][..., 3] == 255
        if reveal and n in sc["canopy"] and foot[1] < sc["ysort"][n]:
            m = m & ~reveal_hole(foot)
        out[m] = rgba[n][m]
    if not placed:
        paste(out, spr, *foot)
    return out


def preview(outdir):
    os.makedirs(outdir, exist_ok=True)
    sc = scene()
    rgba, flat, files, nm = artefacts(sc)
    spr = heroine_48()
    ui = flat.copy(); ui[:UI_TOP, :, :3] = (13, 23, 35); ui[UI_BOTTOM:, :, :3] = (13, 23, 35)
    Image.fromarray(ui).save(os.path.join(outdir, "flat.png"))
    Image.fromarray(ui).resize((W * 2, H * 2), Image.NEAREST).save(os.path.join(outdir, "flat-2x.png"))
    for k, foot in (("spawn", (340, 253)), ("ledger", (120, 187)), ("fount-n", (176, 232)), ("report", (470, 247)),
                    ("kiosk", (558, 166)), ("elm", (404, 262)), ("liang", (282, 186))):
        s = still(rgba, sc, spr, foot)
        s[:UI_TOP, :, :3] = (13, 23, 35); s[UI_BOTTOM:, :, :3] = (13, 23, 35)
        Image.fromarray(s).save(os.path.join(outdir, f"still-{k}.png"))
    g = composite_rgba(rgba, sc["order"])
    Image.fromarray(g).resize((W * 2, H * 2), Image.NEAREST).save(os.path.join(outdir, "guides-2x.png"))
    rt = os.path.join(outdir, "rt")
    os.makedirs(rt, exist_ok=True)
    for k, b in files.items():
        with open(_fs(os.path.join(rt, nm[k])), "wb") as f:
            f.write(b)
    v, m = static_checks(sc, rgba, flat)
    print(json.dumps({"verdicts": v, "metrics": {k: m[k] for k in m if k != "layer_origin"}}, indent=1, default=str))


# ============================================================================ provenance (no generated-reference pixel import)
_AUDIT = {"on": False, "opened": []}


def _audit_hook(event, args):
    if _AUDIT["on"] and event == "open" and args and isinstance(args[0], (str, bytes, os.PathLike)):
        _AUDIT["opened"].append(os.fsdecode(args[0]))


def build_under_audit():
    """Build the scene and every artefact while recording every file the process opens."""
    sys.addaudithook(_audit_hook)
    _AUDIT["opened"].clear(); _AUDIT["on"] = True
    try:
        sc = scene()
        rgba, flat, files, nm = artefacts(sc)
    finally:
        _AUDIT["on"] = False
    roots = {os.path.normcase(os.path.abspath(p)) for p in (sys.prefix, sys.base_prefix, sys.exec_prefix)}
    data_files = [p for p in _AUDIT["opened"]
                  if not any(os.path.normcase(os.path.abspath(p)).startswith(r) for r in roots)
                  and not p.lower().endswith((".py", ".pyc", ".pyd", ".dll"))]
    return sc, rgba, flat, files, nm, {"files_opened_total": len(_AUDIT["opened"]), "data_files_opened": data_files}


def provenance(flat, audit):
    rep = {"builder_audit": audit, "gates": {}, "metrics": {}}
    rep["gates"]["builder_opened_no_image_or_data_file"] = len(audit["data_files_opened"]) == 0
    src = open(os.path.abspath(__file__), "rb").read().decode("utf-8")
    body = src.split("# ============================================================================ artefacts")[0]
    rep["gates"]["art_code_names_no_reference_or_v06_file"] = all(
        s not in body.split("PALETTE = [")[1] for s in ("style-alignment-reference", "nyc-chp-v06", "Image.open"))
    v06_flat_path = os.path.join(rp(V06_DIR_REL), f"{SLUG}_{AREA}_flat_{V06_TAG}.png")
    v06_gpl_path = os.path.join(rp(V06_DIR_REL), f"{SLUG}_{AREA}_palette_{V06_TAG}.gpl")
    ref_path = rp(REF_REL)
    mine = flat[..., :3].astype(np.int32)
    lum = lambda x: x[..., 0] * 0.299 + x[..., 1] * 0.587 + x[..., 2] * 0.114
    band = slice(UI_TOP, UI_BOTTOM)
    if os.path.exists(_fs(v06_flat_path)):
        v06 = np.array(Image.open(_fs(v06_flat_path)).convert("RGB")).astype(np.int32)
        same = (mine == v06).all(-1)
        rep["metrics"]["v06_flat_exact_rgb_match_share_visible"] = round(float(same[band].mean()), 5)
        # identical non-uniform 4x4 patches at the same position = copied content
        hits = 0
        for y in range(UI_TOP, UI_BOTTOM - 3, 2):
            for x in range(0, W - 3, 2):
                p = mine[y:y + 4, x:x + 4]
                if len({tuple(c) for c in p.reshape(-1, 3).tolist()}) > 1 and (p == v06[y:y + 4, x:x + 4]).all():
                    hits += 1
        rep["metrics"]["v06_identical_nonuniform_4x4_patches"] = hits
        rep["metrics"]["v06_luma_correlation_visible"] = round(float(np.corrcoef(lum(mine[band]).ravel(),
                                                                                 lum(v06[band]).ravel())[0, 1]), 4)
        rep["gates"]["no_v06_pixel_content_reused"] = hits == 0 and rep["metrics"][
            "v06_flat_exact_rgb_match_share_visible"] < 0.01
        v06_cols = {tuple(c) for c in v06.reshape(-1, 3).tolist()}
        rep["metrics"]["palette_colours_also_in_v06_flat"] = sum(1 for c in PAL_RGB.astype(int).tolist()
                                                                 if tuple(c) in v06_cols)
    else:
        rep["metrics"]["v06_baseline_present"] = False
    if os.path.exists(_fs(v06_gpl_path)):
        gl = [l.split() for l in read_bytes(v06_gpl_path).decode().splitlines()[4:] if l.strip()]
        v06_pal = {tuple(int(t) for t in l[:3]) for l in gl}
        rep["metrics"]["palette_colours_equal_to_a_v06_palette_colour"] = sum(
            1 for c in PAL_RGB.astype(int).tolist() if tuple(c) in v06_pal)
    if os.path.exists(_fs(ref_path)):
        ref_bytes = read_bytes(ref_path)
        rep["metrics"]["reference_sha256_matches_pin"] = sha(ref_bytes) == REF_SHA
        ref = np.array(Image.open(io.BytesIO(ref_bytes)).convert("RGB"))
        ref_cols = set(map(tuple, np.unique(ref.reshape(-1, 3), axis=0).tolist()))
        rep["metrics"]["reference_distinct_colours"] = len(ref_cols)
        rep["metrics"]["palette_colours_present_in_reference"] = sum(1 for c in PAL_RGB.astype(int).tolist()
                                                                     if tuple(c) in ref_cols)
        # control: the same palette nudged by small fixed offsets hits the dense continuous-colour reference at a
        # similar rate, so exact hits measure the reference's colour density, not sampling
        ctrl = []
        for off in ((2, -1, 1), (-2, 1, -1), (1, 2, -2), (-1, -2, 2), (3, 0, -3), (0, 3, 3)):
            ctrl.append(sum(1 for c in PAL_RGB.astype(int).tolist()
                            if tuple(min(255, max(0, c[i] + off[i])) for i in range(3)) in ref_cols))
        rep["metrics"]["control_nudged_palette_hits_in_reference"] = ctrl
        rep["metrics"]["palette_colours_used_in_flat_present_in_reference_pixel_share"] = round(float(
            np.isin(mine[band].reshape(-1, 3) @ np.array([65536, 256, 1]),
                    np.array([c[0] * 65536 + c[1] * 256 + c[2] for c in ref_cols])).mean()), 4)
        full = np.array(Image.fromarray(ref).resize((W, H), Image.BOX)).astype(np.int32)
        rep["metrics"]["reference_box640_luma_correlation_visible"] = round(float(np.corrcoef(
            lum(mine[band]).ravel(), lum(full[band]).ravel())[0, 1]), 4)
        near = (np.abs(mine - full).sum(-1) <= 6)
        rep["metrics"]["reference_box640_near_rgb_share_visible"] = round(float(near[band].mean()), 5)
    rep["note"] = ("The builder opens no image (audit hook). The v06 flat and the generated reference are opened only "
                   "here, after the build, to measure that nothing was copied.")
    return rep


def manifest(sc, files, nm, metrics):
    return {
        "run": RUN, "status": "UNAPPROVED candidate (scene environment not accepted; science scenes stay 3/12)",
        "author": "Claude Code (Opus 5.5) on the signed-in claude.ai Max subscription; no API key, no image model",
        "tool": "tools/" + os.path.basename(os.path.abspath(__file__)),
        "source": "native code-authored pixel art: hand-written palette, hand-placed architecture coordinates and "
                  "crown lobes, deterministic material brushes; no imported, generated, sampled or traced pixels; "
                  "not hand-painted in a GUI",
        "conceptual_guides_not_pixel_sources": [
            "real City Hall / City Hall Park form (central pavilion + portico, projecting wings, roof balustrades, "
            "cupola with clock; Mould fountain with cast-iron candelabra; central walk, lawns, trees)",
            "docs/qa/...style-alignment-visual-direction_unapproved-v01_20261016-225800-2a4e7c91.md (light/material "
            "priorities); the generated reference was not opened by the builder"],
        "audit_baseline_preserved": V06_DIR_REL,
        "canvas": [W, H], "runtime_ui_rows": [UI_TOP, UI_BOTTOM],
        "layers_bottom_to_top": sc["order"], "layer_origin": sc["origin"],
        "ysort_pivots": {n: int(p) for n, p in sc["ysort"].items()},
        "palette": {"colours": len(PALETTE), "names": PAL_NAMES},
        "hotspots_unchanged_from_runtime": {k: list(v) for k, v in HOTSPOTS.items()},
        "files": {k: {"name": nm[k], "sha256": sha_text(b) if k in ("gpl", "scene", "tres") else sha(b),
                      "hash": "sha256-text-lf-v1" if k in ("gpl", "scene", "tres") else "sha256-bytes"}
                  for k, b in sorted(files.items())},
    }


def build():
    sc, rgba, flat, files, nm, audit = build_under_audit()
    v, m = static_checks(sc, rgba, flat)
    if not all(v.values()) or audit["data_files_opened"]:
        print(json.dumps(v, indent=1), audit)
        raise SystemExit("static gates fail; not writing")
    cand = rp(CAND_REL)
    os.makedirs(_fs(cand), exist_ok=True)
    longest = 0
    for k, b in files.items():
        p = os.path.join(cand, nm[k])
        longest = max(longest, len(os.path.abspath(p)) + len(".import"))
        print(write_new(p, b), nm[k])
    mb = (json.dumps(manifest(sc, files, nm, m), indent=2) + "\n").encode()
    print(write_new(os.path.join(cand, nm["manifest"]), mb), nm["manifest"])
    print("longest path incl. .import:", longest)


def run_pixelorama(exe, args, fake_appdata):
    env = dict(os.environ)
    env["APPDATA"] = fake_appdata
    t0 = time.time()
    p = subprocess.run([exe, "--headless", "--quit", "--"] + args, env=env, capture_output=True, timeout=180)
    return {"rc": p.returncode, "seconds": round(time.time() - t0, 2)}


def snapshot(root):
    out = {}
    if os.path.isdir(root):
        for dp, _, fs in os.walk(root):
            for f in fs:
                q = os.path.join(dp, f)
                try:
                    out[os.path.relpath(q, root)] = os.path.getmtime(q)
                except OSError:
                    pass
    return out


def pixelorama_gate(exe, files, rgba, flat, order):
    real = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    before = snapshot(real)
    tmp = tempfile.mkdtemp(prefix="wb-chp7-")
    rep = {"pixelorama_sha256": sha(read_bytes(exe)), "steps": {}}
    try:
        for k in ("pxo", "ora"):
            src = os.path.join(tmp, f"src.{k}")
            with open(src, "wb") as f:
                f.write(files[k])
            for split in (False, True):
                label = f"{k}_{'split' if split else 'flat'}"
                d = os.path.join(tmp, label); os.makedirs(d)
                fake = os.path.join(tmp, "appdata_" + label); os.makedirs(fake)
                r = run_pixelorama(exe, ["--export"] + (["--split-layers"] if split else []) +
                                   ["-o", os.path.join(d, "f.png"), src], fake)
                pngs = sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))
                r["pngs"] = len(pngs)
                r["source_unchanged"] = read_bytes(src) == files[k]
                if not split:
                    a = decode(read_bytes(os.path.join(d, pngs[0]))) if pngs else None
                    r["flat_exact"] = a is not None and a.shape == flat.shape and bool((a == flat).all())
                else:
                    hits = set()
                    for f in pngs:
                        a = decode(read_bytes(os.path.join(d, f)))
                        hits |= {n for n in order if a.tobytes() == rgba[n].tobytes()}
                    r["art_layers_exact"] = all(n in hits for n in order if n != "guides")
                    r["art_layers_matched"] = len([n for n in order if n != "guides" and n in hits])
                    r["guides_exported"] = "guides" in hits
                rep["steps"][label] = r
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    after = snapshot(real)
    changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k) and
                     not k.endswith(".running"))
    rep["real_appdata_changed_except_running"] = changed
    st = rep["steps"]
    rep["verdicts"] = {
        "pixelorama_pxo_flat_exact": st["pxo_flat"].get("flat_exact", False),
        "pixelorama_ora_flat_exact": st["ora_flat"].get("flat_exact", False),
        "pixelorama_pxo_split_layers_exact": st["pxo_split"].get("art_layers_exact", False),
        "pixelorama_ora_split_layers_exact": st["ora_split"].get("art_layers_exact", False),
        "pixelorama_hidden_guides_not_exported": not st["pxo_split"].get("guides_exported", True) and
                                                 not st["ora_split"].get("guides_exported", True),
        "pixelorama_sources_unchanged": all(v["source_unchanged"] for v in st.values()),
        "pixelorama_real_appdata_untouched": not changed,
    }
    return rep


def check(exe, write_report, use_pixelorama):
    sc, rgba, flat, files, nm, audit = build_under_audit()
    cand = rp(CAND_REL)
    rep = {"run": RUN, "gates": {}, "metrics": {}}
    on_disk = {}
    for k, b in files.items():
        disk = read_bytes(os.path.join(cand, nm[k]))
        on_disk[k] = (sha_text(disk) == sha_text(b)) if k in ("gpl", "scene", "tres") else (disk == b)
    rep["gates"]["candidate_files_equal_fresh_rebuild"] = all(on_disk.values())
    rep["gates"]["build_deterministic"] = artefacts(scene())[2] == files
    man = json.loads(read_bytes(os.path.join(cand, nm["manifest"])))
    v06_man_path = os.path.join(rp(V06_DIR_REL), f"{SLUG}_{AREA}_manifest_{V06_TAG}.json")
    rep["metrics"]["v06_baseline_present"] = os.path.exists(_fs(v06_man_path))
    if rep["metrics"]["v06_baseline_present"]:
        v06_man = json.loads(read_bytes(v06_man_path))
        ok06 = True
        for k, e in v06_man["files"].items():
            b = read_bytes(os.path.join(rp(V06_DIR_REL), e["name"]))
            ok06 &= (sha_text(b) if e["hash"] == "sha256-text-lf-v1" else sha(b)) == e["sha256"]
        rep["gates"]["v06_baseline_files_unchanged"] = bool(ok06)
    rep["gates"]["manifest_hashes_match_files"] = all(
        man["files"][k]["sha256"] == (sha_text(b) if k in ("gpl", "scene", "tres") else sha(b))
        for k, b in files.items())
    v, m = static_checks(sc, rgba, flat)
    rep["gates"].update(v); rep["metrics"].update(m)
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        dj = json.loads(z.read("data.json"))
    rep["gates"]["pxo_lists_named_layers_guides_hidden"] = [l["name"] for l in dj["layers"]] == sc["order"] and \
        [l["visible"] for l in dj["layers"]] == [n != "guides" for n in sc["order"]]
    rep["gates"]["tres_matches_scene_json"] = json.loads(
        files["tres"].decode().split('metadata/scene_json = "', 1)[1].rsplit('"', 1)[0]
        .replace('\\"', '"').replace("\\\\", "\\")) == json.loads(files["scene"])
    rep["metrics"]["layer_count"] = len(sc["order"])
    prov = provenance(flat, audit)
    rep["provenance"] = prov
    rep["gates"].update({"provenance_" + k: val for k, val in prov["gates"].items()})
    if use_pixelorama:
        rep["pixelorama"] = pixelorama_gate(exe, files, rgba, flat, sc["order"])
        rep["gates"].update(rep["pixelorama"]["verdicts"])
    rep["result"] = "PASS" if all(rep["gates"].values()) else "FAIL"
    rep["note"] = "Technical gates only; passing them is not art acceptance."
    print(json.dumps({"result": rep["result"], "gates": rep["gates"], "provenance_metrics": prov["metrics"]},
                     indent=1))
    if write_report:
        out = rp(OUT_REL)
        os.makedirs(_fs(out), exist_ok=True)
        print(write_new(os.path.join(out, nm["report"]), (json.dumps(rep, indent=2, default=str) + "\n").encode()))
        print(write_new(os.path.join(out, nm["provenance"]), (json.dumps(prov, indent=2, default=str) + "\n").encode()))
    return 0 if rep["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("dir", nargs="?")
    ap.add_argument("--write-report", action="store_true")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    a = ap.parse_args()
    if a.mode == "preview":
        if not a.dir or os.path.abspath(a.dir).startswith(REPO):
            raise SystemExit("preview needs a directory outside the repo")
        preview(a.dir)
    elif a.mode == "build":
        build()
    else:
        sys.exit(check(a.pixelorama, a.write_report, not a.no_pixelorama))


if __name__ == "__main__":
    main()
