"""UNAPPROVED, NONRUNTIME pilot v04: NYC City Hall Park (2537 science hub), ONE 640x360 walkable camera composition.

A NEW, separate candidate forked from the pilot v03 tool (run nyc-chp-v03_20261016-160059-4b2f50f6, whose files are
left untouched and re-hashed by `check`) after the Codex visual review of v03 (relayed in the v04 task, 2026-10-16):
civic identity, skyline and park activity improved, but the central promenade is a flat repeated tile strip, the bright
flower beds read as sticker ovals, the fountain water veil reads as a pale cylinder rather than a stone bowl, and the
park visitors are tiny generic figures beside the approved 48-px heroine. Deterministic Python tool authored and run
by Claude (Claude Code, Opus 5.5, claude.ai Max subscription, firstParty; no API key, no image model, no paid
fallback).

v04 changes against that review (each change is commented "v04" where it is made):
  * promenade: bluestone flag courses that thin toward City Hall (10 -> 5 rows), per-course slab-length tables in
    running bond, a soldier-course granite edge band, a footfall-polished centre lane that drifts per course, cleft
    streaks and damp patches, and a warm-granite sett crossing band where the statue / east walks meet the axis
    (with a small teal wayfinding ring: the restrained 2537 science cue on the ground, nothing on City Hall).
  * flower beds: no granite ring; each bed is an asymmetric union of hand-sized foliage lobes (lumpy, lit like the
    crowns, soil showing at the front lip), bloom drifts are feathered head clusters on a lattice (dense core, sparse
    rim) in muted tones, with a low clipped-box ball or grass accent at one end and a north-east contact shade.
  * fountain: the overflow veil is replaced by a stone tazza -- thick lit lip, water seen in the bowl, a gadrooned
    bowl body in shadow underneath, a baluster pedestal -- with four thin, unevenly spaced overflow strands and splash
    marks; a tiny bubbler instead of a foam crown; eight small teal nozzle nodes on the inner tier (science cue).
  * people: every baked human figure is removed from the scene art (the four door-scaled stair figures and the five
    half-scale lawn occupants). Full-size visitors (48-px class) are a SEPARATE TEST-ONLY OVERLAY (ground PNG + atlas
    PNG + JSON with pivots), never part of the 24-layer stack; captures are rendered with the overlay and art-only.
  * shrub borders: the layer is renamed `shrub-borders`; the fountain-plaza border is cut back west of the
    behind-fountain capture and muted, so the heroine's head and shoulders read against plain lawn.

v03 changes against the v02 audit (kept in v04 unless noted above):
  * facade: per-window state table (blinds, curtains, lit, sky reflections), weathering streaks, cornice shadow band,
    deep window reveals, roof urns, Justice figure on the cupola; the whole building is hazed one aerial-perspective
    step (own hazed-marble ramp) so it no longer shares values with the hero-scale gate piers -> reads distant;
    door-scaled visitors on the stair give the facade a human yardstick.
  * skyline: a sky band and broken rooflines; three hazed depth planes in warm brick, limestone, terracotta and glass
    (Woolworth-like terracotta piers at the left, Municipal-Building-like limestone colonnade at the right, water
    tanks, one slim 2537 garden tower in the far plane with a faint teal seam) instead of grey blocks.
  * lawns / trees: shrub borders on lawn edges, a picnic, a bench reader and a gardener occupy the lawns; flower beds
    get stone edging and grouped bloom drifts; hero crowns get hand-cut gaps that show limbs, edge spill and
    asymmetric lobes; back-grove crowns are hazed and mirrored per instance.
  * fountain: the tall 2-px jet is gone; a solid two-tier centrepiece (pedestal, wide upper bowl with falling sheets,
    a low foam crown) hides the lower body of anyone directly behind it instead of slicing through her.
  * behind-tree: the SE plane forks low (no lollipop) and the capture foot is moved so the trunk covers one side of
    the heroine while her far foot and contact shadow stay visible.

What it writes: one 640x360 logical-pixel scene (exactly one gameplay camera: game/project.godot viewport 640x360,
window 1280x720, integer 2x) as a 24-layer editable stack -- a native Pixelorama .pxo (pxo_version 7) and an .ora --
plus a palette (.gpl), the actor contact-shadow sprite, a walk mask PNG, a walkability JSON, the separate test-only
visitor overlay (ground PNG, atlas PNG, JSON) and a manifest. `check` adds the Pixelorama 1.2.3 headless export
round-trip and two Godot 4.7.2 gates (headless texel gate along a heroine route on the art stack, and real windowed
renders at 1280x720 and native 640x360 with the test overlay, plus native 640x360 art-only). Nothing is wired into
the game runtime; science scene art stays 0/11.

AUTHORING ROUTE (disclosed). NOT a Pixelorama GUI paint pass (no desktop/computer-use access to the GUI in this
session). Landmarks, trees (one hand-written lobe list per tree), wear marks, stains, cracks, leaf litter, worn turf,
beds, props, lawn occupants and window states are explicit table entries below; textures are hand-drawn motifs (leaf clumps, grass tufts) placed on
fixed lattices with hand-written offset tables. No value-noise thresholds and no hashed pixel scatter are used for
texture; the only hash use left is choosing a granite slab's tone from a short hand-written tone table.

Reference use. City Hall follows the published description of the building (NYC DCAS City Hall page cited in the v01
audit; the Justice figure on the cupola is part of that published description of the tower): a central pavilion, two projecting wings, a columned entrance portico and a domed tower. Bay counts, column
counts and proportions are an interpretation at backdrop scale, NOT measured from LPC elevations, and no reference
pixel is copied. Lower Manhattan context beyond Chambers Street (Woolworth-like terracotta piers on Broadway, a
Municipal-Building-like limestone colonnade, the Tweed Courthouse roof, brick and limestone blocks with water tanks,
one invented slim 2537 garden tower) is generic massing in hazed colours, not traced. The v03 visual-direction
reference image (outputs/...visual-direction-reference_nonruntime-v03_20261016-124945-33aa88e9.png, Codex, generated,
UNAPPROVED) was looked at for density ideas only; none of its pixels or colours are sampled.

v02 composition (kept in v03):

  * dollhouse join: the walk now ends at hero-scale granite gate piers with lanterns and hero-scale railings; the
    forecourt beyond them recedes (paving courses thin to 2 rows, stair risers graded 4 -> 2 rows); lawns flow from
    the park up to the building with tufts that shrink with distance; trees recede in three sizes.
  * horizontal bands: no full-width grove, hedge or picket belt; skyline, tree clumps and lawns break irregularly.
  * City Hall: projecting wings (+9 rows), central pavilion (+3), projecting entrance portico (+7) with a stair;
    wing shadows fall on the recessed links (sun from the south-west); invented green banners removed.
  * foliage: four species with their own clump size, ramp and crown lobes (London plane, American elm, honey
    locust, flowering dogwood); leaning / forked trunks; plane-tree bark mottling.
  * paving: wear layer (cracks, stains, patched slabs, polished lane, moss joints, sunken pavers, worn turf, litter);
    the continuous teal centre seam is replaced by two wayfinding medallions; lamp shadows are short stubby shapes.
  * fountain: low inner tier and arching jets in the base layer; only a slim column, bowl and jet are Y-sorted; a
    readability gate blocks feet where an occluder would hide only the feet ("standing on" read).
  * actor contact shadow: a two-step alpha ellipse (sun south-west, nudged north-east), drawn under the actor.

Modes
  preview <dir>   render layers, flat, runtime stills, 2x views and guides into <dir> (outside the repo)
  build           write candidate files (never overwrites a different file)
  check           static gates + Pixelorama headless round-trip (APPDATA redirected to temp; --no-pixelorama) +
                  Godot gates in throwaway temp projects (--no-godot); --write-report writes the JSON report and the
                  Godot render captures (1280x720 + 640x360 with the test overlay, 640x360 art-only) into
                  outputs/<RUN>/.
Run: python -I -B <this file> preview <tempdir> | build | check [--write-report] [--no-pixelorama] [--no-godot]
"""
import argparse, hashlib, io, json, math, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
AREA = "nyc-city-hall-park"
VER = "unapproved-v05"
STAMP = "20261016-220852"
RUN_ID = "74330a19"
RUN = f"nyc-chp-v05_{STAMP}-{RUN_ID}"       # short run dir: keeps candidate paths well under MAX_PATH (260)
CAND_REL = f"game/assets/environments/candidates/{RUN}"
OUT_REL = f"outputs/{RUN}"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))
# v05: forked from the v04 tool; v04 files are re-hashed (never rewritten) and used as the comparison baseline
V04_RUN = "nyc-chp-v04_20261016-172144-eb092a52"
V04_TAG = "unapproved-v04_20261016-172144-eb092a52"
V04_TOOL_REL = ("tools/rpg-2-star-ocean-the-second_nyc-city-hall-park_walkable-pilot-640x360_pixelorama-build_"
                f"{V04_TAG}.py")
V04_CAND_REL = f"game/assets/environments/candidates/{V04_RUN}"
V04_OUT_REL = f"outputs/{V04_RUN}"
V04_QA_REL = f"docs/qa/rpg-2-star-ocean-the-second_nyc-city-hall-park_walkable-pilot-640x360_qa-note_{V04_TAG}.md"


def v04_name(purpose, ext):
    return f"{SLUG}_{AREA}_{purpose}_{V04_TAG}.{ext}"


V04_REVIEW = ("Codex native-640 visual judgment of v04, relayed in the v05 task prompt on 2026-10-16 (no separate audit "
              "file): City Hall and fountain silhouettes work; window rows and tree crowns still repeat; facade, grass "
              "and path materials are too even; the 2537 science-city layer is mostly a few tiny accent pixels; the "
              "one-off test NPCs remain simplified overlays and cannot become accepted character art")
V03_RUN = "nyc-chp-v03_20261016-160059-4b2f50f6"
V03_TOOL_REL = ("tools/rpg-2-star-ocean-the-second_nyc-city-hall-park_walkable-pilot-640x360_pixelorama-build_"
                "unapproved-v03_20261016-160059-4b2f50f6.py")
V03_CAND_REL = f"game/assets/environments/candidates/{V03_RUN}"
V03_MANIFEST = ("rpg-2-star-ocean-the-second_nyc-city-hall-park_scene-manifest_unapproved-v03_"
                "20261016-160059-4b2f50f6.json")
V03_FLAT = ("rpg-2-star-ocean-the-second_nyc-city-hall-park_scene-flat-640x360_unapproved-v03_"
            "20261016-160059-4b2f50f6.png")
V03_QA_REL = ("docs/qa/rpg-2-star-ocean-the-second_nyc-city-hall-park_walkable-pilot-640x360_qa-note_unapproved-v03_"
              "20261016-160059-4b2f50f6.md")
REVIEW_NOTE = ("Codex visual review of v03, relayed in the v04 task prompt on 2026-10-16 (no separate audit file): "
               "civic identity clearer, skyline and park activity better than v02; central promenade a flat repeated "
               "tile strip; bright flower beds like sticker ovals; water veil a pale cylinder rather than a stone "
               "bowl; several park visitors tiny generic dots beside the approved 48-px heroine")
V02_RUN = "nyc-chp-v02_20261016-055120-59848a60"
V02_TOOL_REL = ("tools/rpg-2-star-ocean-the-second_nyc-city-hall-park_walkable-pilot-640x360_pixelorama-build_"
                "unapproved-v02_20261016-055120-59848a60.py")
AUDIT_REL = ("docs/qa/rpg-2-star-ocean-the-second_nyc-city-hall-park_walkable-v02-codex-visual-audit_"
             "unapproved-v01_20261016-064422-216b6bc3.md")
VISUAL_REF_REL = ("outputs/rpg-2-star-ocean-the-second_nyc-city-hall-park_visual-direction-reference_nonruntime-v03_"
                  "20261016-124945-33aa88e9.png")
V04_CHANGES = [
    "promenade: bluestone courses thinning toward City Hall (10 -> 5 rows), per-course slab tables in running bond, "
    "soldier-course granite edge bands, a footfall-polished centre lane drifting per course, cleft streaks, damp "
    "patches, and a warm-granite sett crossing band where the statue / east walks meet the axis",
    "flower beds: granite ring removed; asymmetric unions of foliage lobes with a soil lip, feathered bloom-head "
    "drifts in muted tones, one low box ball or grass accent per bed, north-east contact shade",
    "fountain: veil replaced by a stone tazza (thick lit lip, water in the bowl, gadrooned shaded body, baluster "
    "pedestal) with four thin unevenly spaced overflow strands, splash marks and a tiny bubbler",
    "science cue (restrained, on the ground only): a small teal wayfinding ring in the crossing band and eight teal "
    "nozzle nodes on the fountain's inner tier; City Hall is unchanged",
    "people: the four stair figures and five half-scale lawn occupants are removed from the art; full-size test-only "
    "visitors live in a separate overlay (ground PNG, atlas PNG, JSON) drawn Y-sorted in the captures",
    "shrub borders: layer renamed shrub-borders; the fountain-plaza border is cut back west of the behind-fountain "
    "capture and muted so her silhouette reads against lawn",
]
V03_CHANGES = [
    "skyline: sky band, broken rooflines, three hazed planes in brick / limestone / terracotta / glass; "
    "Woolworth-like piers (left), Municipal-Building-like colonnade (right), water tanks, one faint 2537 garden tower",
    "City Hall: per-window state table (blinds, curtains, lit, three reflection shapes), cornice shadow band, splash "
    "grime, 17 hand-placed rain streaks, deep-reveal shadows, Justice figure on the cupola, whole building and far "
    "stair hazed one aerial-perspective step; four door-scaled visitors on the stair",
    "trees: hand-cut crown gaps showing limbs, asymmetric lobe lists, SE plane forks low (V) with a low east bough, "
    "elm in vase form, back groves mirrored per instance with a spill lobe and hazed north of row 80",
    "lawns: new lawn-life layer (seated reader, picnic pair on a gingham blanket, bench reader, kneeling gardener, a "
    "small 2537 garden drone, three mounded shrub borders); seven mown patches break the tuft lattice",
    "flower beds: granite edging, mulch line, solid bloom drifts with lit caps and bloom ticks (v02 dots read dark)",
    "fountain: the tall 2-px jet is removed; two-tier centrepiece with a wide upper bowl, overflow veil (every 2nd "
    "column) and a low foam crown; the behind-fountain capture moves to stand directly behind it",
    "behind-tree capture moved 5 px west: trunk covers her east side, far foot and contact shadow visible",
    "gates: standing-on rule now counts a row against the heroine's own texels in that row (v02 counter could never "
    "exceed 0); contact-shadow gate accepts a behind capture whose front sprite covers >= 50 % of the footprint; "
    "native 640x360 windowed Godot render added beside 1280x720",
]
REFERENCE_URL = "https://www.nyc.gov/site/dcas/business/dcasmanagedbuildings/city-hall.page"
HEROINE_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
               "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
PIXELORAMA_DEFAULT = "C:/Users/hkzha/AppData/Local/Programs/Pixelorama-1.2.3/Pixelorama-Windows-64bit/Pixelorama.exe"
PIXELORAMA_VERSION = "v1.2.3-stable"
GODOT_REL = "work/tooling/godot-4-7-2/Godot_v4.7.2-stable_win64_console.exe"      # gitignored local tooling
W, H = 640, 360                   # one gameplay camera (logical viewport)
VIEW = 2                          # window 1280x720 = integer 2x
WIN_LONG_PREFIX = "\\\\?\\"


def fname(purpose, ext):
    """AGENTS naming: project slug, area, purpose, version, timestamp and run id are all in the file name."""
    return f"{SLUG}_{AREA}_{purpose}_{VER}_{STAMP}-{RUN_ID}.{ext}"


EXPORT_STEM = f"{SLUG}_{AREA}_pixelorama-export_{VER}_{STAMP}-{RUN_ID}"

LAYERS = ["skyline", "forecourt", "back-groves", "streets", "city-hall", "park-ground", "ground-wear",
          "ground-detail", "fountain-basin", "cast-shadows", "props-low", "shrub-borders", "forecourt-near",
          "tree-nw-ysort", "lamp-w-ysort", "trees-ne-ysort", "statue-ysort", "fountain-ysort", "lamp-e-ysort",
          "tree-se-ysort", "tree-sw-ysort", "cart-ysort", "fg-occlusion", "guides"]          # bottom -> top
ART_LAYERS = LAYERS[:-1]
BASE_LAYERS = LAYERS[:13]                                                 # merged into one base at runtime
YSORT_LAYERS = LAYERS[13:22]

# ============================================================================ palette (all hand-picked)
PALETTE = [
    ("ink", "15171d"),
    ("m0", "3e3d45"), ("m1", "5f5c62"), ("m2", "857f7c"), ("m3", "a8a196"), ("m4", "c7bfb0"), ("m5", "dfd8c8"),
    ("m6", "f2ede0"),
    ("w0", "1f2a36"), ("w1", "334556"), ("w2", "587486"), ("wl", "e6be74"), ("wl2", "f6dfa6"),
    ("r0", "384446"), ("r1", "4d5c5d"), ("r2", "66787a"),
    ("au0", "7e5f27"), ("au1", "bd9238"), ("au2", "ecd07c"),
    ("f0", "14241c"), ("f1", "1f3a27"), ("f2", "2d5530"), ("f3", "437539"), ("f4", "5f9444"), ("f5", "86b558"),
    ("f6", "b0d27a"),
    ("g0", "2a4627"), ("g1", "375c2f"), ("g2", "477437"), ("g3", "5f8d41"), ("g4", "7da650"),
    ("b0", "2a201b"), ("b1", "463427"), ("b2", "67503d"),
    ("p0", "4d4a47"), ("p1", "6c675f"), ("p2", "8b847a"), ("p3", "aaa294"), ("p4", "c6beae"), ("p5", "dcd5c6"),
    ("x0", "3f4045"), ("x1", "55575c"), ("x2", "6c6e71"), ("x3", "848583"),
    ("a0", "25282d"), ("a1", "33373d"), ("a2", "434850"), ("a3", "596068"),
    ("lw", "d6d6cc"),
    ("k0", "1b2128"), ("k1", "2c3540"), ("k2", "435160"), ("k3", "66798a"),
    ("c0", "26566c"), ("c1", "377e98"), ("c2", "63adc2"), ("c3", "aee1e8"),
    ("t0", "186a70"), ("t1", "33b2ae"), ("t2", "8aeedd"),
    ("fl0", "b84a7c"), ("fl1", "e39ab4"), ("fl2", "e6c95a"), ("fl3", "efece0"), ("fl4", "7f66bd"), ("fl5", "d9663f"),
    ("br0", "553026"), ("br1", "774533"),
    ("wd0", "45301f"), ("wd1", "6b482c"), ("wd2", "916740"),
    ("s0", "3b2d23"), ("s1", "574131"),
    ("fr", "a33139"), ("fb", "2b3c6c"), ("fo", "d9782e"),
    ("bz0", "2b2a24"), ("bz1", "4a4a3a"), ("bz2", "5f7b66"), ("bz3", "8fb39a"),
    # v02 additions: hazed Lower Manhattan context, earth / worn turf, honey-locust yellow-greens, dogwood bloom,
    # plane-tree bark, vendor umbrella
    ("h0", "4f5866"), ("h1", "65707c"), ("h2", "7d8792"), ("h3", "98a0a8"), ("h4", "b3b8bb"), ("hw", "8a7d68"),
    ("e0", "4e4030"), ("e1", "6e5b43"), ("e2", "917b5c"),
    ("y0", "26361d"), ("y1", "3f5726"), ("y2", "5f7a2f"), ("y3", "86a03f"), ("y4", "b2c565"),
    ("pk0", "a85b7a"), ("pk1", "dc9db3"), ("pk2", "f3d7de"),
    ("bk0", "8a8670"), ("bk1", "b5b096"), ("bk2", "625e4f"),
    ("ub0", "2d5a92"), ("ub1", "e3c24e"),
    # v03 additions. Sky band; far plane (closest to the sky); hazed brick, limestone, terracotta, glass, patina and
    # roof-garden greens for Lower Manhattan; one faint 2537 teal; hazed-marble / roof / window ramps that put City
    # Hall one aerial-perspective step behind the hero-scale gate (each = the v02 colour mixed 18 % toward fa2);
    # hazed grove greens; skin, curtain and picnic-cloth colours for the lawn occupants.
    ("sy0", "a9c3cf"), ("sy1", "c4d6dc"), ("sy2", "dde6e2"),
    ("fa0", "8d9ea8"), ("fa1", "a3b2b9"), ("fa2", "b8c4c7"),
    ("hb0", "6f5f5e"), ("hb1", "8a7470"), ("hb2", "a48d84"),
    ("hl0", "8c8a85"), ("hl1", "a9a59b"), ("hl2", "c4beb0"), ("hl3", "d6d0c0"),
    ("tc0", "9a8c74"), ("tc1", "b8a888"), ("tc2", "d2c4a2"),
    ("hg0", "5d7584"), ("hg1", "7f97a3"), ("hg2", "a7bcc4"),
    ("cu0", "5e8a7e"), ("cu1", "86ae9e"), ("tq", "7fc6c0"), ("gr0", "6b8466"), ("gr1", "86a07a"),
    ("hm0", "54555c"), ("hm1", "6f6f74"), ("hm2", "8e8b8a"), ("hm3", "aba79f"), ("hm4", "c4c0b4"), ("hm5", "d8d4c8"),
    ("hm6", "e7e6db"),
    ("hr0", "4f5b5d"), ("hr1", "606f70"), ("hr2", "758688"),
    ("hw0", "3a4650"), ("hw1", "4b5c6a"), ("hw2", "698292"), ("hwl", "debf83"), ("hwl2", "ebdaac"), ("hcu", "b9a37c"),
    ("q0", "2f4a3a"), ("q1", "3f5e45"), ("q2", "537653"), ("q3", "6b8e62"), ("q4", "88a777"),
    ("hu0", "8d5a3f"), ("hu1", "c58b66"), ("hu2", "e6b58f"), ("fr0", "7d2530"),
    # v04 additions: bluestone (promenade flags) and warm granite (edge bands, crossing setts, south plaza) for local
    # material variation; a deeper skin ramp, olive and mustard cloth for the test-only visitor overlay only
    ("bs0", "545a61"), ("bs1", "6d7379"), ("bs2", "878c90"), ("bs3", "a0a4a6"), ("bs4", "b8bbba"),
    ("wg0", "6a5f57"), ("wg1", "877b70"), ("wg2", "a4978a"), ("wg3", "beb2a2"),
    ("hd0", "4e3226"), ("hd1", "6e4a36"), ("hd2", "8f6549"),
    ("ol0", "434a2b"), ("ol1", "5e663c"), ("ol2", "7d8550"), ("mu0", "8f6e2a"), ("mu1", "c09a3e"),
    # v05 additions: hazed lichen for the facade plinth
    ("lc0", "6f7a68"), ("lc1", "8a9480"),
    # v05: a cooler blue-green ramp for the American elm so it no longer shares the plane trees' greens
    ("el0", "172723"), ("el1", "22392f"), ("el2", "2f4f3c"), ("el3", "41684b"), ("el4", "5a855a"), ("el5", "7aa06c"),
]
SKIN = ("hu0", "hu1", "hu2", "hd0", "hd1", "hd2")             # v04: people only -> must not appear in any art layer
GUIDE_PALETTE = [("gd-walk", "3cdcff"), ("gd-block", "ff285a"), ("gd-pin", "ffe600"), ("gd-route", "ff00ff")]
ALL_PAL = PALETTE + GUIDE_PALETTE
I = {n: i for i, (n, _) in enumerate(ALL_PAL)}
RGB = np.array([[int(h[j:j + 2], 16) for j in (0, 2, 4)] for _, h in ALL_PAL], np.uint8)
N_ART = len(PALETTE)
LUMA_IDX = (RGB.astype(np.int32) @ np.array([299, 587, 114])) // 1000

SHADE = {  # opaque cast-shadow colour for each ground colour (no semi-alpha anywhere in the scene layers)
    "g4": "g2", "g3": "g1", "g2": "g1", "g1": "g0", "g0": "f1",
    "p5": "p3", "p4": "p2", "p3": "p2", "p2": "p1", "p1": "p0", "p0": "p0",
    "x3": "x1", "x2": "x1", "x1": "x0", "x0": "a1", "a3": "a1", "a2": "a1", "a1": "a0",
    "f6": "f4", "f5": "f3", "f4": "f3", "f3": "f2", "f2": "f1", "f1": "f0",
    "fl0": "f2", "fl1": "fl0", "fl2": "au0", "fl3": "p3", "fl4": "f2", "fl5": "br1",
    "m6": "m4", "m5": "m3", "m4": "m3", "m3": "m2", "m2": "m1",
    "c3": "c1", "c2": "c1", "c1": "c0", "lw": "p2", "t1": "t0", "t2": "t1", "k3": "k2", "k2": "k1",
    "s1": "s0", "wd2": "wd1", "wd1": "wd0", "au1": "au0", "au2": "au1", "fr": "fr0", "fr0": "br0",
    "e2": "e1", "e1": "e0", "e0": "b1", "y4": "y2", "y3": "y1", "y2": "y1", "y1": "y0",
    "pk2": "pk0", "pk1": "pk0", "bk1": "bk0", "bk0": "bk2", "bk2": "b1",
    "w2": "w1", "w1": "w0", "wl": "au1", "wl2": "wl", "m1": "m0", "r2": "r1", "r1": "r0",
    "h4": "h3", "h3": "h2", "h2": "h1", "h1": "h0", "b2": "b1", "b1": "b0",
    "bs4": "bs2", "bs3": "bs1", "bs2": "bs1", "bs1": "bs0", "bs0": "a2",
    "wg3": "wg1", "wg2": "wg1", "wg1": "wg0", "wg0": "p0", "c0": "w0", "t0": "c0",
}
SHADE_LUT = np.arange(len(ALL_PAL), dtype=np.int16)
for _a, _b in SHADE.items():
    SHADE_LUT[I[_a]] = I[_b]

# ============================================================================ hand-authored geometry (logical px)
CX = 320                            # City Hall / central walk axis lies between columns 319 and 320 (mirror: 639-x)
# City Hall elevation rows for a section at depth 0 (the recessed links); deeper sections shift down by `d` rows
ROOF = (48, 57)
BAL = (58, 63)
CORN = (64, 67)
UP = (68, 95)
STRING = (96, 98)
LOW = (99, 126)
PLINTH = (127, 131)
# (kind, x0, x1, depth rows): projecting wings +9, central pavilion +3, links recessed
SECTIONS = [("wing", 150, 207, 9), ("link", 208, 275, 0), ("centre", 276, 363, 3), ("link", 364, 431, 0),
            ("wing", 432, 489, 9)]
PORTICO = (282, 357, 7)                                         # x0, x1, depth rows of the entrance portico
PORT_COLS = [284, 298, 312, 324, 338, 352]                      # lower-tier column left x (4 px wide), symmetric
# per-window state, keyed (section, side 0 = west / 1 = east, storey, bay); unlisted windows are dark glass with one
# of three sky-reflection shapes. Deliberately asymmetric: the east and west halves never share a pattern.
# v05: every window is now listed, one letter per bay west -> east (east halves are listed in screen order and then
# reversed into the mirrored bay index), so value -- not just a 1-px reflection -- varies along each row at 640x360:
#   d dark glass   s sky reflection (pale upper pane)   r low reflection (pale lower pane)   b blind   l low blind
#   c curtains     w warm lit   o open sash (dark lower third)
# No two neighbours in a row share a letter, no bay repeats its storey above/below, and the halves are not mirrored.
WINDOW_ROWS = {("wing", 0, "up"): "sbd", ("wing", 0, "low"): "dwl", ("link", 0, "up"): "bsws",
               ("link", 0, "low"): "cdrb", ("centre", 0, "up"): "csdwb", ("link", 1, "up"): "dlsw",
               ("link", 1, "low"): "wsdc", ("wing", 1, "up"): "wbs", ("wing", 1, "low"): "rdo"}
WINDOW_CODE = {"d": "dark", "s": "sky", "r": "sky-low", "b": "blind", "l": "blind-low", "c": "curtain", "w": "lit",
               "o": "sash"}
WINDOW_STATE = {}
for (_k, _s, _st), _row in WINDOW_ROWS.items():
    _row = _row if _s == 0 or _k == "centre" else _row[::-1]       # east halves: mirrored bay 0 is the outermost
    for _b, _ch in enumerate(_row):
        WINDOW_STATE[(_k, _s, _st, _b)] = WINDOW_CODE[_ch]
# weathering: 1-px rain streaks (x, y0, y1) washing down from sills and cornice ends, darkened one SHADE step on
# the wall only; hand placed, not mirrored
STREAKS = [(153, 68, 79), (161, 98, 106), (176, 118, 124), (203, 73, 84), (214, 96, 103), (233, 88, 95),
           (258, 66, 72), (271, 112, 121), (283, 74, 79), (360, 70, 80), (371, 89, 97), (395, 110, 118),
           (413, 66, 73), (436, 99, 107), (452, 80, 87), (470, 117, 125), (486, 70, 82)]
HAZE = {"m0": "hm0", "m1": "hm1", "m2": "hm2", "m3": "hm3", "m4": "hm4", "m5": "hm5", "m6": "hm6",
        "r0": "hr0", "r1": "hr1", "r2": "hr2", "w0": "hw0", "w1": "hw1", "w2": "hw2", "wl": "hwl", "wl2": "hwl2",
        "k0": "w0", "k1": "w1", "c3": "hg2"}
# v04: the v03 door-scaled stair VISITORS (10-row dots) are removed from the art; people are test-overlay only
FLAGS = [(242, "us"), (396, "nyc")]                              # flagpole x, flag (forecourt, behind the railing)
FLAG_BASE, FLAG_TOP = 137, 60
STAIR_TOP = 139                                                  # first tread row under the portico podium
STAIR_RISERS = (2, 2, 2, 3, 3, 3, 4)                             # graded: thin far steps, thick near steps
GATE_PIERS = [(266, 279), (360, 373)]                            # hero-scale piers x0, x1 (rows 124..171)
PIER_TOP = 124
RAILS = [(214, 265), (374, 425)]                                 # hero-scale railings x0, x1 (rows 143..171)
SUN = (0.30, 0.17)                                               # ground shadow offset per row of height (+x, -y)
WALK_TOP = 172
# park paths (masks built in park_masks()) -- network kept from v01, fountain plaza re-proportioned
AXIS = (292, 347)                                               # granite central walk x range
SOUTH_PLAZA = (44, 639, 338, 359)
FOUNTAIN = (172, 272)                                           # basin centre
PLAZA_R = (92, 62)
BASIN_R = (44, 24)
BASIN_IN = (40, 21)
DIAG = ((226, 240), (298, 200), 12)                             # NE diagonal hex walk: p, q, half width
EAST_CONN = (250, 258, 292, 281)
S_CONN = (150, 300, 193, 338)
W_GATE = (62, 258, 92, 281)
STATUE_WALK = (348, 255, 450, 277)
STATUE_C = (470, 266, 34, 23)
E_WALK_H = (490, 255, 603, 277)
E_WALK_V = (572, 255, 603, 338)
BROADWAY = (0, 41)                                              # road x range; curb 42..43; sidewalk 44..61
BW_FENCE = 62                                                   # fence columns 62..63, gate gap rows 258..281
PARK_ROW = 604                                                  # fence 604..605, sidewalk 606..639
LAMPS = {"lamp-w-ysort": [(295, 226)], "lamp-e-ysort": [(344, 292)]}    # staggered, not mirrored pairs
FOUNTAIN_LAMPS = [(104, 272), (240, 272)]                        # candelabra on the plaza (fountain-ysort)
STATUE = (470, 268)
CART = (470, 344)                                               # vendor cart: left x of the body, wheel base row
YSORT_PIVOTS = {"tree-nw-ysort": 204, "lamp-w-ysort": 226, "trees-ne-ysort": 240, "statue-ysort": 268,
                "fountain-ysort": 272, "lamp-e-ysort": 292, "tree-se-ysort": 300, "tree-sw-ysort": 330,
                "cart-ysort": 344}
FENCES = [(350, 368, 253), (394, 436, 253), (504, 570, 253), (350, 436, 281), (504, 570, 281),  # (x0, x1, base)
          (66, 84, 336), (108, 148, 336), (196, 289, 336), (350, 426, 336), (452, 569, 336)]
BENCHES = [(372, 252), (86, 336), (429, 336)]                    # left x, base row (benches sit in fence gaps)
BINS = [(342, 256), (560, 342)]
BOLLARDS = [(50, 342), (50, 352)]
PYLON = (214, 230)                                              # info pylon base centre
PINS = {"spawn_south": (320, 350), "city_hall_gate": (320, 178), "axis_mid": (320, 292),
        "fountain_south": (172, 318), "fountain_behind": (184, 236), "info_pylon": (214, 244),
        "statue_plaque": (470, 284), "statue_behind": (470, 250), "tree_se_behind": (398, 268),
        "lamp_w_behind": (300, 216), "lamp_w_front": (300, 234), "fountain_lamp_front": (110, 284),
        "exit_broadway_gate": (70, 270), "exit_park_row": (596, 350)}
YSORT_CASES = [("fountain_behind", "fountain-ysort", True), ("fountain_lamp_front", "fountain-ysort", False),
               ("statue_behind", "statue-ysort", True), ("statue_plaque", "statue-ysort", False),
               ("tree_se_behind", "tree-se-ysort", True), ("lamp_w_behind", "lamp-w-ysort", True),
               ("lamp_w_front", "lamp-w-ysort", False)]
ROUTE = ["spawn_south", (320, 300), (320, 270), (262, 270), (232, 244), "info_pylon", (200, 236), "fountain_behind",
         (184, 224), (140, 224), (140, 236), (130, 236),     # v04: leave the tazza pocket north-about, not across it
         (112, 250), "exit_broadway_gate", (112, 292), "fountain_south", (172, 348), (320, 348),
         "axis_mid", (320, 266), (440, 266), (452, 250), "statue_behind", (486, 252), (500, 266), (588, 266),
         (588, 348), "exit_park_row", (420, 348), (320, 348), "lamp_w_front", (314, 234), (314, 216), "lamp_w_behind",
         "city_hall_gate"]
CAPTURES = {"axis": "axis_mid", "fountain": "fountain_behind", "tree": "tree_se_behind"}   # v04: short view names
# actor contact shadow: rows of a 17x5 two-step alpha ellipse ('X' core, 'x' rim), centred 1 px east of the foot
# and 1 row north of it (sun from the south-west pushes the contact shadow slightly north-east)
SHADOW_ROWS = ["....xxxxxxxxx....",
               "..xxXXXXXXXXXxx..",
               ".xXXXXXXXXXXXXXx.",
               "..xxXXXXXXXXXxx..",
               "....xxxxxxxxx...."]
SHADOW_ALPHA = {"X": 118, "x": 64}
SHADOW_OFF = (1, -1)                                             # (dx, dy) of the shadow centre from the foot
# ============================================================================ helpers
YY, XX = np.mgrid[0:H, 0:W]


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > 247 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def rp(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(p):
    with open(_fs(p), "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha_text(b):
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def new():
    return np.full((H, W), -1, np.int16)


def hval(*key):
    """Deterministic hash in [0, 1): only picks a slab / hex-block tone or a course offset from a short hand table."""
    return int.from_bytes(hashlib.sha256(repr(key).encode()).digest()[:4], "little") / 2 ** 32


def C(c):
    return I[c] if isinstance(c, str) else c


def rect(L, x0, y0, x1, y1, c, reg=None):
    x0, x1 = max(0, x0), min(W - 1, x1)
    y0, y1 = max(0, y0), min(H - 1, y1)
    if x0 <= x1 and y0 <= y1:
        L[y0:y1 + 1, x0:x1 + 1] = C(c)
        if reg is not None:
            reg[y0:y1 + 1, x0:x1 + 1] = True


def px(L, x, y, c, reg=None):
    if 0 <= x < W and 0 <= y < H:
        L[y, x] = C(c)
        if reg is not None:
            reg[y, x] = True


def stamp(L, x, y, rows, cmap, reg=None):
    """Paint a hand-authored sprite (top-left at x, y). '.' is transparent; other chars map through cmap."""
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if ch in ". ":
                continue
            px(L, x + i, y + j, cmap[ch], reg)


def ell(cx, cy, rx, ry):
    return ((XX + 0.5 - cx) / rx) ** 2 + ((YY + 0.5 - cy) / ry) ** 2 <= 1.0


def box(x0, y0, x1, y1):
    return (XX >= x0) & (XX <= x1) & (YY >= y0) & (YY <= y1)


def seg(p, q, hw):
    (x0, y0), (x1, y1) = p, q
    dx, dy = x1 - x0, y1 - y0
    t = np.clip(((XX + 0.5 - x0) * dx + (YY + 0.5 - y0) * dy) / float(dx * dx + dy * dy), 0, 1)
    return np.hypot(XX + 0.5 - (x0 + t * dx), YY + 0.5 - (y0 + t * dy)) <= hw


def shift_of(names, c, d):
    i = names.index(c)
    return names[max(0, min(len(names) - 1, i + d))]


def dilate(m, r=1):
    out = m.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            out |= np.roll(np.roll(m, dy, 0), dx, 1)
    return out


def edge_below(m):
    """True where m and the texel below is not m (bottom edges)."""
    b = np.zeros_like(m)
    b[:-1] = m[:-1] & ~m[1:]
    return b


def edge_above(m):
    a = np.zeros_like(m)
    a[1:] = m[1:] & ~m[:-1]
    return a


def cyl(u):
    """Light across a vertical cylinder (u in -1..1), sun from the front-left (south-west)."""
    u = max(-1.0, min(1.0, u))
    return 0.55 * math.sqrt(max(0.0, 1 - u * u)) - 0.45 * u + 0.05


def tone(ramp, v, cuts):
    k = 0
    while k < len(cuts) and v >= cuts[k]:
        k += 1
    return ramp[k]


def poly(L, pts, c, mask=None):
    """1-px polyline through hand-written points (cracks, tar seams); optionally clipped to a mask."""
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        n = max(abs(x1 - x0), abs(y1 - y0), 1)
        for k in range(n + 1):
            x, y = int(round(x0 + (x1 - x0) * k / n)), int(round(y0 + (y1 - y0) * k / n))
            if 0 <= x < W and 0 <= y < H and (mask is None or mask[y, x]):
                L[y, x] = I[c]


def shade_region(L, mask):
    """Darken already painted texels of L inside mask by one SHADE step (opaque, palette only)."""
    sel = mask & (L >= 0)
    L[sel] = SHADE_LUT[L[sel]]


def mirror(x, w=1):
    return W - 1 - x - (w - 1)


def merge_orphans(L, region, passes=2):
    """Cluster cleanup inside `region`: a texel whose four neighbours (inside the region) all differ from it takes
    the most common neighbour colour (ties -> the darker one), so clusters stay intentional, never lone texels."""
    for _ in range(passes):
        ys, xs = np.nonzero(region)
        changed = 0
        for y, x in zip(ys, xs):
            c = L[y, x]
            nb = [L[y + dy, x + dx] for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1))
                  if 0 <= y + dy < H and 0 <= x + dx < W and region[y + dy, x + dx]]
            if len(nb) < 3 or c in nb:
                continue
            cnt = {}
            for n in nb:
                cnt[n] = cnt.get(n, 0) + 1
            best = max(cnt.items(), key=lambda kv: (kv[1], -LUMA_IDX[kv[0]]))[0]
            L[y, x] = best
            changed += 1
        if not changed:
            break


# ============================================================================ foliage: hand-written lobes, leaf clumps
LIGHT = np.array([-0.55, -0.62, 0.56])
LIGHT = LIGHT / np.linalg.norm(LIGHT)
OFF7 = ((0, 0), (1, -1), (-1, 1), (1, 1), (0, -1), (-1, 0), (1, 0))       # fixed clump offset table (cycled)
SIZE5 = (1.0, 0.84, 1.14, 0.92, 1.06)                                      # fixed clump size cycle
SPECIES = {   # ramp dark -> light, tone cuts, leaf-clump spacing (px), optional gaps / bloom, bark style
    "plane": {"ramp": ("f0", "f1", "f2", "f3", "f4", "f5", "f6"), "cuts": (-0.40, -0.14, 0.12, 0.36, 0.60, 0.84),
              "clump": 5.2, "bark": "plane"},
    "bedleaf": {"ramp": ("f1", "f2", "f3", "f4", "f5"), "cuts": (-0.30, 0.0, 0.30, 0.62), "clump": 2.6,
                "bark": "dark"},                                    # v04 bed foliage
    "elm": {"ramp": ("f0", "f1", "f2", "f3", "f4", "f5"), "cuts": (-0.34, -0.06, 0.22, 0.50, 0.76), "clump": 4.4,
            "bark": "dark"},
    "locust": {"ramp": ("y0", "y1", "y2", "y3", "y4"), "cuts": (-0.28, 0.02, 0.32, 0.64), "clump": 3.4,
               "holes": 9, "bark": "dark"},
    "dogwood": {"ramp": ("f1", "f2", "f3", "f4", "f5"), "cuts": (-0.30, 0.0, 0.30, 0.60), "clump": 3.8,
                "bloom": True, "bark": "dark"},
    "mid": {"ramp": ("f0", "f1", "f2", "f3", "f4", "f5"), "cuts": (-0.36, -0.06, 0.24, 0.52, 0.80), "clump": 3.6,
            "bark": "dark"},
    "back": {"ramp": ("f0", "f1", "f2", "f3", "f4"), "cuts": (-0.26, 0.06, 0.38, 0.70), "clump": 3.2,
             "bark": "dark"},
    "backhaze": {"ramp": ("q0", "q1", "q2", "q3", "q4"), "cuts": (-0.26, 0.06, 0.38, 0.70), "clump": 3.2,
                 "bark": "dark"},
    "box": {"ramp": ("f1", "f2", "f3", "f4", "f5"), "cuts": (-0.30, 0.0, 0.30, 0.62), "clump": 2.8, "bark": "dark"},
}


def crown(L, cx, cy, lobes, sp, reg=None, squash=0.86, gain=1.0, gaps=(), phase=0, crevice=0, pockets=(),
          sprays=(), aspect=1.0, ramp=None, clump=None):
    """Canopy from a hand-written lobe list (dx, dy, r px). Each lobe is lit as a sphere from the south-west; its
    area is filled with leaf clumps on a fixed staggered lattice (OFF7 / SIZE5 tables, no random jitter). Every clump
    is a small disc with a lit upper-left crescent and a shaded lower-right rim, drawn top to bottom so nearer clumps
    overlap farther ones; the canopy silhouette is the union of the clumps (lumpy, never a smooth ellipse).
    v03: `gaps` is a hand-written list of (dx, dy, rx, ry) sky holes -- clumps centred inside one are skipped, so
    limbs painted before the crown show through and the silhouette is no longer a closed round mass.
    v05 (all optional; defaults reproduce v04 exactly, so shrub borders / beds whose masks feed collision are
    unchanged): `phase` shifts this tree's place in the OFF7 / SIZE5 tables so no two crowns share a clump pattern;
    `crevice` darkens (by that many ramp steps) the clumps of a farther lobe that sit just above a nearer lobe's rim,
    so the canopy reads as separate leaf masses with dark seams instead of one field of identical balls; `pockets`
    are hand-placed (dx, dy, rx, ry) deep-shade cavities inside the crown (two steps darker, limbs read in them);
    `sprays` are hand-placed (dx, dy, n, ux, uy) chains of n small clumps reaching out of the silhouette along
    (ux, uy); `aspect` stretches clumps horizontally (elm: layered, drooping masses); `ramp` / `clump` override the
    species ramp and clump spacing per tree."""
    S = SPECIES[sp]
    ramp, cuts, s = ramp or S["ramp"], S["cuts"], clump or S["clump"]
    lob = sorted(((cx + dx, cy + dy, r) for dx, dy, r in lobes), key=lambda t: t[1])
    R = max(math.hypot(dx, dy) + r for dx, dy, r in lobes)
    bx0 = int(min(lx - r for lx, _, r in lob)) - 1
    bx1 = int(max(lx + r for lx, _, r in lob)) + 1
    by0 = int(min(ly - r * squash for _, ly, r in lob)) - 1
    by1 = int(max(ly + r * squash for _, ly, r in lob)) + 1
    clumps = []
    j, y = 0, float(by0)
    while y <= by1:
        i, x = 0, bx0 + (s / 2 if j % 2 else 0.0)
        while x <= bx1:
            ox, oy = OFF7[(i * 3 + j * 5 + phase) % 7]
            qx, qy = x + ox, y + oy
            hit = None
            for lb in lob:
                if ((qx - lb[0]) / lb[2]) ** 2 + ((qy - lb[1]) / (lb[2] * squash)) ** 2 <= 1.0:
                    hit = lb
            if hit is not None and any(((qx - cx - gx) / gr) ** 2 + ((qy - cy - gy) / gq) ** 2 <= 1.0
                                       for gx, gy, gr, gq in gaps):
                hit = None
            if hit is not None and not (S.get("holes") and (i * 7 + j * 3) % S["holes"] == 0):
                clumps.append((qy, qx, hit, SIZE5[(i + 2 * j + phase) % 5], i, j))
            x += s
            i += 1
        y += s * 0.74
        j += 1
    for (dx, dy, n, ux, uy) in sprays:                                  # v05: leaf sprays reaching out of the crown
        base = min(lob, key=lambda lb: math.hypot(cx + dx - lb[0], cy + dy - lb[1]))
        for q in range(n):
            clumps.append((cy + dy + uy * s * 0.62 * q, cx + dx + ux * s * 0.62 * q, base, (0.74, 0.62, 0.52)[q % 3],
                           q, -1))
    clumps.sort(key=lambda t: (t[0], t[1]))
    union = np.zeros((H, W), bool)
    top = len(ramp) - 1
    for (qy, qx, (lx, ly, r), sz, i, j) in clumps:
        nx, ny = (qx - lx) / r, (qy - ly) / (r * squash)
        nz = math.sqrt(max(0.0, 1 - nx * nx - ny * ny))
        v = ((nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2]) * 0.78
             + (-0.30 * (qx - cx) / R - 0.42 * (qy - cy) / R) * 0.55) * gain
        k = sum(1 for c in cuts if v >= c)
        if crevice:                                                     # v05: seam above a nearer mass's rim
            for lb in lob:
                if lb[1] > ly:
                    e = math.hypot((qx - lb[0]) / lb[2], (qy - lb[1]) / (lb[2] * squash))
                    if 1.0 < e <= 1.0 + 0.9 * s / lb[2] and qy < lb[1]:
                        k -= crevice
                        break
        if any(((qx - cx - px_) / prx) ** 2 + ((qy - cy - py_) / pry) ** 2 <= 1.0 for px_, py_, prx, pry in pockets):
            k -= 2                                                      # v05: hand-placed deep-shade cavity
        rr = s * 0.62 * sz
        rx_ = rr * aspect
        for yy in range(max(0, int(math.floor(qy - rr))), min(H, int(math.ceil(qy + rr)) + 1)):
            for xx in range(max(0, int(math.floor(qx - rx_))), min(W, int(math.ceil(qx + rx_)) + 1)):
                u, w = (xx + 0.5 - qx) / rx_, (yy + 0.5 - qy) / rr
                d2 = u * u + w * w
                if d2 > 1.0:
                    continue
                if rr >= 2.3 and -u * 0.6 - w * 0.8 > 0.40 and d2 < 0.85:
                    kk = k + 1
                elif u * 0.55 + w * 0.85 > (0.52 if rr >= 2.3 else 0.70):
                    kk = k - 1
                else:
                    kk = k
                L[yy, xx] = I[ramp[max(0, min(top, kk))]]
                union[yy, xx] = True
        if S.get("bloom") and (i + 2 * j) % 3 == 0 and k >= 1:              # dogwood bracts: 2x2 / 2x1 clusters
            bx, by = int(round(qx)) - 1, int(round(qy)) - 1
            if k >= 3:
                stamp(L, bx, by, ["PP", "pq"], {"P": "pk2", "p": "pk1", "q": "pk0"})
            else:
                stamp(L, bx, by, ["pp", "q."], {"p": "pk1", "q": "pk0"})
    hole = ~union & ((np.roll(union, 1, 0) & np.roll(union, -1, 0)) | (np.roll(union, 1, 1) & np.roll(union, -1, 1)))
    L[hole] = I[ramp[0]]                                              # close 1-px pinholes between clumps
    union |= hole
    u8 = sum(np.roll(np.roll(union, dy, 0), dx, 1).astype(np.int8) for dy in (-1, 0, 1) for dx in (-1, 0, 1)
             if (dy, dx) != (0, 0))
    nook = ~union & (u8 >= 6)                                         # v03: also close 1-px nooks a gap leaves
    L[nook] = I[ramp[0]]
    union |= nook
    edge = np.zeros_like(union)
    edge[:-1] |= union[:-1] & ~union[1:]
    edge[:, :-1] |= union[:, :-1] & ~union[:, 1:]
    L[edge] = I[ramp[0]]
    merge_orphans(L, union)
    if reg is not None:
        reg |= union
    return union


def limb(L, p, q, w0, w1, bark, reg=None, mottle=False):
    """Tapered bark segment p -> q, lit from the west. 'plane': pale bark with olive / cream patches at fixed
    fractions of the main stem; 'dark': furrowed bark with a dashed furrow down the middle."""
    (x0, y0), (x1, y1) = p, q
    n = max(1, int(round(max(abs(x1 - x0), abs(y1 - y0)))))
    for k in range(n + 1):
        t = k / n
        xc, yc = x0 + (x1 - x0) * t, y0 + (y1 - y0) * t
        w = max(1, int(round(w0 + (w1 - w0) * t)))
        flare = 1 if (k <= 1 and w0 >= 5) else 0
        xa = int(math.floor(xc - w / 2.0 + 0.5)) - flare
        xb = xa + w - 1 + 2 * flare
        yy = int(round(yc))
        for xx in range(xa, xb + 1):
            u = (xx - xa + 0.5) / (xb - xa + 1)
            if bark == "plane":
                c = "bk0" if u < 0.36 else ("bk2" if u < 0.76 else "b1")
            else:
                c = "b2" if u < 0.34 else ("b1" if u < 0.78 else "b0")
                if xb - xa >= 3 and xx == xa + (xb - xa + 1) // 2 and (yy // 3) % 2 == 0:
                    c = "b0"
            px(L, xx, yy, c, reg)
    if mottle:
        for f, side in ((0.10, 1), (0.22, 0), (0.40, 1), (0.55, 0), (0.70, 1)):
            xc, yc = x0 + (x1 - x0) * f, y0 + (y1 - y0) * f
            xx = int(round(xc)) - 2 if side == 0 else int(round(xc)) + 1
            rect(L, xx, int(round(yc)), xx + 1, int(round(yc)) + 2, "bk1" if side == 0 else "bk0", reg)


def paint_tree(L, t, reg=None):
    bark = SPECIES[t["sp"]]["bark"]
    for n, (p, q, w0, w1) in enumerate(t.get("limbs", ())):
        limb(L, p, q, w0, w1, bark, reg, mottle=(bark == "plane" and n == 0))
    return crown(L, t["c"][0], t["c"][1], t["lobes"], t["sp"], reg, gain=t.get("gain", 1.0), gaps=t.get("gaps", ()),
                 **{k: t[k] for k in CROWN_V05_KEYS if k in t})


CROWN_V05_KEYS = ("phase", "crevice", "pockets", "sprays", "aspect", "ramp", "clump")


TREES = {   # hero-scale Y-sorted trees; each has its own trunk polylines, lobe list and hand-cut crown gaps (v03)
    "tree-nw-ysort": [dict(sp="plane", base=(96, 204), c=(100, 148),
                           limbs=[((96, 204), (98, 178), 9, 7), ((97, 186), (84, 166), 5, 3),
                                  ((99, 184), (114, 162), 5, 3), ((114, 163), (108, 138), 3, 2),
                                  ((84, 167), (77, 150), 3, 2), ((113, 164), (125, 150), 2, 2)],
                           lobes=[(-24, -12, 14), (-6, -26, 13), (14, -22, 12), (30, -10, 11), (-34, 4, 11),
                                  (-12, -6, 17), (12, -4, 15), (34, 10, 8), (-22, 16, 12), (2, 14, 13),
                                  (20, 18, 9), (-40, -4, 7), (40, -2, 6), (6, -36, 7)],
                           gaps=[(8, -10, 6, 4), (-21, 6, 5, 4), (24, 4, 4, 3)],
                           phase=2, crevice=1, pockets=[(-8, 2, 6, 4), (17, 7, 5, 3), (-28, 12, 4, 3)],     # v05
                           sprays=[(-44, -10, 3, -1, -0.4), (38, -16, 3, 1, -0.5), (-32, 24, 2, -1, 0.6),
                                   (8, -42, 2, 0.3, -1)])],
    "trees-ne-ysort": [dict(sp="locust", base=(462, 240), c=(464, 196),
                            limbs=[((462, 240), (465, 214), 5, 4), ((465, 216), (456, 203), 3, 2),
                                   ((465, 215), (475, 204), 3, 2)],
                            lobes=[(-14, -8, 11), (3, -14, 12), (17, -6, 10), (-8, 6, 11), (12, 8, 10),
                                   (-21, 7, 7), (24, -14, 6)],
                            gaps=[(4, 0, 4, 3)],
                            phase=4, crevice=1, pockets=[(-4, 4, 4, 3)],                                    # v05
                            sprays=[(-28, -6, 2, -1, 0.2), (26, -20, 2, 1, -0.6)]),
                       dict(sp="elm", base=(540, 240), c=(542, 184),
                            limbs=[((540, 240), (541, 214), 8, 6), ((540, 216), (522, 190), 4, 3),
                                   ((541, 214), (543, 182), 4, 3), ((542, 216), (561, 190), 4, 3),
                                   ((523, 192), (514, 178), 2, 2), ((560, 192), (570, 180), 2, 2)],
                            lobes=[(-32, -10, 12), (-16, -20, 13), (2, -24, 12), (18, -20, 13), (32, -8, 11),
                                   (-22, 2, 10), (22, 2, 10), (0, -6, 11), (-40, -2, 6), (40, 4, 6)],
                            gaps=[(-10, -2, 5, 4), (12, -4, 5, 4)],
                            phase=5, crevice=1, aspect=1.3, ramp=("el0", "el1", "el2", "el3", "el4", "el5"),   # v05
                            pockets=[(-20, -6, 5, 3), (20, -8, 5, 3), (0, 0, 6, 3)],
                            sprays=[(-46, 0, 3, -1, 0.5), (46, 6, 3, 1, 0.6), (-8, -34, 2, -0.3, -1)])],
    "tree-se-ysort": [dict(sp="plane", base=(410, 300), c=(412, 194),
                           limbs=[((410, 300), (411, 266), 10, 8), ((411, 268), (400, 226), 6, 4),
                                  ((412, 268), (424, 222), 6, 4), ((400, 228), (388, 206), 4, 2),
                                  ((424, 224), (440, 208), 4, 2), ((413, 252), (434, 236), 4, 3),
                                  ((401, 232), (405, 206), 3, 2)],
                           lobes=[(-26, -6, 12), (-12, -14, 12), (4, -22, 11), (18, -14, 12), (30, -4, 10),
                                  (-18, 4, 11), (14, 4, 12), (-4, -4, 10), (30, 32, 8), (38, 26, 7),
                                  (22, 36, 6), (-36, 2, 6)],
                           gaps=[(-2, 6, 5, 4), (8, -6, 4, 3), (24, 14, 5, 4)],
                           phase=3, crevice=1, pockets=[(-14, 2, 5, 3), (10, -5, 4, 3)],                     # v05
                           sprays=[(-42, 0, 3, -1, 0.3), (36, -16, 2, 1, -0.6), (-14, -26, 2, -0.4, -1)])],
    "tree-sw-ysort": [dict(sp="dogwood", base=(262, 330), c=(262, 304),
                           limbs=[((260, 330), (256, 312), 3, 2), ((263, 330), (265, 310), 3, 2),
                                  ((265, 329), (272, 314), 2, 2)],
                           lobes=[(-10, -4, 9), (2, -8, 10), (12, -2, 8), (-4, 5, 9), (9, 6, 8), (-15, 3, 5)],
                           phase=1, crevice=1, sprays=[(-19, 0, 2, -1, 0.3)])],                           # v05
}
MID_TREES = [   # backdrop scale (forecourt-near), overlapping the wing corners
    dict(sp="mid", base=(134, 160), c=(136, 128), limbs=[((134, 160), (135, 140), 4, 3)],
         lobes=[(-14, -6, 11), (2, -12, 12), (15, -4, 10), (-6, 6, 11), (10, 7, 9)], phase=1, crevice=1),
    dict(sp="mid", base=(494, 158), c=(496, 128), limbs=[((494, 158), (495, 140), 4, 3)],
         lobes=[(-13, -5, 10), (1, -11, 11), (14, -4, 10), (-5, 6, 10), (11, 6, 9)], phase=4, crevice=1)]
SHRUBS = [dict(sp="box", base=(196, 171), c=(196, 161), lobes=[(-12, 2, 9), (0, -3, 11), (12, 2, 8)]),
          dict(sp="box", base=(444, 171), c=(444, 161), lobes=[(-13, 2, 8), (0, -3, 11), (12, 2, 9)])]
BACK_TPL = {"A": [(-8, -4, 7), (4, -7, 8), (10, 1, 6), (-3, 4, 8)],
            "B": [(-9, 0, 7), (0, -8, 8), (9, -2, 7), (2, 5, 7)],
            "C": [(-6, -6, 6), (5, -6, 7), (-9, 3, 6), (7, 4, 6), (0, 1, 8)]}
BACK_TREES = [  # (x, y, scale, lobe template, trunk base row or None); listed back (north) to front
    (116, 34, 1.0, "B", None), (82, 44, 1.3, "A", None), (140, 56, 0.9, "C", None), (106, 68, 1.2, "A", None),
    (70, 76, 1.4, "C", None), (128, 96, 1.1, "C", None), (90, 104, 1.3, "B", None), (74, 132, 1.2, "A", 150),
    (286, 46, 0.8, "B", None), (354, 46, 0.8, "A", None), (228, 44, 0.9, "C", None), (262, 46, 0.7, "A", None),
    (384, 44, 0.8, "B", None), (414, 42, 1.0, "C", None), (174, 46, 0.9, "A", None), (466, 46, 0.9, "B", None),
    (526, 64, 1.0, "B", None), (594, 62, 1.2, "C", None), (560, 76, 1.3, "A", None), (536, 100, 1.2, "C", None),
    (600, 96, 1.1, "A", None), (574, 108, 1.4, "B", None), (520, 124, 1.0, "A", 140), (592, 134, 1.2, "C", 152),
    (60, 52, 1.2, "C", None), (148, 84, 1.0, "B", None), (150, 116, 1.0, "A", 132), (100, 128, 1.1, "B", 146),
    (506, 70, 1.0, "A", None), (492, 98, 0.9, "C", None), (604, 40, 1.1, "A", None), (500, 112, 1.1, "B", 128),
    (548, 128, 1.2, "A", 146), (126, 40, 1.0, "C", None), (548, 46, 1.0, "B", None),
]
FG_TREES = [dict(sp="mid", c=(-4, 366), lobes=[(-6, -16, 16), (16, -10, 15), (2, 4, 20), (26, 6, 12)]),
            dict(sp="mid", c=(646, 368), lobes=[(-18, -12, 15), (2, -18, 14), (-4, 2, 19), (-26, 8, 11)])]


# ============================================================================ skyline: restrained Lower Manhattan
WATER_TANK = ["...a...", "..aAa..", ".aAAAa.", "LWWWWdd", "lwwwwdd", "LWWWWdd", "lwwwwdd", "LWWWWdd", ".k...k.",
              ".kk.kk.", "kkkkkkk"]
TANK_MAP = {"a": "h1", "A": "h2", "L": "e2", "l": "e1", "W": "hw", "w": "e1", "d": "e0", "k": "h0"}


def paint_skyline():
    """Opaque base: the sky band and hazed Lower Manhattan north of Chambers Street seen over City Hall, in three
    aerial-perspective planes (far towers nearly sky-coloured; a warmer mid plane of brick, limestone and terracotta
    blocks with broken rooflines and water tanks; the nearest Tweed Courthouse roof). Left: Woolworth-like
    terracotta piers; right: Municipal-Building-like limestone colonnade; far plane: one slim 2537 garden tower with a
    faint teal seam. Generic massing, an interpretation, not traced."""
    L = new()
    L[:, :] = I["sy2"]
    rect(L, 0, 0, W - 1, 3, "sy0"); rect(L, 0, 4, W - 1, 10, "sy1")
    for (x0, x1, top, prof) in FAR_TOWERS:                           # far plane: pier shadows only, no window grid
        rect(L, x0, top, x1, 60, "fa1")
        rect(L, x0, top, x0, 60, "fa2")
        if prof == "stepped":
            rect(L, x0, top, x0 + 4, top + 5, "sy1"); rect(L, x1 - 3, top, x1, top + 3, "sy1")
            rect(L, x0 + 5, top, x0 + 5, top + 5, "fa2"); rect(L, x0, top + 6, x0 + 4, top + 6, "fa2")
        if prof == "ribbed":
            for x in range(x0 + 3, x1 - 1, 4):
                rect(L, x, top + 2, x, 60, "fa0")
        rect(L, x0, top, x1, top, "fa2")
    gx0, gx1 = GARDEN_TOWER                                         # 2537 garden tower: terraces + teal seam
    rect(L, gx0, 0, gx1, 60, "fa1"); rect(L, gx0, 0, gx0 + 1, 60, "fa2"); rect(L, gx1, 0, gx1, 60, "fa0")
    for y in range(3, 40, 7):
        rect(L, gx0 - 1, y, gx1 + 1, y, "gr1"); rect(L, gx0 - 1, y + 1, gx1 + 1, y + 1, "gr0")
        rect(L, gx0 + 2, y - 1, gx0 + 4, y - 1, "gr1"); rect(L, gx1 - 5, y - 1, gx1 - 4, y - 1, "gr1")
        rect(L, (gx0 + gx1) // 2, y + 2, (gx0 + gx1) // 2, y + 5, "tq")
    for (x0, x1, top, mat, win, tank) in MID_BLOCKS:                 # mid plane: material, cornice, own rhythm
        face, lit, shade, glass, trim = SKY_MAT[mat]
        rect(L, x0, top, x1, 60, face)
        rect(L, x0, top, x0, 60, lit)
        rect(L, x1, top, x1, 60, shade)
        rect(L, x0, top, x1, top, trim); rect(L, x0, top + 1, x1, top + 1, shade)
        dx, dy, ox, oy, skip = win
        for r, y in enumerate(range(top + 3 + oy, 60, dy)):
            for c, x in enumerate(range(x0 + 1 + ox, x1 - 1, dx)):
                if (r + c * 2) % skip == skip - 1:
                    continue
                rect(L, x, y, x + (1 if mat in ("brick", "terra") else 0), y + 1, glass)
                if mat == "brick":
                    rect(L, x, y - 1, x + 1, y - 1, trim)
        if tank is not None:
            stamp(L, tank, top - len(WATER_TANK) + 1, WATER_TANK, TANK_MAP)
    for (x, y) in SKY_LIT_WINDOWS:                                    # a few warm windows (late afternoon)
        rect(L, x, y, x + 1, y + 1, "hwl")
    # Woolworth-like terracotta tower at the left (Broadway): piers, recessed spandrels, pointed heads; rises out of
    # the frame, so only its pier rhythm and Gothic heads show
    rect(L, 64, 0, 150, 60, "tc1")
    for x in range(64, 151, 6):
        rect(L, x, 0, x, 60, "tc2"); rect(L, x + 1, 0, x + 1, 60, "tc1"); rect(L, x + 5, 0, x + 5, 60, "tc0")
        for y in range(4, 60, 9):
            rect(L, x + 2, y, x + 4, y + 5, "hg0"); px(L, x + 3, y - 1, "hg0")
            rect(L, x + 2, y + 6, x + 4, y + 6, "tc0")
            px(L, x + 2, y, "tc1"); px(L, x + 4, y, "tc1")
    for y in (21, 22, 46, 47):                                        # belt courses
        rect(L, 64, y, 150, y, "tc2" if y in (21, 46) else "tc0")
    rect(L, 150, 0, 150, 60, "tc0")
    # lower neighbour with a copper mansard (x 151..177)
    rect(L, 151, 12, 177, 60, "hb1"); rect(L, 151, 9, 177, 13, "cu0"); rect(L, 151, 9, 177, 9, "cu1")
    for x in range(154, 176, 6):
        rect(L, x, 10, x + 1, 12, "cu1"); rect(L, x, 17, x + 1, 19, "hb0"); rect(L, x, 25, x + 1, 27, "hb0")
    # Tweed Courthouse roof directly behind City Hall: hazed slate hip, ridge, two limestone chimneys
    for y in range(24, 48):
        inset = max(0, 36 - (y - 24) * 36 // 23)
        rect(L, 200 + inset, y, 440 - inset, y, "hr0" if (y - 24) % 3 == 2 else "hr1")
        px(L, 200 + inset, y, "hr2"); px(L, 440 - inset, y, "hr0")
    rect(L, 236, 24, 404, 24, "hr2")
    for cxx in (250, 384):
        rect(L, cxx, 15, cxx + 5, 24, "hl1"); rect(L, cxx + 5, 16, cxx + 5, 24, "hl0"); rect(L, cxx - 1, 15, cxx + 6, 15, "hl3")
    # Municipal-Building-like limestone block (right): colonnade base, grouped window bays, setback central tower
    rect(L, 462, 6, 603, 60, "hl1")
    for b, x in enumerate(range(466, 600, 12)):
        rect(L, x - 2, 6, x - 1, 60, "hl2")
        for xx in (x + 1, x + 4, x + 7):
            for y in range(12, 33, 4):
                rect(L, xx, y, xx + 1, y + 2, "hg0" if (b + y // 4) % 5 else "hg1")
    rect(L, 462, 33, 603, 33, "hl3"); rect(L, 462, 34, 603, 35, "hl0")
    for x in range(464, 602, 5):                                      # colonnade
        rect(L, x, 36, x + 1, 60, "hl2"); rect(L, x + 2, 36, x + 4, 60, "hl0")
    rect(L, 524, 38, 542, 60, "hl0"); rect(L, 526, 40, 540, 60, "hg0")    # central arch (shadowed passage)
    for y in range(38, 42):
        px(L, 524 + (41 - y), y, "hl2"); px(L, 542 - (41 - y), y, "hl2")
    rect(L, 462, 6, 603, 6, "hl3"); rect(L, 462, 7, 603, 7, "hl0")
    rect(L, 590, 0, 603, 6, "sy1")                                    # east end steps down
    rect(L, 514, 0, 552, 6, "hl2")                                    # central tower rises out of the frame
    for x in range(516, 551, 5):
        rect(L, x, 0, x + 1, 5, "hl3"); rect(L, x + 2, 0, x + 2, 5, "hl0")
    rect(L, 462, 6, 462, 60, "hl2"); rect(L, 603, 6, 603, 60, "hl0")
    return L


FAR_TOWERS = [(176, 205, 6, "ribbed"), (206, 229, 11, "flat"), (252, 284, 3, "stepped"), (285, 300, 9, "flat"),
              (338, 366, 4, "ribbed"), (367, 384, 13, "flat"), (408, 436, 7, "stepped"), (437, 461, 2, "ribbed")]
GARDEN_TOWER = (234, 247)
SKY_MAT = {"brick": ("hb1", "hb2", "hb0", "hb0", "hl2"), "lime": ("hl1", "hl2", "hl0", "hg0", "hl3"),
           "terra": ("tc1", "tc2", "tc0", "hg0", "tc2"), "glass": ("hg1", "hg2", "hg0", "hg0", "hg2")}
MID_BLOCKS = [  # (x0, x1, roof row, material, (dx, dy, x off, y off, skip every n-th), water-tank x or None)
    (178, 203, 17, "lime", (3, 5, 1, 1, 7), 186), (204, 233, 21, "brick", (5, 4, 2, 0, 4), None),
    (250, 279, 15, "terra", (4, 4, 1, 1, 6), 266), (280, 299, 19, "brick", (4, 5, 0, 0, 3), None),
    (340, 362, 18, "glass", (3, 4, 0, 0, 99), None), (363, 389, 14, "brick", (5, 4, 1, 1, 5), 372),
    (390, 411, 20, "lime", (3, 5, 1, 0, 4), None), (412, 440, 16, "brick", (4, 4, 2, 1, 6), 428),
    (441, 461, 12, "terra", (4, 5, 1, 1, 5), None)]
SKY_LIT_WINDOWS = [(207, 25), (217, 29), (369, 18), (387, 22), (420, 21), (452, 30), (186, 31), (494, 16)]


BACK_EXTRA = ((-12, 3, 4), (11, -5, 4), (3, 7, 5), (-6, -9, 4), (13, 4, 3))    # one spill lobe per tree (cycled)


def paint_back_groves():
    """Mid-distance groves. v03: every second tree mirrors its template and each gets one extra spill lobe from a
    short hand table, so no two neighbours share a silhouette; trees north of row 80 use the hazed q ramp."""
    L = new()
    for k, (x, y, s, tpl, tb) in enumerate(BACK_TREES):
        sgn = -1 if k % 2 else 1
        lobes = [(sgn * dx * s, dy * s, r * s) for dx, dy, r in BACK_TPL[tpl]]
        ex, ey, er = BACK_EXTRA[k % len(BACK_EXTRA)]
        lobes.append((sgn * ex * s, ey * s, er * s))
        if tb is not None:
            limb(L, (x, tb), (x, y + int(6 * s)), 3, 2, "dark")
        crown(L, x, y, lobes, "backhaze" if y < 80 else "back", gain=0.9, phase=k % 7, crevice=1)   # v05: phase, seams
    return L


# ============================================================================ streets (Broadway, Park Row)
def lamp_sprite(L, x, base, reg=None):
    """Cast-iron park lantern (about 3.3 m at the heroine scale) with a 2537 teal sensor ring under the lantern."""
    rect(L, x - 2, base - 5, x + 2, base, "k1", reg); rect(L, x - 2, base - 5, x - 2, base, "k3", reg)
    rect(L, x - 3, base, x + 3, base, "k0", reg); rect(L, x - 2, base - 6, x + 2, base - 6, "k2", reg)
    rect(L, x - 1, base - 50, x, base - 7, "k2", reg); rect(L, x, base - 50, x, base - 7, "k0", reg)
    px(L, x - 1, base - 40, "k3", reg); px(L, x - 1, base - 20, "k3", reg)
    rect(L, x - 2, base - 30, x + 1, base - 29, "k3", reg); rect(L, x + 1, base - 30, x + 1, base - 29, "k1", reg)
    rect(L, x - 2, base - 52, x + 1, base - 51, "t1", reg); rect(L, x - 2, base - 52, x - 1, base - 52, "t2", reg)
    rect(L, x - 3, base - 54, x + 2, base - 53, "k1", reg)
    rect(L, x - 3, base - 62, x + 2, base - 55, "k1", reg)
    rect(L, x - 2, base - 61, x + 1, base - 56, "wl", reg); rect(L, x - 2, base - 61, x - 1, base - 59, "wl2", reg)
    rect(L, x - 4, base - 63, x + 3, base - 63, "k2", reg); rect(L, x - 2, base - 64, x + 1, base - 64, "k1", reg)
    px(L, x - 1, base - 65, "k1", reg); px(L, x - 1, base - 66, "k3", reg)


ASPHALT_PATCHES = [(1, 64, 6, 90), (34, 150, 40, 171), (1, 236, 6, 249), (34, 296, 40, 318)]
TAR_SEAMS = [[(2, 120), (4, 126), (3, 133)], [(36, 210), (38, 216), (37, 224)], [(4, 300), (6, 305), (5, 311)],
             [(35, 30), (37, 36)]]
SIDEWALK_STAINS = [(52, 124, 3, 5), (49, 262, 2, 4), (56, 318, 3, 2), (616, 70, 4, 3), (630, 250, 3, 5),
                   (612, 330, 4, 2)]
STREET_TREE = dict(sp="mid", base=(622, 149), c=(622, 112), limbs=[((622, 149), (622, 122), 4, 3)],
                   lobes=[(-8, -4, 8), (4, -8, 9), (10, 0, 7), (-2, 5, 9)])


def paint_streets():
    L = new()
    road = box(BROADWAY[0], 0, BROADWAY[1], H - 1)
    L[road] = I["a1"]
    for (x0, y0, x1, y1) in ASPHALT_PATCHES:                        # repaired asphalt, hand placed
        rect(L, x0, y0, x1, y1, "a2"); rect(L, x0, y1, x1, y1, "a0"); rect(L, x1, y0, x1, y1, "a0")
    for pts in TAR_SEAMS:
        poly(L, pts, "a0")
    for (mx, my) in ((37, 270), (3, 180)):                          # manhole covers
        m = ell(mx, my, 3, 2)
        L[m] = I["k1"]; L[m & edge_above(m)] = I["a3"]
    # maglev guideway (2537): concrete slab with expansion joints, two grooves, teal centre strip
    gw = box(8, 0, 32, H - 1)
    L[gw] = I["a2"]
    for y in range(10, H, 24):
        rect(L, 8, y, 32, y, "a1")
    rect(L, 8, 0, 8, H - 1, "a3"); rect(L, 32, 0, 32, H - 1, "a0")
    rect(L, 12, 0, 12, H - 1, "a0"); rect(L, 28, 0, 28, H - 1, "a0")
    rect(L, 19, 0, 20, H - 1, "t0")
    for y in range(4, H, 12):
        rect(L, 19, y, 20, y + 3, "t1")
    rect(L, 36, 0, 37, H - 1, "a1")
    for y in range(6, 330, 22):                                     # lane dashes (one-way southbound lane)
        rect(L, 37, y, 37, y + 9, "lw")
    for x in range(2, 41, 8):                                       # crosswalk at the south plaza
        rect(L, x, 341, x + 3, 357, "lw")
    rect(L, 42, 0, 42, H - 1, "p4"); rect(L, 43, 0, 43, H - 1, "p2")
    sw = box(44, 0, 61, H - 1)
    L[sw] = I["p3"]
    for y in range(5, H, 14):
        rect(L, 44, y, 61, y, "p2")
    rect(L, 53, 0, 53, H - 1, "p2")
    pr = box(606, 0, W - 1, H - 1)
    L[pr] = I["p3"]
    for y in range(9, H, 14):
        rect(L, 606, y, W - 1, y, "p2")
    rect(L, 622, 0, 622, H - 1, "p2")
    for (sx, sy, rx, ry) in SIDEWALK_STAINS:
        L[ell(sx, sy, rx, ry) & (sw | pr)] = I["p2"]
    # tall park fences (Broadway side with gate gap, Park Row side): pickets, lit tops
    for x0 in (BW_FENCE, PARK_ROW):
        for y in range(0, 338):
            if x0 == BW_FENCE and 256 <= y <= 283:
                continue
            px(L, x0, y, "k1"); px(L, x0 + 1, y, "k0")
            if y % 4 in (0, 1):
                px(L, x0, y, "k2")
    for (y0, y1) in ((250, 257), (282, 289)):                       # Broadway gate piers (registered as items)
        rect(L, 60, y0, 65, y1, "m3"); rect(L, 60, y0, 61, y1, "m4"); rect(L, 65, y0, 65, y1, "m2")
        rect(L, 59, y0, 66, y0 + 1, "m5")
    # maglev tram on the guideway: brushed-steel roof (toned down so it no longer competes with City Hall)
    rect(L, 7, 34, 33, 110, "m2")
    rect(L, 7, 34, 7, 110, "m3"); rect(L, 33, 34, 33, 110, "k1"); rect(L, 32, 34, 32, 110, "m1")
    rect(L, 7, 34, 33, 35, "m3")
    for (a, b) in ((46, 55), (88, 97)):
        rect(L, 12, a, 28, b, "k1"); rect(L, 12, a, 28, a, "k2"); rect(L, 13, a + 2, 27, b - 2, "m1")
    for y in range(38, 108, 6):
        rect(L, 19, y, 20, y + 3, "t0")
    for y in (64, 72, 80):
        rect(L, 19, y, 20, y + 1, "t1")
    rect(L, 7, 111, 33, 120, "k1")
    rect(L, 9, 112, 31, 115, "w1"); rect(L, 9, 112, 14, 113, "w2")
    rect(L, 8, 117, 10, 118, "t1"); rect(L, 30, 117, 32, 118, "t1")
    rect(L, 12, 117, 28, 118, "k2"); rect(L, 7, 120, 33, 120, "k0")
    rect(L, 34, 36, 35, 120, "a0")
    # glass tram shelter on the Broadway sidewalk (roof from above, posts, map screen)
    rect(L, 39, 182, 61, 190, "k1")
    rect(L, 40, 183, 60, 189, "c3")
    rect(L, 40, 186, 60, 189, "w2")
    for x in range(44, 60, 5):
        rect(L, x, 183, x, 189, "k2")
    rect(L, 40, 183, 46, 184, "lw")
    rect(L, 44, 191, 45, 214, "k1"); rect(L, 58, 191, 59, 214, "k1")
    rect(L, 46, 192, 57, 205, "w2")
    rect(L, 49, 194, 54, 201, "t0"); rect(L, 50, 195, 53, 197, "t1"); rect(L, 50, 199, 51, 200, "t2")
    rect(L, 46, 207, 57, 208, "k2"); rect(L, 46, 209, 57, 209, "k0")
    # NYC subway stair entrance on the Park Row sidewalk: descending stair, railings, green globe lamps, sign plate
    for y in range(194, 227):
        depth = (226 - y) // 8
        rect(L, 612, y, 630, y, ("a3", "a2", "a1", "a0", "a0")[depth])
        if (226 - y) % 3 == 0:
            rect(L, 612, y, 630, y, ("p3", "a3", "a2", "a1", "a1")[depth])
    for xr in (610, 631):
        rect(L, xr, 192, xr + 1, 226, "k1"); rect(L, xr, 192, xr, 226, "k2")
        rect(L, xr - 1 if xr == 610 else xr + 2, 192, xr - 1 if xr == 610 else xr + 2, 227, "p4")
    rect(L, 610, 192, 632, 193, "k1"); rect(L, 610, 192, 632, 192, "k2"); rect(L, 609, 191, 633, 191, "p4")
    rect(L, 614, 188, 628, 190, "k1"); rect(L, 615, 189, 627, 189, "lw"); rect(L, 615, 189, 617, 189, "f4")
    for gx in (611, 631):
        rect(L, gx, 206, gx, 226, "k1"); rect(L, gx - 1, 225, gx + 1, 226, "k0")
        stamp(L, gx - 2, 198, [".lg.", "lggf", "gggf", ".ff."], {"l": "f6", "g": "f4", "f": "f3"})
        rect(L, gx - 1, 202, gx + 1, 202, "k1")
    lamp_sprite(L, 624, 300)                                         # classic lamp on Park Row (never reachable)
    rect(L, 614, 147, 630, 151, "k1"); rect(L, 615, 148, 629, 150, "s1"); rect(L, 615, 148, 629, 148, "s0")
    paint_tree(L, STREET_TREE)                                       # NYC street tree in an iron-guarded pit
    return L


# ============================================================================ City Hall
def facade_window(L, x, top, h, arched, key, front):
    """One window. Its state comes from the hand-written WINDOW_STATE table (blind / low blind / curtains / lit /
    dark) and dark panes take one of three sky-reflection shapes, so no two neighbouring windows repeat. Deep reveal:
    the lintel and west jamb throw a 1-px shadow into the opening (sun from the south-west)."""
    state = WINDOW_STATE.get(key, "dark")
    lit = state == "lit"
    glass, mull, refl = ("wl", "au0", "wl2") if lit else ("w0", "w1", "w2")
    frame_l, frame_r = ("m6", "m3") if front else ("m5", "m2")
    rect(L, x - 1, top - 1, x + 6, top + h, frame_l)
    rect(L, x + 6, top - 1, x + 6, top + h, frame_r)
    rect(L, x, top, x + 5, top + h - 1, glass)
    if arched:
        px(L, x - 1, top - 1, "m4" if front else "m3")
        px(L, x + 6, top - 1, "m4" if front else "m3")
        px(L, x, top, frame_l); px(L, x + 5, top, frame_l)
        rect(L, x + 2, top - 3, x + 3, top - 2, "m6" if front else "m5")       # keystone
    mid = top + h // 3 if arched else top + h // 2
    if state in ("blind", "blind-low"):                                    # cream roller blind, hem, dark below
        yb = top + (h * 2) // 5 if state == "blind" else top + h - 4
        rect(L, x, top + (1 if arched else 0), x + 5, yb, "tc2"); rect(L, x, yb, x + 5, yb, "m2")
        rect(L, x + 5, top + 1, x + 5, yb - 1, "tc1")
    elif state == "curtain":                                               # tied-back curtains framing dark glass
        for cx_ in (x, x + 5):
            rect(L, cx_, top + 1, cx_, top + h - 1, "hcu")
        px(L, x + 1, mid + 1, "hcu"); px(L, x + 4, mid + 1, "hcu")
    elif state in ("sky", "sky-low"):                                      # v05: a pane full of pale sky, with a
        ya, yb = (top + (1 if arched else 0), mid - 1) if state == "sky" else (mid + 1, top + h - 1)   # cloud
        rect(L, x, top, x + 5, top + h - 1, "w2")                          # band; reads as a pale pane at 1x
        rect(L, x, ya, x + 5, yb, "c3")
        for k in range(yb - ya + 1):
            gx = x + 5 - (k * 3) // 2
            if x <= gx <= x + 5 and k % 3 != 2:
                px(L, gx, ya + k, "w2")
    elif state == "sash":                                                  # v05: lower sash raised -> dark room
        rect(L, x, top + h - 5, x + 5, top + h - 1, "k0")
        rect(L, x, top + h - 6, x + 5, top + h - 6, "m3")
    rect(L, x, mid, x + 5, mid, mull)
    rect(L, x + 2, top + 1, x + 2, top + h - 1, mull)
    if state in ("dark", "curtain"):
        v = key[1] * 1 + {"up": 0, "low": 1}[key[2]] + 2 * key[3]
        v = (v + {"wing": 0, "link": 1, "centre": 2}[key[0]]) % 3
        if v == 0:
            rect(L, x + (1 if state == "curtain" else 0), top + 1 if arched else top, x + 1, top + 2, refl)
        elif v == 1:
            px(L, x + 3, top + 2, refl); px(L, x + 4, top + 1, refl); px(L, x + 3, mid + 2, refl)
        else:
            rect(L, x + 3, top + h - 3, x + 4, top + h - 2, "w1"); px(L, x + 1, top + 1, refl)
    elif lit:
        rect(L, x, top + 1 if arched else top, x + 1, top + 2, refl)
    rect(L, x, top + (1 if arched else 0), x + 5, top + (1 if arched else 0), "w0" if not lit else "au0")
    rect(L, x, top + 1, x, top + h - 1, "w0" if not lit else "au0")      # west-jamb reveal shadow
    rect(L, x - 2, top + h + 1, x + 7, top + h + 1, "m6" if front else "m5")    # sill
    rect(L, x - 1, top + h + 2, x + 6, top + h + 2, "m2")


def hood(L, x, top, pediment, front):
    """Cornice hood over an upper-storey window (6 px wide); wings carry a small pediment."""
    hi = "m6" if front else "m5"
    rect(L, x - 2, top - 3, x + 7, top - 3, hi)
    rect(L, x - 1, top - 2, x + 6, top - 2, "m2")
    if pediment == "seg":                                              # v05: segmental arch hood (centre pavilion)
        rect(L, x - 1, top - 4, x + 6, top - 4, hi); rect(L, x + 1, top - 5, x + 4, top - 5, hi)
        px(L, x - 1, top - 4, "m4" if front else "m3"); px(L, x + 6, top - 4, "m3" if front else "m2")
    elif pediment:
        rect(L, x, top - 4, x + 5, top - 4, hi); rect(L, x + 2, top - 5, x + 3, top - 5, hi)


def section_rows(kind, d):
    return {"roof": (ROOF[0], BAL[0] + d - 1), "bal": (BAL[0] + d, BAL[1] + d), "corn": (CORN[0] + d, CORN[1] + d),
            "up": (UP[0] + d, UP[1] + d), "string": (STRING[0] + d, STRING[1] + d), "low": (LOW[0] + d, LOW[1] + d),
            "plinth": (PLINTH[0] + d, PLINTH[1] + d + (3 if kind == "wing" else 0))}


WEST_X0 = {"wing": 150, "link": 208}
LINK_DADOS = (0, 15, 31, 47, 65)   # v05: balustrade pedestals on the links (x offsets, 3 px wide)


def dado(L, x, b0, b1, front):
    """v05: a solid balustrade pedestal (3 px) so the balustrade reads in grouped runs, not one repeating band."""
    rect(L, x, b0 - 1, x + 2, b1, "m4" if front else "m3"); rect(L, x, b0 - 1, x + 2, b0 - 1, "m6" if front else "m5")
    rect(L, x + 2, b0, x + 2, b1, "m2"); px(L, x, b0, "m5" if front else "m4")
WING_BAYS = (8, 26, 43)            # window left-x offsets inside the west wing (east wing mirrored)
WING_PILS = (1, 19, 36, 54)        # 3-px pilasters
LINK_BAYS = (7, 23, 39, 55)
CENTRE_BAYS = (290, 304, 317, 330, 344)


def paint_section(L, kind, x0, x1, d, side):
    r = section_rows(kind, d)
    front = kind != "link"
    wall, joint = ("m4", "m3") if front else ("m3", "m2")

    def X(o, w):
        xw = WEST_X0[kind] + o
        return xw if side == 0 else mirror(xw, w)

    for y in range(r["roof"][0], r["roof"][1] + 1):                    # roof from above, hipped at wing ends
        inset = max(0, ROOF[0] + 7 - y) if kind == "wing" else 0
        xa, xb = (x0 + inset, x1) if side == 0 else (x0, x1 - inset)
        rect(L, xa, y, xb, y, "r1" if (y - ROOF[0]) % 3 else "r0")
        for x in range(x0 + 3, x1 + 1, 7):
            if xa <= x <= xb and y >= r["roof"][0] + 2 and L[y, x] == I["r1"]:
                L[y, x] = I["r0"]
    rect(L, x0, r["roof"][1], x1, r["roof"][1], "r2")
    rect(L, x0, r["corn"][0], x1, r["plinth"][0] - 1, wall)
    rusticate(L, x0, x1, r["low"][0], r["low"][1], kind, side)     # v05: rusticated base vs smooth upper storey
    rect(L, x0, r["plinth"][0], x1, r["plinth"][1], "m2")
    rect(L, x0, r["plinth"][0], x1, r["plinth"][0], "m4" if front else "m3")
    if kind == "wing":
        rect(L, x0, r["plinth"][0] + 2, x1, r["plinth"][0] + 2, "m3")
    rect(L, x0, r["string"][0], x1, r["string"][0], "m5"); rect(L, x0, r["string"][0] + 1, x1, r["string"][0] + 1, "m4")
    rect(L, x0, r["string"][1], x1, r["string"][1], "m2")
    rect(L, x0, r["corn"][0], x1, r["corn"][0], "m6"); rect(L, x0, r["corn"][0] + 1, x1, r["corn"][0] + 1, "m4")
    rect(L, x0, r["corn"][0] + 2, x1, r["corn"][0] + 2, "m1")
    for x in range(x0, x1 + 1):
        px(L, x, r["corn"][1], "m4" if x % 2 == 0 else "m2")
    rect(L, x0, r["bal"][0], x1, r["bal"][0], "m6"); rect(L, x0, r["bal"][0] + 1, x1, r["bal"][0] + 1, "m3")
    for x in range(x0, x1 + 1):
        rect(L, x, r["bal"][0] + 2, x, r["bal"][1] - 1, ("m5", "m3", "m0")[x % 3])
    rect(L, x0, r["bal"][1], x1, r["bal"][1], "m4")
    if kind == "wing":
        for o in WING_PILS:
            x = X(o, 3)
            rect(L, x, r["up"][0], x + 1, r["low"][1], "m5"); rect(L, x + 2, r["up"][0], x + 2, r["low"][1], "m3")
            rect(L, x - 1, r["up"][0], x + 3, r["up"][0], "m6"); rect(L, x - 1, r["up"][0] + 1, x + 3, r["up"][0] + 1, "m4")
            rect(L, x - 1, r["low"][0], x + 3, r["low"][0], "m5")
            rect(L, x, r["bal"][0] - 1, x + 2, r["bal"][1], "m4"); rect(L, x, r["bal"][0] - 1, x + 2, r["bal"][0] - 1, "m6")
            rect(L, x + 2, r["bal"][0], x + 2, r["bal"][1], "m2")
        cx0 = X(12, 5)                                               # chimney stack on the wing roof
        rect(L, cx0, ROOF[0] - 6, cx0 + 4, ROOF[0] + 3, "m2"); rect(L, cx0, ROOF[0] - 6, cx0 + 1, ROOF[0] + 3, "m3")
        rect(L, cx0 - 1, ROOF[0] - 7, cx0 + 5, ROOF[0] - 6, "m4")
        bays, ped = WING_BAYS, True
    else:
        sx = X(22, 16)                                               # skylight on the link roof
        rect(L, sx, 51, sx + 15, 55, "k1"); rect(L, sx + 1, 52, sx + 14, 54, "c3"); rect(L, sx + 8, 52, sx + 14, 54, "w2")
        bays, ped = LINK_BAYS, False
        for o in LINK_DADOS:                                         # v05: balustrade dados between the bays
            dado(L, X(o, 3), r["bal"][0], r["bal"][1], False)
    for bi, o in enumerate(bays):
        x = X(o, 6)
        facade_window(L, x, r["up"][0] + 7, 13, False, (kind, side, "up", bi), front)
        hood(L, x, r["up"][0] + 7, ped, front)
        facade_window(L, x, r["low"][0] + 6, 16, True, (kind, side, "low", bi), front)


def paint_centre(L):
    kind, x0, x1, d = SECTIONS[2]
    r = section_rows(kind, d)
    for y in range(r["roof"][0], r["roof"][1] + 1):
        rect(L, x0, y, x1, y, "r1" if (y - ROOF[0]) % 3 else "r0")
    rect(L, x0, r["roof"][1], x1, r["roof"][1], "r2")
    rect(L, x0, r["corn"][0], x1, r["plinth"][1], "m4")
    for y in range(r["low"][0] + 3, r["low"][1], 4):
        rect(L, x0, y, x1, y, "m3")
    rect(L, x0, r["plinth"][0], x1, r["plinth"][1], "m2"); rect(L, x0, r["plinth"][0], x1, r["plinth"][0], "m4")
    rect(L, x0, r["corn"][0], x1, r["corn"][0], "m6"); rect(L, x0, r["corn"][0] + 1, x1, r["corn"][0] + 1, "m4")
    rect(L, x0, r["corn"][0] + 2, x1, r["corn"][0] + 2, "m1")
    for x in range(x0, x1 + 1):
        px(L, x, r["corn"][1], "m4" if x % 2 == 0 else "m2")
    rect(L, x0, r["bal"][0], x1, r["bal"][0], "m6"); rect(L, x0, r["bal"][0] + 1, x1, r["bal"][0] + 1, "m3")
    for x in range(x0, x1 + 1):
        rect(L, x, r["bal"][0] + 2, x, r["bal"][1] - 1, ("m5", "m3", "m0")[x % 3])
    rect(L, x0, r["bal"][1], x1, r["bal"][1], "m4")
    for x in [x0] + list(PORT_COLS) + [x1 - 2]:                       # v05: dados over the pilasters and the ends
        dado(L, x, r["bal"][0], r["bal"][1], True)
    for qx, lit in ((x0, True), (x1 - 2, False)):                     # pavilion quoins
        for y in range(r["corn"][1] + 1, r["plinth"][0], 3):
            rect(L, qx, y, qx + 2, min(y + 1, r["plinth"][0] - 1), ("m5" if lit else "m3") if (y // 3) % 2 else "m4")
    for x in PORT_COLS:                                               # upper-storey Corinthian pilasters
        rect(L, x, r["up"][0], x + 1, r["up"][1], "m5"); rect(L, x + 2, r["up"][0], x + 2, r["up"][1], "m3")
        rect(L, x - 1, r["up"][0], x + 3, r["up"][0], "m6"); rect(L, x - 1, r["up"][0] + 1, x + 3, r["up"][0] + 1, "m4")
        px(L, x - 1, r["up"][0] + 1, "m6"); px(L, x + 3, r["up"][0] + 1, "m3")
    for bi, x in enumerate(CENTRE_BAYS):
        if x == 317:
            facade_window(L, x, r["up"][0] + 6, 15, True, ("centre", 0, "up", bi), True)
        else:
            facade_window(L, x, r["up"][0] + 7, 13, False, ("centre", 0, "up", bi), True)
            hood(L, x, r["up"][0] + 7, "seg" if bi in (0, 4) else True, True)     # v05: hood hierarchy


def paint_portico(L):
    """Columned entrance portico (+7 rows): terrace balustrade, entablature, dark loggia with arched openings and the
    lit door, six Ionic columns with their shadows on the loggia wall, porch podium."""
    xa, xb = PORTICO[0] - 2, PORTICO[1] + 2
    rect(L, xa, 98, xb, 98, "m6")
    for x in range(xa, xb + 1):
        rect(L, x, 99, x, 101, ("m5", "m3", "m0")[x % 3])
    rect(L, xa, 102, xb, 102, "m4")
    for x in PORT_COLS:
        rect(L, x, 97, x + 3, 102, "m5"); rect(L, x, 97, x + 3, 97, "m6"); rect(L, x + 3, 98, x + 3, 102, "m3")
    rect(L, xa, 103, xb, 103, "m6"); rect(L, xa, 104, xb, 104, "m4"); rect(L, xa, 105, xb, 105, "m2")
    rect(L, xa, 106, xb, 133, "m1")
    for y in range(110, 134, 5):
        rect(L, xa, y, xb, y, "m0")
    for (a, b) in ((288, 297), (302, 311), (316, 323), (328, 337), (342, 351)):
        if a == 316:
            rect(L, 317, 112, 322, 131, "wl"); rect(L, 318, 110, 321, 111, "wl"); rect(L, 318, 108, 321, 109, "wl2")
            rect(L, 317, 112, 318, 131, "wl2"); rect(L, 320, 113, 320, 131, "au0")
        else:
            c = (a + b) // 2
            rect(L, c - 2, 113, c + 2, 131, "w0"); rect(L, c - 1, 112, c + 1, 112, "w0"); rect(L, c - 2, 114, c - 1, 116, "w2")
    for x in PORT_COLS:
        for i, c in enumerate(("m5", "m6", "m4", "m2")):
            rect(L, x + i, 108, x + i, 131, c)
        rect(L, x - 1, 106, x + 4, 106, "m6"); rect(L, x - 1, 107, x + 4, 107, "m4")
        px(L, x - 1, 107, "m5"); px(L, x + 4, 107, "m2")
        rect(L, x - 1, 132, x + 4, 133, "m4"); rect(L, x - 1, 133, x + 4, 133, "m2")
        rect(L, x + 4, 108, x + 5, 131, "m0")
    rect(L, xa - 2, 134, xb + 2, 134, "m5"); rect(L, xa - 2, 135, xb + 2, 135, "m4")
    rect(L, xa - 2, 136, xb + 2, 137, "m3"); rect(L, xa - 2, 138, xb + 2, 138, "m2")


def paint_cupola(L):
    c = 319.5
    rect(L, 300, 38, 339, 57, "m4"); rect(L, 300, 38, 302, 57, "m5"); rect(L, 337, 38, 339, 57, "m2")
    rect(L, 298, 36, 341, 36, "m6"); rect(L, 298, 37, 341, 37, "m3"); rect(L, 300, 38, 339, 38, "m2")
    rect(L, 314, 43, 325, 56, "m1"); rect(L, 315, 42, 324, 42, "m1"); rect(L, 317, 41, 322, 41, "m1")
    for y in range(44, 56, 2):
        rect(L, 315, y, 324, y, "m2")
    rect(L, 313, 41, 313, 56, "m5"); rect(L, 326, 41, 326, 56, "m3")
    for wx in (305, 331):
        rect(L, wx, 46, wx + 2, 48, "w0"); px(L, wx, 46, "w2")
    for x in range(306, 334):
        u = (x + 0.5 - c) / 14
        v = cyl(u)
        col = tone(["m1", "m2", "m3", "m4", "m5", "m6"], v, (0.05, 0.22, 0.38, 0.52, 0.66))
        rect(L, x, 24, x, 35, col)
        if int(round((x + 0.5 - c) / 4.6)) % 2 == 0 and abs(u) < 0.95 and abs(x + 0.5 - c) > 6:
            rect(L, x, 26, x, 34, shift_of(["m0", "m1", "m2", "m3", "m4", "m5", "m6"], col, -2))
    for y in range(25, 35):
        for x in range(314, 326):
            d = math.hypot(x + 0.5 - c, (y + 0.5 - 29.5) * 1.05)
            if d <= 4.6:
                px(L, x, y, "m6")
            elif d <= 5.6:
                px(L, x, y, "au1" if x < c else "au0")
    rect(L, 319, 26, 320, 29, "k0"); rect(L, 320, 29, 322, 30, "k0")
    rect(L, 304, 22, 335, 22, "m6"); rect(L, 304, 23, 335, 23, "m2")
    for y in range(11, 22):
        t = (21.5 - y) / 11.0
        hw = 13.5 * math.sqrt(max(0.0, 1 - t * t))
        for x in range(int(c - hw), int(c + hw) + 1):
            u = (x + 0.5 - c) / max(hw, 1)
            v = cyl(u) + 0.12 * (1 - t)
            col = tone(["m1", "m2", "m3", "m4", "m5", "m6"], v, (0.02, 0.2, 0.36, 0.5, 0.64))
            if abs(x + 0.5 - c) > 1 and int(x + 0.5 - c) % 4 == 0:
                col = shift_of(["m1", "m2", "m3", "m4", "m5", "m6"], col, -1)
            px(L, x, y, col)
    rect(L, 316, 6, 323, 10, "m4"); rect(L, 316, 6, 317, 10, "m5"); rect(L, 322, 6, 323, 10, "m2")
    rect(L, 319, 7, 320, 9, "m0"); rect(L, 315, 5, 324, 5, "m5")
    # Justice figure on the cupola (scales west, sword east), cut by the frame top like the towers behind it
    stamp(L, 316, 0, ["b.AA.s", "baAAas", "..AA..", ".aAAa.", "aaAAaa"], {"A": "au2", "a": "au1", "b": "au0",
                                                                        "s": "m6"})
    for y in range(0, 48):                                           # shade-side outline against the city behind
        row = np.nonzero(np.isin(L[y, 296:344], [I[n] for n in ("m1", "m2", "m3", "m4", "m5", "m6")]))[0]
        if len(row):
            px(L, 296 + row.max() + 1, y, "m0")


# ---------------------------------------------------------------------------- v05 facade hierarchy and selective aging
# Material hierarchy: a rusticated ground storey (channelled bed joints, staggered head joints, a lit arris on every
# block) under a smooth ashlar upper storey; the projecting wings carry the stronger relief. Head-joint spacings are
# hand tables, offset per course and per side so the two halves never mirror.
RUST_UNITS = {"front": (9, 12, 10, 11, 8, 12, 10), "link": (11, 9, 12, 10, 13)}


def rusticate(L, x0, x1, y0, y1, kind, side):
    front = kind != "link"
    lit, joint = ("m5", "m2") if front else ("m4", "m2")
    units = RUST_UNITS["front" if front else "link"]
    for c, ya in enumerate(range(y0, y1 + 1, 4)):
        yb = min(y1, ya + 3)
        if c:
            rect(L, x0, ya, x1, ya, lit)                               # lit arris on the block top
        if yb - ya == 3:
            rect(L, x0, yb, x1, yb, joint)                             # channelled bed joint
        x, k = x0 + (5 if (c + side) % 2 else 1), c * 2 + side * 3
        while x <= x1:
            rect(L, x, ya + (1 if c else 0), x, yb - 1, joint)        # head joint
            x += units[k % len(units)]
            k += 1


# Selective aging. Limestone darkens where it is SHELTERED from rain (under cornices, in re-entrant corners, the
# recessed links) and stays clean where rain WASHES it (below sills); the centre pavilion reads as recently cleaned.
# Every zone is a hand-written profile (depth per 4-px chunk, or width per 4-row chunk), dithered on its last row.
SOOT_BANDS = [  # (x0, x1, top row, depth in rows per 4-px chunk west -> east)
    (208, 275, 71, (7, 9, 6, 4, 2, 3, 5, 9, 11, 8, 5, 3, 3, 5, 7, 6, 4)),       # west link under the cornice
    (364, 431, 71, (3, 5, 6, 7, 4, 2, 2, 3, 7, 9, 8, 6, 9, 12, 9, 6, 4)),       # east link
    (150, 207, 80, (2, 3, 4, 3, 1, 0, 0, 2, 3, 1, 0, 2, 4, 5, 3)),              # west wing (lighter)
    (432, 489, 80, (3, 4, 2, 1, 0, 2, 4, 5, 3, 1, 0, 0, 2, 3, 5)),              # east wing (lighter)
    (208, 275, 100, (0, 2, 3, 1, 0, 0, 2, 4, 3, 1, 0, 0, 1, 3, 2, 0, 0)),       # under the link string course
    (364, 431, 100, (0, 0, 1, 3, 4, 2, 0, 0, 1, 2, 1, 0, 2, 4, 3, 1, 0)),
]
SOOT_CORE = 5                       # chunks at least this deep get a second shade step in their upper third
SOOT_COLS = [  # (x of the corner, direction into the wall, first row, width per 4-row chunk top -> bottom)
    (431, -1, 68, (3, 3, 2, 2, 3, 4, 3, 2, 2, 1, 1, 2, 2, 3, 2)),              # east re-entrant corner
    (150, 1, 77, (1, 1, 2, 1, 0, 0, 1, 1, 2, 2, 1, 0, 0, 1, 2)),               # west wing outer arris
    (489, -1, 77, (0, 1, 1, 2, 2, 1, 1, 0, 0, 1, 1, 2, 1, 1, 0)),              # east wing outer arris
]
PLINTH_GRIME = {  # splash grime height (rows) per 4-px chunk, per section (v04: a uniform 2-row band)
    150: (3, 4, 2, 2, 3, 1, 1, 2, 3, 4, 3, 2, 2, 3, 4), 208: (2, 1, 1, 2, 3, 3, 2, 1, 1, 1, 2, 4, 5, 3, 2, 2, 1),
    276: (1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1),
    364: (1, 2, 2, 1, 1, 2, 3, 2, 1, 1, 2, 2, 3, 4, 3, 2, 2), 432: (2, 3, 3, 2, 1, 1, 2, 2, 3, 2, 1, 2, 4, 4, 3)}
WASH = [(161, 100, 104), (196, 101, 104), (447, 100, 104), (480, 100, 103), (293, 94, 98), (347, 95, 98),
        (234, 90, 94), (266, 91, 95), (370, 90, 93), (418, 90, 95)]                  # rain-washed streaks (x, y0, y1)
REPAIRS = [(224, 80, 227, 82), (236, 108, 240, 110), (183, 90, 185, 93), (452, 117, 457, 118), (401, 112, 404, 114)]
LICHEN = [(152, 140), (480, 139), (210, 128), (425, 128), (271, 129)]               # stamp top-left on the plinth
ROOF_PATCHES = [(180, 52, 187, 53), (246, 50, 251, 51), (402, 53, 409, 54), (455, 51, 460, 52), (333, 49, 338, 50)]
WING_TREE_SHADE = ([(164, 118, 12, 9), (155, 106, 6, 5), (172, 129, 9, 6)], [(161, 114, 2, 1), (167, 124, 1.5, 1)])
LIT_LUT = {"m2": "m3", "m3": "m4", "m4": "m5", "m5": "m6"}


def age_facade(L):
    """v05 selective aging (before the haze remap): soot in sheltered zones, uneven splash grime, rain-washed clean
    streaks, crisp lighter repair stones, lichen at the plinth, replaced slates, and the dappled shade of the west
    mid-tree on the west wing. Wall / joint colours only, so window glass and trim keep their read."""
    walls = np.isin(L, [I[c] for c in ("m2", "m3", "m4", "m5")])
    chk = (XX + YY) % 2 == 0
    soot = np.zeros((H, W), bool)
    core = np.zeros((H, W), bool)
    for (x0, x1, top, depths) in SOOT_BANDS:
        for k, d in enumerate(depths):
            if d:
                xa, xb = x0 + 4 * k, min(x1, x0 + 4 * k + 3)
                soot |= box(xa, top, xb, top + d - 2) | (box(xa, top + d - 1, xb, top + d - 1) & chk)
                if d >= SOOT_CORE:
                    core |= box(xa, top, xb, top + d // 3 - 1) | (box(xa, top + d // 3, xb, top + d // 3) & chk)
    for (xc, dr, y0, widths) in SOOT_COLS:
        for k, w in enumerate(widths):
            for j in range(w):
                col = box(xc + dr * j, y0 + 4 * k, xc + dr * j, y0 + 4 * k + 3)
                soot |= col if j < w - 1 else (col & chk)              # innermost column dithered
    shade_region(L, soot & walls)
    shade_region(L, core & walls & np.isin(L, [I[c] for c in ("m2", "m3", "m4")]))
    for kind, x0, x1, d in SECTIONS:
        r = section_rows(kind, d)
        for k, hh in enumerate(PLINTH_GRIME[x0]):
            xa, xb = x0 + 4 * k, min(x1, x0 + 4 * k + 3)
            yb = r["plinth"][0] - 1
            g = box(xa, yb - hh + 2, xb, yb) | (box(xa, yb - hh + 1, xb, yb - hh + 1) & chk)
            shade_region(L, g & np.isin(L, [I["m3"], I["m4"], I["m5"]]))
    for (x, y0, y1) in WASH:
        for y in range(y0, y1 + 1):
            c = int(L[y, x])
            for a, b in LIT_LUT.items():
                if c == I[a]:
                    L[y, x] = I[b]
                    break
    for (x0, y0, x1, y1) in REPAIRS:
        rect(L, x0, y0, x1, y1, "m5"); rect(L, x0, y0, x1, y0, "m6"); px(L, x1, y1, "m4")
    for (x, y) in LICHEN:
        stamp(L, x, y, ["ab.", "bab"], {"a": "lc1", "b": "lc0"})
    for (x0, y0, x1, y1) in ROOF_PATCHES:
        rect(L, x0, y0, x1, y1, "r2"); rect(L, x0, y1, x1, y1, "r1")
    lobes, flecks = WING_TREE_SHADE
    sh = np.zeros((H, W), bool)
    for e in lobes:
        sh |= ell(*e)
    for e in flecks:
        sh &= ~ell(*e)
    shade_region(L, sh & box(150, 96, 190, 143) & (L >= 0))


def paint_city_hall():
    """Central pavilion (+3 rows), two projecting wings (+9), recessed links, columned entrance portico (+7), domed
    clock tower. Drawn back to front; wing / pavilion shadows fall on the recessed walls east of them."""
    L = new()
    for kind, x0, x1, d in SECTIONS:
        if kind == "link":
            paint_section(L, kind, x0, x1, d, 0 if x0 < CX else 1)
    paint_centre(L)
    for kind, x0, x1, d in SECTIONS:
        if kind == "wing":
            paint_section(L, kind, x0, x1, d, 0 if x0 < CX else 1)
    shade_region(L, box(208, BAL[0], 216, PLINTH[1]) & ((XX - 208) < 4 + (YY - BAL[0])))   # west wing's shadow
    shade_region(L, box(364, BAL[0], 366, PLINTH[1]))                                       # pavilion's shadow
    shade_region(L, box(360, 102, 363, PLINTH[1] + 3))                                      # portico's shadow
    for kind, x0, x1, d in SECTIONS:                                 # cornice shadow band on the upper wall
        r = section_rows(kind, d)
        wall = I["m4"] if kind != "link" else I["m3"]
        shade_region(L, box(x0, r["up"][0] + 1, x1, r["up"][0] + 2) & (L == wall))
    for (x, y0, y1) in STREAKS:                                      # (v05: splash grime moved into age_facade)
        shade_region(L, box(x, y0, x, y1) & np.isin(L, [I["m4"], I["m3"]]))
    age_facade(L)                                                    # v05: selective aging, before the portico
    paint_portico(L)
    paint_cupola(L)
    haze(L)
    return L


def haze(L, mask=None):
    """Aerial perspective: remap the backdrop's marble / roof / glass colours to their hazed twins (HAZE table)."""
    lut = np.arange(len(ALL_PAL), dtype=np.int16)
    for a, b in HAZE.items():
        lut[I[a]] = I[b]
    sel = (L >= 0) if mask is None else (mask & (L >= 0))
    L[sel] = lut[L[sel]]


# ============================================================================ forecourt (backdrop scale) and gate
LAWN_LIGHT = [(178, 196, 44, 12), (468, 204, 50, 14), (520, 306, 40, 12), (372, 318, 22, 7), (250, 304, 20, 7),
              (184, 152, 40, 9), (452, 152, 36, 9)]
LAWN_DAMP = [(136, 186, 30, 9), (580, 226, 24, 8), (80, 318, 18, 8), (420, 162, 18, 5)]
TUFT = {"near": ((0, 0, 1), (-1, 1, 1), (0, 1, 1), (0, 2, -1), (1, 2, -1)),
        "mid": ((0, 0, 1), (1, 0, 1), (1, 1, -1), (2, 1, -1)),
        "far": ((0, 0, 1), (1, 0, 1))}
TUFT_LAT = {"near": (6, 4), "mid": (5, 3), "far": (4, 3)}
TUFT_ROWS = {"far": (0, 149), "mid": (150, 199), "near": (200, H - 1)}
JIT = ((0, 2), (3, 1), (1, 3), (4, 0), (2, 2), (5, 1))             # fixed lattice offsets, cycled per cell
MOWN = [(452, 196, 44, 9), (570, 228, 26, 7), (104, 186, 34, 8), (520, 326, 34, 6), (112, 312, 22, 6),
        (236, 192, 22, 5), (400, 296, 26, 6)]                         # v03: hand-placed tuft-free (mown) patches


# v05 park-lawn material hierarchy (key "lawn" only; the forecourt keeps the v04 lawn). Each zone is a hand-placed
# ellipse (x, y, rx, ry) painted with a 2x2-checker rim: broad sunlit swards, brighter crests inside them, damp / shaded
# swales along fences and under the canopy, clover-and-weed patches (yellow-green) and two strips of drought-browned
# turf where the lawn meets hot paving. Together they replace the even g2 field with a readable large-scale value map.
LAWN_SUN = [(240, 182, 28, 8), (424, 200, 32, 9), (562, 302, 24, 7), (128, 318, 28, 7), (590, 204, 14, 10),
            (378, 300, 20, 6), (250, 318, 14, 5), (118, 232, 14, 5)]
LAWN_CREST = [(236, 181, 11, 3), (428, 199, 13, 3), (124, 318, 9, 2), (566, 301, 9, 2), (592, 206, 5, 4)]
LAWN_SWALE = [(200, 331, 34, 5), (476, 322, 32, 5), (520, 182, 22, 6), (88, 300, 12, 9), (400, 244, 22, 5),
              (152, 250, 14, 5), (282, 214, 10, 6)]
LAWN_CLOVER = [(152, 200, 10, 3), (380, 188, 8, 3), (600, 236, 6, 4), (524, 333, 10, 3), (232, 324, 8, 2),
               (98, 303, 6, 3), (446, 296, 7, 2), (286, 178, 5, 2)]
LAWN_DRY = [(270, 250, 12, 2.5), (356, 284, 9, 2), (566, 284, 10, 2.2), (100, 286, 8, 2)]
TUFT_BLADE = ((0, 0, 1), (0, 1, 0), (0, 2, -1))                     # v05 second tuft motif (upright blade), sun zones


def lawn_zones(base, chk):
    def zone(tab, c, core=0.8):
        for (zx, zy, rx, ry) in tab:
            e = ((XX + 0.5 - zx) / rx) ** 2 + ((YY + 0.5 - zy) / ry) ** 2
            base[(e <= core) | ((e <= 1.0) & chk)] = I[c]
    zone(LAWN_SUN, "g3")
    zone(LAWN_CREST, "g4", 0.7)
    zone(LAWN_SWALE, "g1")
    zone(LAWN_CLOVER, "y2", 0.6)
    zone(LAWN_DRY, "y3", 0.6)


def grass(L, mask, key):
    """Lawn: hand-placed sunlit and damp zones (2x2 checker borders) and a hand-drawn tuft motif on a fixed staggered
    lattice. Tufts shrink with distance (3-row near tufts, 2-row mid, 2-px far ticks) so lawns recede toward City
    Hall instead of ending in a band. v05 (park lawn): the lawn_zones value map, and an upright-blade motif replaces
    every third tuft inside sunlit zones so the lattice no longer reads as one repeated stamp."""
    chk = (XX // 2 + YY // 2) % 2 == 0
    base = np.full((H, W), I["g2"], np.int16)
    for (zx, zy, rx, ry) in LAWN_LIGHT:
        e = ((XX + 0.5 - zx) / rx) ** 2 + ((YY + 0.5 - zy) / ry) ** 2
        base[(e <= 0.8) | ((e <= 1.0) & chk)] = I["g3"]
    for (zx, zy, rx, ry) in LAWN_DAMP:
        e = ((XX + 0.5 - zx) / rx) ** 2 + ((YY + 0.5 - zy) / ry) ** 2
        base[(e <= 0.8) | ((e <= 1.0) & chk)] = I["g1"]
    if key == "lawn":
        lawn_zones(base, chk)
    L[mask] = base[mask]
    ramp = [I[c] for c in ("g0", "g1", "g2", "g3", "g4")]
    order = {c: i for i, c in enumerate(ramp)}
    yramp = [I[c] for c in ("y0", "y1", "y2", "y3", "y4")]
    yorder = {c: i for i, c in enumerate(yramp)}
    for kind, (r0, r1) in TUFT_ROWS.items():
        cw, ch = TUFT_LAT[kind]
        for gy in range(r0 // ch, r1 // ch + 1):
            for gx in range(0, W // cw + 1):
                if (gx * 5 + gy * 3) % 7 == 0:
                    continue
                if any(((gx * cw + 0.5 - mx) / mrx) ** 2 + ((gy * ch + 0.5 - my) / mry) ** 2 <= 1.0
                       for mx, my, mrx, mry in MOWN):
                    continue                                          # v03: freshly mown patches break the lattice
                jx, jy = JIT[(gx + 2 * gy) % 6]
                x, y = gx * cw + jx % cw, gy * ch + jy % ch
                if not (r0 <= y <= r1) or not (0 < x < W - 1) or y + 2 >= H or not mask[y, x]:
                    continue
                rp_, b = ramp, order.get(int(L[y, x]), 2)
                if key == "lawn" and int(L[y, x]) in yorder:                # v05: clover / dry tufts stay yellow
                    rp_, b = yramp, yorder[int(L[y, x])]
                motif = TUFT[kind]
                if key == "lawn" and kind == "near" and b >= 3 and (gx + gy) % 3 == 0:
                    motif = TUFT_BLADE                                      # v05: upright blades in sunlit swards
                for dx, dy, d in motif:
                    if mask[y + dy, x + dx]:
                        L[y + dy, x + dx] = rp_[max(0, min(4, b + d))]


def hedge_strip(L, xa, xb, y0, y1):
    """Clipped box border at the building base: lit top row with 2-px sprigs every 7 px, notches every 16 px."""
    rect(L, xa, y0, xb, y1, "f3")
    rect(L, xa, y0, xb, y0, "f4")
    for x in range(xa + 2, xb, 7):
        rect(L, x, y0, x + 1, y0, "f5")
    rect(L, xa, y1, xb, y1, "f1")
    for x in range(xa + 8, xb - 2, 16):
        rect(L, x, y0 + 1, x, y1 - 1, "f2")


BORDER_BLOOMS = [(160, 145, "fl1"), (163, 146, "fl3"), (181, 145, "fl2"), (199, 145, "fl1"), (444, 145, "fl4"),
                 (461, 146, "fl3"), (478, 145, "fl1"), (220, 133, "fl2"), (253, 133, "fl1"), (384, 133, "fl1"),
                 (414, 133, "fl2")]
LANDING_COURSES = [((158, 159), (5, 4, 6, 5, 4, 6)), ((160, 162), (7, 6, 8, 6, 7)), ((163, 166), (9, 11, 8, 10)),
                   ((167, 171), (13, 11, 15, 12, 14))]


def lobe_shadow_mask(t, clip=None):
    """Ground shadow of a tree: every lobe projected along the sun (+x, -y per row of height), flattened."""
    bx, b = t["base"]
    sm = np.zeros((H, W), bool)
    cx, cy = t["c"]
    for dx, dy, r in t["lobes"]:
        z = b - (cy + dy)
        sm |= ell(cx + dx + SUN[0] * z, b - SUN[1] * z, r * 0.95, r * 0.45)
    zt = b - cy
    sm |= seg((bx, b), (bx + SUN[0] * zt, b - SUN[1] * zt), 2.5)
    return sm if clip is None else sm & clip


def paint_forecourt():
    L = new()
    lawn = box(64, 40, PARK_ROW - 1, WALK_TOP - 1)
    grass(L, lawn, "forecourt")
    for (xa, xb, y0, y1) in ((152, 205, 144, 147), (434, 487, 144, 147), (210, 273, 132, 135), (366, 429, 132, 135)):
        hedge_strip(L, xa, xb, y0, y1)
        shade_region(L, box(xa - 1, y1 + 1, xb + 1, y1 + 1))                # contact shade under the border
    for (x, y, c) in BORDER_BLOOMS:
        rect(L, x, y, x + 1, y, c); px(L, x, y + 1, c); px(L, x + 1, y + 1, "f2")
    shade_region(L, box(208, 132, 216, 143) & (L >= 0))                      # west wing's ground shadow
    # grand stair: graded risers (2-row far steps at the portico, 4-row near steps), splaying toward the gate
    y = STAIR_TOP
    for k, h in enumerate(STAIR_RISERS):
        xa, xb = 276 - 2 * k, 363 + 2 * k
        rect(L, xa, y, xb, y, "m5")
        if h >= 2:
            rect(L, xa, y + 1, xb, y + 1, "m2")
        if h >= 3:
            rect(L, xa, y + 2, xb, y + h - 1, "m3")
        px(L, xa, y, "m6")
        y += h
    for (a, b, lit) in ((256, 263, True), (376, 383, False)):               # cheek blocks
        rect(L, a, 139, b, 157, "m4" if lit else "m3"); rect(L, a, 139, b, 140, "m6" if lit else "m5")
        rect(L, a, 157, b, 157, "m2"); rect(L, b, 141, b, 156, "m3" if lit else "m2")
    # landing and forecourt walk inside the gate: courses thin with distance (5 -> 2 rows), slabs shorten
    for ci, ((ya, yb), widths) in enumerate(LANDING_COURSES):
        x, k = 256 - (ci * 3) % 7, 0
        while x <= 383:
            w = widths[k % len(widths)]
            t = ("p4", "p3", "p4", "p4", "p3")[(k + ci) % 5]
            rect(L, max(256, x + 1), ya + 1, min(383, x + w - 1), yb, t)
            if yb - ya >= 2:
                rect(L, max(256, x + 1), ya + 1, min(383, x + 2), ya + 1, "p5" if t == "p4" else "p4")
            rect(L, max(256, x), ya, min(383, x + w - 1), ya, "p2")
            if 256 <= x <= 383:
                rect(L, x, ya, x, yb, "p2")
            x += w
            k += 1
    rect(L, 280, 170, 359, 170, "t0")                                        # access light line (2537)
    for x in range(282, 358, 6):
        rect(L, x, 170, x + 1, 170, "t1")
    # shadows on the forecourt ground: gate piers, railing top rails, mid-distance trees
    sh = np.zeros((H, W), bool)
    for (a, b) in GATE_PIERS:
        for yy in range(162, WALK_TOP):
            s = (WALK_TOP - 1 - yy) * SUN[0] / SUN[1]
            sh |= box(int(a + s), yy, int(b + s), yy)
        sh |= ell((a + b) / 2 + SUN[0] * 56, WALK_TOP - 1 - SUN[1] * 56, 4, 1.5)
    for (a, b) in RAILS:
        sh |= box(a + 7, 166, b + 7, 166)
    for t in MID_TREES:
        sh |= lobe_shadow_mask(t)
    shade_region(L, sh & lawn & (YY >= 136))
    haze(L, YY < 146)                                                # far treads and cheek tops share the building's haze
    return L


def paint_forecourt_near():
    L = new()
    for t in MID_TREES:
        paint_tree(L, t)
    for x, kind in FLAGS:                                            # flagpoles with the U.S. and NYC flags
        rect(L, x, FLAG_TOP, x, FLAG_BASE, "m5"); rect(L, x + 1, FLAG_TOP, x + 1, FLAG_BASE, "m3")
        rect(L, x - 1, FLAG_BASE - 1, x + 2, FLAG_BASE, "m2"); px(L, x, FLAG_TOP - 1, "au2")
        fx0, fy0, fw, fh = x + 2, FLAG_TOP + 2, 17, 11
        for i in range(fw):
            dy = 1 if 5 <= i <= 10 else 0
            for j in range(fh):
                if kind == "us":
                    col = "fr" if j % 2 == 0 else "m6"
                    if i < 7 and j < 6:
                        col = "fb" if (i + j) % 3 else "m6"
                else:
                    col = "fb" if i < 6 else ("m6" if i < 12 else "fo")
                    if (i, j) in ((8, 4), (9, 5), (8, 6), (9, 4)):
                        col = "fb"
                px(L, fx0 + i, fy0 + j + dy, col)
            px(L, fx0 + i, fy0 + fh + dy, "m2" if i % 3 else "m1")
    for ex in (RAILS[0][0] - 4, RAILS[1][1] + 1):                    # granite end posts with ball finials
        rect(L, ex, 138, ex + 3, 171, "m4"); rect(L, ex, 138, ex, 171, "m5"); rect(L, ex + 3, 138, ex + 3, 171, "m2")
        rect(L, ex - 1, 136, ex + 4, 137, "m6"); rect(L, ex - 1, 137, ex + 4, 137, "m3")
        stamp(L, ex, 133, [".ab.", "abbc", ".cc."], {"a": "m6", "b": "m4", "c": "m2"})
    for (xa, xb) in RAILS:                                           # hero-scale iron railings on a granite curb
        rect(L, xa, 167, xb, 171, "m3"); rect(L, xa, 167, xb, 167, "m5"); rect(L, xa, 171, xb, 171, "m2")
        rect(L, xa, 164, xb, 164, "k2"); rect(L, xa, 165, xb, 165, "k1")
        for x in range(xa + 1, xb, 4):
            rect(L, x, 145, x, 166, "k1"); rect(L, x - 1, 145, x + 1, 145, "k1"); px(L, x, 143, "k2"); px(L, x, 144, "k2")
        rect(L, xa, 147, xb, 147, "k3"); rect(L, xa, 148, xb, 148, "k1")
    for t in SHRUBS:
        paint_tree(L, t)
    for (a, b) in GATE_PIERS:                                        # hero-scale granite gate piers with lanterns
        rect(L, a - 1, 164, b + 1, 171, "m3"); rect(L, a - 1, 164, b + 1, 164, "m5"); rect(L, a - 1, 171, b + 1, 171, "m2")
        rect(L, a - 1, 165, a - 1, 170, "m4")
        rect(L, a, 134, b, 163, "m4"); rect(L, a, 134, a + 1, 163, "m5"); rect(L, b, 134, b, 163, "m2")
        rect(L, a + 3, 138, b - 3, 159, "m3")
        rect(L, a + 3, 138, b - 3, 138, "m2"); rect(L, a + 3, 139, a + 3, 159, "m2")
        rect(L, a + 4, 159, b - 3, 159, "m5"); rect(L, b - 3, 139, b - 3, 158, "m5")
        mid = (a + b) // 2
        rect(L, mid, 141, mid, 156, "t0"); px(L, mid, 141, "t2"); px(L, mid, 146, "t1"); px(L, mid, 151, "t1")
        rect(L, a - 2, 128, b + 2, 128, "m6"); rect(L, a - 2, 129, b + 2, 130, "m4"); rect(L, a - 2, 129, a - 1, 130, "m5")
        rect(L, a - 1, 131, b + 1, 131, "m2"); rect(L, a, 132, b, 133, "m4"); rect(L, b, 132, b, 133, "m2")
        lc = mid
        rect(L, lc - 2, 126, lc + 3, 127, "k1"); rect(L, lc, 122, lc + 1, 125, "k2")
        rect(L, lc - 3, 113, lc + 4, 121, "k1")
        rect(L, lc - 2, 114, lc + 3, 120, "wl"); rect(L, lc - 2, 114, lc - 1, 117, "wl2"); rect(L, lc + 1, 114, lc + 1, 120, "au0")
        rect(L, lc - 4, 112, lc + 5, 112, "k2"); rect(L, lc - 3, 111, lc + 4, 111, "k1"); rect(L, lc, 109, lc + 1, 110, "k2")
    return L


# ============================================================================ park ground (hero scale)
def park_masks():
    m = {}
    m["axis"] = box(AXIS[0], WALK_TOP, AXIS[1], H - 1)
    x0, x1, y0, y1 = SOUTH_PLAZA
    m["south"] = box(x0, y0, x1, y1)
    m["plaza"] = ell(*FOUNTAIN, *PLAZA_R)
    m["basin"] = ell(*FOUNTAIN, *BASIN_R)
    m["diag"] = seg(*DIAG)
    m["east_conn"] = box(*EAST_CONN)
    m["s_conn"] = box(*S_CONN)
    m["w_gate"] = box(*W_GATE)
    m["statue_walk"] = box(*STATUE_WALK)
    m["statue_c"] = ell(*STATUE_C)
    m["e_walk"] = box(*E_WALK_H) | box(*E_WALK_V)
    park = box(64, WALK_TOP, PARK_ROW - 1, H - 1) | m["south"]
    m["granite"] = (m["axis"] | m["south"] | m["plaza"] | m["statue_c"]) & ~m["basin"]
    m["hex"] = (m["diag"] | m["east_conn"] | m["s_conn"] | m["w_gate"] | m["statue_walk"] | m["e_walk"]) & \
        ~m["granite"] & ~m["basin"]
    m["path"] = (m["granite"] | m["hex"]) & (YY >= WALK_TOP)
    m["lawn"] = park & ~m["path"] & ~m["basin"] & (YY >= WALK_TOP)
    return m


SLAB_TONES = ("p3", "p3", "p4", "p3", "p2", "p3", "p4", "p3")
SOUTH_TONES = ("p3", "p4", "wg2", "p3", "wg1", "p3", "p4", "bs2", "p3", "wg3")   # v04: warm granite, rare bluestone
WIDTHS = (14, 10, 18, 12, 16, 9, 13, 15, 11, 17)
LIT_STEP = {"p2": "p3", "p3": "p4", "p4": "p5", "wg1": "wg2", "wg2": "wg3", "wg3": "p5", "bs1": "bs2", "bs2": "bs3",
            "bs3": "bs4", "bs4": "p5"}
# v04 central promenade (x 292..347, rows 172..337): bluestone flags whose courses thin with distance, a granite
# soldier-course edge band inside each curb, a polished footfall lane and a warm-granite sett crossing band where the
# statue walk and the east connector meet the axis. Every table is hand written.
PROM_X = (292, 347)
PROM_COURSES_N = (5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 8, 9, 9)            # rows 172..255, thin far -> thick near
PROM_COURSES_S = (9, 9, 9, 9, 10, 10)                               # rows 282..337
PROM_BAND = (256, 281)                                              # sett crossing band
PROM_WIDTHS = (13, 9, 16, 11, 7, 14, 10, 18, 12, 8, 15, 11)         # slab lengths
PROM_TONES = ("bs2", "bs3", "bs2", "p3", "bs2", "bs3", "bs1", "bs2", "wg2", "bs3")   # bluestone; rare granite
LANE_DRIFT = (0, 1, 1, 2, 1, 0, -1, -1, -2, -1, 0, 1, 2, 2, 1, 0, -1, -2, -1)        # lane centre offset per course
EDGE_UNITS = (7, 9, 6, 8, 10, 7, 9, 8, 6, 9)                        # soldier-course unit lengths (near scale)
SETT_TONES = ("wg1", "wg2", "wg1", "wg1", "wg3", "wg2", "wg2", "wg1")
RING_C = (337, 268)                                                 # teal wayfinding ring in the crossing band
POLISH = {"bs1": "bs2", "bs2": "bs3", "bs3": "bs4", "wg2": "wg3"}


def promenade(L, mask):
    xa, xb = PROM_X
    fx0, fx1 = xa + 4, xb - 4                                       # bluestone field 296..343
    courses, y = [], WALK_TOP
    for h in PROM_COURSES_N:
        courses.append((y, h)); y += h
    assert y == PROM_BAND[0]
    y = PROM_BAND[1] + 1
    for h in PROM_COURSES_S:
        courses.append((y, h)); y += h
    assert y == 338
    field = mask & box(fx0, 0, fx1, H - 1)
    for c, (ya, h) in enumerate(courses):
        yb = ya + h - 1
        lane_c, lane_hw = 320 + LANE_DRIFT[c % len(LANE_DRIFT)], 5 + h // 2
        k = int(hval("prom", "ph", c) * len(PROM_WIDTHS))
        x = fx0 - int(hval("prom", "off", c) * 15)
        while x <= fx1:
            w = PROM_WIDTHS[k % len(PROM_WIDTHS)]
            sx0, sx1 = max(fx0, x), min(fx1, x + w - 1)
            t = PROM_TONES[int(hval("prom", c, k) * len(PROM_TONES))]
            lane = abs((sx0 + sx1) / 2 - lane_c) <= lane_hw
            tt = POLISH.get(t, t) if lane else t
            jt = "bs1" if lane else "bs0"
            L[field & box(sx0, ya + 1, sx1, yb)] = I[tt]
            if not lane and h >= 6:                                    # NW bevel (worn away inside the lane)
                L[field & (box(sx0 + 1, ya + 1, sx0 + 3, ya + 1) | box(sx0 + 1, ya + 2, sx0 + 1, ya + 2))] = \
                    I[LIT_STEP[tt]]
            if not lane and k % 5 == 2 and w >= 10 and h >= 6:          # bluestone cleft streak
                yy = ya + h // 2 + c % 2
                L[field & box(sx0 + 2, yy, sx0 + w // 2, yy)] = I[SHADE[tt]]
            L[field & box(sx0, ya, sx1, ya)] = I[jt]
            if x >= fx0:
                L[field & box(x, ya, x, yb)] = I[jt]
            x += w
            k += 1
    for side, (b0, b1, jc) in enumerate(((xa + 1, xa + 2, xa + 3), (xb - 2, xb - 1, xb - 3))):
        y, k = WALK_TOP, side * 3                                       # soldier course, units shrink with distance
        while y <= 337:
            n = max(4, int(round(EDGE_UNITS[k % len(EDGE_UNITS)] * (0.55 + 0.45 * (y - WALK_TOP) / 165))))
            y1 = min(337, y + n - 1)
            tone_ = ("wg1", "wg2", "wg1", "wg0")[k % 4]
            L[mask & box(b0, y, b1, y1)] = I[tone_]
            L[mask & box(b0, y, b1, y)] = I["wg0"]
            L[mask & box(b0, y + 1, b0, y + 1)] = I[LIT_STEP.get(tone_, "wg1")]
            y, k = y1 + 1, k + 1
        L[mask & box(jc, WALK_TOP, jc, 337)] = I["bs0"]
    ya, yb = PROM_BAND                                                  # warm-granite sett crossing band
    band = mask & box(xa + 1, ya, xb - 1, yb)
    L[band & box(0, ya, W - 1, ya)] = I["wg0"]
    L[band & box(0, ya + 1, W - 1, ya + 1)] = I["wg2"]
    for c, y0 in enumerate(range(ya + 2, yb - 2, 7)):
        x = xa + 1 - (3 if c % 2 else 0)
        k = 0
        while x <= xb:
            t = SETT_TONES[int(hval("sett", c, k) * len(SETT_TONES))]
            L[band & box(x + 1, y0 + 1, x + 6, y0 + 6)] = I[t]
            L[band & box(x + 1, y0 + 1, x + 2, y0 + 1)] = I[LIT_STEP[t]]
            L[band & (box(x, y0, x, y0 + 6) | box(x, y0, x + 6, y0))] = I["wg0"]
            x += 7
            k += 1
    L[band & box(0, yb - 2, W - 1, yb - 2)] = I["wg0"]
    L[band & box(0, yb - 1, W - 1, yb - 1)] = I["wg2"]
    L[band & box(0, yb, W - 1, yb)] = I["wg1"]


def flags(L, mask, y0, y1, course_h, key, widths=WIDTHS, tones=SLAB_TONES, joint="p2"):
    """Granite flag courses with irregular slab lengths; each slab's tone is picked from a short hand table, and it
    gets one 4-px L-shaped bevel highlight at its north-west corner (no per-texel speckle)."""
    for c, ya in enumerate(range(y0, y1 + 1, course_h)):
        off = int(hval(key, "off", c) * 23)
        k = int(hval(key, "ph", c) * len(widths))
        x = -off
        while x < W:
            w = widths[k % len(widths)]
            t = tones[int(hval(key, c, k) * len(tones))]
            L[mask & box(x + 1, ya + 1, x + w - 1, ya + course_h - 1)] = I[t]
            L[mask & (box(x + 1, ya + 1, x + 3, ya + 1) | box(x + 1, ya + 2, x + 1, ya + 2))] = I[LIT_STEP[t]]
            L[mask & (box(x, ya, x, ya + course_h - 1) | box(x, ya, x + w - 1, ya))] = I[joint]
            x += w
            k += 1


# v05 hex-paver material zones, applied per paver (cell centre inside the ellipse): sun-faded pavers on the open
# sunny walks, oil / leaf-tannin stained pavers under trees and at the cart, and darker freshly re-laid pavers where a
# utility trench was reinstated (next to the 2537 vault lids).
PAVE_ZONES = [(268, 222, 16, 9, "faded"), (372, 266, 14, 8, "relaid"), (424, 264, 12, 7, "stained"),
              (530, 266, 22, 9, "faded"), (588, 300, 12, 14, "stained"), (588, 330, 10, 7, "relaid"),
              (170, 322, 14, 11, "faded"), (78, 270, 11, 9, "stained"), (276, 270, 11, 8, "relaid"),
              (232, 238, 10, 6, "stained")]
PAVE_LUT = {"faded": {"x1": "x2", "x2": "x3", "x3": "p2"}, "stained": {"x3": "x2", "x2": "x1", "x1": "a2"},
            "relaid": {"x3": "x1", "x2": "x1"}}


def hex_pavers(L, mask, key="hex", sx=10, sy=6):
    """NYC park hexagonal pavers: Voronoi cells of a hex lattice squashed for the 3/4 view, mortar on cell borders,
    a lit upper lip on each block; block tone picked per cell from a short hand table."""
    ys, xs = np.nonzero(mask)
    if not len(ys):
        return
    fx, fy = xs + 0.5, ys + 0.5
    j0 = np.floor(fy / sy).astype(int)
    best = np.full(len(xs), 1e9); second = np.full(len(xs), 1e9)
    bid = np.zeros((len(xs), 2), int)
    by = np.zeros(len(xs))
    for dj in (-1, 0, 1, 2):
        j = j0 + dj
        off = (j % 2) * (sx / 2)
        i0 = np.floor((fx - off) / sx).astype(int)
        for di in (-1, 0, 1):
            i = i0 + di
            cxs, cys = i * sx + off, j * sy
            d = np.hypot(fx - cxs, (fy - cys) * (sx / sy) * 0.866)
            upd = d < best
            second = np.where(upd, best, np.minimum(second, d))
            bid[upd] = np.stack([i[upd], j[upd]], 1)
            by = np.where(upd, cys, by)
            best = np.where(upd, d, best)
    joint = (second - best) < 1.25
    tones = np.array([I[("x2", "x2", "x1", "x2", "x3", "x2")[int(hval(key, a, b) * 6)]] for a, b in bid])
    if key == "hex":                                                 # v05: whole pavers change inside each zone
        ccx = bid[:, 0] * sx + (bid[:, 1] % 2) * (sx / 2)
        ccy = bid[:, 1] * sy
        for (zx, zy, rx, ry, kind) in PAVE_ZONES:
            inz = ((ccx + 0.5 - zx) / rx) ** 2 + ((ccy + 0.5 - zy) / ry) ** 2 <= 1.0
            lut = np.arange(len(ALL_PAL))
            for a, b in PAVE_LUT[kind].items():
                lut[I[a]] = I[b]
            tones = np.where(inz, lut[tones], tones)
    out = np.where(joint, I["x0"], tones)
    lip = (~joint) & (fy - by < -sy * 0.32)
    out = np.where(lip & (tones == I["x2"]), I["x3"], out)
    out = np.where(lip & (tones == I["x1"]), I["x2"], out)
    L[ys, xs] = out


def paint_park_ground():
    L = new()
    m = park_masks()
    grass(L, m["lawn"], "lawn")
    gm = m["granite"] & (YY >= WALK_TOP)
    axis_s = (m["axis"] | m["south"]) & ~m["plaza"] & gm
    promenade(L, axis_s & m["axis"] & ~m["south"])                  # v04: bluestone promenade, not a tile strip
    flags(L, axis_s & m["south"], 338, 359, 11, "south", widths=(22, 16, 28, 19, 25, 17, 24), tones=SOUTH_TONES)
    cx, cy = FOUNTAIN                                                # fountain plaza: radial granite rings
    pl = m["plaza"] & ~m["basin"]
    ys, xs = np.nonzero(pl)
    rr = np.hypot((xs + 0.5 - cx) / PLAZA_R[0], (ys + 0.5 - cy) / PLAZA_R[1])
    th = np.arctan2((ys + 0.5 - cy) / PLAZA_R[1], (xs + 0.5 - cx) / PLAZA_R[0])
    k = np.floor((rr - 0.5) / 0.1).astype(int)
    frac = (rr - 0.5) / 0.1 - k
    ring_tone = np.array([I[t] for t in ("p3", "p4", "p3", "p3", "p2", "p2")])
    out = ring_tone[np.clip(k, 0, 5)]
    nseg = 22 + 7 * np.clip(k, 0, 5)
    a = (th / (2 * np.pi) + 0.5) * nseg + 0.5 * (k % 2)
    af = a - np.floor(a)
    rad_joint = (af < 0.9 / (2 * np.pi * rr * PLAZA_R[0] / nseg))
    ring_joint = frac < 0.12
    out = np.where(ring_joint | rad_joint, I["p2"], out)
    out = np.where((rr > 0.95), I["p1"], out)
    out = np.where((rr > 0.95) & (np.floor(a * 2) % 2 == 0), I["p2"], out)
    seg_id = np.floor(a).astype(int)
    hi = (~ring_joint) & (~rad_joint) & (frac < 0.32) & (rr <= 0.95) & (out == I["p3"]) & ((k + seg_id) % 3 == 0)
    out = np.where(hi, I["p4"], out)
    L[ys, xs] = out
    sc = m["statue_c"] & ~m["plaza"]                                 # statue circle with a compass ring
    flags(L, sc, 240, 292, 7, "statue", widths=(9, 12, 8, 11, 10))
    sx0, sy0, srx, sry = STATUE_C
    ring = sc & ~ell(sx0, sy0, srx - 2, sry - 1.5)
    L[ring] = I["p2"]
    L[ring & edge_above(sc)] = I["p4"]
    hex_pavers(L, m["hex"] & (YY >= WALK_TOP))
    lawn, path = m["lawn"], m["path"]                                # granite curbs, lit on the north side
    up = np.zeros_like(path); up[1:] = path[1:] & lawn[:-1]
    dn = np.zeros_like(path); dn[:-1] = path[:-1] & lawn[1:]
    lf = np.zeros_like(path); lf[:, 1:] = path[:, 1:] & lawn[:, :-1]
    rt = np.zeros_like(path); rt[:, :-1] = path[:, :-1] & lawn[:, 1:]
    L[up | lf] = I["p5"]
    L[dn | rt] = I["p2"]
    gl = np.zeros_like(lawn); gl[:-1] = lawn[:-1] & path[1:]
    L[gl] = I["g1"]
    return L


# ============================================================================ wear (every mark hand placed)
CRACKS = [[(298, 186), (301, 189), (301, 193), (304, 196)], [(340, 206), (337, 210), (338, 215)],
          [(308, 248), (312, 250), (317, 250), (319, 253)], [(330, 318), (333, 315), (338, 315)],
          [(196, 232), (200, 229), (205, 229)], [(128, 298), (131, 302), (131, 305)],
          [(452, 350), (456, 347), (462, 347), (465, 344)], [(560, 352), (563, 355), (568, 355)],
          [(470, 286), (474, 289)], [(306, 340), (309, 344), (309, 349)]]
STAINS = [(382, 259, 9, 2), (342, 262, 4, 2), (488, 350, 10, 2), (322, 175, 9, 2), (566, 347, 4, 2),
          (596, 300, 3, 6), (186, 330, 6, 2), (240, 352, 6, 2),
          (301, 214, 6, 2.5), (339, 232, 5, 2), (299, 312, 6, 3), (340, 326, 6, 2.5)]   # v04: damp edge patches
PATCHES = [(300, 238, 312, 245), (326, 186, 339, 192), (500, 344, 522, 353)]      # v04: first moved off the band
MOSS_BOXES = [(292, 172, 300, 250), (64, 236, 150, 262), (346, 300, 347, 337),
              (348, 255, 452, 258), (572, 280, 576, 338), (150, 300, 154, 338), (490, 274, 571, 277)]   # v05: +4
# v05: wet splash apron on the fountain plaza, on the lee (north-east) side of the basin only, with a dithered rim
SPLASH = (57, 33)                    # outer radii about the basin centre
SPLASH_LEE_X = -6                    # only texels east of FOUNTAIN x + this
SUNKEN = [(270, 216), (522, 266), (588, 314), (79, 270)]
TURF = [("ell", 100, 207, 13, 4), ("line", [(88, 252), (95, 257), (104, 258)], 2), ("ell", 262, 331, 8, 2),
        ("ell", 540, 241, 9, 2), ("ell", 462, 241, 6, 2), ("ell", 410, 301, 7, 2), ("line", [(286, 176), (282, 184),
                                                                                              (283, 192)], 2)]
LEAF = {"a": ["a.", ".b"], "b": [".a", "ab"], "c": ["ab"], "d": ["a", "b"]}
LITTER = [(118, 240, "a", "au0", "s1"), (104, 252, "b", "fl5", "au0"), (126, 246, "c", "e2", "s1"),
          (418, 262, "a", "au0", "s1"), (430, 271, "d", "fl5", "au0"), (396, 276, "b", "e2", "s1"),
          (560, 262, "c", "au0", "s1"), (548, 270, "a", "fl5", "au0"), (296, 318, "c", "pk1", "pk0"),
          (294, 326, "d", "pk1", "pk0"), (300, 331, "a", "pk2", "pk1"), (452, 262, "b", "y3", "y1"),
          (474, 270, "c", "y3", "y1"), (86, 296, "a", "au0", "s1")]


def paint_ground_wear():
    """Wear layer (separate so a painter can edit or hide it): hairline cracks, oil / damp stains, replaced slabs,
    moss in shaded joints, sunken hex pavers, trampled turf and mulch rings, small leaf / petal litter."""
    L = new()
    m = park_masks()
    pave = m["path"]
    g = paint_park_ground()                                         # read-only reference for joint detection
    for (x0, y0, x1, y1) in PATCHES:
        msk = box(x0, y0, x1, y1) & m["granite"]
        L[msk] = I["p4"]
        L[msk & ~box(x0 + 1, y0 + 1, x1 - 1, y1 - 1)] = I["p2"]
        L[msk & box(x0 + 1, y0 + 1, x0 + 3, y0 + 1)] = I["p5"]
    for (sx, sy, rx, ry) in STAINS:
        e = ((XX + 0.5 - sx) / rx) ** 2 + ((YY + 0.5 - sy) / ry) ** 2
        chk = (XX // 2 + YY // 2) % 2 == 0
        msk = ((e <= 0.7) | ((e <= 1.0) & chk)) & pave
        L[msk] = SHADE_LUT[np.clip(np.where(L[msk] >= 0, L[msk], g[msk]), 0, None)]
    fx, fy = FOUNTAIN                                                 # v05: wet splash apron (lee side)
    e = ((XX + 0.5 - fx) / SPLASH[0]) ** 2 + ((YY + 0.5 - fy) / SPLASH[1]) ** 2
    chk = (XX // 2 + YY // 2) % 2 == 0
    wet = ((e <= 0.86) | ((e <= 1.0) & chk)) & ~m["basin"] & (XX >= fx + SPLASH_LEE_X) & m["granite"]
    L[wet] = SHADE_LUT[np.clip(np.where(L[wet] >= 0, L[wet], g[wet]), 0, None)]
    for pts in CRACKS:
        poly(L, pts, "p1", m["granite"])
    near_lawn = dilate(m["lawn"], 2)
    for (x0, y0, x1, y1) in MOSS_BOXES:
        msk = box(x0, y0, x1, y1) & pave & near_lawn & np.isin(g, [I["p2"], I["x0"], I["bs0"]])
        L[msk] = I["g1"]
    for (sx, sy) in SUNKEN:
        msk = ell(sx, sy, 4, 2.2) & m["hex"]
        L[msk] = I["x1"]
        L[msk & (edge_above(msk) | edge_below(msk))] = I["x0"]
    for t in TURF:
        if t[0] == "ell":
            _, sx, sy, rx, ry = t
            e = ((XX + 0.5 - sx) / rx) ** 2 + ((YY + 0.5 - sy) / ry) ** 2
            core = (e <= 0.55) & m["lawn"]
            rim = (e <= 1.0) & ~core & m["lawn"] & ((XX // 2 + YY // 2) % 2 == 0)
            L[core] = I["s1"] if rx <= 9 else I["e1"]
            L[core & edge_above(core)] = I["e2"]
            L[rim] = I["e2"] if rx > 9 else I["e1"]
        else:
            _, pts, hw = t
            msk = np.zeros((H, W), bool)
            for p, q in zip(pts, pts[1:]):
                msk |= seg(p, q, hw)
            msk &= m["lawn"]
            L[msk] = I["e1"]
            L[msk & edge_above(msk)] = I["e2"]
    for (x, y, shape, ca, cb) in LITTER:
        stamp(L, x, y, LEAF[shape], {"a": ca, "b": cb})
    return L


# ============================================================================ ground detail: beds, drains, wayfinding
PIGEON = {0: [".kg..", "kmmmx", "..mx."], 1: ["..gk.", "xmmmk", ".xm.."]}
PIGEONS = [(232, 349, 0), (241, 352, 1), (248, 347, 0), (146, 322, 1), (152, 325, 0)]


BEDS = [  # v04: centre, foliage lobes (dx, dy, r; squashed 0.42 for the 3/4 view), bloom drifts (dx, dy, rx, ry,
    # (lit, mid, shade)), accents ("ball", dx, dy, r) / ("grass", dx, dy). Asymmetric on purpose: lobes of unequal
    # size, drifts of unequal size and spacing, one accent at one end only. Bed 1 sits east of the behind-fountain
    # capture so her head reads against lawn.
    dict(c=(214, 191), lobes=[(-16, 2, 7), (-6, -1, 10), (8, -2, 11), (19, 2, 8), (26, 4, 4)],
         drifts=[(-10, 0, 8.5, 3.4, ("pk1", "pk0", "fl0")), (5, -1, 6, 3.0, ("fl3", "m4", "m3")),
                 (16, 2, 6, 2.8, ("fl4", "c1", "fb"))],
         accents=[("grass", 25, 3)]),
    dict(c=(500, 232), lobes=[(-12, 1, 7), (-3, -1, 9), (8, 0, 8), (15, 3, 5)],
         drifts=[(-6, 0, 7.5, 3.2, ("fl2", "au1", "au0")), (8, 1, 5.5, 2.8, ("fl1", "fl0", "pk0"))],
         accents=[("ball", -15, 1, 4)]),
    dict(c=(524, 305), lobes=[(-24, 2, 8), (-13, -1, 11), (1, 1, 10), (14, -2, 10), (25, -3, 6), (31, -1, 4)],
         drifts=[(-15, 0, 9.5, 3.6, ("fl4", "c1", "fb")), (2, 1, 6, 3.0, ("fl3", "m4", "m3")),
                 (17, -2, 7.5, 3.0, ("pk1", "pk0", "fl0"))],
         accents=[("grass", -27, 2), ("ball", 30, -1, 4)]),
    dict(c=(278, 299), lobes=[(-5, 1, 6), (3, -1, 5)], drifts=[], accents=[("ball", 0, -1, 4)])]
GRASS = [(-3, 4), (-2, 6), (-1, 7), (0, 8), (1, 7), (2, 5), (3, 4)]    # ornamental grass: (tip dx, height) strokes


def bed(L, b):
    """v04 planted bed: no stone ring. Foliage is a crown-style clump canopy over a lobe union (lumpy silhouette, lit
    from the south-west, dark lower / east edge), a mulch lip shows under its south edge, and each bloom drift is a
    cluster of 2x1 / 2x2 heads on a fixed 3x2 lattice -- dense in the drift core, every other head on its rim -- so a
    drift reads as many flowers with leaves between, never a flat sticker oval. Returns the bed's foliage union."""
    cx, cy = b["c"]
    u = crown(L, cx, cy, b["lobes"], "bedleaf", squash=0.42)
    lip = np.zeros_like(u)
    lip[1:] = u[:-1] & ~u[1:]                                         # first row below the south edge
    L[lip] = I["e1"]
    L[lip & ((XX % 3) == 0)] = I["e0"]
    for (dx, dy, rx, ry, (hi, mid, lo)) in b["drifts"]:
        dcx, dcy = cx + dx, cy + dy
        for j, y in enumerate(range(int(dcy - ry) - 1, int(dcy + ry) + 2, 2)):
            for i, x in enumerate(range(int(dcx - rx) - 1 + (j % 2), int(dcx + rx) + 2, 3)):
                e = ((x + 0.5 - dcx) / rx) ** 2 + ((y + 0.5 - dcy) / ry) ** 2
                if e > 1.3 or not u[y, x] or (e > 0.7 and (i + j) % 2):
                    continue
                L[y, x] = I[hi if (x < dcx or e < 0.3) else mid]
                if e <= 0.7 and u[y, x + 1]:
                    L[y, x + 1] = I[mid]
                if e <= 0.7 and u[y + 1, x]:
                    L[y + 1, x] = I[lo]
    for a in b["accents"]:
        if a[0] == "ball":
            _, dx, dy, r = a
            u |= crown(L, cx + dx, cy + dy, [(0, 0, r)], "box", squash=0.8)
        else:
            _, dx, dy = a
            gx, gy = cx + dx, cy + dy
            for k, (tx, hgt) in enumerate(GRASS):
                poly(L, [(gx + tx // 2, gy), (gx + tx, gy - hgt)], "y3" if k % 2 else "y2")
                px(L, gx + tx, gy - hgt, "y4")
                u[gy - hgt:gy + 1, gx - 3:gx + 4] |= L[gy - hgt:gy + 1, gx - 3:gx + 4] >= 0
    return u


def bed_masks():
    """Foliage unions of the beds (painted on a scratch layer; used for their contact shade)."""
    return [bed(new(), b) for b in BEDS]


def paint_ground_detail():
    L = new()
    m = park_masks()
    for b in BEDS:
        bed(L, b)
    # v04: the axis medallion becomes a small teal wayfinding ring set into the crossing band (restrained 2537 cue);
    # the south medallion is kept
    ring = ell(*RING_C, 6.5, 2.9) & ~ell(*RING_C, 5.2, 1.8)
    L[ring] = I["t0"]
    for (dx, dy) in ((-6, 0), (5, 0), (0, -2), (0, 2)):
        px(L, RING_C[0] + dx, RING_C[1] + dy, "t1")
    rect(L, RING_C[0] - 1, RING_C[1], RING_C[0], RING_C[1], "t1")
    for (x, y) in ((320, 338),):
        stamp(L, x - 3, y - 2, [".ttt.", "tTsTt", ".ttt."], {"t": "t0", "T": "t1", "s": "t2"})
    for (x, y) in ((320, 324), (172, 332), (588, 300)):              # cast-iron drain grates
        rect(L, x - 4, y - 2, x + 3, y + 1, "k1"); rect(L, x - 4, y - 2, x + 3, y - 2, "k2")
        for xx in range(x - 3, x + 3, 2):
            rect(L, xx, y - 1, xx, y, "k0")
    for (x, y, f) in PIGEONS:
        stamp(L, x, y, PIGEON[f], {"k": "x0", "g": "bz2", "m": "m2", "x": "m1"})
    paint_tech_ground(L)                                             # v05: flat 2537 infrastructure
    return L


# ============================================================================ fountain
def paint_fountain_basin():
    """Basin (base layer): granite coping lit from the south-west, outer wall face, water with a shaded north band,
    broken ripple arcs, a low inner tier and eight arching jets -- all low enough never to rise above the back rim."""
    L = new()
    cx, cy = FOUNTAIN
    out = ell(cx, cy, *BASIN_R)
    inn = ell(cx, cy, *BASIN_IN)
    rim = out & ~inn
    ys, xs = np.nonzero(rim)
    for x, y in zip(xs, ys):
        ang = math.atan2(y + 0.5 - cy, x + 0.5 - cx)
        lit = -math.cos(ang) * 0.5 - math.sin(ang) * 0.3
        L[y, x] = I["m5"] if lit > 0.2 else (I["m4"] if lit > -0.25 else I["m3"])
    L[rim & edge_above(out)] = I["m6"]
    wall = np.zeros((H, W), bool)
    for x in range(cx - BASIN_R[0], cx + BASIN_R[0] + 1):
        col = np.nonzero(out[:, x])[0]
        if len(col) and col.max() >= cy:
            for k in range(1, 4):
                wall[col.max() + k, x] = True
    L[wall] = I["m3"]
    L[wall & edge_below(wall)] = I["m2"]
    L[wall & ((XX % 9) == 0)] = I["m2"]
    L[inn] = I["c1"]
    L[inn & ~ell(cx, cy + 3, BASIN_IN[0] - 1, BASIN_IN[1] - 2) & (YY < cy)] = I["c0"]       # shade under north coping
    L[inn & edge_below(inn)] = I["c2"]
    ang = np.arctan2(YY + 0.5 - cy, XX + 0.5 - cx)
    for (rx, ry) in ((24, 11), (32, 16)):                            # broken ripple arcs (fixed 8-step pattern)
        ring = ell(cx, cy + 1, rx, ry) & ~ell(cx, cy + 1, rx - 1.2, ry - 1)
        L[inn & ring & (np.floor((ang + math.pi) / (math.pi / 8)) % 2 == 0)] = I["c2"]
    tier = ell(cx, cy + 1, 15, 7)
    tin = ell(cx, cy + 1, 12, 5)
    L[tier & ~tin] = I["m4"]
    L[tier & ~tin & (XX < cx) & (YY < cy + 1)] = I["m5"]
    L[tier & edge_above(tier)] = I["m6"]
    L[tier & edge_below(tier)] = I["m2"]
    L[tin] = I["c2"]
    L[tin & ell(cx - 3, cy - 1, 6, 2)] = I["c3"]
    for kk in range(8):                                              # arching jets, inner tier -> outer pool
        a = kk * math.pi / 4 + math.pi / 8
        sx, sy = cx + 15 * math.cos(a), cy + 1 + 7 * math.sin(a)
        ex, ey = cx + 29 * math.cos(a), cy + 1 + 14 * math.sin(a)
        for s in range(0, 11):
            t = s / 10
            x = sx + (ex - sx) * t
            y = sy + (ey - sy) * t - 5 * math.sin(math.pi * t)
            px(L, int(round(x)), int(round(y)), "c3")
            px(L, int(round(x)), int(round(y)) + 1, "c2")
        rect(L, int(round(ex)) - 1, int(round(ey)), int(round(ex)) + 1, int(round(ey)), "c3")
    for kk in range(NOZZLES):                                        # v04: teal nozzle nodes (2537 water system)
        a = kk * math.pi / 4 + math.pi / 8
        nx, ny = int(round(cx + 15 * math.cos(a))), int(round(cy + 1 + 7 * math.sin(a)))
        px(L, nx, ny, "t1"); px(L, nx + 1, ny, "t0")
    return L


BUBBLER = ["..WW..",                # v04: a tiny bubbler in the bowl (6 x 3) instead of the v03 foam crown
           ".WCCc.",
           "WCCcCc"]
BOWL_TOP = 225                      # tazza lip top row (the stone an actor behind the fountain stands behind)
BOWL_RIM = (17.5, 3.4)              # lip ellipse radii (x, y) about (cx, BOWL_TOP + 3.4)
BOWL_BODY = (16, 16, 15, 14, 13, 11, 9, 7, 6)          # half widths of the gadrooned bowl body, rows 232..240
PEDESTAL = [(241, 5), (242, 4), (243, 3), (244, 3), (245, 3), (246, 3), (247, 3), (248, 3), (249, 3), (250, 3),
            (251, 5), (252, 5), (253, 4), (254, 4), (255, 4), (256, 4), (257, 4), (258, 4), (259, 4), (260, 5),
            (261, 5), (262, 6), (263, 6), (264, 6), (265, 6), (266, 6)]   # baluster: (row, half width)
STRANDS = ((-10, "fall"), (7, "fall"), (-15, "drip"), (13, "drip"))   # overflow: x offset, kind (uneven on purpose)
NOZZLES = 8                         # teal nozzle nodes on the inner tier (2537 cue, restrained)


def fountain_sprite(L, reg=None):
    """Y-sorted centrepiece (v04): a stone tazza on a baluster pedestal. The lip is a thick lit stone ring seen from
    above with water inside; the bowl body below it is gadrooned stone in its own shadow (sun high from the
    south-west, so the underside is the darkest stone); four thin overflow strands fall unevenly from the front of the
    lip past the pedestal to the inner tier. Stone dominates the read; water is the accent (v03 read as a pale fluted
    cylinder). A heroine directly behind it is hidden from the thighs down by the bowl."""
    cx, cy = FOUNTAIN
    ramp = ["m1", "m2", "m3", "m4", "m5", "m6"]
    for (y, hw) in PEDESTAL:                                          # baluster, darker under the bowl
        for x in range(cx - hw, cx + hw):
            v = cyl((x + 0.5 - cx) / hw) - (0.16 if y <= 247 else 0.0)
            px(L, x, y, tone(ramp, v, (0.02, 0.18, 0.36, 0.52, 0.66)), reg)
    for y, (a, b) in ((251, ("m6", "m4")), (252, ("m2", "m2")), (262, ("m6", "m5")), (263, ("m2", "m2"))):
        hw = dict(PEDESTAL)[y]
        rect(L, cx - hw, y, cx + hw - 1, y, a, reg); px(L, cx + hw - 1, y, b, reg)
    for i, hw in enumerate(BOWL_BODY):                                # bowl body: gadroons converge to the stem,
        y = BOWL_TOP + 7 + i                                          # the whole body in the lip's shadow
        for x in range(cx - hw, cx + hw):
            u = (x + 0.5 - cx) / hw
            v = cyl(u) - 0.03 * i - 0.24
            rib = int(math.floor((u + 1) * 4.5)) % 2 == 1
            col = tone(ramp, v - (0.09 if rib else 0.0), (0.02, 0.16, 0.32, 0.48, 0.64))
            px(L, x, y, col, reg)
        px(L, cx - hw, y, "m1", reg); px(L, cx + hw - 1, y, "m0", reg)   # silhouette against the plaza
        if i == 0:
            rect(L, cx - hw, y, cx + hw - 1, y, "m0", reg)            # deep shadow under the lip
        if i == len(BOWL_BODY) - 1:
            rect(L, cx - hw, y, cx + hw - 1, y, "m1", reg)
    lip = ell(cx, BOWL_TOP + BOWL_RIM[1], *BOWL_RIM)
    water = ell(cx, BOWL_TOP + BOWL_RIM[1] - 0.4, BOWL_RIM[0] - 3.5, BOWL_RIM[1] - 1.5)
    ys, xs = np.nonzero(lip & ~water)
    for y, x in zip(ys, xs):
        front = y + 0.5 > BOWL_TOP + BOWL_RIM[1]
        if not front:                                                 # lip top surface, far side
            c = "m6" if x < cx + 6 else "m5"
        elif y >= BOWL_TOP + 2 * BOWL_RIM[1] - 1.5:                    # lip front face (thick stone)
            c = "m4" if x < cx - 6 else ("m3" if x < cx + 8 else "m2")
        else:
            c = "m6" if x < cx - 4 else "m5"
        px(L, x, y, c, reg)
    L[lip & edge_below(lip)] = I["m1"]
    ys, xs = np.nonzero(water)
    for y, x in zip(ys, xs):                                          # water in the bowl: shaded far band, glints
        c = "c0" if y + 0.5 < BOWL_TOP + 2.6 else ("c3" if (x < cx - 7 and (x + y) % 3 == 0) else "c1")
        px(L, x, y, c, reg)
    stamp(L, cx - 3, BOWL_TOP, BUBBLER, {"C": "c3", "c": "c2", "W": "lw"}, reg)
    for k, (ox, kind) in enumerate(STRANDS):                          # overflow: falls taper into drops, drips
        x = cx + ox                                                   # are short dribbles off the lip
        col = np.nonzero(lip[:, x])[0]
        y0 = int(col.max()) + 1
        y1 = (cy - 4 + (k % 2)) if kind == "fall" else y0 + 9
        for y in range(y0, y1 + 1):
            d = y - y0
            if kind == "fall" and d <= 7:                             # a 2-px sheet leaving the lip
                px(L, x, y, "c3", reg); px(L, x + 1, y, "c2" if d % 3 else "c1", reg)
            elif kind == "fall" and y <= y1 - 6:
                px(L, x, y, "c3" if d % 5 < 3 else "c2", reg)
            elif kind == "fall":                                      # breaks into 2-texel drops above the tier
                if (y1 - y) % 3 != 2:
                    px(L, x, y, "c2", reg)
            elif d <= 3:
                px(L, x, y, "c3" if d < 2 else "c2", reg)
            elif d in (5, 6, 8, 9):
                px(L, x, y, "c2", reg)
        if kind == "fall":                                            # splash ring on the inner tier
            rect(L, x - 2, y1 + 1, x + 2, y1 + 1, "c3", reg); px(L, x - 3, y1, "c2", reg); px(L, x + 3, y1, "c2", reg)


def candelabra(L, x, base, reg=None):
    """Fountain-plaza candelabra: cast-iron post, two arms and three white globes (unlike the walk lanterns)."""
    rect(L, x - 3, base - 3, x + 3, base, "k1", reg); rect(L, x - 3, base - 3, x - 3, base, "k3", reg)
    rect(L, x - 4, base, x + 4, base, "k0", reg); rect(L, x - 2, base - 6, x + 2, base - 4, "k2", reg)
    rect(L, x - 1, base - 49, x, base - 7, "k2", reg); rect(L, x, base - 49, x, base - 7, "k0", reg)
    px(L, x - 1, base - 20, "k3", reg); rect(L, x - 2, base - 26, x + 1, base - 25, "k3", reg)
    rect(L, x - 8, base - 40, x + 7, base - 40, "k1", reg); rect(L, x - 7, base - 41, x + 6, base - 41, "k2", reg)
    for gx, gy in ((x - 8, base - 46), (x + 7, base - 46), (x, base - 52)):
        rect(L, gx - 1, gy + 2, gx, gy + 5, "k1", reg)
        stamp(L, gx - 2, gy - 2, [".lw.", "lwwm", "wwmm", ".mm."], {"l": "m6", "w": "lw", "m": "m4"}, reg)


def statue_sprite(L, reg=None):
    x, b = STATUE
    rect(L, x - 10, b - 2, x + 9, b, "m3", reg); rect(L, x - 10, b, x + 9, b, "m2", reg)
    rect(L, x - 10, b - 2, x + 9, b - 2, "m5", reg)
    rect(L, x - 8, b - 14, x + 7, b - 3, "m4", reg); rect(L, x - 8, b - 14, x - 6, b - 3, "m5", reg)
    rect(L, x + 6, b - 14, x + 7, b - 3, "m2", reg)
    rect(L, x - 4, b - 10, x + 3, b - 6, "bz1", reg); rect(L, x - 3, b - 9, x + 2, b - 9, "bz2", reg)
    rect(L, x - 3, b - 7, x + 1, b - 7, "bz2", reg)
    rect(L, x - 9, b - 16, x + 8, b - 15, "m6", reg); rect(L, x - 9, b - 15, x + 8, b - 15, "m3", reg)
    fig = ["...hh....", "..hHHh...", "..hHHh...", "...hh....", "..cCCc...", ".cCCCCc..", ".cCCCCcc.", ".cCCCCcc.",
           ".cCcCCc..", "..cCCCc..", "..cCCCcc.", "..cCCCCc.", "..cCCCCc.", ".ccCCCCcc", ".ccCCCCcc", "..cc.cc..",
           "..cc.cc..", "..cC.Cc..", "..cC.Cc..", "..cc.cc..", ".ccc.ccc."]
    stamp(L, x - 5, b - 17 - len(fig), fig, {"h": "bz1", "H": "bz2", "c": "bz0", "C": "bz1"}, reg)
    for j in range(len(fig)):
        row = fig[j]
        k = next((i for i, ch in enumerate(row) if ch not in ". "), None)
        if k is not None:
            px(L, x - 5 + k + 1, b - 17 - len(fig) + j, "bz3" if j % 3 else "bz2", reg)


def cart_sprite(L, reg=None):
    """Street-vendor cart on the south plaza: steel body, blue / yellow umbrella, two wheels (no brand marks)."""
    x0, b = CART
    x1 = x0 + 35
    cxu = x0 + 17
    for i, hw in enumerate((6, 11, 15, 18, 20, 21, 21, 21)):         # umbrella dome, alternating panels
        y = b - 58 + i
        for x in range(cxu - hw, cxu + hw + 1):
            pan = int(math.floor((x - cxu) / 6.0 + 0.5)) % 2
            c = ("ub0", "ub1")[pan]
            if i == 7:
                c = ("k2", "au1")[pan]
            px(L, x, y, c, reg)
    for x in range(cxu - 21, cxu + 22, 6):
        rect(L, x, b - 50, x + 1, b - 50, "k2", reg)
    rect(L, cxu, b - 50, cxu + 1, b - 22, "k2", reg); rect(L, cxu + 1, b - 50, cxu + 1, b - 22, "k1", reg)
    rect(L, x0 - 1, b - 21, x1 + 1, b - 21, "m6", reg)
    rect(L, x0, b - 20, x1, b - 5, "m4", reg); rect(L, x0, b - 20, x0 + 1, b - 5, "m5", reg)
    rect(L, x1, b - 20, x1, b - 5, "m2", reg); rect(L, x0, b - 5, x1, b - 5, "m2", reg)
    rect(L, x0 + 2, b - 14, x1 - 1, b - 12, "ub1", reg); rect(L, x0 + 2, b - 11, x1 - 1, b - 10, "ub0", reg)
    rect(L, x0 + 4, b - 18, x0 + 12, b - 16, "m2", reg); rect(L, x0 + 5, b - 17, x0 + 11, b - 17, "k1", reg)
    rect(L, x0 + 24, b - 23, x0 + 24, b - 22, "fr", reg); rect(L, x0 + 26, b - 23, x0 + 26, b - 22, "ub1", reg)
    rect(L, x0 + 28, b - 24, x0 + 29, b - 22, "m5", reg)
    for wx in (x0 + 3, x0 + 27):
        stamp(L, wx, b - 4, [".kk.", "kmmk", "kmmk", ".kk."], {"k": "k0", "m": "k2"}, reg)


def bench(L, x, b, reg):
    rows = ["k..................k",
            "kWWWWWWWWWWWWWWWWWWk",
            "kddddddddddddddddddk",
            "kWWWWWWWWWWWWWWWWWWk",
            "k..................k",
            "kSSSSSSSSSSSSSSSSSSk",
            "kDDDDDDDDDDDDDDDDDDk",
            "k.k..............k.k",
            "k.k..............k.k"]
    stamp(L, x, b - len(rows) + 1, rows, {"k": "k1", "W": "wd2", "d": "wd1", "S": "wd2", "D": "wd0"}, reg)


def bin_sprite(L, x, b, reg):
    rows = [".KKKK.", "KkKkKK", "KkkkkK", "KkKkKK", "KkkkkK", "KkKkKK", ".KKKK."]
    stamp(L, x - 3, b - len(rows) + 1, rows, {"K": "k1", "k": "f1"}, reg)
    px(L, x - 2, b - len(rows) + 1, "k3", reg)


def paint_props():
    L = new()
    items = {}

    def item(name, fn, base):
        reg = np.zeros((H, W), bool)
        fn(reg)
        items[name] = {"mask": reg, "base": base}

    for i, (x0, x1, b) in enumerate(FENCES):                         # low NYC park hoop fences
        def f(reg, x0=x0, x1=x1, b=b):
            for x in range(x0, x1 + 1):
                ph = (x - x0) % 6
                px(L, x, b - 3, "k3" if ph < 3 else "k2", reg)
                if ph in (0, 1, 5):
                    px(L, x, b - 2, "k1", reg)
                if ph in (0, 3):
                    px(L, x, b - 1, "k1", reg); px(L, x, b, "k0", reg)
                    px(L, x, b - 2, "k1", reg)
            rect(L, x0, b - 4, x0, b, "k1", reg); rect(L, x1, b - 4, x1, b, "k1", reg)
        item(f"fence_{i}", f, b)
    for i, (x, b) in enumerate(BENCHES):
        item(f"bench_{i}", lambda reg, x=x, b=b: bench(L, x, b, reg), b)
    for i, (x, b) in enumerate(BINS):
        item(f"bin_{i}", lambda reg, x=x, b=b: bin_sprite(L, x, b, reg), b)
    for i, (x, b) in enumerate(BOLLARDS):
        def bo(reg, x=x, b=b):
            rect(L, x - 2, b - 6, x + 1, b, "k1", reg); rect(L, x - 2, b - 6, x - 2, b, "k3", reg)
            rect(L, x - 2, b - 4, x + 1, b - 4, "t1", reg); rect(L, x - 2, b - 7, x + 1, b - 7, "k2", reg)
        item(f"bollard_{i}", bo, b)

    def pylon(reg):
        x, b = PYLON
        rect(L, x - 3, b - 1, x + 3, b, "k0", reg)
        rect(L, x - 2, b - 17, x + 2, b - 2, "k1", reg); rect(L, x - 2, b - 17, x - 2, b - 2, "k2", reg)
        rect(L, x - 1, b - 15, x + 1, b - 7, "t0", reg); rect(L, x - 1, b - 14, x + 1, b - 13, "t1", reg)
        rect(L, x - 1, b - 11, x, b - 11, "t2", reg); rect(L, x - 1, b - 9, x + 1, b - 9, "t1", reg)
        rect(L, x - 2, b - 19, x + 2, b - 18, "t1", reg); rect(L, x - 2, b - 19, x - 1, b - 19, "t2", reg)
    item("info_pylon", pylon, PYLON[1])
    for i, (y0, y1) in enumerate(((250, 257), (282, 289))):           # Broadway gate piers (drawn in streets)
        items[f"broadway_pier_{i}"] = {"mask": box(59, y0, 66, y1), "base": y1}
    return L, items


# ============================================================================ v05: 2537 civic infrastructure layer
# Restrained, readable at 640x360, and always at path edges -- never on City Hall, never in the clean centre lane:
#   * guide seams: the soldier-course inner joints of the promenade carry an inlaid light guide (dashes thin out
#     toward City Hall, so it leads the eye from the south entry to the gate);
#   * service-vault lids: brushed-steel hatches with a status diode, set into freshly re-laid paving;
#   * irrigation valve boxes on lawn edges and sensor diodes on the cast-iron drain grates (smart drainage);
#   * sensor posts: graphite bollards with a teal light band at path junctions, on the lawn NORTH of the walk so an
#     actor who can overlap one always stands in front of it (base layer, no Y-sort, no collision change);
#   * one environmental mast (air / weather station with a small photovoltaic leaf) beside the promenade.
# None of these is a collision item: the v04 walk mask is kept exactly (gate). Their depth order is audited
# separately (0 wrong-order feet), and none may touch a test-only visitor's box.
GUIDE_SEAMS = {"cols": (295, 344), "north": (174, 254, 3, 7), "south": (284, 336, 6, 3)}   # rows, dash on / off
TECH_LIDS = [(226, 345), (376, 262), (582, 324), (268, 266)]           # top-left of a 10 x 6 hatch
TECH_VALVES = [(352, 322), (552, 247), (70, 300)]                      # top-left of a 6 x 4 valve box (lawn)
DRAIN_SENSORS = [(320, 324), (172, 332), (588, 300)]                    # the v04 drain grates
TECH_POSTS = [(444, 252), (584, 252), (72, 255), (358, 300)]           # (x, base row) on the lawn north of a walk
TECH_MAST = (362, 236)                                                  # (x, base row) east of the promenade
POST = ["..TT..",
        ".kttK.",
        ".lkkK.",
        ".lkkK.",
        ".lkkK.",
        ".lkkK.",
        ".lmmK.",
        ".lkkK.",
        ".lkkK.",
        "oooooo"]
POST_MAP = {"T": "t2", "t": "t1", "k": "k1", "K": "k0", "l": "k3", "m": "m3", "o": "k0"}
MAST = ["cccccccP.",
        "CCCCCCcP.",
        "tttttttP.",
        "....KkP..",
        "....lk...",
        "....lk...",
        "...TtT...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "....lk...",
        "...mmmm..",
        "..mMMMMo.",
        "..ooooo.."]
MAST_MAP = {"c": "c1", "C": "c0", "t": "t0", "P": "k1", "K": "k2", "k": "k1", "l": "k3", "T": "t1", "m": "m4",
            "M": "m3", "o": "m2"}


def paint_tech_ground(L):
    """Flat infrastructure (ground-detail layer): guide seams, vault lids, valve boxes, drain sensors."""
    for x in GUIDE_SEAMS["cols"]:
        for part in ("north", "south"):
            y0, y1, on, off = GUIDE_SEAMS[part]
            for k, y in enumerate(range(y0, y1 + 1, on + off)):
                rect(L, x, y, x, min(y1, y + on - 1), "t0")
                if part == "south" and k % 2 == 0:
                    px(L, x, y, "t1")
    for (x, y) in TECH_LIDS:
        rect(L, x, y, x + 9, y + 5, "m2"); rect(L, x + 1, y + 1, x + 8, y + 4, "m3")
        rect(L, x + 1, y + 1, x + 8, y + 1, "m4"); rect(L, x + 2, y + 3, x + 7, y + 3, "k2")
        rect(L, x, y + 5, x + 9, y + 5, "k1"); px(L, x + 8, y + 2, "t1"); px(L, x + 7, y + 2, "t0")
    for (x, y) in TECH_VALVES:
        rect(L, x, y, x + 5, y + 3, "k1"); rect(L, x + 1, y + 1, x + 4, y + 2, "k2"); rect(L, x, y, x + 5, y, "k3")
        px(L, x + 4, y + 1, "t1")
    for (x, y) in DRAIN_SENSORS:
        rect(L, x + 2, y - 3, x + 3, y - 3, "t1"); px(L, x - 4, y - 3, "t0")


def paint_tech_props(L):
    """Upright infrastructure (props-low base layer). Returns {name: {mask, base}} for the depth audit only."""
    items = {}
    for i, (x, b) in enumerate(TECH_POSTS):
        reg = np.zeros((H, W), bool)
        stamp(L, x - 3, b - len(POST) + 1, POST, POST_MAP, reg)
        items[f"tech_post_{i}"] = {"mask": reg, "base": b}
    x, b = TECH_MAST
    reg = np.zeros((H, W), bool)
    stamp(L, x - 4, b - len(MAST) + 1, MAST, MAST_MAP, reg)
    items["tech_mast"] = {"mask": reg, "base": b}
    return items


def tech_shadow_mask():
    sm = np.zeros((H, W), bool)
    for (x, b) in TECH_POSTS:
        sm |= seg((x, b), (x + SUN[0] * 10, b - SUN[1] * 10), 1.6)
    x, b = TECH_MAST
    sm |= seg((x, b), (x + SUN[0] * 18, b - SUN[1] * 18), 1.0) | ell(x + SUN[0] * 22, b - SUN[1] * 22, 4, 1.2)
    return sm


# ============================================================================ shrub borders (v04: no baked people)
# v04: the v03 `lawn-life` layer is renamed `shrub-borders`. Its half-scale occupants, picnic blanket and garden drone
# are no longer scene art: people (and the drone, which would animate) live only in the separate TEST-ONLY visitor
# overlay below, at the approved 48-px scale.
SHRUB_BORDERS = [  # (sp, (x0, x1), base row, lobe radius, bloom colours or None): mounded beds on lawn edges only
    ("hydrangea", (128, 158), 208, 5, ("c2", "fl4", "c0")),     # v04: cut back west of the behind-fountain capture
    ("hydrangea", (396, 434), 250, 5, ("fl4", "pk1", "fl0")),   # behind the NE hoop fence
    ("box", (66, 82), 333, 5, None)]                            # SW fence corner


def shrub_border(L, sp, x0, x1, base, r, bloom, reg):
    """A mounded border as one hand-spaced lobe row (lobes alternate 2 rows up / down and grow toward the middle),
    lit like the hero crowns; hydrangea heads are 2x2 clusters in three hand-picked tones."""
    n = max(2, (x1 - x0) // (r + 1))
    lobes = []
    for k in range(n + 1):
        lx = x0 + r + (x1 - x0 - 2 * r) * k / n
        lobes.append((lx - (x0 + x1) / 2, (-2 if k % 2 else 0) - (1 if 0 < k < n else 0), r + (1 if k % 3 == 1 else 0)))
    cx, cy = (x0 + x1) / 2, base - r * 0.7
    u = crown(L, cx, cy, lobes, "box", reg, squash=0.7)
    if bloom:
        hi, mid, lo = bloom
        ys, _ = np.nonzero(u)
        for j, y in enumerate(range(int(ys.min()) + 2, base - 2, 3)):     # flower heads on a fixed 5x3 lattice
            for k, x in enumerate(range(x0 + 2 + (j % 2) * 2, x1 - 1, 5)):
                if u[y + 1, x + 1] and u[y - 1, x]:
                    stamp(L, x - 1, y - 1, ["ab", "bc"], {"a": hi, "b": mid if (j + k) % 3 else hi, "c": lo}, reg)
    return u


def paint_shrub_borders():
    L = new()
    items = {}
    for (sp, (x0, x1), base, r, bloom) in SHRUB_BORDERS:
        reg = np.zeros((H, W), bool)
        shrub_border(L, sp, x0, x1, base, r, bloom, reg)
        items[f"shrub_border_{x0}"] = {"mask": reg, "base": base}
    return L, items


def border_shadow_mask():
    """Ground contact shade of the shrub borders (north-east of each mound)."""
    sm = np.zeros((H, W), bool)
    for (sp, (a, b), base, r, bloom) in SHRUB_BORDERS:
        sm |= box(a + 3, base - 2 * r, b + 3, base) & ~box(a, base - 2 * r, b, base)
    return sm


# ============================================================================ v04: TEST-ONLY full-size visitor overlay
# NOT scene art and never part of the 24-layer stack: a separate overlay (ground PNG + atlas PNG + JSON pivots) that
# shows park activity at the approved 48-px heroine scale, Y-sorted with her like future NPC sprites would be. Bodies
# are built from hand-written row-span tables (x0, x1 relative to the sprite's centre column), lit from the south-west
# (west column lit, two east columns shaded), then given a selective outline (west edge = shade tone, other edges =
# the material's dark tone), the same reading as the heroine's selout. Faces, book spines and paper lines are explicit
# feature texels. No pixel is copied from the heroine or any reference.
HEAD = [(-2, 2), (-4, 3), (-4, 4), (-5, 4), (-5, 5), (-5, 5), (-5, 5), (-5, 5), (-4, 4), (-4, 4), (-3, 3), (-2, 2)]
HAIR_SHORT = HEAD[:4] + [[(-5, -1), (2, 5)], [(-5, -4), (4, 5)], [(-5, -5), (5, 5)], [(-5, -5), (5, 5)]]
HAIR_LONG_TOP = HEAD[:4] + [[(-5, -2), (1, 5)]] + [[(-5, -4), (4, 5)]] * 7
HAIR_LONG_FALL = [[(-6, -4), (4, 6)]] * 5 + [[(-6, -5), (5, 6)]]               # over the shoulders, rows 12..17
CAP = [(-3, 3), (-5, 4), (-5, 5), (-6, 6)]
EYES = [(-2, 6, "k0"), (2, 6, "k0")]


def R(n, *spans):
    return [list(spans) if len(spans) > 1 else spans[0]] * n


FIGURES = {
    # standing, facing south: vendor with an apron and a cap (47 rows: the heroine is 48)
    "STAND_APRON": [("skin", 0, HEAD), ("cap", 0, CAP, "B"), ("hair", 4, R(3, (-5, -5), (5, 5))),
                    ("skin", 12, [(-1, 1)]),
                    ("top", 13, [(-5, 5)] + R(9, (-7, 7)) + R(7, (-6, 6))),
                    ("top", 14, [(-8, -8)] + R(12, (-9, -8)), "R"), ("top", 14, [(8, 8)] + R(12, (8, 9)), "L"),
                    ("skin", 27, R(3, (-9, -8))), ("skin", 27, R(3, (8, 9))),
                    ("legs", 30, R(12, (-5, -1)) + R(3, (-4, -1))), ("legs", 30, R(12, (1, 5)) + R(3, (1, 4))),
                    ("shoe", 45, R(2, (-5, -1))), ("shoe", 45, R(2, (1, 5))),
                    ("apron", 18, R(16, (-5, 5)), "T")],
    # walking away north (back view), long coat, low bun, tote on the east shoulder; east leg lifted mid-stride
    "WALK_AWAY": [("hair", 0, HEAD), ("skin", 5, R(2, (-6, -6))), ("skin", 5, R(2, (6, 6))),
                  ("skin", 12, [(-1, 1)]),
                  ("legs", 32, R(13, (-5, -1))), ("legs", 32, R(10, (1, 5))),
                  ("shoe", 45, R(2, (-5, -1))), ("shoe", 42, R(2, (1, 5))),
                  ("top", 13, [(-5, 5)] + R(18, (-7, 7))),
                  ("top", 14, [(-8, -8)] + R(13, (-9, -8)), "R"), ("top", 14, [(8, 8)] + R(13, (8, 9)), "L"),
                  ("skin", 28, R(2, (-9, -8))), ("skin", 28, R(2, (8, 9))),
                  ("bag", 17, R(10, (9, 12))), ("hair", 9, [(-3, 3), (-3, 3), (-2, 2)])],
    # sitting cross-legged on the lawn with an open book (29 rows)
    "SEATED_BOOK": [("skin", 0, HEAD), ("hair", 0, HAIR_SHORT), ("skin", 12, [(-1, 1)]),
                    ("top", 13, [(-5, 5)] + R(7, (-7, 7)) + R(4, (-6, 6))),
                    ("top", 14, [(-8, -8)] + R(7, (-9, -8)), "R"), ("top", 14, [(8, 8)] + R(7, (8, 9)), "L"),
                    ("top", 22, [(-9, -6), (-8, -5)]), ("top", 22, [(6, 9), (5, 8)]),
                    ("legs", 23, [[(-10, -7), (7, 10)], [(-11, -4), (4, 11)], (-11, 11), (-10, 10),
                             [(-9, -3), (3, 9)], [(-7, -4), (4, 7)]]),
                    ("legs", 25, [(-6, 7)], "T"),
                    ("shoe", 26, [(1, 4), (1, 3)]), ("shoe", 27, [(-3, 0), (-3, -1)]),
                    ("book", 21, R(4, (-4, 4))), ("skin", 22, R(2, (-5, -5))), ("skin", 22, R(2, (5, 5)))],
    # sitting cross-legged, long hair, a paper cup in both hands (29 rows)
    "SEATED_CUP": [("skin", 0, HEAD), ("hair", 0, HAIR_LONG_TOP),
                   ("skin", 12, [(-1, 1)]),
                   ("top", 13, [(-5, 5)] + R(7, (-7, 7)) + R(4, (-6, 6))),
                   ("hair", 12, HAIR_LONG_FALL),
                   ("top", 14, [(-8, -8)] + R(7, (-9, -8)), "R"), ("top", 14, [(8, 8)] + R(7, (8, 9)), "L"),
                   ("top", 22, [(-8, -3), (-7, -2)]), ("top", 22, [(3, 8), (2, 7)]),
                   ("legs", 23, [[(-10, -7), (7, 10)], [(-11, -4), (4, 11)], (-11, 11), (-10, 10),
                             [(-9, -3), (3, 9)], [(-7, -4), (4, 7)]]),
                   ("legs", 25, [(-7, 6)], "T"),
                   ("shoe", 26, [(-4, -1), (-3, -1)]), ("shoe", 27, [(0, 3), (1, 3)]),
                   ("skin", 21, R(2, (-2, 2))), ("cup", 18, R(3, (-1, 1)))],
    # sitting with knees drawn up, forearms wrapped over the knees (29 rows)
    "KNEES_UP": [("skin", 0, HEAD), ("hair", 0, HAIR_SHORT), ("skin", 12, [(-1, 1)]),
                 ("top", 13, [(-5, 5)] + R(7, (-7, 7)) + R(4, (-6, 6))),
                 ("top", 14, [(-8, -8)] + R(5, (-9, -8)), "R"), ("top", 14, [(8, 8)] + R(5, (8, 9)), "L"),
                 ("legs", 17, [(-5, -2), (-6, -1)] + R(8, (-6, -1))), ("legs", 17, [(2, 5), (1, 6)] + R(8, (1, 6))),
                 ("top", 20, R(2, (-9, -1)) + [(-8, -1)], "T"), ("top", 20, R(2, (1, 9)) + [(1, 8)], "T"),
                 ("skin", 21, R(2, (-1, 1))),
                 ("shoe", 27, R(2, (-6, -2))), ("shoe", 27, R(2, (2, 6)))],
    # sitting on a park bench reading a newspaper; thighs foreshortened, shins down to the paving (40 rows)
    "BENCH_PAPER": [("skin", 0, HEAD), ("hair", 0, HAIR_SHORT), ("skin", 12, [(-1, 1)]),
                    ("top", 13, [(-5, 5)] + R(8, (-7, 7)) + R(4, (-6, 6))),
                    ("top", 14, [(-8, -8)] + R(9, (-9, -8)), "R"), ("top", 14, [(8, 8)] + R(9, (8, 9)), "L"),
                    ("legs", 26, R(3, (-6, 6))),
                    ("legs", 29, R(9, (-5, -1))), ("legs", 29, R(9, (1, 5))),
                    ("shoe", 38, R(2, (-6, -1))), ("shoe", 38, R(2, (1, 6))),
                    ("paper", 18, R(7, (-7, 7))), ("skin", 20, R(2, (-8, -8))), ("skin", 20, R(2, (8, 8)))],
    # kneeling on the lawn edge facing the bed (back view), straw sun hat, trowel in the east hand, bucket (32 rows)
    "KNEEL_BACK": [("hat", 0, [(-3, 3), (-4, 4), (-4, 4), (-7, 7), (-7, 7)], "B"),
                   ("hair", 5, R(4, (-5, 5)) + [(-4, 4)]), ("skin", 10, [(-2, 2)]),
                   ("legs", 24, R(3, (-7, 7))),
                   ("legs", 27, R(3, (-7, -1))), ("legs", 27, R(3, (1, 7))),
                   ("sole", 30, R(2, (-6, -2))), ("sole", 30, R(2, (2, 6))),
                   ("top", 11, [(-6, 6)] + R(8, (-7, 7)) + R(4, (-6, 6))),
                   ("top", 12, [(-8, -8)] + R(6, (-9, -8)), "R"),
                   ("top", 12, [(8, 8)] + R(2, (8, 9)) + R(3, (8, 12))),
                   ("skin", 15, R(2, (13, 14))), ("tool", 13, [(15, 15), (15, 16), (15, 16), (16, 16)]),
                   ("bucket", 24, [(-13, -9)] + R(7, (-12, -9)))],
}
# feature texels (x rel. centre, row, colour) drawn after the outline
FEATURES = {
    "STAND_APRON": EYES + [(-3, 26, "m3"), (-2, 26, "m3"), (-1, 26, "m3"), (0, 26, "m3"), (1, 26, "m3"),
                           (2, 26, "m3"), (3, 26, "m3")],
    "WALK_AWAY": [(1, 43, "m4"), (2, 43, "m4"), (3, 43, "m4"), (10, 16, "wd0"), (11, 16, "wd0"), (9, 15, "wd0")],
    "SEATED_BOOK": EYES + [(0, 21, "m3"), (0, 22, "m3"), (0, 23, "m3"), (0, 24, "m3")],
    "SEATED_CUP": EYES + [(-1, 18, "lw"), (0, 18, "lw"), (1, 18, "m4")],
    "KNEES_UP": EYES,
    "BENCH_PAPER": EYES + [(x, y, "m3") for y in (20, 22) for x in (-6, -5, -4, -3, -1, 1, 2, 3, 5, 6)]
                   + [(0, y, "m2") for y in range(18, 25)],
    "KNEEL_BACK": [(-12, 24, "k3"), (-11, 24, "k3"), (-10, 24, "k3")],
}
VISITOR_MATS = {   # material -> (lit, mid, shade, dark) per visitor
    "vendor": {"skin": ("hd2", "hd1", "hd0", "b0"), "cap": ("c1", "ub0", "fb", "k1"), "hair": ("k1", "k0", "k0", "k0"),
               "top": ("c1", "ub0", "fb", "k1"), "legs": ("x2", "x1", "x0", "k0"), "shoe": ("k1", "k0", "k0", "k0"),
               "apron": ("m6", "m5", "m4", "m2")},
    "commuter": {"hair": ("b2", "b1", "b0", "b0"), "skin": ("hu2", "hu1", "hu0", "b1"),
                 "top": ("x3", "x2", "x1", "a1"), "legs": ("k2", "k1", "k0", "k0"), "shoe": ("b1", "b0", "b0", "k0"),
                 "bag": ("wd2", "wd1", "wd0", "b0")},
    "reader": {"skin": ("hu2", "hu1", "hu0", "b1"), "hair": ("b1", "b0", "b0", "k0"), "top": ("c2", "c1", "c0", "w0"),
               "legs": ("tc2", "tc1", "tc0", "e0"), "shoe": ("b1", "b0", "b0", "k0"), "book": ("m6", "m6", "m4", "m2")},
    "picnic_a": {"skin": ("hu2", "hu1", "hu0", "b1"), "hair": ("br1", "br0", "br0", "b0"),
                 "top": ("fl1", "fl0", "pk0", "br0"), "legs": ("m5", "m4", "m3", "m1"), "shoe": ("m4", "m3", "m2", "m1"),
                 "cup": ("m6", "lw", "m4", "m2")},
    "picnic_b": {"skin": ("hd2", "hd1", "hd0", "b0"), "hair": ("k1", "k0", "k0", "k0"),
                 "top": ("ol2", "ol1", "ol0", "f0"), "legs": ("w2", "w1", "w0", "k0"), "shoe": ("m5", "m4", "m3", "k1")},
    "bench": {"skin": ("hu2", "hu1", "hu0", "b1"), "hair": ("m4", "m3", "m2", "m1"), "top": ("mu1", "mu0", "au0", "b1"),
              "legs": ("x2", "x1", "x0", "k0"), "shoe": ("b1", "b0", "b0", "k0"), "paper": ("m6", "m5", "m4", "m2")},
    "gardener": {"hat": ("tc2", "mu1", "mu0", "wd0"), "hair": ("b1", "b0", "b0", "k0"), "skin": ("hd2", "hd1", "hd0", "b0"),
                 "top": ("f4", "f3", "f2", "f1"), "legs": ("wd2", "wd1", "wd0", "b0"), "sole": ("e2", "e1", "e0", "b1"),
                 "tool": ("m5", "m4", "m3", "k1"), "bucket": ("k3", "k2", "k1", "k0")},
}
DRONE_V04 = [".kk.......kk.",                # 2537 garden drone: twin rotors, body, teal status light, mist nozzle
             "kkkk.....kkkk",
             "..kmmmmmmmk..",
             ".kmMMMMMMmmk.",
             ".kmTtmmmmmmk.",
             "..kkk...kkk..",
             "...c.....c..."]
DRONE_HOVER = 14                     # rows between the drone's bottom row and its ground shadow (its pivot)
# (name, figure, material set, centre x, pivot = foot row). Placed on lawn or paving well clear of every heroine pin
# (gate: no visitor box meets the heroine box at any pin), seated people beside the trees / beds that motivate them.
VISITORS_V04 = [("reader_nw", "SEATED_BOOK", "reader", 113, 214),
                ("commuter_diag", "WALK_AWAY", "commuter", 263, 226),
                ("picnic_b", "KNEES_UP", "picnic_b", 398, 318),
                ("picnic_a", "SEATED_CUP", "picnic_a", 381, 320),
                ("bench_sitter", "BENCH_PAPER", "bench", 438, 340),
                ("gardener", "KNEEL_BACK", "gardener", 521, 244),
                ("vendor", "STAND_APRON", "vendor", 460, 346)]
DRONE_AT_V04 = (494, 206)            # top-left; pivot = 206 + 6 + DRONE_HOVER (shadow on the bed it tends)
VISITOR_CLASS = {"STAND_APRON": "standing", "WALK_AWAY": "standing", "SEATED_BOOK": "ground-seated",
                 "SEATED_CUP": "ground-seated", "KNEES_UP": "ground-seated", "BENCH_PAPER": "bench-seated",
                 "KNEEL_BACK": "kneeling"}
CLASS_HEIGHT = {"standing": (44, 50), "ground-seated": (26, 32), "bench-seated": (36, 42), "kneeling": (30, 35)}
PICNIC = (370, 314, 406, 324)        # blanket x0, y0, x1, y1 (gingham, 3/4 view) -- overlay ground, not art


def figure(fig, mats, width=33):
    """Paint one visitor from its span table into a small index sprite; returns (idx, centre column)."""
    h = max(r0 + len(sp) for (_, r0, sp, *_) in FIGURES[fig])
    c = width // 2
    col = np.full((h, width), -1, np.int16)
    mat = np.full((h, width), -1, np.int16)
    order = list(mats)
    for part in FIGURES[fig]:
        m, r0, spans = part[:3]
        opt = part[3] if len(part) > 3 else ""
        lit, mid, sh, dk = mats[m]
        for j, sp in enumerate(spans):
            for (x0, x1) in (sp if isinstance(sp, list) else [sp]):
                wd = x1 - x0 + 1
                for x in range(x0, x1 + 1):
                    if wd >= 3 and x == x0:
                        cc = lit
                    elif (wd >= 5 and x >= x1 - 1) or (wd >= 3 and x == x1):
                        cc = sh
                    else:
                        cc = mid
                    if ("L" in opt and x == x0) or ("R" in opt and x == x1) or ("T" in opt and j == 0) or \
                            ("B" in opt and j == len(spans) - 1):
                        cc = dk
                    col[r0 + j, c + x] = I[cc]
                    mat[r0 + j, c + x] = order.index(m)
    op = col >= 0
    pad = np.pad(op, 1)
    out = col.copy()
    for y, x in zip(*np.nonzero(op)):
        up, dn, lf, rt = pad[y, x + 1], pad[y + 2, x + 1], pad[y + 1, x], pad[y + 1, x + 2]
        if up and dn and lf and rt:
            continue
        lit, mid, sh, dk = mats[order[mat[y, x]]]
        out[y, x] = I[sh] if (not lf and up and dn and rt) else I[dk]       # sunlit west edge keeps the shade tone
    for (x, y, cc) in FEATURES.get(fig, ()):
        if 0 <= y < h and op[y, c + x]:
            out[y, c + x] = I[cc]
    return out, c


def visitor_overlay(base_idx):
    """The separate test-only overlay. Returns (ground index layer, [visitor dicts with a small index sprite, scene
    top-left, pivot, class]). Ground = opaque contact shades (one SHADE step of the art beneath, so no semi-alpha),
    the picnic blanket, basket and bottle, and the drone's hover shadow."""
    g = new()
    x0, y0, x1, y1 = PICNIC
    for y in range(y0, y1 + 1):
        for x in range(x0 + (y1 - y) // 3, x1 + 1 - (y - y0) // 4):
            band = ((x - x0) // 3 + (y - y0) // 2) % 2
            c = ("fr", "m5")[band] if y < y1 else "fr0"
            if x >= x1 - (y - y0) // 4 - 1 and y < y1:
                c = "fr0" if band == 0 else "m3"
            px(g, x, y, c)
    stamp(g, x1 - 7, y1 - 4, [".kkkk.", "k....k", "WWWWWW", "wWWWWd", "wwwwdd"],
          {"k": "wd0", "W": "wd2", "w": "wd1", "d": "wd0"})                       # basket at the front corner
    stamp(g, 391, y1 - 3, ["g", "G", "G"], {"g": "f5", "G": "f3"})              # bottle between the pair
    vis = []
    sm = np.zeros((H, W), bool)
    for (name, fig, ms, cx, pivot) in VISITORS_V04:
        idx, c = figure(fig, VISITOR_MATS[ms])
        ys, xs = np.nonzero(idx >= 0)
        idx = idx[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        sx0 = cx - c + int(xs.min())
        sy0 = pivot - idx.shape[0] + 1
        vis.append({"name": name, "figure": fig, "class": VISITOR_CLASS[fig], "idx": idx, "x0": sx0, "y0": sy0,
                    "pivot": pivot, "height_px": int(idx.shape[0]), "width_px": int(idx.shape[1])})
        wd = idx.shape[1]
        if VISITOR_CLASS[fig] == "standing":
            sm |= ell(cx + 3, pivot - 0.5, 7.5, 2.2)
        else:
            sm |= ell(cx + 3, pivot - 1, wd * 0.52, 2.8)
    dx, dy = DRONE_AT_V04
    d = np.full((len(DRONE_V04), len(DRONE_V04[0])), -1, np.int16)
    stamp(d, 0, 0, DRONE_V04, {"k": "k1", "m": "m3", "M": "m5", "T": "t2", "t": "t1", "c": "c3"})
    dpiv = dy + len(DRONE_V04) - 1 + DRONE_HOVER
    vis.append({"name": "garden_drone", "figure": "DRONE", "class": "prop-hover", "idx": d, "x0": dx, "y0": dy,
                "pivot": dpiv, "height_px": int(d.shape[0]), "width_px": int(d.shape[1])})
    sm |= ell(dx + 7, dpiv - 0.5, 4.5, 1.4)
    src = np.where(g >= 0, g, base_idx)
    g[sm] = SHADE_LUT[np.clip(src[sm], 0, None)]
    return g, vis


def visitor_full_rgba(v):
    """One visitor as a full-canvas RGBA layer (for the Python runtime stack)."""
    L = new()
    h, w = v["idx"].shape
    sub = L[v["y0"]:v["y0"] + h, v["x0"]:v["x0"] + w]
    m = v["idx"] >= 0
    sub[m] = v["idx"][m]
    return to_rgba(L)


def visitor_atlas(vis):
    """Pack the visitor sprites left to right (1 px gap) into one RGBA atlas; returns (rgba, rects)."""
    hmax = max(v["idx"].shape[0] for v in vis)
    wsum = sum(v["idx"].shape[1] + 1 for v in vis) + 1
    a = np.zeros((hmax, wsum, 4), np.uint8)
    rects, x = [], 1
    for v in vis:
        h, w = v["idx"].shape
        m = v["idx"] >= 0
        blk = np.zeros((h, w, 4), np.uint8)
        blk[m, :3] = RGB[v["idx"][m]]
        blk[m, 3] = 255
        a[0:h, x:x + w] = blk
        rects.append([x, 0, w, h])
        x += w + 1
    return a, rects


def paint_ysort(layer):
    L = new()
    for t in TREES.get(layer, ()):
        paint_tree(L, t)
    for x, b in LAMPS.get(layer, ()):
        lamp_sprite(L, x, b)
    if layer == "statue-ysort":
        statue_sprite(L)
    if layer == "fountain-ysort":
        fountain_sprite(L)
        for x, b in FOUNTAIN_LAMPS:
            candelabra(L, x, b)
    if layer == "cart-ysort":
        cart_sprite(L)
    return L


def paint_fg():
    L = new()
    for t in FG_TREES:
        crown(L, t["c"][0], t["c"][1], t["lobes"], t["sp"], gain=0.8)
    return L


# v05 dappled canopy shadow: sun flecks as (u, v, rx, ry) in each projected lobe's unit ellipse (u east, v south),
# cycled per lobe with a sign flip on odd lobes so neighbouring lobes never share a pattern; plus every hand-cut crown
# gap projected to the ground. A hand table, not a hash or noise.
FLECKS = ((-0.48, -0.18, 3.2, 1.3), (0.30, 0.34, 2.4, 1.1), (0.56, -0.36, 2.0, 1.0), (-0.12, 0.52, 1.8, 1.0),
          (0.08, -0.56, 2.6, 1.1), (-0.66, 0.30, 1.6, 0.9), (0.42, 0.02, 1.4, 0.8))
FLECKS_PER_LOBE = 3


def tree_shadow_masks(t):
    """v05: (rim, core) masks of one tree's dappled ground shadow. Rim = projected lobes with a 2x2-dithered edge
    (one shade step); core = the inner 40 % of each projected lobe and the trunk (a second step); sun flecks are cut
    out of both."""
    bx, b = t["base"]
    cx, cy = t["c"]
    chk = (XX // 2 + YY // 2) % 2 == 0
    inner, outer, core, fl = (np.zeros((H, W), bool) for _ in range(4))
    for n, (dx, dy, r) in enumerate(t["lobes"]):
        z = b - (cy + dy)
        ex, ey, rx, ry = cx + dx + SUN[0] * z, b - SUN[1] * z, r * 0.95, r * 0.45
        e = ((XX + 0.5 - ex) / rx) ** 2 + ((YY + 0.5 - ey) / ry) ** 2
        inner |= e <= 0.80
        outer |= e <= 1.0
        core |= e <= 0.40
        sgn = -1 if n % 2 else 1
        for q in range(FLECKS_PER_LOBE):
            u, v, frx, fry = FLECKS[(n * 2 + q) % len(FLECKS)]
            fl |= ell(ex + sgn * u * rx, ey + v * ry, frx, fry)
    for (gx, gy, gr, gq) in t.get("gaps", ()):
        z = b - (cy + gy)
        fl |= ell(cx + gx + SUN[0] * z, b - SUN[1] * z, gr * 0.9, max(1.0, gq * 0.45))
    zt = b - cy
    trunk = seg((bx, b), (bx + SUN[0] * zt, b - SUN[1] * zt), 2.5)
    rim = (inner | (outer & chk) | trunk) & ~fl
    return rim, (core | trunk) & ~fl & ~dilate(fl, 1)


def paint_shadows(below_idx):
    """Opaque cast shadows on the park (sun from the south-west -> shadows fall north-east, up-right on screen).
    Lamp shadows are 2 px wide and end in a lantern blob, so they no longer read as hairline cracks.
    v05: hero-tree shadows are dappled and two-toned (tree_shadow_masks)."""
    sm = np.zeros((H, W), bool)
    sm2 = np.zeros((H, W), bool)
    for trees in TREES.values():
        for t in trees:
            rim, core = tree_shadow_masks(t)
            sm |= rim
            sm2 |= core
    for lamps in LAMPS.values():
        for (x, b) in lamps:
            sm |= seg((x, b), (x + SUN[0] * 52, b - SUN[1] * 52), 1.0)
            sm |= ell(x + SUN[0] * 60, b - SUN[1] * 60, 3, 1.6)
    for (x, b) in FOUNTAIN_LAMPS:
        sm |= seg((x, b), (x + SUN[0] * 44, b - SUN[1] * 44), 1.0)
        sm |= ell(x + SUN[0] * 50, b - SUN[1] * 50, 5, 1.8)
    sx, sb = STATUE
    sm |= ell(sx + 11, sb - 6, 12, 5)
    fx, fy = FOUNTAIN
    sm |= ell(fx + SUN[0] * 40, fy - 2 - SUN[1] * 40, 13, 3.5) & ell(fx, fy, *BASIN_IN)      # upper bowl on water
    for (x, b) in BENCHES:
        sm |= box(x + 2, b - 10, x + 21, b - 9)
    for (x0, x1, b) in FENCES:
        sm |= box(x0 + 2, b - 5, x1 + 2, b - 5) & ((XX % 6) < 3)
    sm |= seg((PYLON[0], PYLON[1]), (PYLON[0] + 6, PYLON[1] - 4), 1.5)
    cx0, cb = CART
    sm |= box(cx0 + 4, cb - 8, cx0 + 41, cb - 2) | ell(cx0 + 17 + SUN[0] * 54, cb - SUN[1] * 54, 20, 3)
    sm |= border_shadow_mask()
    sm |= tech_shadow_mask()                                         # v05: posts and mast
    for u in bed_masks():                                            # v04: beds shade the lawn north-east
        sm |= (np.roll(np.roll(u, -1, 0), 2, 1) | np.roll(u, 1, 1)) & ~u
    m = park_masks()
    region = ((YY >= WALK_TOP) & (XX >= 64) & (XX < PARK_ROW)) | m["south"]
    sm &= region
    sm2 &= sm
    L = new()
    L[sm] = SHADE_LUT[np.clip(below_idx[sm], 0, None)]
    L[sm2] = SHADE_LUT[L[sm2]]                                        # v05: second step in the canopy core
    return L


# ============================================================================ actor, walkability, audits
def heroine_48():
    """Approved v8 static south idle (96 texels = 48 logical px) sampled 2:1 for the logical scene."""
    a = np.array(Image.open(rp(HEROINE_REL)).convert("RGBA"))
    ys, xs = np.nonzero(a[..., 3])
    a = a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = a.shape[:2]
    small = np.array(Image.fromarray(a, "RGBA").resize((max(1, w // 2), h // 2), Image.NEAREST))
    small[..., 3] = np.where(small[..., 3] >= 128, 255, 0)
    return small


def overlap_feet(mask, spr_alpha):
    """Boolean map of foot positions (x, y) at which the actor sprite would overlap any texel of `mask`."""
    sh, sw = spr_alpha.shape
    out = np.zeros((H, W), bool)
    ys, xs = np.nonzero(mask)
    if not len(ys):
        return out
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    sub = mask[y0:y1 + 1, x0:x1 + 1]
    oy, ox = np.nonzero(spr_alpha)
    for j, i in zip(oy, ox):
        fy0 = y0 + sh - 1 - j
        fx0 = x0 + sw // 2 - i
        ya, xa = max(0, fy0), max(0, fx0)
        yb, xb = min(H, fy0 + sub.shape[0]), min(W, fx0 + sub.shape[1])
        if ya < yb and xa < xb:
            out[ya:yb, xa:xb] |= sub[ya - fy0:yb - fy0, xa - fx0:xb - fx0]
    return out


def erode(mask, rx, ry):
    m = np.pad(mask.astype(np.int32), ((ry + 1, ry), (rx + 1, rx)))
    s = m.cumsum(0).cumsum(1)
    k = (2 * ry + 1) * (2 * rx + 1)
    tot = s[2 * ry + 1:, 2 * rx + 1:] - s[:-2 * ry - 1, 2 * rx + 1:] - s[2 * ry + 1:, :-2 * rx - 1] + \
        s[:-2 * ry - 1, :-2 * rx - 1]
    return tot[:H, :W] == k


def walkable(items, spr_alpha):
    m = park_masks()
    area = m["path"] & (YY >= WALK_TOP) & (XX >= 64) & (XX <= 634)
    area &= ~dilate(m["basin"], 3)
    wk = erode(area | ~box(0, 0, W - 1, H - 1), 4, 2) & area
    wk[H - 1, :] = False
    collars = {}
    for name, it in items.items():           # derived collar: feet north of the base whose sprite overlaps the item
        ov = overlap_feet(it["mask"], spr_alpha)
        col = ov & (YY < it["base"])
        ys, xs = np.nonzero(it["mask"])
        foot = box(xs.min() - 5, it["base"] - 4, xs.max() + 5, it["base"] + 3)
        collars[name] = col | foot
        wk &= ~collars[name]
    # Y-sorted objects: footprint collars only (the Y-sort handles in front / behind); (x0, x1, base row)
    feet = {f"candelabra_{i}": (x - 4, x + 4, b) for i, (x, b) in enumerate(FOUNTAIN_LAMPS)}
    feet["statue_pedestal"] = (STATUE[0] - 11, STATUE[0] + 11, STATUE[1])
    feet["vendor_cart"] = (CART[0], CART[0] + 35, CART[1])
    for layer, lamps in LAMPS.items():
        for i, (x, b) in enumerate(lamps):
            feet[f"{layer}_{i}"] = (x - 4, x + 4, b)
    for name, (x0, x1, b) in feet.items():
        c = box(x0 - 4, b - (8 if name == "vendor_cart" else 6), x1 + 4, b + 3)
        collars[name] = c
        wk &= ~c
    return wk, collars


def standing_on_risk(walk, rgba, spr_alpha, run_max=10):
    """Readability gate. A foot is risky when the sprites drawn over the actor there (Y-sort layers whose pivot is
    south of her foot row, plus fg-occlusion) hide >= 50 % of her bottom three opaque rows across >= 6 columns (a
    wide occluder, not a pole or jet) while covering <= run_max rows upward from her feet (v03: a row counts when
    >= 40 % of HER OWN texels in that row are hidden; the v02 rule measured against the widest lower-body row, which
    her 2-texel bottom row can never reach, so its run was always 0 and every foot-hiding occluder was flagged however
    tall): the occluder's top edge then sits at her feet and she reads as standing ON it (the v01 fountain / tree
    captures). Risky feet are removed from the walk mask."""
    fg, ys = occluder_masks(rgba)
    sh, sw = spr_alpha.shape
    rows_px = spr_alpha.sum(1)
    bottom = int(np.nonzero(rows_px)[0].max())
    band = np.zeros_like(spr_alpha)
    band[bottom - 2:bottom + 1] = spr_alpha[bottom - 2:bottom + 1]
    nband = int(band.sum())
    body_w = int(spr_alpha[max(0, bottom - 11):bottom + 1].sum(1).max())
    risky = np.zeros((H, W), bool)
    cache = {}
    for y, x in zip(*np.nonzero(walk)):
        if y not in cache:
            o = fg.copy()
            for n, pv in YSORT_PIVOTS.items():
                if y < pv:
                    o |= ys[n]
            cache[y] = o
        o = cache[y]
        x0, y0 = x - sw // 2, y - sh + 1
        if x0 < 0 or y0 < 0 or x0 + sw > W or not o[y0 + bottom - 2:y0 + bottom + 1, x0:x0 + sw].any():
            continue
        win = o[y0:y0 + sh, x0:x0 + sw] & spr_alpha
        hb = win & band
        if int(hb.sum()) * 2 < nband or int(hb.any(0).sum()) < 6:
            continue
        cov = win.sum(1)
        run = 0
        for r in range(bottom, -1, -1):
            if rows_px[r] == 0:
                continue
            if cov[r] * 10 >= rows_px[r] * 4:
                run += 1
            else:
                break
        if run <= run_max:
            risky[y, x] = True
    return risky


def contact_shadow():
    """Actor contact shadow sprite (RGBA, black with two alpha steps), from the hand-written SHADOW_ROWS."""
    a = np.zeros((len(SHADOW_ROWS), len(SHADOW_ROWS[0]), 4), np.uint8)
    for j, row in enumerate(SHADOW_ROWS):
        for i, ch in enumerate(row):
            if ch in SHADOW_ALPHA:
                a[j, i, 3] = SHADOW_ALPHA[ch]
    return a


def shadow_offset():
    """Top-left of the shadow sprite relative to the foot texel."""
    return SHADOW_OFF[0] - len(SHADOW_ROWS[0]) // 2, SHADOW_OFF[1] - len(SHADOW_ROWS) // 2


def apply_shadow(dst, foot):
    """Runtime blend of a black texel with alpha A: c' = round(c * (255 - A) / 255), integer, half up. The Godot
    texel gate applies the same integer formula; the windowed GPU render is compared against it with tolerance."""
    sh = contact_shadow()
    ox, oy = shadow_offset()
    x0, y0 = foot[0] + ox, foot[1] + oy
    for j in range(sh.shape[0]):
        for i in range(sh.shape[1]):
            A = int(sh[j, i, 3])
            if A and 0 <= x0 + i < W and 0 <= y0 + j < H:
                c = dst[y0 + j, x0 + i, :3].astype(np.int32)
                dst[y0 + j, x0 + i, :3] = ((c * (255 - A) + 127) // 255).astype(np.uint8)


def occluder_masks(rgba):
    """For each Y-sort pivot, the mask of everything drawn over an actor whose foot row is north of the pivot."""
    fg = rgba["fg-occlusion"][..., 3] == 255
    ys = {n: rgba[n][..., 3] == 255 for n in YSORT_LAYERS}
    return fg, ys


def visibility(walk, rgba, spr_alpha, step=2):
    fg, ys = occluder_masks(rgba)
    sh, sw = spr_alpha.shape
    tot = spr_alpha.sum()
    fails, worst, worst_at = [], 1.0, None
    for y in range(0, H, step):
        o = fg.copy()
        for n, pv in YSORT_PIVOTS.items():
            if y < pv:
                o |= ys[n]
        for x in range(0, W, step):
            if not walk[y, x]:
                continue
            x0, y0 = x - sw // 2, y - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            vis = 1 - (o[y0:y0 + sh, x0:x0 + sw] & spr_alpha).sum() / tot
            if vis < worst:
                worst, worst_at = vis, (x, y)
            if vis < 1 / 3:
                fails.append((x, y))
    return fails, worst, worst_at


def depth_audit(items, walk, spr_alpha):
    res = {}
    for name, it in items.items():
        ov = overlap_feet(it["mask"], spr_alpha) & walk
        res[name] = {"overlapping_walkable_feet": int(ov.sum()),
                     "wrong_order_feet": int((ov & (YY < it["base"])).sum()), "base_row": it["base"]}
    return res


def flood(mask, start):
    seen = np.zeros_like(mask)
    if not mask[start[1], start[0]]:
        return seen
    stack = [start]
    seen[start[1], start[0]] = True
    while stack:
        x, y = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and mask[ny, nx] and not seen[ny, nx]:
                seen[ny, nx] = True
                stack.append((nx, ny))
    return seen


def route_points():
    pts = [PINS[p] if isinstance(p, str) else p for p in ROUTE]
    out = [pts[0]]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        n = max(abs(x1 - x0), abs(y1 - y0))
        for k in range(1, n + 1):
            out.append((int(round(x0 + (x1 - x0) * k / n)), int(round(y0 + (y1 - y0) * k / n))))
    return out


# ============================================================================ scene assembly
def composite_idx(layers, names):
    out = layers[names[0]].copy()
    for n in names[1:]:
        m = layers[n] >= 0
        out[m] = layers[n][m]
    return out


def scene():
    spr = heroine_48()
    spr_alpha = spr[..., 3] == 255
    layers = {"skyline": paint_skyline(), "forecourt": paint_forecourt(), "back-groves": paint_back_groves(),
              "streets": paint_streets(), "city-hall": paint_city_hall(), "park-ground": paint_park_ground(),
              "ground-wear": paint_ground_wear(), "ground-detail": paint_ground_detail(),
              "fountain-basin": paint_fountain_basin()}
    assert list(layers) == LAYERS[:9]
    below = composite_idx(layers, list(layers))
    layers["cast-shadows"] = paint_shadows(below)
    props, items = paint_props()
    tech_items = paint_tech_props(props)                             # v05: audit-only, not collision items
    layers["props-low"] = props
    layers["shrub-borders"], border_items = paint_shrub_borders()
    items.update(border_items)
    layers["forecourt-near"] = paint_forecourt_near()
    for n in YSORT_LAYERS:
        layers[n] = paint_ysort(n)
    layers["fg-occlusion"] = paint_fg()
    despeckled = despeckle_ground(layers)
    walk, collars = walkable(items, spr_alpha)
    occ = {n: to_rgba(layers[n]) for n in YSORT_LAYERS + ["fg-occlusion"]}
    risky = standing_on_risk(walk, occ, spr_alpha)
    collars["standing_on_readability"] = risky
    walk = walk & ~risky
    layers["guides"] = paint_guides(walk, collars)
    ov_ground, ov_vis = visitor_overlay(composite_idx(layers, BASE_LAYERS))      # v04: separate test-only overlay
    return {"layers": layers, "items": items, "walk": walk, "collars": collars, "spr": spr, "spr_alpha": spr_alpha,
            "despeckled_ground_texels": despeckled, "standing_on_blocked_feet": int(risky.sum()),
            "overlay_ground": ov_ground, "overlay_visitors": ov_vis, "tech_items": tech_items}


GROUND_LAYERS = ("forecourt", "park-ground", "ground-wear", "ground-detail", "cast-shadows", "fountain-basin")
LUMA = (RGB[:, :3].astype(np.int32) @ np.array([299, 587, 114])) // 1000


def despeckle_ground(layers, passes=3):
    """A ground texel left brighter than all 8 neighbours by >= 40 luma (usually a 2 px slab highlight half
    covered by a lamp post or fence) takes its darkest neighbour's colour. Sprite layers are never edited."""
    fixed = 0
    for _ in range(passes):
        flat = composite_idx(layers, ART_LAYERS)
        l = LUMA[np.clip(flat, 0, None)]
        p = np.pad(l, 1, mode="edge")
        pi = np.pad(flat, 1, mode="edge")
        nbs = [(dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1) if (dy, dx) != (0, 0)]
        nb = np.stack([p[1 + dy:1 + dy + H, 1 + dx:1 + dx + W] for dy, dx in nbs])
        nbi = np.stack([pi[1 + dy:1 + dy + H, 1 + dx:1 + dx + W] for dy, dx in nbs])
        iso = (l - nb.max(0) >= 40) & (YY >= 130)
        darkest = np.take_along_axis(nbi, nb.argmin(0)[None], 0)[0]
        n = 0
        for y, x in zip(*np.nonzero(iso)):
            for name in reversed(ART_LAYERS):
                if layers[name][y, x] >= 0:
                    if name in GROUND_LAYERS:
                        layers[name][y, x] = darkest[y, x]
                        n += 1
                    break
        fixed += n
        if not n:
            break
    return fixed


def paint_guides(walk, collars):
    L = new()
    for y in range(2, H, 4):
        for x in range(2, W, 4):
            if y >= 150:
                L[y, x] = I["gd-walk"] if walk[y, x] else I["gd-block"]
    for k, (x, y) in PINS.items():
        rect(L, x - 1, y - 1, x + 1, y + 1, "gd-pin")
    for (x, y) in route_points()[::3]:
        px(L, x, y, "gd-route")
    return L


# ============================================================================ raster output
def to_rgba(idx):
    a = np.zeros((H, W, 4), np.uint8)
    m = idx >= 0
    a[m, :3] = RGB[idx[m]]
    a[m, 3] = 255
    return a


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


def composite_rgba(rgba_layers, names):
    out = rgba_layers[names[0]].copy()
    for n in names[1:]:
        m = rgba_layers[n][..., 3] == 255
        out[m] = rgba_layers[n][m]
    return out


def paste(dst, spr, x, ybase):
    h, w = spr.shape[:2]
    x0, y0 = x - w // 2, ybase - h + 1
    for j in range(h):
        for i in range(w):
            if spr[j, i, 3] and 0 <= x0 + i < W and 0 <= y0 + j < H:
                dst[y0 + j, x0 + i] = spr[j, i]


def runtime_stack_still(rgba, spr, foot, shadow=True, overlay=None):
    """Runtime draw order proposal: base (layers 1-13 merged) -> Y-sorted {9 sprite layers, actor} by pivot row (a
    sprite layer is drawn over the actor when the actor's foot row is north of its pivot); the actor's contact
    shadow is drawn immediately before the actor -> fg-occlusion. v04: with `overlay` (the TEST-ONLY visitor
    overlay: {"ground": rgba, "sprites": [(pivot, rgba)]}) its ground layer is drawn over the base and each visitor
    joins the Y-sort after the sprite layers (tree order on ties: layers, visitors, actor last)."""
    out = composite_rgba(rgba, BASE_LAYERS)
    seq = [(YSORT_PIVOTS[n], 0, i, rgba[n]) for i, n in enumerate(sorted(YSORT_LAYERS, key=lambda n: YSORT_PIVOTS[n]))]
    if overlay is not None:
        gm = overlay["ground"][..., 3] == 255
        out[gm] = overlay["ground"][gm]
        seq += [(pv, 1, j, a) for j, (pv, a) in enumerate(overlay["sprites"])]
    placed = False
    for pv, _, _, a in sorted(seq, key=lambda t: t[:3]):
        if not placed and foot[1] < pv:
            if shadow:
                apply_shadow(out, foot)
            paste(out, spr, foot[0], foot[1]); placed = True
        m = a[..., 3] == 255
        out[m] = a[m]
    if not placed:
        if shadow:
            apply_shadow(out, foot)
        paste(out, spr, foot[0], foot[1])
    fm = rgba["fg-occlusion"][..., 3] == 255
    out[fm] = rgba["fg-occlusion"][fm]
    return out


def x2(a):
    return np.repeat(np.repeat(a, VIEW, 0), VIEW, 1)


# ============================================================================ containers
DT = (2026, 10, 16, 17, 21, 44)


def zput(z, name, payload, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, DT)
    zi.compress_type = method
    z.writestr(zi, payload)


def make_ora(rgba, comp_png):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.5" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for n in reversed(LAYERS):
        vis = "hidden" if n == "guides" else "visible"
        stack.append(f'<layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.000" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>", ""]
    thumb = Image.open(io.BytesIO(comp_png)).convert("RGBA").resize((256, 144), Image.NEAREST)
    tb = io.BytesIO(); thumb.save(tb, "PNG")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "mimetype", b"image/openraster", zipfile.ZIP_STORED)
        zput(z, "stack.xml", "\n".join(stack).encode())
        for n in LAYERS:
            zput(z, f"data/{n}.png", png_bytes(rgba[n]))
        zput(z, "mergedimage.png", comp_png)
        zput(z, "Thumbnails/thumbnail.png", tb.getvalue())
    return buf.getvalue()


def make_pxo(rgba, comp_png):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in LAYERS]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYERS], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(EXPORT_STEM), "frame_current_tag": "0",
                      "include_tag_in_filename": "false", "interpolation": "0", "lines_count": "1",
                      "new_dir_for_each_frame_tag": "false", "number_of_digits": "4", "number_of_frames": "1",
                      "orientation": "0", "repeat_count": "0", "resize": "100", "save_quality": "0.75",
                      "separator_character": "\"_\"", "sheet_layers_as_separate_files": "false",
                      "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": 0, "export_profile": export_profile,
            "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json, "license": "", "metadata": {},
            "next_keyframe_id": 0, "palettes": [], "pixelorama_version": PIXELORAMA_VERSION,
            "project_current_palette_name": "", "pxo_version": 7, "reference_images": [], "size_x": W, "size_y": H,
            "symmetry_points": [W - 1.0, H - 1.0], "tags": [], "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0,
            "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "",
            "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "data.json", json.dumps(data, separators=(",", ":")))
        zput(z, "mimetype", "application/x-pixelorama")
        zput(z, "preview.png", comp_png)
        zput(z, "image_data/frames/1/", b"")
        for li, n in enumerate(LAYERS, start=1):
            zput(z, f"image_data/frames/1/layer_{li}", np.ascontiguousarray(rgba[n]).tobytes())
            zput(z, f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_gpl():
    lines = ["GIMP Palette", f"Name: {SLUG}_{AREA}_scene-palette_{VER}", "Columns: 8", "#"]
    for n, h in PALETTE:
        r, g, b = (int(h[j:j + 2], 16) for j in (0, 2, 4))
        lines.append(f"{r:3d} {g:3d} {b:3d}\t{n}")
    return ("\n".join(lines) + "\n").encode()


def walkmask_png(walk):
    a = np.zeros((H, W, 4), np.uint8)
    a[walk] = (255, 255, 255, 255)
    return png_bytes(a)


# ============================================================================ metrics
def isolated_bright(flat, region=None):
    """Single texels brighter than all 8 neighbours by luma >= 40 (the 'pale fleck' defect)."""
    l = flat[..., :3].astype(np.int32) @ np.array([299, 587, 114]) // 1000
    p = np.pad(l, 1, mode="edge")
    nb = np.stack([p[1 + dy:1 + dy + H, 1 + dx:1 + dx + W] for dy in (-1, 0, 1) for dx in (-1, 0, 1)
                   if (dy, dx) != (0, 0)])
    iso = (l - nb.max(0) >= 40)
    if region is not None:
        iso &= region
    ys, xs = np.nonzero(iso)
    return int(len(ys)), [[int(x), int(y)] for y, x in zip(ys[:12], xs[:12])]


def single_texel_islands(flat, region):
    """Share of texels with no 4-neighbour of the same colour (noise, as opposed to intentional clusters)."""
    c = flat[..., 0].astype(np.int32) << 16 | flat[..., 1].astype(np.int32) << 8 | flat[..., 2]
    p = np.pad(c, 1, mode="edge")
    same = np.zeros((H, W), bool)
    for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        same |= p[1 + dy:1 + dy + H, 1 + dx:1 + dx + W] == c
    iso = ~same & region
    return round(float(iso.sum()) / max(1, int(region.sum())), 4)


def occlusion_profile(rgba, spr_alpha, foot):
    """For one foot: share of the actor's opaque texels hidden, share of her bottom 3 rows hidden, and the run of
    rows (from the feet upward) at least 40 % covered -- the numbers behind the standing-on readability gate."""
    fg, ys = occluder_masks(rgba)
    o = fg.copy()
    for n, pv in YSORT_PIVOTS.items():
        if foot[1] < pv:
            o |= ys[n]
    sh, sw = spr_alpha.shape
    x0, y0 = foot[0] - sw // 2, foot[1] - sh + 1
    win = o[y0:y0 + sh, x0:x0 + sw] & spr_alpha
    rows_px = spr_alpha.sum(1)
    bottom = int(np.nonzero(rows_px)[0].max())
    band = spr_alpha[bottom - 2:bottom + 1]
    body_w = int(spr_alpha[max(0, bottom - 11):bottom + 1].sum(1).max())
    cov = win.sum(1)
    run = 0
    for r in range(bottom, -1, -1):
        if rows_px[r] and cov[r] * 10 >= rows_px[r] * 4:
            run += 1
        elif rows_px[r]:
            break
    return {"hidden_share": round(float(win.sum()) / int(spr_alpha.sum()), 3),
            "foot_band_hidden_share": round(float(win[bottom - 2:bottom + 1].sum()) / int(band.sum()), 3),
            "covered_rows_from_feet": run}


def static_checks(sc, rgba, flat):
    layers, walk, spr = sc["layers"], sc["walk"], sc["spr"]
    v = {}
    v["canvas_640x360_all_layers"] = all(rgba[n].shape == (H, W, 4) for n in LAYERS)
    v["base_layer_opaque"] = bool((rgba["skyline"][..., 3] == 255).all())
    v["binary_alpha_all_layers"] = all(bool(np.isin(rgba[n][..., 3], (0, 255)).all()) for n in LAYERS)
    used = set()
    for n in ART_LAYERS:
        used |= set(np.unique(layers[n][layers[n] >= 0]).tolist())
    v["art_layers_palette_only"] = all(0 <= u < N_ART for u in used)
    flat_cols = {tuple(c) for c in np.unique(flat[..., :3].reshape(-1, 3), axis=0).tolist()}
    v["flat_colours_subset_of_palette"] = flat_cols <= {tuple(c) for c in RGB[:N_ART].tolist()}
    v["flat_opaque"] = bool((flat[..., 3] == 255).all())
    v["heroine_48_logical_px"] = spr.shape[0] == 48
    fails, worst, worst_at = visibility(walk, rgba, sc["spr_alpha"])
    v["every_walkable_foot_keeps_one_third_visible"] = not fails
    da = depth_audit(sc["items"], walk, sc["spr_alpha"])
    v["depth_audit_zero_wrong_order_feet"] = all(d["wrong_order_feet"] == 0 for d in da.values())
    v["walkable_never_in_backdrop"] = not bool(walk[:WALK_TOP].any())
    m = park_masks()
    v["walkable_only_on_paving"] = not bool((walk & ~m["path"]).any())
    v["walkable_never_in_fountain_basin"] = not bool((walk & m["basin"]).any())
    v["no_standing_on_ambiguity_at_walkable_feet"] = not bool(standing_on_risk(walk, rgba, sc["spr_alpha"]).any())
    ys_ok = {}
    for key, layer, behind in YSORT_CASES:
        foot = PINS[key]
        st = runtime_stack_still(rgba, spr, foot)
        sm = rgba[layer][..., 3] == 255
        hm = np.zeros((H, W), bool)
        sh, sw = spr.shape[:2]
        x0, y0 = foot[0] - sw // 2, foot[1] - sh + 1
        hm[y0:y0 + sh, x0:x0 + sw] = spr[..., 3] == 255
        both = sm & hm
        n = int(both.sum())
        on_top = int((st[both] == rgba[layer][both]).all(axis=1).sum())
        ys_ok[key] = {"layer": layer, "behind": behind, "overlap_texels": n, "sprite_on_top_texels": on_top,
                      "ok": n > 0 and ((on_top == n) if behind else (on_top < n)),
                      "walkable": bool(walk[foot[1], foot[0]]),
                      "occlusion": occlusion_profile(rgba, sc["spr_alpha"], foot)}
    v["ysort_behind_front_correct"] = all(c["ok"] and c["walkable"] for c in ys_ok.values())
    sh_spr = contact_shadow()
    v["contact_shadow_two_alpha_steps"] = set(np.unique(sh_spr[..., 3]).tolist()) == {0} | set(SHADOW_ALPHA.values())
    cap_shadow, cap_shadow_occ = {}, {}
    fgm, ysm = occluder_masks(rgba)
    for cap, key in CAPTURES.items():
        foot = PINS[key]
        a = runtime_stack_still(rgba, spr, foot, shadow=True)
        b = runtime_stack_still(rgba, spr, foot, shadow=False)
        cap_shadow[cap] = int((a != b).any(axis=2).sum())
        fp = np.zeros((H, W), bool)                                   # shadow footprint at this foot
        ox, oy = shadow_offset()
        shs = sh_spr[..., 3] > 0
        fp[foot[1] + oy:foot[1] + oy + shs.shape[0], foot[0] + ox:foot[0] + ox + shs.shape[1]] = shs
        over = fgm.copy()
        for n, pv in YSORT_PIVOTS.items():
            if foot[1] < pv:
                over |= ysm[n]
        cap_shadow_occ[cap] = round(float((fp & over).sum()) / int(fp.sum()), 3)
    # v03: the shadow must show (>= 12 texels) unless the capture is a behind case whose over-actor sprite covers at
    # least half of the shadow footprint (behind the fountain veil the shadow is correctly mostly hidden)
    v["contact_shadow_visible_or_occluded_by_front_sprite"] = all(
        cap_shadow[c] >= 12 or cap_shadow_occ[c] >= 0.5 for c in CAPTURES)
    reach = flood(walk, PINS["spawn_south"])
    pins_ok = {k: bool(reach[y, x]) for k, (x, y) in PINS.items()}
    v["all_pins_reachable_from_spawn"] = all(pins_ok.values())
    v["pins_on_walkable_texels"] = all(bool(walk[y, x]) for (x, y) in PINS.values())
    rpts = route_points()
    blocked = [p for p in rpts if not walk[p[1], p[0]]]
    v["heroine_route_fully_walkable"] = not blocked
    fl_walk, fl_ex = isolated_bright(flat, YY >= 150)
    fl_all, _ = isolated_bright(flat)
    v["no_isolated_bright_flecks_in_walkable_park"] = fl_walk == 0
    islands = {"park_rows_150_359": single_texel_islands(flat, YY >= 150),
               "backdrop_rows_0_149": single_texel_islands(flat, YY < 150)}
    v4v, v4m = v04_checks(sc, rgba, flat)
    v.update(v4v)
    v5v, v5m = v05_checks(sc, rgba, flat)
    v.update(v5v)
    return {"verdicts": v, "v04": v4m, "v05": v5m, "visibility_worst": round(float(worst), 3), "visibility_worst_at": worst_at,
            "visibility_fail_count": len(fails), "visibility_fail_examples": fails[:10], "depth_audit": da,
            "ysort_cases": ys_ok, "pins_reachable": pins_ok, "route_points": len(rpts),
            "route_blocked_examples": blocked[:10],
            "isolated_bright_flecks": {"park_rows_150_359": fl_walk, "examples": fl_ex, "whole_frame": fl_all},
            "single_texel_colour_islands_share": islands,
            "palette": {"art_colours": N_ART, "used_in_flat": len(flat_cols)},
            "despeckled_ground_texels": sc["despeckled_ground_texels"],
            "standing_on_blocked_feet": sc["standing_on_blocked_feet"],
            "contact_shadow_visible_texels_per_capture": cap_shadow,
            "contact_shadow_footprint_share_under_front_sprites": cap_shadow_occ,
            "capture_occlusion": {cap: occlusion_profile(rgba, sc["spr_alpha"], PINS[key])
                                  for cap, key in CAPTURES.items()},
            "walkable_texels": int(walk.sum()), "walkable_share_of_park_rows": round(
                float(walk[WALK_TOP:].sum()) / ((H - WALK_TOP) * W), 3)}


# ============================================================================ v04 focused checks
TEAL = ("t0", "t1", "t2", "tq")


def hull_area(mask):
    """Area of the convex hull of a mask's texel corners (monotone chain), for bed solidity."""
    ys, xs = np.nonzero(mask)
    pts = sorted({(x + dx, y + dy) for x, y in zip(xs.tolist(), ys.tolist()) for dx in (0, 1) for dy in (0, 1)})
    if len(pts) < 3:
        return float(len(pts))

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    h = lo[:-1] + up[:-1]
    return abs(sum(h[i][0] * h[(i + 1) % len(h)][1] - h[(i + 1) % len(h)][0] * h[i][1] for i in range(len(h)))) / 2


def promenade_metrics(flat):
    """Material-variation numbers for the promenade field (x 296..343, rows 172..337 minus the crossing band):
    distinct colours and the standard deviation of 8x8 block-mean luma (a flat repeated strip scores low)."""
    l = flat[..., :3].astype(np.int32) @ np.array([299, 587, 114]) // 1000
    rows = [y for y in range(WALK_TOP, 338) if not (PROM_BAND[0] <= y <= PROM_BAND[1])]
    sub = l[rows][:, 296:344]
    rgb = flat[rows][:, 296:344, :3].reshape(-1, 3)
    blocks = [sub[j:j + 8, i:i + 8].mean() for j in range(0, sub.shape[0] - 7, 8) for i in range(0, 48, 8)]
    return {"distinct_colours": int(len(np.unique(rgb, axis=0))), "block8_luma_std": round(float(np.std(blocks)), 2)}


V03_PINNED = {   # SHA-256 recorded in the v03 QA note (text files compared as sha256-text-lf-v1)
    f"{V03_TOOL_REL}": "d8c40162a79bcfa4f4e0446b8ab237cc91b26e5d48efbcf1d4d36f7569cf879e",
    f"{V03_CAND_REL}/{V03_MANIFEST}": "2ffcbe9d8c1c4db3a075b3b3b1a6f40eeb244161ad3279dde81056b06d428fd5",
    **{f"outputs/{V03_RUN}/rpg-2-star-ocean-the-second_nyc-city-hall-park_{k}_unapproved-v03_20261016-160059-4b2f50f6"
       f".{e}": h for k, e, h in (
           ("godot-render-1280x720-axis", "png", "7af861402c635d7ee1d93d302c6f822c1a2c35ba0acfa2fb02f2e762a6c19743"),
           ("godot-render-1280x720-behind-fountain", "png",
            "5fcc7b1957579c8bcf65ce747a96c7d90fe0092bdb40ea8acc66db9eb543a133"),
           ("godot-render-1280x720-behind-tree", "png",
            "60530564d7785d9b7d33195dc872fe2da47d9f816dd64f67a49eb2a909141433"),
           ("godot-render-640x360-axis", "png", "2d193c5555175af8ce93b85eabc24e4b3f015cea76cb63e5d9302509c8fa63f0"),
           ("godot-render-640x360-behind-fountain", "png",
            "b886dfada793a009a25a83221b768460c56979f64e96d6b2e4028e311845b637"),
           ("godot-render-640x360-behind-tree", "png",
            "8b2d8bbcbb9616923101edec51d744ad06b53bf38e21a11c3baf2b377164ed81"),
           ("technical-check-report", "json", "cb04eb82075ff111170ff87a8ed8a36096c3e115613c963b5ec733f419ae0dd2"))}}


def v03_unchanged():
    """Re-hash every v03 candidate file listed in the v03 manifest plus the v03 tool, manifest, captures and report
    pinned in the v03 QA note (text files LF-normalised, binaries exact)."""
    d = rp(V03_CAND_REL)
    man = json.loads(read_bytes(os.path.join(d, V03_MANIFEST)))
    res = {}
    for fn, h in list((f"{V03_CAND_REL}/{k}", v) for k, v in man["files_sha256_bytes"].items()) + \
            list(V03_PINNED.items()):
        b = read_bytes(rp(fn))
        res[fn.split("/")[-1]] = (sha_text(b) if fn.endswith((".gpl", ".json", ".py")) else sha(b)) == h
    return res


def v04_checks(sc, rgba, flat):
    layers, v = sc["layers"], {}
    skin = [I[c] for c in SKIN]
    skin_hits = {n: int(np.isin(layers[n], skin).sum()) for n in ART_LAYERS}
    v["art_layers_have_no_people_skin_texels"] = not any(skin_hits.values())
    pm = promenade_metrics(flat)
    v03_flat = decode(read_bytes(os.path.join(rp(V03_CAND_REL), V03_FLAT)))[2]
    pm03 = promenade_metrics(v03_flat)
    v["promenade_more_material_variation_than_v03"] = pm["block8_luma_std"] > pm03["block8_luma_std"] and \
        pm["distinct_colours"] > pm03["distinct_colours"]
    v["promenade_courses_thin_with_distance"] = list(PROM_COURSES_N) == sorted(PROM_COURSES_N) and \
        PROM_COURSES_N[0] < PROM_COURSES_S[-1]
    bm = bed_masks()
    det = layers["ground-detail"]
    sol = [round(float(u.sum()) / hull_area(u), 3) for u in bm]
    ring_tx = sum(int((np.isin(det, [I["p2"], I["p4"]]) & dilate(u, 1)).sum()) for u in bm)
    v["beds_have_no_stone_ring"] = ring_tx == 0
    v["beds_are_irregular_not_ovals"] = all(s_ < 0.95 for s_ in sol)
    fy = layers["fountain-ysort"]
    cx, cy = FOUNTAIN
    win = np.zeros((H, W), bool)
    win[BOWL_TOP - 2:cy + 1, cx - 20:cx + 21] = True
    stone = int((np.isin(fy, [I[c] for c in ("m0", "m1", "m2", "m3", "m4", "m5", "m6")]) & win).sum())
    water = int((np.isin(fy, [I[c] for c in ("c0", "c1", "c2", "c3", "lw")]) & win).sum())
    below = np.isin(fy, [I[c] for c in ("c0", "c1", "c2", "c3", "lw")])[BOWL_TOP + 7:cy - 5, cx - 20:cx + 21]
    v["fountain_stone_dominates_water"] = stone >= 2 * water
    v["fountain_overflow_is_strands_not_a_veil"] = int(below.sum(1).max()) <= 6
    teal = [I[c] for c in TEAL]
    teal_hall = int(np.isin(layers["city-hall"], teal).sum())
    cue = int(np.isin(layers["ground-detail"], teal)[PROM_BAND[0]:PROM_BAND[1] + 1].sum()) + \
        int(np.isin(layers["fountain-basin"], teal).sum())
    v["science_cue_restrained_and_off_city_hall"] = teal_hall == 0 and 0 < cue <= 120
    # ---- test-only overlay
    ov_g = to_rgba(sc["overlay_ground"])
    atlas = decode(png_bytes(visitor_atlas(sc["overlay_visitors"])[0]))[2]
    ok_pal = all(0 <= u < N_ART for u in np.unique(sc["overlay_ground"][sc["overlay_ground"] >= 0]).tolist())
    for vis in sc["overlay_visitors"]:
        ok_pal &= all(0 <= u < N_ART for u in np.unique(vis["idx"][vis["idx"] >= 0]).tolist())
    v["overlay_binary_alpha_palette_only"] = ok_pal and bool(np.isin(ov_g[..., 3], (0, 255)).all()) and \
        bool(np.isin(atlas[..., 3], (0, 255)).all())
    v["overlay_separate_from_art_stack"] = not any("npc" in n or "visitor" in n for n in LAYERS) and \
        bool((composite_rgba(rgba, ART_LAYERS) == flat).all())
    heights = {vis["name"]: (vis["class"], vis["height_px"]) for vis in sc["overlay_visitors"]}
    v["overlay_visitor_heights_match_48px_classes"] = all(
        CLASS_HEIGHT[c][0] <= h <= CLASS_HEIGHT[c][1] for c, h in heights.values() if c in CLASS_HEIGHT)
    spr_h, spr_w = sc["spr"].shape[:2]
    clash = []
    for pin, (x, y) in PINS.items():
        hx0, hy0 = x - spr_w // 2, y - spr_h + 1
        for vis in sc["overlay_visitors"]:
            h, w = vis["idx"].shape
            if hx0 < vis["x0"] + w and vis["x0"] < hx0 + spr_w and hy0 < vis["y0"] + h and vis["y0"] < hy0 + spr_h:
                clash.append([pin, vis["name"]])
    v["overlay_visitors_clear_of_heroine_at_every_pin"] = not clash
    m = park_masks()
    feet_ok = {}
    for vis in sc["overlay_visitors"]:
        fx = vis["x0"] + vis["idx"].shape[1] // 2
        feet_ok[vis["name"]] = bool(WALK_TOP <= vis["pivot"] < H and 64 <= fx < PARK_ROW and
                                    not m["basin"][vis["pivot"], fx])
    v["overlay_feet_in_park_not_basin_or_backdrop"] = all(feet_ok.values())
    v["overlay_heroine_scale_unchanged_48px"] = spr_h == 48
    v03 = v03_unchanged()
    v["v03_candidate_files_unchanged"] = all(v03.values()) and len(v03) == 16
    longest = max(len(os.path.join(REPO, *rel.split("/"))) for rel in
                  [f"{CAND_REL}/{n}" for k, n in names().items() if not k.startswith(("cap", "report"))] +
                  [f"{OUT_REL}/{n}" for k, n in names().items() if k.startswith(("cap", "report"))])
    v["all_written_paths_le_252_chars"] = longest <= 252
    return v, {"people_skin_texels_per_art_layer": {k: n for k, n in skin_hits.items() if n},
               "promenade": {"v04": pm, "v03": pm03, "courses_north": PROM_COURSES_N, "courses_south": PROM_COURSES_S},
               "bed_solidity": sol, "bed_stone_ring_texels": ring_tx,
               "fountain_window": {"stone_texels": stone, "water_texels": water,
                                   "max_water_texels_per_row_below_lip": int(below.sum(1).max())},
               "teal_texels": {"city_hall": teal_hall, "new_cue_ring_and_nozzles": cue},
               "overlay": {"visitors": {k: {"class": c, "height_px": h} for k, (c, h) in heights.items()},
                           "pin_clashes": clash, "feet_ok": feet_ok,
                           "ground_texels": int((ov_g[..., 3] == 255).sum())},
               "v03_files_checked": len(v03), "longest_written_path_chars": longest}


# ============================================================================ v05 focused checks and v04 comparison
V04_PINNED = {   # SHA-256 recorded in the v04 QA note (text files compared as sha256-text-lf-v1)
    V04_TOOL_REL: "c7c53e350c386ff14a1fd07349940debcf62668978ddba1958b8db87372809fa",
    **{f"{V04_CAND_REL}/{v04_name(p, e)}": h for p, e, h in (
        ("scene-24layer", "pxo", "5119170ee29be16520c9512ede6b1534ba771c597fff072464f2e987ad4ddb3d"),
        ("scene-24layer", "ora", "d6ffb72374bf30c939aa669a333798da62c82b2188eebacfe662fa741e6e4cb3"),
        ("scene-flat-640x360", "png", "abd7a30f736b226b7bb5873989e671f5a2925b25cb9e7d98eeef96b46c10ea91"),
        ("scene-palette", "gpl", "0086f5fe86cd10c465b90a110e2d5f234c96dc7fc2413299b24d7ad0295ce825"),
        ("scene-walkmask", "png", "4eab4b742cfcd0eb9701867bf97742b43e7f3a42b1b4a3b86bceae93342ef2b8"),
        ("scene-walkability", "json", "937829ccfc7dcfc5dff4cafc7e88acb0df2a94129bd290ffcf4d60c3cabcd70f"),
        ("contact-shadow", "png", "ddba14ee0a49be60c49e4e5aa25d83f6ca2aedf45f610710b1a5981fdcbd0e8d"),
        ("test-npc-ground", "png", "67e9c545303e5cca80300fd6ee994b6466971778334e7289c2266c3b27dda8a8"),
        ("test-npc-atlas", "png", "5fef46b7d36d19dc857b5e9210d8b4a58a5ca2ee3bac81f4c326511e63019ded"),
        ("test-npc-overlay", "json", "06b55567f9790632bfdfc6e6812f4d246a832cbe550712948c6bbbd6d9259fa1"),
        ("scene-manifest", "json", "bc9753b3625c24e3605d7f555fb01e2eb3571b24910000d1dabcf4d7e047529a"))},
    **{f"{V04_OUT_REL}/{v04_name(p, e)}": h for p, e, h in (
        ("godot-render-1280x720-axis-test-npc", "png", "c774d58e38b6a2e00d246911063c8b06baaceece4573c377e9a938683fd7f61c"),
        ("godot-render-1280x720-fountain-test-npc", "png",
         "8bbef791652422e843b8f1d1c0dccd5beeee8a8c0692b4fcb6bb45a3ccc60095"),
        ("godot-render-1280x720-tree-test-npc", "png", "0da8ce5005593f615aee30ab2a6cc2c1e4db0ffccad1b0b07dd8ec55f83a6004"),
        ("godot-render-640x360-axis-test-npc", "png", "9f61420cc4c40d214056f9a2b8a1dac38cc981f82971d6156237a7b16b43a42a"),
        ("godot-render-640x360-fountain-test-npc", "png", "9d0974fecbcdde91d67430e8b6d88570ea349fd81c0ab79942327707d6cff82f"),
        ("godot-render-640x360-tree-test-npc", "png", "951fa1691d9da58da1db6134192286262c329549994dd2e860edbd28e342b1dc"),
        ("godot-render-640x360-axis-art-only", "png", "bc3e29f6ee0071911537376aa9e5b4e821cd27bd621104ab66a5ff38abdaccbe"),
        ("godot-render-640x360-fountain-art-only", "png", "6b07e1f6fb0dce6548d378baa9b80d53a5da7868370e513c67f46c59187ee8ae"),
        ("godot-render-640x360-tree-art-only", "png", "8cfc12caa01e0e820e5df05f78fbd9f72cc48b21a4fa01633418a549dc38fac1"),
        ("technical-check-report", "json", "36a9cd4ff741f6dc20d332ff8fb4d58ed0a2909458e85ec24188f431d4fc74e6"))},
}
V04_ART_ONLY_AXIS = f"{V04_OUT_REL}/{v04_name('godot-render-640x360-axis-art-only', 'png')}"


def v04_unchanged():
    """Re-hash the 22 v04 files pinned in the v04 QA note (11 candidate files, 10 outputs, the v04 tool)."""
    res = {}
    for rel, h in V04_PINNED.items():
        p = rp(rel)
        if not os.path.exists(_fs(p)):
            res[rel.split("/")[-1]] = False
            continue
        b = read_bytes(p)
        res[rel.split("/")[-1]] = (sha_text(b) if rel.endswith((".gpl", ".json", ".py")) else sha(b)) == h
    return res


def v04_layers():
    """The v04 24-layer stack, read back from the v04 .ora (never rebuilt)."""
    with zipfile.ZipFile(io.BytesIO(read_bytes(rp(f"{V04_CAND_REL}/{v04_name('scene-24layer', 'ora')}")))) as z:
        return {n: decode(z.read(f"data/{n}.png"))[2] for n in LAYERS}


def luma_of(rgb):
    return rgb[..., :3].astype(np.int32) @ np.array([299, 587, 114]) // 1000


def block_std(l, mask, b=8, min_fill=0.75):
    """Standard deviation of b x b block-mean luma over blocks at least min_fill inside mask (large-scale value
    structure: an even material scores low)."""
    vals = []
    for y in range(0, H - b + 1, b):
        for x in range(0, W - b + 1, b):
            mm = mask[y:y + b, x:x + b]
            if mm.mean() >= min_fill:
                vals.append(l[y:y + b, x:x + b][mm].mean())
    return round(float(np.std(vals)), 2) if vals else 0.0


def dup_block_share(rgba_img, mask, b=6):
    """Repetition: share of fully-masked b x b blocks (on a b-grid) whose exact pixels occur in another such block."""
    seen = {}
    for y in range(0, H - b + 1, b):
        for x in range(0, W - b + 1, b):
            if mask[y:y + b, x:x + b].all():
                k = rgba_img[y:y + b, x:x + b, :3].tobytes()
                seen[k] = seen.get(k, 0) + 1
    tot = sum(seen.values())
    return round(sum(c for c in seen.values() if c > 1) / tot, 4) if tot else 0.0, tot


def window_boxes():
    """(x, top, h) of every City Hall window (wings, links, centre upper) in screen coordinates."""
    out = []
    for kind, x0, x1, d in SECTIONS:
        if kind == "centre":
            r = section_rows(kind, d)
            out += [(x, r["up"][0] + (6 if x == 317 else 7), 15 if x == 317 else 13) for x in CENTRE_BAYS]
            continue
        side = 0 if x0 < CX else 1
        r = section_rows(kind, d)
        for o in (WING_BAYS if kind == "wing" else LINK_BAYS):
            xw = WEST_X0[kind] + o
            x = xw if side == 0 else mirror(xw, 6)
            out += [(x, r["up"][0] + 7, 13), (x, r["low"][0] + 6, 16)]
    return out


def material_metrics(flat, layers_rgba):
    """Numbers behind the v05 comparison, computed identically for v04 and v05 (flat = composited art at 1x)."""
    l = luma_of(flat)
    m = park_masks()
    lawn = m["lawn"] & (YY >= WALK_TOP)
    hexm = m["hex"] & (YY >= WALK_TOP)
    hall = (layers_rgba["city-hall"][..., 3] == 255) & box(150, 60, 489, 143)
    tree_m = np.zeros((H, W), bool)
    for n in ("tree-nw-ysort", "trees-ne-ysort", "tree-se-ysort", "tree-sw-ysort"):
        tree_m |= layers_rgba[n][..., 3] == 255
    tree_rgba = composite_rgba(layers_rgba, ["tree-nw-ysort", "trees-ne-ysort", "tree-se-ysort", "tree-sw-ysort"])
    win = []
    for (x, top, hh) in window_boxes():
        win.append(flat[top - 1:top + hh + 1, x - 1:x + 7, :3].tobytes())
    win_l = [float(l[top:top + hh, x:x + 6].mean()) for (x, top, hh) in window_boxes()]
    rows = {}
    for (x, top, hh) in window_boxes():
        rows.setdefault(top, []).append(x)
    adj_same = 0
    for top, xs in rows.items():
        xs = sorted(xs)
        for a, b in zip(xs, xs[1:]):
            if flat[top:top + 12, a:a + 6, :3].tobytes() == flat[top:top + 12, b:b + 6, :3].tobytes():
                adj_same += 1
    dup_tree, n_tree = dup_block_share(tree_rgba, tree_m)
    dup_lawn, _ = dup_block_share(flat, lawn)
    dup_hex, _ = dup_block_share(flat, hexm)
    dup_hall, _ = dup_block_share(flat, hall, b=4)
    return {"facade": {"block4_luma_std": block_std(l, hall, 4), "distinct_colours": int(len(np.unique(
                flat[hall][:, :3], axis=0))), "dup_4x4_block_share": dup_hall,
                       "windows": len(win), "distinct_window_patches": len(set(win)),
                       "window_mean_luma_std": round(float(np.std(win_l)), 2),
                       "identical_adjacent_window_pairs": adj_same},
            "tree_crowns": {"dup_6x6_block_share": dup_tree, "blocks": n_tree,
                            "distinct_colours": int(len(np.unique(tree_rgba[tree_m][:, :3], axis=0))),
                            "block8_luma_std": block_std(luma_of(tree_rgba), tree_m, 8, 1.0)},
            "lawn": {"block8_luma_std": block_std(l, lawn), "distinct_colours": int(len(np.unique(flat[lawn][:, :3],
                                                                                                axis=0))),
                     "dup_6x6_block_share": dup_lawn},
            "hex_paving": {"block8_luma_std": block_std(l, hexm), "dup_6x6_block_share": dup_hex}}


def tech_elements(sc):
    """Every v05 infrastructure element as (name, mask) in screen space (flat ones from the tables)."""
    els = []
    for x in GUIDE_SEAMS["cols"]:
        els.append((f"guide_seam_{x}", box(x, GUIDE_SEAMS["north"][0], x, GUIDE_SEAMS["south"][1]) &
                    np.isin(sc["layers"]["ground-detail"], [I["t0"], I["t1"]])))
    els += [(f"vault_lid_{i}", box(x, y, x + 9, y + 5)) for i, (x, y) in enumerate(TECH_LIDS)]
    els += [(f"valve_box_{i}", box(x, y, x + 5, y + 3)) for i, (x, y) in enumerate(TECH_VALVES)]
    els += [(n, it["mask"]) for n, it in sc["tech_items"].items()]
    return els


NEAR_PATH_PX = 12                   # "near the paths": within a quarter of the heroine's 48-px height of a walk


def v05_checks(sc, rgba, flat):
    layers, v = sc["layers"], {}
    v04w = read_bytes(rp(f"{V04_CAND_REL}/{v04_name('scene-walkmask', 'png')}"))
    v["walkmask_identical_to_v04"] = bool(np.array_equal(decode(v04w)[2][..., 3] == 255, sc["walk"])) and \
        walkmask_png(sc["walk"]) == v04w
    wj = json.loads(read_bytes(rp(f"{V04_CAND_REL}/{v04_name('scene-walkability', 'json')}")))
    mine = walkability_json(sc)
    same = {k: wj[k] == json.loads(json.dumps(mine[k])) for k in ("cells_rows_top_to_bottom", "pins", "ysort_pivots",
                                                                  "heroine_route", "collars_blocked_texels",
                                                                  "standing_on_readability_blocked_feet", "exits")}
    v["pins_route_pivots_collars_exits_unchanged_vs_v04"] = all(same.values())
    v04_atlas = read_bytes(rp(f"{V04_CAND_REL}/{v04_name('test-npc-atlas', 'png')}"))
    oj = json.loads(read_bytes(rp(f"{V04_CAND_REL}/{v04_name('test-npc-overlay', 'json')}")))
    v["test_overlay_visitors_identical_to_v04"] = png_bytes(visitor_atlas(sc["overlay_visitors"])[0]) == v04_atlas \
        and [(d["name"], d["scene_top_left"], d["pivot_row"]) for d in oj["visitors"]] == \
        [(d["name"], [d["x0"], d["y0"]], d["pivot"]) for d in sc["overlay_visitors"]]
    teal = [I[c] for c in TEAL]
    teal_hall = int(np.isin(layers["city-hall"], teal).sum())
    teal_art = {n: int(np.isin(layers[n], teal).sum()) for n in ART_LAYERS}
    park_teal = sum(int(np.isin(layers[n], teal)[WALK_TOP:].sum()) for n in ART_LAYERS)
    v["science_layer_off_city_hall_and_restrained"] = teal_hall == 0 and park_teal <= 0.006 * (H - WALK_TOP) * W
    m = park_masks()
    near = dilate(m["path"], NEAR_PATH_PX)
    l = luma_of(flat)
    tech = {}
    for name, mk in tech_elements(sc):
        ring = dilate(mk, 2) & ~mk
        tech[name] = {"texels": int(mk.sum()), "touches_path_band": bool((mk & near).any()),
                      "luma_contrast_vs_2px_ring": round(abs(float(l[mk].mean()) - float(l[ring].mean())), 1),
                      "has_teal": bool(np.isin(composite_idx(layers, ART_LAYERS)[mk], teal).any()) or
                      name.startswith(("vault", "valve"))}
    v["infrastructure_at_path_edges"] = all(t["touches_path_band"] for t in tech.values())
    v["infrastructure_legible_at_native_640"] = all(t["texels"] >= 8 and t["luma_contrast_vs_2px_ring"] >= 18
                                                    for t in tech.values())
    da = depth_audit(sc["tech_items"], sc["walk"], sc["spr_alpha"])
    v["infrastructure_depth_audit_zero_wrong_order_feet"] = all(d["wrong_order_feet"] == 0 for d in da.values())
    clash = []
    for name, mk in tech_elements(sc):
        for vis in sc["overlay_visitors"]:
            h, w = vis["idx"].shape
            if mk[vis["y0"]:vis["y0"] + h, vis["x0"]:vis["x0"] + w].any():
                clash.append([name, vis["name"]])
    v["infrastructure_clear_of_test_visitors"] = not clash
    v["infrastructure_not_collision_items"] = not any(k.startswith("tech") for k in sc["collars"])
    win_ok = all(len(set(r)) >= min(3, len(r)) and all(a != b for a, b in zip(r, r[1:])) for r in WINDOW_ROWS.values())
    v["window_states_vary_along_every_row"] = win_ok
    # quantitative comparison with v04 (v04 read back from its .ora, never rebuilt)
    l4 = v04_layers()
    flat4 = composite_rgba(l4, ART_LAYERS)
    mm5 = material_metrics(flat, rgba)
    mm4 = material_metrics(flat4, l4)
    v["facade_more_value_variation_than_v04"] = mm5["facade"]["block4_luma_std"] > mm4["facade"]["block4_luma_std"] \
        and mm5["facade"]["window_mean_luma_std"] > mm4["facade"]["window_mean_luma_std"]
    v["tree_crowns_less_repetitive_than_v04"] = \
        mm5["tree_crowns"]["dup_6x6_block_share"] <= mm4["tree_crowns"]["dup_6x6_block_share"] and \
        mm5["tree_crowns"]["distinct_colours"] > mm4["tree_crowns"]["distinct_colours"]
    v["lawn_more_large_scale_variation_than_v04"] = mm5["lawn"]["block8_luma_std"] > mm4["lawn"]["block8_luma_std"]
    v["hex_paving_more_variation_than_v04"] = \
        mm5["hex_paving"]["block8_luma_std"] > mm4["hex_paving"]["block8_luma_std"]
    rim_core = [tree_shadow_masks(t) for ts in TREES.values() for t in ts]
    sh_all = np.zeros((H, W), bool)
    for rim, core in rim_core:
        sh_all |= rim | core
    hull = np.zeros((H, W), bool)
    for ts in TREES.values():
        for t in ts:
            hull |= lobe_shadow_mask(t)
    flecks = hull & ~sh_all & dilate(sh_all, 2) & (YY >= WALK_TOP)
    v["tree_shadows_dappled_two_tone"] = int(flecks.sum()) >= 150 and \
        int(np.isin(layers["cast-shadows"], [I["g0"], I["f1"]]).sum()) > 0
    changed = [n for n in LAYERS if not (rgba[n] == l4[n]).all()]
    return v, {"walkability_fields_equal_v04": same, "teal_texels": {"city_hall": teal_hall, "park_rows": park_teal,
                                                                       "per_layer": {k: n for k, n in teal_art.items()
                                                                                     if n}},
               "infrastructure": tech, "infrastructure_depth_audit": da, "infrastructure_visitor_clashes": clash,
               "comparison_v04_vs_v05_flat_1x": {"v04": mm4, "v05": mm5},
               "dappled_shadow_fleck_texels": int(flecks.sum()),
               "layers_changed_vs_v04": changed,
               "texels_changed_vs_v04_flat": int((flat != flat4).any(axis=2).sum())}


# ============================================================================ build
def artefacts(sc):
    layers = sc["layers"]
    rgba = {n: to_rgba(layers[n]) for n in LAYERS}
    flat = composite_rgba(rgba, ART_LAYERS)
    comp_png = png_bytes(flat)
    files = {"pxo": make_pxo(rgba, comp_png), "ora": make_ora(rgba, comp_png), "gpl": make_gpl(),
             "flat": comp_png, "walkmask": walkmask_png(sc["walk"]), "shadow": png_bytes(contact_shadow())}
    atlas, rects = visitor_atlas(sc["overlay_visitors"])                   # v04: separate test-only overlay files
    for v, r in zip(sc["overlay_visitors"], rects):
        v["atlas_rect"] = r
    files["npc_ground"] = png_bytes(to_rgba(sc["overlay_ground"]))
    files["npc_atlas"] = png_bytes(atlas)
    files["npc_json"] = (json.dumps(overlay_json(sc), indent=1) + "\n").encode()
    return rgba, flat, files


def overlay_rgba(sc):
    return {"ground": to_rgba(sc["overlay_ground"]),
            "sprites": [(v["pivot"], visitor_full_rgba(v)) for v in sc["overlay_visitors"]]}


def overlay_json(sc):
    return {"candidate": RUN, "status": "TEST-ONLY visitor overlay: not scene art, not part of the 24-layer .pxo / .ora "
                                        "stack, not runtime NPCs; shows park activity at the approved 48-px heroine "
                                        "scale for review only. UNAPPROVED.",
            "scale_reference_px": 48,
            "ground_png": names()["npc_ground"], "atlas_png": names()["npc_atlas"],
            "draw_order": "base art -> overlay ground (opaque contact shades, picnic blanket) -> Y-sort {9 art sprite "
                          "layers, visitors, heroine} by pivot row (ties: art layers, visitors, heroine last) -> "
                          "fg-occlusion",
            "collision": "none: the walk mask is art-only; real NPCs would bring their own collision",
            "visitors": [{"name": v["name"], "figure": v["figure"], "class": v["class"],
                          "atlas_rect_xywh": v["atlas_rect"], "scene_top_left": [v["x0"], v["y0"]],
                          "pivot_row": v["pivot"], "height_px": v["height_px"], "width_px": v["width_px"]}
                         for v in sc["overlay_visitors"]]}


def names():
    return {"pxo": fname("scene-24layer", "pxo"), "ora": fname("scene-24layer", "ora"),
            "shadow": fname("contact-shadow", "png"),
            "npc_ground": fname("test-npc-ground", "png"), "npc_atlas": fname("test-npc-atlas", "png"),
            "npc_json": fname("test-npc-overlay", "json"),
            "gpl": fname("scene-palette", "gpl"), "walk": fname("scene-walkability", "json"),
            "walkmask": fname("scene-walkmask", "png"), "flat": fname("scene-flat-640x360", "png"),
            "manifest": fname("scene-manifest", "json"),
            **{f"cap_{v}": fname(f"godot-render-1280x720-{v}-test-npc", "png") for v in CAPTURES},
            **{f"cap640_{v}": fname(f"godot-render-640x360-{v}-test-npc", "png") for v in CAPTURES},
            **{f"capart_{v}": fname(f"godot-render-640x360-{v}-art-only", "png") for v in CAPTURES},
            "report": fname("technical-check-report", "json")}


def walkability_json(sc):
    walk = sc["walk"]
    cells = []
    for cy in range(0, H, 8):
        row = ""
        for cx in range(0, W, 8):
            c = walk[cy:cy + 8, cx:cx + 8]
            row += "1" if c.all() else ("p" if c.any() else "0")
        cells.append(row)
    return {"candidate": RUN, "status": "UNAPPROVED test-only pilot; not wired to any runtime scene",
            "canvas": [W, H], "grid_px": 8,
            "cells_legend": {"1": "every foot texel walkable", "p": "partly walkable", "0": "not walkable"},
            "cells_rows_top_to_bottom": cells, "walk_top_row": WALK_TOP,
            "collision_mask_png": names()["walkmask"], "foot_rule": "a foot texel is walkable iff the mask is opaque",
            "pins": {k: list(v) for k, v in PINS.items()},
            "ysort_pivots": YSORT_PIVOTS,
            "runtime_draw_order_proposal": "base (layers 1-13 merged) -> Y-sorted {9 *-ysort layers, actor} by "
                                           "pivot row (actor last on ties; the actor's contact shadow is drawn just "
                                           "before the actor) -> fg-occlusion",
            "actor_contact_shadow": {"png": names()["shadow"], "offset_from_foot": list(shadow_offset()),
                                     "blend": "black, alpha 118 core / 64 rim, normal alpha blend"},
            "standing_on_readability_blocked_feet": sc["standing_on_blocked_feet"],
            "collars_blocked_texels": {k: int((v & ~walk).sum()) for k, v in sc["collars"].items()},
            "exits": {"exit_broadway_gate": "west park gate onto the Broadway sidewalk (transition trigger)",
                      "exit_park_row": "south plaza east end toward Park Row (transition trigger)",
                      "city_hall_gate": "scanner piers on the axis; interaction, the forecourt is not walkable"},
            "heroine_route": [PINS[p] if isinstance(p, str) else p for p in ROUTE]}


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def build_all():
    sc = scene()
    rgba, flat, files = artefacts(sc)
    return sc, rgba, flat, files


def preview(outdir):
    sc, rgba, flat, files = build_all()
    os.makedirs(outdir, exist_ok=True)
    Image.fromarray(flat, "RGBA").save(os.path.join(outdir, "flat.png"))
    Image.fromarray(x2(flat), "RGBA").save(os.path.join(outdir, "flat_x2.png"))
    spr = sc["spr"]
    ov = overlay_rgba(sc)
    for key in set(CAPTURES.values()) | {"spawn_south", "city_hall_gate", "statue_behind", "lamp_w_behind"}:
        st = runtime_stack_still(rgba, spr, PINS[key])
        Image.fromarray(x2(st), "RGBA").save(os.path.join(outdir, f"still_{key}_x2.png"))
        st = runtime_stack_still(rgba, spr, PINS[key], overlay=ov)
        Image.fromarray(st, "RGBA").save(os.path.join(outdir, f"still_{key}_npc_x1.png"))
        Image.fromarray(x2(st), "RGBA").save(os.path.join(outdir, f"still_{key}_npc_x2.png"))
    for k in ("npc_ground", "npc_atlas"):
        with open(os.path.join(outdir, f"{k}.png"), "wb") as f:
            f.write(files[k])
    Image.fromarray(np.repeat(np.repeat(decode(files["npc_atlas"])[2], 6, 0), 6, 1), "RGBA").save(
        os.path.join(outdir, "npc_atlas_x6.png"))
    g = composite_rgba(rgba, ART_LAYERS + ["guides"])
    Image.fromarray(x2(g), "RGBA").save(os.path.join(outdir, "guides_x2.png"))
    for n in LAYERS:
        Image.fromarray(rgba[n], "RGBA").save(os.path.join(outdir, f"layer_{n}.png"))
    rep = static_checks(sc, rgba, flat)
    with open(os.path.join(outdir, "checks.json"), "w") as f:
        json.dump(rep, f, indent=1, default=str)
    print(json.dumps({k: v for k, v in rep.items() if k not in ("depth_audit",)}, indent=1, default=str))


def manifest(sc, rgba, files, rep):
    nm = names()
    return {
        "project": SLUG, "area": AREA, "run": RUN, "version": "v04",
        "derived_from": {"run": V03_RUN, "tool": V03_TOOL_REL, "qa_note": V03_QA_REL,
                         "note": "v03 files untouched (re-hashed by the v04 check); v04 is a new separate candidate "
                                 "forked from the v03 tool"},
        "status": "UNAPPROVED / NONRUNTIME test-only walkable pilot (one 640x360 camera composition). Not accepted "
                  "art, not runtime-integrated, runtime default unchanged. Acceptance is creator review only; science "
                  "scene art stays 0/11. Codex judges before any review request.",
        "art_approved": False, "runtime_integrated": False, "counters_changed": False, "human_reviewed": False,
        "review_input": REVIEW_NOTE,
        "v04_changes_vs_v03": V04_CHANGES,
        "v03_changes_vs_v02_kept": V03_CHANGES,
        "removed_from_art": {"stair_figures_v03": 4, "lawn_occupants_v03": 5,
                             "also_moved_to_overlay": ["picnic blanket, basket and bottle", "garden drone"],
                             "creator_permission": "the task allowed removing the tiny stair figures; full-size "
                                                   "visitors are to be a separate test-only overlay, not baked art"},
        "test_only_visitor_overlay": {"ground_png": nm["npc_ground"], "atlas_png": nm["npc_atlas"],
                                      "json": nm["npc_json"],
                                      "status": "TEST-ONLY, not scene art, not in the .pxo / .ora, not runtime NPCs",
                                      "visitors": [{"name": v["name"], "class": v["class"],
                                                    "height_px": v["height_px"], "pivot_row": v["pivot"]}
                                                   for v in sc["overlay_visitors"]]},
        "captures": {"with_test_overlay": "godot-render-{1280x720,640x360}-{axis,fountain,tree}-test-npc",
                     "art_only": "godot-render-640x360-{axis,fountain,tree}-art-only"},
        "capture_pins_vs_v03": {"axis": {"v03": [320, 292], "v04": list(PINS["axis_mid"])},
                                "fountain": {"v03": [172, 240], "v04": list(PINS["fountain_behind"]),
                                             "why": "dead centre behind the new low tazza her legs ended exactly at "
                                                    "the lip and she read as standing in the bowl; 12 px east the "
                                                    "lip and bowl hide her west leg while her east boot and contact "
                                                    "shadow stand on the paving behind the fountain"},
                                "tree": {"v03": [398, 268], "v04": list(PINS["tree_se_behind"])}},
        "authoring_route": {
            "method": "deterministic Python tool with hand-written placement tables, authored and run by Claude "
                      "(Claude Code, claude.ai Max subscription, firstParty; no API key, no image model, no paid "
                      "fallback); writes a native pxo_version 7 .pxo and an .ora with 24 named layers",
            "pixelorama_gui_paint_pass": False,
            "disclosure": "no desktop/computer-use access to the Pixelorama GUI in this session",
            "texture_policy": "hand-drawn motifs (leaf clumps, grass tufts, bed clumps, bloom heads) on fixed "
                              "lattices with hand-written offset tables; wear marks, stains, cracks, litter, beds, "
                              "trees, props and visitor bodies (row-span tables) are explicit table entries; no "
                              "value-noise thresholds, no hashed pixel scatter (a hash only picks a slab / sett / hex "
                              "block tone or a course offset from a short hand table)",
            "reference_usage": "City Hall massing follows the published description (central pavilion, two "
                               "projecting wings, columned entrance portico, domed tower); bay / column counts are "
                               "an interpretation, not measured from LPC elevations; no reference pixel copied; "
                               "Lower Manhattan context is generic hazed massing",
            "reference_url": REFERENCE_URL, "audit_reference": AUDIT_REL, "v04_review_input": REVIEW_NOTE,
            "density_idea_reference": {"file": VISUAL_REF_REL, "use": "looked at for density ideas only (canopy "
                                       "variation, planted borders, lawn occupation, warmer city blocks); no pixel "
                                       "or colour sampled; it is itself an UNAPPROVED generated concept"}},
        "canvas": {"w": W, "h": H, "camera": "top-down 3/4; top = north (City Hall), bottom = south",
                   "gameplay_camera": "exactly one 640x360 logical viewport (window 1280x720, integer 2x; also "
                                      "captured in a native 640x360 window)",
                   "scale_reference": {"file": HEROINE_REL, "logical_height_px": int(sc["spr"].shape[0])},
                   "forced_perspective": "backdrop rows 0..171 (city beyond Chambers St, City Hall at reduced "
                                         "scale, forecourt) is not walkable; walkable park rows 172..359 at heroine "
                                         "scale; the walk ends at hero-scale gate piers and railings, the forecourt "
                                         "beyond them recedes (graded stair risers, thinning paving courses, smaller "
                                         "tufts and trees)"},
        "layers_bottom_to_top": [
            {"index": i + 1, "name": n, "visible": n != "guides", "locked": n == "guides",
             "runtime_export": ("merged into base" if n in BASE_LAYERS else
                                f"Y-sorted sprite layer, pivot row {YSORT_PIVOTS[n]}" if n in YSORT_PIVOTS else
                                "overlay above actors" if n == "fg-occlusion" else "never exported (hidden guides)"),
             "opaque_texels": int((rgba[n][..., 3] == 255).sum())} for i, n in enumerate(LAYERS)],
        "palette": [{"name": n, "hex": "#" + h} for n, h in PALETTE],
        "guide_palette": [{"name": n, "hex": "#" + h} for n, h in GUIDE_PALETTE],
        "pins": {k: list(v) for k, v in PINS.items()},
        "static_checks": rep,
        "files_sha256_bytes": {nm[k]: sha(v) for k, v in files.items()},
        "tool": {"file": TOOL_REL, "sha256_text_lf_v1": sha_text(read_bytes(os.path.abspath(__file__))),
                 "python": sys.version.split()[0], "pillow": Image.__version__, "numpy": np.__version__},
    }


def build():
    sc, rgba, flat, files = build_all()
    if build_all()[3] != files:
        raise SystemExit("build is not deterministic")
    rep = static_checks(sc, rgba, flat)
    cand = rp(CAND_REL)
    os.makedirs(_fs(cand), exist_ok=True)
    nm = names()
    for k in ("pxo", "ora", "flat", "gpl", "walkmask", "shadow", "npc_ground", "npc_atlas", "npc_json"):
        print(write_new(os.path.join(cand, nm[k]), files[k]), nm[k])
    files["walk"] = (json.dumps(walkability_json(sc), indent=1) + "\n").encode()
    print(write_new(os.path.join(cand, nm["walk"]), files["walk"]), nm["walk"])
    man = manifest(sc, rgba, files, rep)
    print(write_new(os.path.join(cand, nm["manifest"]), (json.dumps(man, indent=2, default=str) + "\n").encode()),
          nm["manifest"])
    print(json.dumps(rep["verdicts"], indent=1))
    return 0


# ============================================================================ Pixelorama gate (isolated APPDATA)
def snapshot_dir(root):
    snap = {}
    if root and os.path.isdir(root):
        for d, _, fs in os.walk(root):
            for f in fs:
                p = os.path.join(d, f)
                try:
                    st = os.stat(p)
                    snap[os.path.relpath(p, root).replace("\\", "/")] = (st.st_size, st.st_mtime_ns)
                except OSError:
                    snap[os.path.relpath(p, root).replace("\\", "/")] = None
    return snap


def run_isolated(exe, args, fake_appdata, real_root):
    """Pixelorama headless with APPDATA pointed at a temp dir. Kill-switch: if anything in the real
    %APPDATA%\\pixelorama other than the GUI's own .running heartbeat changes, or .running disappears."""
    env = dict(os.environ)
    env["APPDATA"] = fake_appdata
    before = snapshot_dir(real_root)
    t0 = time.time()
    p = subprocess.Popen([exe, "--headless", "--quit", "--"] + args, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    killed, marker_missing = False, False
    while p.poll() is None:
        now = snapshot_dir(real_root)
        changed = {k for k in set(before) | set(now) if before.get(k) != now.get(k) and k != ".running"}
        if ".running" in before and ".running" not in now:
            marker_missing = True
        if changed or marker_missing or time.time() - t0 > 240:
            p.kill(); killed = True
            break
        time.sleep(0.01)
    so, se = p.communicate()
    after = snapshot_dir(real_root)
    noise = ("shader_compiler", "custom_samplers", "Condition \"!actions")
    tail = [l for l in so.splitlines() + se.splitlines() if l.strip() and not any(s in l for s in noise)]
    return {"args": [os.path.basename(a) if os.path.isabs(a) else a for a in args], "exit_code": p.returncode,
            "seconds": round(time.time() - t0, 1), "killed_by_guard": killed,
            "fake_user_dir_created": os.path.isdir(os.path.join(fake_appdata, "pixelorama")),
            "real_dir_changed_except_running": sorted(k for k in set(before) | set(after)
                                                      if before.get(k) != after.get(k) and k != ".running"),
            "real_running_marker_present_after": (".running" in after) if ".running" in before else None,
            "output_tail": tail[-5:]}


def pixelorama_gate(exe, files, rgba, flat):
    real_root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    rep = {"pixelorama": exe, "pixelorama_sha256": sha(read_bytes(exe)),
           "isolation": "APPDATA redirected to a fresh temp dir per run; real %APPDATA%\\pixelorama polled every "
                        "10 ms with a kill-switch", "steps": {}}
    tmp = tempfile.mkdtemp(prefix="wb-chpgate-")
    try:
        src = {}
        for k in ("pxo", "ora"):
            src[k] = os.path.join(tmp, f"src.{k}")
            with open(_fs(src[k]), "wb") as f:
                f.write(files[k])
        flats = []
        for label, k, split in (("pxo_flat_1", "pxo", False), ("pxo_flat_2", "pxo", False),
                                ("pxo_split", "pxo", True), ("ora_flat", "ora", False), ("ora_split", "ora", True)):
            d = os.path.join(tmp, label); os.makedirs(d)
            fake = os.path.join(tmp, "appdata_" + label); os.makedirs(fake)
            args = ["--export"] + (["--split-layers"] if split else []) + ["-o", os.path.join(d, "f.png"), src[k]]
            r = run_isolated(exe, args, fake, real_root)
            r["pngs"] = sorted(f for f in os.listdir(_fs(d)) if f.lower().endswith(".png"))
            r["source_copy_unchanged"] = read_bytes(src[k]) == files[k]
            if not split and len(r["pngs"]) == 1:
                b = read_bytes(os.path.join(d, r["pngs"][0]))
                a = decode(b)[2]
                r["png_sha256"] = sha(b)
                r["flat_equals_expected"] = a.shape == flat.shape and bool((a == flat).all())
                r["differing_texels"] = int((a != flat).any(axis=2).sum()) if a.shape == flat.shape else None
                if k == "pxo":
                    flats.append(b)
            if split:
                got = []
                for f in r["pngs"]:
                    a = decode(read_bytes(os.path.join(d, f)))[2]
                    hit = [n for n in LAYERS if a.shape == rgba[n].shape and a.tobytes() == rgba[n].tobytes()]
                    got.append({"file": f, "exact_layer_match": hit,
                                "semi_alpha": int(((a[..., 3] > 0) & (a[..., 3] < 255)).sum())})
                r["split"] = got
                matched = [h for g in got for h in g["exact_layer_match"]]
                r["art_layers_all_exact"] = all(n in matched for n in ART_LAYERS)
                r["guides_exported"] = "guides" in matched or any("guides" in g["file"] for g in got)
                order = {n: i for i, n in enumerate(LAYERS)}
                stack = sorted((order[g["exact_layer_match"][0]], g["file"]) for g in got
                               if g["exact_layer_match"] and g["exact_layer_match"][0] != "guides")
                if stack:
                    comp = decode(read_bytes(os.path.join(d, stack[0][1])))[2].copy()
                    for _, f in stack[1:]:
                        a = decode(read_bytes(os.path.join(d, f)))[2]
                        m = a[..., 3] == 255
                        comp[m] = a[m]
                    r["split_composite_equals_flat"] = bool((comp == flat).all())
            rep["steps"][label] = r
        rep["pxo_flat_runs_identical"] = len(flats) == 2 and flats[0] == flats[1]
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    st = rep["steps"]
    rep["verdicts"] = {
        "pixelorama_isolation_held": all(not v["killed_by_guard"] and not v["real_dir_changed_except_running"]
                                         and v["real_running_marker_present_after"] is not False
                                         for v in st.values()),
        "pixelorama_pxo_flat_exact": all(st[k].get("flat_equals_expected") for k in ("pxo_flat_1", "pxo_flat_2")),
        "pixelorama_pxo_flat_deterministic": rep["pxo_flat_runs_identical"],
        "pixelorama_pxo_split_layers_exact": st["pxo_split"].get("art_layers_all_exact", False),
        "pixelorama_pxo_split_composite_equals_flat": st["pxo_split"].get("split_composite_equals_flat", False),
        "pixelorama_ora_flat_exact": st["ora_flat"].get("flat_equals_expected", False),
        "pixelorama_ora_split_layers_exact": st["ora_split"].get("art_layers_all_exact", False),
        "pixelorama_sources_unchanged": all(v["source_copy_unchanged"] for v in st.values()),
        "pixelorama_split_does_not_export_hidden_guides": not any(st[k].get("guides_exported")
                                                                  for k in ("pxo_split", "ora_split")),
    }
    return rep


# ============================================================================ Godot gates (throwaway temp projects)
GODOT_TEXEL_SCRIPT = r'''extends SceneTree
# Test-only, nonruntime (headless): load the split layer PNGs from the .ora with Image.load_from_file, hash raw RGBA,
# walk the heroine route on the exported collision mask, and composite a runtime-stack still (base -> Y-sorted
# {sprite layers, contact shadow + actor} by pivot row -> fg-occlusion) at every sampled route foot; report SHA-256
# per still. The contact shadow uses the runtime integer formula c' = (c * (255 - A) + 127) / 255 on raw bytes.
func _shadow(st: Image, sh: Image, foot, soff) -> void:
	var d = st.get_data()
	var sd = sh.get_data()
	var sw = sh.get_width()
	var x0 = int(foot[0]) + int(soff[0])
	var y0 = int(foot[1]) + int(soff[1])
	for j in range(sh.get_height()):
		for i in range(sw):
			var al = sd[(j * sw + i) * 4 + 3]
			var x = x0 + i
			var y = y0 + j
			if al == 0 or x < 0 or y < 0 or x >= 640 or y >= 360:
				continue
			var o = (y * 640 + x) * 4
			for c in range(3):
				d[o + c] = int((d[o + c] * (255 - al) + 127) / 255)
	st.set_data(640, 360, false, Image.FORMAT_RGBA8, d)

func _init():
	var a = OS.get_cmdline_user_args()
	var dir: String = a[0]
	var cases = JSON.parse_string(FileAccess.get_file_as_string(dir + "/cases.json"))
	var out = {"layers": {}, "stills": {}}
	var imgs = {}
	for n in cases["art_layers"]:
		var img = Image.load_from_file(dir + "/" + n + ".png")
		if img.get_format() != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		var h = HashingContext.new()
		h.start(HashingContext.HASH_SHA256)
		h.update(img.get_data())
		out["layers"][n] = {"w": img.get_width(), "h": img.get_height(), "sha256_rgba": h.finish().hex_encode()}
		imgs[n] = img
	var hero = Image.load_from_file(dir + "/heroine48.png")
	hero.convert(Image.FORMAT_RGBA8)
	out["heroine_h"] = hero.get_height()
	var shadow = Image.load_from_file(dir + "/shadow.png")
	shadow.convert(Image.FORMAT_RGBA8)
	var soff = cases["shadow_offset"]
	var mask = Image.load_from_file(dir + "/walkmask.png")
	var blocked = 0
	var jumps = 0
	var prev = null
	for p in cases["route"]:
		if mask.get_pixel(int(p[0]), int(p[1])).a < 0.5:
			blocked += 1
		if prev != null and (absi(int(p[0]) - int(prev[0])) > 1 or absi(int(p[1]) - int(prev[1])) > 1):
			jumps += 1
		prev = p
	out["route_points"] = cases["route"].size()
	out["route_blocked"] = blocked
	out["route_jumps"] = jumps
	var base = imgs[cases["base_layers"][0]].duplicate()
	for i in range(1, cases["base_layers"].size()):
		base.blend_rect(imgs[cases["base_layers"][i]], Rect2i(0, 0, 640, 360), Vector2i(0, 0))
	for key in cases["feet"].keys():
		var foot = cases["feet"][key]
		var st = base.duplicate()
		var hp = Vector2i(int(foot[0]) - hero.get_width() / 2, int(foot[1]) - hero.get_height() + 1)
		var placed = false
		for sp in cases["ysort_sprites"]:
			if not placed and int(foot[1]) < int(sp[1]):
				_shadow(st, shadow, foot, soff)
				st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
				placed = true
			st.blend_rect(imgs[sp[0]], Rect2i(0, 0, 640, 360), Vector2i(0, 0))
		if not placed:
			_shadow(st, shadow, foot, soff)
			st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
		st.blend_rect(imgs["fg-occlusion"], Rect2i(0, 0, 640, 360), Vector2i(0, 0))
		var hs = HashingContext.new()
		hs.start(HashingContext.HASH_SHA256)
		hs.update(st.get_data())
		out["stills"][key] = hs.finish().hex_encode()
	var f = FileAccess.open(dir + "/godot_report.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("GODOT_TEXEL_GATE_DONE")
	quit()
'''

GODOT_RENDER_SCRIPT = r'''extends SceneTree
# Test-only, nonruntime (WINDOWED, real GL Compatibility renderer): Sprite2D per base layer, a y_sort_enabled Node2D
# holding the nine Y-sorted layers (position.y = pivot, offset.y = -pivot) and the heroine (position = foot, added
# last so she wins ties) whose child is the alpha contact shadow (show_behind_parent), then the fg-occlusion
# overlay. v04: optional TEST-ONLY visitor overlay (ground sprite over the base; each visitor a Y-sorted sprite cut
# from the atlas, added after the art layers and before the heroine). 640x360 viewport, window from the project
# (1280x720 or 640x360), integer canvas_items stretch, nearest filtering. Captures the root
# viewport at each requested foot.
func _initialize():
	_run()

func _spr(path: String) -> Sprite2D:
	var s = Sprite2D.new()
	s.centered = false
	s.texture = ImageTexture.create_from_image(Image.load_from_file(path))
	return s

func _run():
	var a = OS.get_cmdline_user_args()
	var dir: String = a[0]
	var cases = JSON.parse_string(FileAccess.get_file_as_string(dir + "/cases.json"))
	var world = Node2D.new()
	world.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	root.add_child(world)
	for n in cases["base_layers"]:
		world.add_child(_spr(dir + "/" + n + ".png"))
	var ov = cases.get("overlay")
	if ov != null:
		world.add_child(_spr(dir + "/" + ov["ground"]))
	var ys = Node2D.new()
	ys.y_sort_enabled = true
	world.add_child(ys)
	for sp in cases["ysort_sprites"]:
		var s = _spr(dir + "/" + sp[0] + ".png")
		s.position = Vector2(0, int(sp[1]))
		s.offset = Vector2(0, -int(sp[1]))
		ys.add_child(s)
	if ov != null:
		var atlas = Image.load_from_file(dir + "/" + ov["atlas"])
		for v in ov["visitors"]:
			var r = v["atlas_rect_xywh"]
			var vs = Sprite2D.new()
			vs.centered = false
			vs.texture = ImageTexture.create_from_image(atlas.get_region(Rect2i(int(r[0]), int(r[1]), int(r[2]), int(r[3]))))
			vs.position = Vector2(int(v["scene_top_left"][0]), int(v["pivot_row"]))
			vs.offset = Vector2(0, int(v["scene_top_left"][1]) - int(v["pivot_row"]))
			ys.add_child(vs)
	var himg = Image.load_from_file(dir + "/heroine48.png")
	var hero = Sprite2D.new()
	hero.centered = false
	hero.texture = ImageTexture.create_from_image(himg)
	hero.offset = Vector2(-(himg.get_width() / 2), -himg.get_height() + 1)
	var shadow = Sprite2D.new()
	shadow.centered = false
	shadow.texture = ImageTexture.create_from_image(Image.load_from_file(dir + "/shadow.png"))
	shadow.offset = Vector2(int(cases["shadow_offset"][0]), int(cases["shadow_offset"][1]))
	shadow.show_behind_parent = true
	hero.add_child(shadow)
	ys.add_child(hero)
	world.add_child(_spr(dir + "/fg-occlusion.png"))
	var out = {"captures": {}}
	for key in cases["captures"].keys():
		var foot = cases["captures"][key]
		hero.position = Vector2(int(foot[0]), int(foot[1]))
		for i in range(4):
			await process_frame
		await RenderingServer.frame_post_draw
		var img = root.get_texture().get_image()
		img.convert(Image.FORMAT_RGBA8)
		img.save_png(dir + "/render_" + key + ".png")
		out["captures"][key] = [img.get_width(), img.get_height()]
	out["window_size"] = [root.size.x, root.size.y]
	var f = FileAccess.open(dir + "/render_report.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("GODOT_RENDER_GATE_DONE")
	quit()
'''

RENDER_PROJECT = """config_version=5

[application]
config/name="{name}"

[display]
window/size/viewport_width=640
window/size/viewport_height=360
window/size/window_width_override={ww}
window/size/window_height_override={wh}
window/stretch/mode="canvas_items"
window/stretch/scale_mode="integer"

[rendering]
renderer/rendering_method="gl_compatibility"
renderer/rendering_method.mobile="gl_compatibility"
textures/canvas_textures/default_texture_filter=0
"""


def godot_inputs(data, files, spr, walk):
    with zipfile.ZipFile(io.BytesIO(files["ora"])) as z:
        for n in ART_LAYERS:
            with open(os.path.join(data, f"{n}.png"), "wb") as f:
                f.write(z.read(f"data/{n}.png"))
    for k, fn in (("npc_ground", "npc_ground.png"), ("npc_atlas", "npc_atlas.png")):     # v04 test-only overlay
        with open(os.path.join(data, fn), "wb") as f:
            f.write(files[k])
    Image.fromarray(spr, "RGBA").save(os.path.join(data, "heroine48.png"))
    with open(os.path.join(data, "walkmask.png"), "wb") as f:
        f.write(files["walkmask"])
    with open(os.path.join(data, "shadow.png"), "wb") as f:
        f.write(files["shadow"])


def godot_gates(godot, files, rgba, sc):
    spr, walk = sc["spr"], sc["walk"]
    rep = {"godot": GODOT_REL, "godot_sha256": sha(read_bytes(godot)), "texel_gate": {}, "render_gate": {}}
    caps = {}
    rpts = route_points()
    feet = {f"r{i:04d}": list(p) for i, p in enumerate(rpts) if i % 6 == 0}
    feet.update({k: list(PINS[k]) for k in PINS})
    ysl = sorted(([n, YSORT_PIVOTS[n]] for n in YSORT_LAYERS), key=lambda t: t[1])
    tmp = tempfile.mkdtemp(prefix="wb-chpgodot-")
    pnames = []
    try:
        # ---- headless texel gate
        proj = os.path.join(tmp, "p1"); os.makedirs(proj)
        data = os.path.join(tmp, "d1"); os.makedirs(data)
        fake = os.path.join(tmp, "ad1"); os.makedirs(fake)
        with open(os.path.join(proj, "project.godot"), "w", newline="\n") as f:
            f.write(f'config_version=5\n\n[application]\nconfig/name="chp-texel-{RUN_ID}"\n')
        with open(os.path.join(proj, "gate.gd"), "w", newline="\n") as f:
            f.write(GODOT_TEXEL_SCRIPT)
        godot_inputs(data, files, spr, walk)
        with open(os.path.join(data, "cases.json"), "w") as f:
            json.dump({"art_layers": ART_LAYERS, "base_layers": BASE_LAYERS, "feet": feet, "route": rpts,
                       "ysort_sprites": ysl, "shadow_offset": list(shadow_offset())}, f)
        env = dict(os.environ); env["APPDATA"] = fake
        p = subprocess.run([godot, "--headless", "--path", proj, "--script", "gate.gd", "--", data],
                           capture_output=True, text=True, timeout=900, env=env, encoding="utf-8", errors="replace")
        t = rep["texel_gate"]
        t["exit_code"] = p.returncode
        t["printed_done"] = "GODOT_TEXEL_GATE_DONE" in p.stdout
        gr = json.load(open(os.path.join(data, "godot_report.json")))
        lay_ok = {n: gr["layers"][n]["w"] == W and gr["layers"][n]["h"] == H and
                  gr["layers"][n]["sha256_rgba"] == sha(np.ascontiguousarray(rgba[n]).tobytes()) for n in ART_LAYERS}
        st_bad = []
        for k, foot in feet.items():
            exp = runtime_stack_still(rgba, spr, tuple(foot))
            if gr["stills"].get(k) != sha(np.ascontiguousarray(exp).tobytes()):
                st_bad.append(k)
        t.update({"layers_exact": lay_ok, "stills_compared": len(feet), "stills_mismatched": st_bad[:20],
                  "route_points": gr["route_points"], "route_blocked_on_exported_mask": gr["route_blocked"],
                  "route_jumps_over_1px": gr["route_jumps"], "heroine_h": gr["heroine_h"]})
        # ---- windowed render gates (real renderer): 1280x720 (integer 2x) and native 640x360 (1x) with the
        # TEST-ONLY visitor overlay, and native 640x360 art-only (no overlay)
        capfeet = {k: list(PINS[v]) for k, v in CAPTURES.items()}
        ovj = json.loads(files["npc_json"])
        ov_cases = {"ground": "npc_ground.png", "atlas": "npc_atlas.png", "visitors": ovj["visitors"]}
        ov_rgba = overlay_rgba(sc)
        for scale, (ww, wh), with_ov, tag in ((2, (W * 2, H * 2), True, "1280x720"), (1, (W, H), True, "640x360"),
                                              (1, (W, H), False, "640x360-art-only")):
            proj2 = os.path.join(tmp, f"p2_{tag}"); os.makedirs(proj2)
            data2 = os.path.join(tmp, f"d2_{tag}"); os.makedirs(data2)
            fake2 = os.path.join(tmp, f"ad2_{tag}"); os.makedirs(fake2)
            pname = f"chp-render-{RUN_ID}-{tag}"
            pnames.append(pname)
            with open(os.path.join(proj2, "project.godot"), "w", newline="\n") as f:
                f.write(RENDER_PROJECT.format(name=pname, ww=ww, wh=wh))
            with open(os.path.join(proj2, "gate.gd"), "w", newline="\n") as f:
                f.write(GODOT_RENDER_SCRIPT)
            godot_inputs(data2, files, spr, walk)
            with open(os.path.join(data2, "cases.json"), "w") as f:
                json.dump({"base_layers": BASE_LAYERS, "ysort_sprites": ysl, "captures": capfeet,
                           "shadow_offset": list(shadow_offset()), "overlay": ov_cases if with_ov else None}, f)
            env2 = dict(os.environ); env2["APPDATA"] = fake2
            p2 = subprocess.run([godot, "--path", proj2, "--script", "gate.gd", "--", data2],
                                capture_output=True, text=True, timeout=300, env=env2, encoding="utf-8",
                                errors="replace")
            r = rep["render_gate"].setdefault(tag, {})
            r["exit_code"] = p2.returncode
            r["printed_done"] = "GODOT_RENDER_GATE_DONE" in p2.stdout
            r["script_errors"] = [l for l in (p2.stdout + p2.stderr).splitlines() if "SCRIPT ERROR" in l][:5]
            rr = json.load(open(os.path.join(data2, "render_report.json")))
            r["window_size"] = rr.get("window_size")
            r["captures"] = {}
            for k, foot in capfeet.items():
                b = read_bytes(os.path.join(data2, f"render_{k}.png"))
                got = decode(b)[2]
                one = runtime_stack_still(rgba, spr, tuple(foot), overlay=ov_rgba if with_ov else None)
                exp = x2(one) if scale == 2 else one
                same_shape = got.shape == exp.shape
                sm = np.zeros((H, W), bool)                           # 1x footprint of the alpha contact shadow
                ox, oy = shadow_offset()
                shs = contact_shadow()[..., 3] > 0
                sm[foot[1] + oy:foot[1] + oy + shs.shape[0], foot[0] + ox:foot[0] + ox + shs.shape[1]] = shs
                sm2 = x2(sm) if scale == 2 else sm
                if same_shape:
                    dif = (got[..., :3].astype(np.int16) - exp[..., :3].astype(np.int16))
                    dmask = (dif != 0).any(axis=2)
                    diff = int(dmask.sum())
                    out_sh = int((dmask & ~sm2).sum())
                    max_in = int(np.abs(dif[sm2]).max()) if sm2.any() else 0
                else:
                    diff = out_sh = max_in = None
                r["captures"][k] = {"foot": foot, "size": list(got.shape[1::-1]), "differing_pixels": diff,
                                    "differing_outside_contact_shadow": out_sh,
                                    "max_channel_diff_inside_contact_shadow": max_in,
                                    "equals_python_stack": out_sh == 0 and max_in is not None and max_in <= 1}
                caps[("cap_" if scale == 2 else "cap640_" if with_ov else "capart_") + k] = b
        rep["render_gate"]["godot_wrote_nothing_outside_temp"] = not any(os.path.isdir(os.path.join(
            os.environ.get("APPDATA", ""), "Godot", "app_userdata", n)) for n in pnames + [f"chp-texel-{RUN_ID}"])
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    t, rg = rep["texel_gate"], rep["render_gate"]
    r720, r360, rart = rg["1280x720"], rg["640x360"], rg["640x360-art-only"]
    rep["verdicts"] = {
        "godot_loads_layers_exact": all(t["layers_exact"].values()) and t["exit_code"] == 0,
        "godot_route_walkable_on_exported_mask": t["route_blocked_on_exported_mask"] == 0
                                                 and t["route_jumps_over_1px"] == 0,
        "godot_route_stills_match_ysort_and_occlusion": not t["stills_mismatched"],
        "godot_heroine_48_px": t["heroine_h"] == 48,
        "godot_render_1280x720": all(c["size"] == [W * VIEW, H * VIEW] for c in r720["captures"].values())
                                 and r720["window_size"] == [W * VIEW, H * VIEW],
        "godot_render_1280x720_equals_python_2x_exact_outside_shadow_le1_inside": all(
            c["equals_python_stack"] for c in r720["captures"].values()),
        "godot_render_640x360": all(c["size"] == [W, H] for c in r360["captures"].values())
                                and r360["window_size"] == [W, H],
        "godot_render_640x360_equals_python_1x_exact_outside_shadow_le1_inside": all(
            c["equals_python_stack"] for c in r360["captures"].values()),
        "godot_render_640x360_art_only_equals_python_1x_exact_outside_shadow_le1_inside": all(
            c["equals_python_stack"] for c in rart["captures"].values()) and rart["window_size"] == [W, H],
        "godot_render_no_script_errors": not r720["script_errors"] and not r360["script_errors"]
                                         and not rart["script_errors"] and r720["printed_done"]
                                         and r360["printed_done"] and rart["printed_done"],
        "godot_wrote_nothing_outside_temp": rg["godot_wrote_nothing_outside_temp"],
    }
    return rep, caps


# ============================================================================ check
def check(exe, write_report, use_pixelorama, godot=None):
    sc, rgba, flat, files = build_all()
    nm = names()
    cand = rp(CAND_REL)
    for k in ("pxo", "ora", "flat", "gpl", "walkmask", "shadow", "npc_ground", "npc_atlas", "npc_json"):
        disk = read_bytes(os.path.join(cand, nm[k]))
        if (sha_text(disk) != sha_text(files[k])) if k in ("gpl", "npc_json") else (disk != files[k]):
            raise SystemExit(f"{nm[k]} on disk differs from a fresh rebuild")
    st = static_checks(sc, rgba, flat)
    rep = {"run": RUN, "gates": dict(st["verdicts"]), "static": st}
    gates = rep["gates"]
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        dj = json.loads(z.read("data.json"))
    gates["pxo_layer_stack_is_24_named_layers"] = [l["name"] for l in dj["layers"]] == LAYERS and \
        [l["visible"] for l in dj["layers"]] == [n != "guides" for n in LAYERS] and len(LAYERS) == 24
    with zipfile.ZipFile(io.BytesIO(files["ora"])) as z:
        stack = z.read("stack.xml").decode()
        ora_names = [part.split('"')[0] for part in stack.split('<layer name="')[1:]]
        ora_pngs_exact = all(decode(z.read(f"data/{n}.png"))[2].tobytes() == rgba[n].tobytes() for n in LAYERS)
    gates["ora_stack_is_24_named_layers_guides_hidden"] = ora_names == LAYERS[::-1] and \
        stack.count('visibility="hidden"') == 1 and '<layer name="guides" src="data/guides.png" x="0" y="0" ' \
        'opacity="1.000" visibility="hidden"' in stack
    gates["ora_layer_pngs_exact"] = ora_pngs_exact
    gates["build_deterministic"] = build_all()[3] == files
    caps = {}
    if use_pixelorama:
        rep["pixelorama"] = pixelorama_gate(exe, files, rgba, flat)
        gates.update(rep["pixelorama"]["verdicts"])
    if godot:
        rep["godot"], caps = godot_gates(godot, files, rgba, sc)
        gates.update(rep["godot"]["verdicts"])
    rep["result"] = "PASS" if all(gates.values()) else "FAIL"
    rep["note"] = "Technical gates only. Passing them does not make the art accepted; acceptance is creator review."
    text = json.dumps(rep, indent=2, default=str) + "\n"
    print(json.dumps({"result": rep["result"], "gates": gates}, indent=1))
    if write_report:
        out = rp(OUT_REL)
        os.makedirs(_fs(out), exist_ok=True)
        print(write_new(os.path.join(out, nm["report"]), text.encode()), nm["report"])
        for k, b in caps.items():
            print(write_new(os.path.join(out, nm[k]), b), nm[k])
    return 0 if rep["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("dir", nargs="?")
    ap.add_argument("--write-report", action="store_true")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--no-godot", action="store_true")
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    a = ap.parse_args()
    if a.mode == "preview":
        if not a.dir or os.path.abspath(a.dir).startswith(REPO):
            raise SystemExit("preview needs a directory outside the repo")
        preview(a.dir)
    elif a.mode == "build":
        build()
    else:
        sys.exit(check(a.pixelorama, a.write_report, not a.no_pixelorama, None if a.no_godot else rp(GODOT_REL)))


if __name__ == "__main__":
    main()
