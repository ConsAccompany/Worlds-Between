#!/usr/bin/env python3
"""Global / regional map-art candidate v02: pixel layer builder (UNAPPROVED, NONRUNTIME).

Builds the raster layers of one isolated M2 map-art candidate for the Worlds Between global map:
the whole-Earth view and the two US science-sphere regional views (US Northeast, US Great Lakes).
Every pixel is derived from real geodata. Nothing here is player text, and nothing is read by the
game at run time; the Godot capture tool loads these PNGs only behind its own test flag.

v02 is a separate candidate. It reads no v01 file: it re-extracts its own subset from the same pinned
Natural Earth files. Changes against v01, none of which needs a creator decision:
  - default-zoom declutter by Natural Earth's own ranks: at the min and default regional levels only
    expressways with scalerank <= 3 and urban areas >= URBAN_MIN_SQKM are drawn, in quiet tones close to
    the land; the remaining ranks return at 2x / 4x (nothing is invented, only filtered);
  - flat urban fill (no 2x2 checker) below 4x;
  - globe speckle generalisation at the two smallest levels (enclosed lake specks below LAKE_MIN_PX filled,
    islands below ISLE_MIN_PX drawn as one flat tone, no relief rim on lake shores or one-pixel spurs);
    the generalisation is measured and reported, not hidden;
  - map-only palette moved toward the live header / card / status-panel colours.

Two stages:

  extract  --source-dir <dir with the Natural Earth v5.1.2 GeoJSON files listed in SOURCES>
           Writes the small derived subset (rounded, clipped) that `build` reads. The large source
           files are not stored in the repository; their URLs and SHA-256 are recorded in the subset.
  build    Rasterizes every view and zoom level from the subset plus the game's own runtime geodata
           (game/data/world-map/...geodata...v02...json, the same rings the live map draws),
           writes the flattened PNGs, one editable layered .ora per view (default zoom level), the
           runtime meta JSON for the capture tool and the manifest.
  check    Rebuilds everything in memory and compares it byte for byte with the files on disk and
           the hashes in the manifest. Exit 0 only if identical.

Run with the real Python 3.12 (Pillow + numpy):
  C:/Users/hkzha/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe \
    tools/<this file> build|check|extract [--source-dir DIR]

Projection: the exact math of game/scripts/world_geo_projection.gd. Globe = plate carree; region =
equidistant cylindrical at the registry's central meridian and standard parallel. Zoom levels match
the live map's camera scales (min scale, default framed scale, ... max scale), so a texture drawn at
its own level maps one texel to one logical 640x360 pixel.
"""

import hashlib
import io
import json
import math
import os
import sys
import zipfile

import numpy as np
from PIL import Image, ImageDraw

TAG = "candidate-unapproved-v02_20261016-172153-ab9459d4"
SLUG = "rpg-2-star-ocean-the-second"
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ASSET_DIR_REL = "assets/map-art/global-map-art-candidate-v02-ab9459d4"
ASSET_DIR = os.path.join(ROOT, ASSET_DIR_REL)
SELF_REL = "tools/" + os.path.basename(__file__)

GEODATA_REL = "game/data/world-map/rpg-2-star-ocean-the-second_earth-map_runtime-geodata_m2-us-science-v02_20261015-175011-944d9635.json"
REGISTRY_REL = "game/data/world-map/rpg-2-star-ocean-the-second_earth-map_place-registry_m2-us-science-v02_20261015-175011-eeaa6baa.json"
TRAVEL_REL = "game/data/world-travel/rpg-2-star-ocean-the-second_global-earth-travel_locations-routes_m2-us-science-v02_20261015-175011-c454007b.json"

UPSTREAM = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/v5.1.2/geojson/"
SOURCES = {
    "ne_50m_admin_0_countries": "3e458fc036ad0a66411f2c1e6cac49c5d7bfb81cb1123bc513b22511a2b7fdeb",
    "ne_50m_lakes": "d350b75978b26fe839b797c2c529b2fb8f47fb3983c03f4964e36d5df9378a52",
    "ne_10m_roads": "66a0c7b438e92fd124822cc5921cfa11042f48c294ade5e0f03f2c6640fd0248",
    "ne_10m_urban_areas": "5136ffd816a9b28c0f295e6797b4c03eaa421be80d78b90f542db4a932dd4497",
    "ne_10m_admin_1_states_provinces_lines": "1a1f30ccaaf4cc9c4bde34266f0b8cbb955d3a4cf254b756912255f2ec7c75b6",
    "ne_10m_admin_0_boundary_lines_land": "74d9c16229c095fde65943a9919e337682f044bcebccb120764f38edf3b70f4a",
}
LICENSE = "Natural Earth vector data is public domain: https://www.naturalearthdata.com/about/terms-of-use/"

# Live-map constants (game/scripts/scifi_world_map.gd). The map frame is 640x268 logical pixels.
FRAME_W, FRAME_H = 640.0, 268.0
GLOBAL_ZOOM_RANGE = 7.0
REGION_ZOOM_RANGE = 6.0
REGION_FRAME = (150.0, 44.0, 230.0, 116.0)
# Same clip box as the runtime us_east layer.
US_EAST_CLIP = [-93.0, 36.0, -66.0, 47.5]
GLOBAL_LAKE_MAX_SCALERANK = 0

# v02 declutter thresholds (Natural Earth's own attributes; nothing is added).
DEFAULT_EXPRESSWAY_MAX_RANK = 3   # min / default regional levels: backbone expressways only
URBAN_MIN_SQKM = {"default": 150.0, "x2": 40.0, "x4": 0.0}
# Globe speckle generalisation, by level index (0 = min scale, 1 = 2x). Higher levels are untouched.
LAKE_MIN_PX = {0: 10, 1: 8}
ISLE_MIN_PX = {0: 4, 1: 4}
SPECKLE_LEVELS = (0, 1)

# Live chrome colours the map-only palette is matched to (game/scripts/scifi_world_map.gd, read-only;
# the deterministic checker re-reads them from that file).
CHROME = {
    "header": "#0d1723",
    "card_bg": "#12212b",        # Color(0.07, 0.13, 0.17)
    "label_bg": "#0a141f",       # COLOR_LABEL_BG rgb
    "panel_border": "#25404b",
    "marker": "#79cfc0",
    "here": "#f0d68a",
    "card_kind": "#e9d9a8",
    "card_route": "#d8e6e2",
    "subtext": "#a9c7c4",
}

# ----------------------------------------------------------------------------------------------
# Sphere assignment (display-only candidate). Canon: creator decisions 2026-10-15 — science = US +
# Canada, magic = South America, wuxia = Asia, nature = Oceania, culture = Europe + Africa; Mexico,
# Central America and the Caribbean are mixed borderlands; Antarctica is DLC. Natural Earth's
# CONTINENT field is used for the continents. Countries canon does not place are left UNASSIGNED
# (neutral) instead of being guessed: transcontinental Russia and Turkey, Greenland, Bermuda,
# St. Pierre and Miquelon and NE's open-ocean islands. Puerto Rico and the US Virgin Islands follow
# the Caribbean borderland rule. These are open creator questions, recorded in the QA note.
SPHERE_IDS = {"water": 0, "science": 1, "magic": 2, "wuxia": 3, "nature": 4, "culture": 5,
              "borderland": 6, "unassigned": 7, "dlc_antarctica": 8}
UNASSIGNED_A3 = {"RUS", "TUR", "GRL", "BMU", "SPM"}


def sphere_for(props):
    a3 = props.get("ADM0_A3") or props.get("ISO_A3")
    continent = props.get("CONTINENT")
    if a3 in ("USA", "CAN"):
        return "science"
    if a3 in UNASSIGNED_A3:
        return "unassigned"
    if continent == "Antarctica":
        return "dlc_antarctica"
    if continent == "North America":
        return "borderland"
    if continent == "South America":
        return "magic"
    if continent == "Asia":
        return "wuxia"
    if continent == "Oceania":
        return "nature"
    if continent in ("Europe", "Africa"):
        return "culture"
    return "unassigned"


# ----------------------------------------------------------------------------------------------
# Palette. Restrained: each sphere has four tones (base, texture, light rim, shadow rim); water has
# four. Science, the only open sphere, is the most saturated and luminous; locked spheres are muted.

def _c(hexstr):
    hexstr = hexstr.lstrip("#")
    return (int(hexstr[0:2], 16), int(hexstr[2:4], 16), int(hexstr[4:6], 16), 255)


# v02: water and shelf tones sit between the header (#0d1723) and the route-card fill (#12212b), the
# near-shore band and equator take the status-panel border (#25404b), so the map frame, header strip and
# card read as one dark navy-teal family. Land tints are v01's, slightly deepened in the regions so the
# live map's cream / teal UI stays on top. Default-level roads use a quiet sage tone, not amber.
PALETTE = {
    "ocean_deep": "#0f1e2a",
    "ocean_tick": "#132635",
    "graticule": "#1a3140",
    "equator": "#25404b",
    "shelf_far": "#152b39",
    "shelf_near": "#1d3946",
    "lake": "#1a3542",
    "science_glow": "#285a5c",
    "sphere_border": "#26302f",
    "science": {"base": "#4b7e70", "tex": "#548878", "light": "#76ae9a", "shadow": "#33594f"},
    "magic": {"base": "#57536d", "tex": "#5f5b77", "light": "#6f6a88", "shadow": "#3f3c52"},
    "wuxia": {"base": "#674f4d", "tex": "#705755", "light": "#7f6563", "shadow": "#4a3837"},
    "nature": {"base": "#5e6846", "tex": "#66714d", "light": "#76815a", "shadow": "#444b32"},
    "culture": {"base": "#6f6448", "tex": "#786c4f", "light": "#887b5b", "shadow": "#514934"},
    "borderland": {"base": "#535d5c", "tex": "#596362", "light": "#677271", "shadow": "#3c4444"},
    "unassigned": {"base": "#495153", "tex": "#4f5759", "light": "#5c6567", "shadow": "#353b3d"},
    "dlc_antarctica": {"base": "#55646c", "tex": "#5c6b73", "light": "#6a7a82", "shadow": "#414e55"},
    # Regional views (science land only).
    "r_water": "#0f1e2a",
    "r_shelf_near": "#1d3946",
    "r_shelf_far": "#152b39",
    "r_grat_water": "#182e3c",
    "r_grat_land": "#426a5e",
    "r_land": "#3c6458",
    "r_land_tex": "#40695d",
    "r_land_light": "#5b8c7b",
    "r_land_shadow": "#2a4841",
    "r_urban": "#47705f",
    "r_urban_tex": "#4f7a69",
    "r_state": "#31574d",
    "r_border_land": "#86bfab",
    "r_border_water": "#35717a",
    "r_road_quiet": "#5a806c",
    "r_road_secondary": "#4d7365",
    "r_road_major": "#6c7e62",
    "r_road_express": "#998a60",
}


def rgba(key, tone=None):
    value = PALETTE[key] if tone is None else PALETTE[key][tone]
    return _c(value)


# ----------------------------------------------------------------------------------------------
# Hashing (text locks are line-ending independent: sha256-text-lf-v1).

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_text_lf(data):
    return hashlib.sha256(data.replace(b"\r\n", b"\n")).hexdigest()


def rel(path):
    return os.path.relpath(path, ROOT).replace("\\", "/")


def name(part, ext):
    return "%s_global-map-art_%s_%s.%s" % (SLUG, part, TAG, ext)


def load_json(rel_path):
    with open(os.path.join(ROOT, rel_path), "r", encoding="utf-8") as fh:
        return json.load(fh)


def dumps(data):
    return (json.dumps(data, ensure_ascii=False, indent=1, sort_keys=False) + "\n").encode("utf-8")


# ----------------------------------------------------------------------------------------------
# Extract: Natural Earth -> small derived subset.

def _rnd(v, p):
    return round(v, p)


def _ring_flat(coords, precision):
    out = []
    last = None
    for x, y in coords:
        pt = (_rnd(x, precision), _rnd(y, precision))
        if pt != last:
            out.extend(pt)
            last = pt
    return out


def _bbox_hit(coords, box, margin=0.5):
    w, s, e, n = box
    for x, y in coords:
        if w - margin <= x <= e + margin and s - margin <= y <= n + margin:
            return True
    return False


def _lines_of(geom):
    if geom is None:
        return []
    if geom["type"] == "LineString":
        return [geom["coordinates"]]
    if geom["type"] == "MultiLineString":
        return geom["coordinates"]
    return []


def _polys_of(geom):
    if geom is None:
        return []
    if geom["type"] == "Polygon":
        return [geom["coordinates"]]
    if geom["type"] == "MultiPolygon":
        return geom["coordinates"]
    return []


def extract(source_dir):
    parsed = {}
    sources = []
    for sid, digest in SOURCES.items():
        path = os.path.join(source_dir, sid + ".geojson")
        with open(path, "rb") as fh:
            raw = fh.read()
        actual = sha256_bytes(raw)
        if actual != digest:
            raise SystemExit("source %s sha256 %s != pinned %s" % (sid, actual, digest))
        parsed[sid] = json.loads(raw.decode("utf-8"))
        sources.append({"id": sid, "url": UPSTREAM + sid + ".geojson", "sha256": digest,
                        "hash_algorithm": "sha256-bytes", "license": LICENSE})

    countries = []
    for f in parsed["ne_50m_admin_0_countries"]["features"]:
        p = f["properties"]
        polys = []
        for poly in _polys_of(f["geometry"]):
            polys.append([_ring_flat(ring, 2) for ring in poly])
        countries.append({"a3": p.get("ADM0_A3"), "name_en": p.get("NAME"), "continent": p.get("CONTINENT"),
                          "sphere": sphere_for(p), "polygons": polys})
    countries.sort(key=lambda c: c["a3"] or "")

    lakes = []
    for f in parsed["ne_50m_lakes"]["features"]:
        p = f["properties"]
        if int(p.get("scalerank", 99)) <= GLOBAL_LAKE_MAX_SCALERANK and p.get("featurecla") in ("Lake", "Alkaline Lake"):
            for poly in _polys_of(f["geometry"]):
                lakes.append(_ring_flat(poly[0], 2))

    roads = []
    for f in parsed["ne_10m_roads"]["features"]:
        p = f["properties"]
        if p.get("sov_a3") not in ("USA", "CAN") or p.get("type") == "Ferry Route":
            continue
        kind = p.get("type")
        express = int(p.get("expressway") or 0) == 1
        if kind in ("Major Highway", "Beltway") and express:
            tier = "expressway"
        elif kind in ("Major Highway", "Beltway"):
            tier = "major"
        else:
            tier = "secondary"
        rank = int(p.get("scalerank") or 99)
        for line in _lines_of(f["geometry"]):
            if _bbox_hit(line, US_EAST_CLIP):
                roads.append({"tier": tier, "rank": rank, "points": _ring_flat(line, 3)})

    urban = []
    for f in parsed["ne_10m_urban_areas"]["features"]:
        sqkm = round(float(f["properties"].get("area_sqkm") or 0.0), 1)
        for poly in _polys_of(f["geometry"]):
            if _bbox_hit(poly[0], US_EAST_CLIP, 0.0):
                urban.append({"area_sqkm": sqkm, "rings": [_ring_flat(ring, 3) for ring in poly]})

    states = []
    for f in parsed["ne_10m_admin_1_states_provinces_lines"]["features"]:
        if f["properties"].get("ADM0_A3") not in ("USA", "CAN"):
            continue
        for line in _lines_of(f["geometry"]):
            if _bbox_hit(line, US_EAST_CLIP):
                states.append(_ring_flat(line, 3))

    border = []
    for f in parsed["ne_10m_admin_0_boundary_lines_land"]["features"]:
        p = f["properties"]
        if {p.get("ADM0_A3_L"), p.get("ADM0_A3_R")} != {"CAN", "USA"}:
            continue
        water = "water" in str(p.get("TYPE", "")).lower()
        for line in _lines_of(f["geometry"]):
            if _bbox_hit(line, US_EAST_CLIP):
                border.append({"water": water, "points": _ring_flat(line, 3)})

    subset = {
        "schema": "worlds-between.map-art-candidate.ne-subset.v2",
        "status": "derived-geodata-for-unapproved-nonruntime-map-art-candidate",
        "generated_by": SELF_REL,
        "coordinate_order": "lon,lat pairs in WGS84 degrees, flattened",
        "sources": sources,
        "notes": [
            "Derived only from the pinned Natural Earth v5.1.2 files; coordinates rounded (countries and lakes 0.01 deg, regional layers 0.001 deg). Nothing is added.",
            "Sphere assignment per country is a display-only candidate rule (see sphere_rule); it is not canon for any country the creator has not placed.",
            "v2 adds two Natural Earth attributes used only to filter by zoom: road 'rank' (NE scalerank) and urban 'area_sqkm'.",
        ],
        "sphere_rule": {
            "science": "ADM0_A3 USA or CAN",
            "borderland": "other North America (Mexico, Central America, Caribbean incl. Puerto Rico and US Virgin Islands)",
            "magic": "CONTINENT South America",
            "wuxia": "CONTINENT Asia (except Turkey)",
            "nature": "CONTINENT Oceania",
            "culture": "CONTINENT Europe or Africa (except Russia)",
            "dlc_antarctica": "CONTINENT Antarctica",
            "unassigned": "Russia, Turkey, Greenland, Bermuda, St. Pierre and Miquelon, NE open-ocean islands (no creator decision)",
        },
        "us_east_clip_wsen": US_EAST_CLIP,
        "global": {"countries": countries, "lakes": lakes, "lake_max_scalerank": GLOBAL_LAKE_MAX_SCALERANK},
        "us_east": {"roads": roads, "urban": urban, "state_lines": states, "us_canada_border": border},
    }
    os.makedirs(ASSET_DIR, exist_ok=True)
    out = os.path.join(ASSET_DIR, name("ne-derived-subset", "json"))
    data = (json.dumps(subset, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
    with open(out, "wb") as fh:
        fh.write(data)
    print("SUBSET %s (%d bytes, %d countries, %d lakes, %d roads, %d urban, %d state lines, %d border lines)"
          % (rel(out), len(data), len(countries), len(lakes), len(roads), len(urban), len(states), len(border)))


# ----------------------------------------------------------------------------------------------
# Projection math (mirrors world_geo_projection.gd).

class Proj:
    def __init__(self, meridian, parallel):
        self.cm = meridian
        self.sp = parallel
        self.f = math.cos(math.radians(parallel))

    def project(self, lon, lat):
        return ((lon - self.cm) * self.f, -lat)

    def project_bbox(self, wsen):
        ax, ay = self.project(wsen[0], wsen[3])
        bx, by = self.project(wsen[2], wsen[1])
        return (ax, ay, bx - ax, by - ay)


def region_camera(region, places):
    """min/default/max scale of a region view exactly as scifi_world_map.gd computes them."""
    proj = Proj(region["central_meridian"], region["standard_parallel"])
    bounds = proj.project_bbox(region["pan_bbox_wsen"])
    min_scale = max(FRAME_W / bounds[2], FRAME_H / bounds[3])
    max_scale = min_scale * REGION_ZOOM_RANGE
    frame = region.get("frame_bbox_wsen")
    if not frame:
        mine = [p for p in places if p["region"] == region["id"]]
        frame = [min(p["lon"] for p in mine), min(p["lat"] for p in mine),
                 max(p["lon"] for p in mine), max(p["lat"] for p in mine)]
    px = region.get("frame_px")
    target = tuple(float(v) for v in px) if px and len(px) == 4 else REGION_FRAME
    box = proj.project_bbox(frame)
    fit = min(target[2] / max(box[2], 0.0001), target[3] / max(box[3], 0.0001))
    default = min(max(fit, min_scale), max_scale)
    return proj, bounds, min_scale, default, max_scale


# ----------------------------------------------------------------------------------------------
# Raster helpers.

def hash01(xs, ys, salt):
    h = (xs.astype(np.uint32) * np.uint32(73856093)) ^ (ys.astype(np.uint32) * np.uint32(19349663)) ^ np.uint32(salt)
    h ^= h >> np.uint32(13)
    h *= np.uint32(0x5bd1e995)
    h ^= h >> np.uint32(15)
    return (h & np.uint32(0xFFFF)).astype(np.float32) / 65535.0


def value_noise(w, h, cell, salt):
    gx = np.arange(w, dtype=np.float32) / cell
    gy = np.arange(h, dtype=np.float32) / cell
    x0 = np.floor(gx).astype(np.int64)
    y0 = np.floor(gy).astype(np.int64)
    fx = (gx - x0)[None, :]
    fy = (gy - y0)[:, None]
    fx = fx * fx * (3 - 2 * fx)
    fy = fy * fy * (3 - 2 * fy)
    X0, Y0 = np.meshgrid(x0, y0)
    v00 = hash01(X0, Y0, salt)
    v10 = hash01(X0 + 1, Y0, salt)
    v01 = hash01(X0, Y0 + 1, salt)
    v11 = hash01(X0 + 1, Y0 + 1, salt)
    top = v00 * (1 - fx) + v10 * fx
    bottom = v01 * (1 - fx) + v11 * fx
    return top * (1 - fy) + bottom * fy


BAYER4 = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], dtype=np.float32) / 16.0


def bayer(w, h):
    return np.tile(BAYER4, (h // 4 + 1, w // 4 + 1))[:h, :w]


def shift(mask, dx, dy, fill=False):
    out = np.full_like(mask, fill)
    h, w = mask.shape
    xs = slice(max(dx, 0), w + min(dx, 0))
    xd = slice(max(-dx, 0), w + min(-dx, 0))
    ys = slice(max(dy, 0), h + min(dy, 0))
    yd = slice(max(-dy, 0), h + min(-dy, 0))
    out[yd, xd] = mask[ys, xs]
    return out


def dilate(mask):
    out = mask.copy()
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
        out |= shift(mask, dx, dy)
    return out


def distance_bands(mask, steps):
    """Chebyshev distance (1..steps) of pixels outside mask to the mask; 0 inside / far."""
    dist = np.zeros(mask.shape, dtype=np.uint8)
    grown = mask.copy()
    for step in range(1, steps + 1):
        nxt = dilate(grown)
        dist[nxt & ~grown] = step
        grown = nxt
    return dist


def new_layer(w, h):
    return np.zeros((h, w, 4), dtype=np.uint8)


def paint(layer, mask, color):
    layer[mask] = color


def to_px(points_flat, fn):
    pts = []
    for i in range(0, len(points_flat), 2):
        x, y = fn(points_flat[i], points_flat[i + 1])
        pts.append((x - 0.5, y - 0.5))
    return pts


def fill_rings(draw, rings, fn, value):
    for ring in rings:
        pts = to_px(ring, fn)
        if len(pts) >= 3:
            draw.polygon(pts, fill=value)


def line_mask(w, h, lines, fn):
    img = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(img)
    for flat in lines:
        pts = to_px(flat, fn)
        if len(pts) >= 2:
            draw.line(pts, fill=255, width=1)
    return np.array(img) > 0


def dotted(mask, period, phase=0):
    h, w = mask.shape
    yy, xx = np.mgrid[0:h, 0:w]
    return mask & (((xx + yy + phase) % period) == 0)


def components(mask, eight):
    """Connected components of a boolean mask (BFS; no scipy on this runtime).
    Returns (labels int32 array, sizes list indexed by label, touches_border list)."""
    h, w = mask.shape
    flat = mask.ravel().tolist()
    lab = [0] * (h * w)
    sizes = [0]
    border = [False]
    if eight:
        steps = ((-1, -1), (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1))
    else:
        steps = ((0, -1), (-1, 0), (1, 0), (0, 1))
    current = 0
    for start in range(h * w):
        if not flat[start] or lab[start]:
            continue
        current += 1
        lab[start] = current
        stack = [start]
        count = 0
        touches = False
        while stack:
            i = stack.pop()
            count += 1
            y, x = divmod(i, w)
            if x == 0 or y == 0 or x == w - 1 or y == h - 1:
                touches = True
            for dx, dy in steps:
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h:
                    j = ny * w + nx
                    if flat[j] and not lab[j]:
                        lab[j] = current
                        stack.append(j)
        sizes.append(count)
        border.append(touches)
    return np.array(lab, dtype=np.int32).reshape(h, w), sizes, border


def neighbour_count(mask):
    total = np.zeros(mask.shape, dtype=np.uint8)
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
        total += shift(mask, dx, dy).astype(np.uint8)
    return total


def isolated_mask(rgb):
    """Pixels whose colour differs from all four 4-neighbours (speckle; border pixels excluded)."""
    c = rgb[1:-1, 1:-1]
    diff = np.ones(c.shape[:2], dtype=bool)
    for sl in (rgb[:-2, 1:-1], rgb[2:, 1:-1], rgb[1:-1, :-2], rgb[1:-1, 2:]):
        diff &= np.any(c != sl, axis=2)
    out = np.zeros(rgb.shape[:2], dtype=bool)
    out[1:-1, 1:-1] = diff
    return out


def isolated_pixels(rgb):
    return int(isolated_mask(rgb).sum())


# ----------------------------------------------------------------------------------------------
# Globe.

def render_globe(subset, scale, level_index):
    w = int(round(360.0 * scale))
    h = int(round(180.0 * scale))

    def fn(lon, lat):
        return ((lon + 180.0) * scale, (90.0 - lat) * scale)

    ids_img = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(ids_img)
    countries = subset["global"]["countries"]

    def area(c):
        total = 0.0
        for poly in c["polygons"]:
            ring = poly[0]
            xs, ys = ring[0::2], ring[1::2]
            total += abs(sum(xs[i] * ys[i - 1] - xs[i - 1] * ys[i] for i in range(len(xs)))) * 0.5
        return total

    for c in sorted(countries, key=lambda c: (-area(c), c["a3"] or "")):
        sid = SPHERE_IDS[c["sphere"]]
        for poly in c["polygons"]:
            fill_rings(draw, poly[:1], fn, sid)
            fill_rings(draw, poly[1:], fn, 0)
    fill_rings(draw, subset["global"]["lakes"], fn, 0)
    lake_img = Image.new("L", (w, h), 0)
    fill_rings(ImageDraw.Draw(lake_img), subset["global"]["lakes"], fn, 1)
    ids = np.array(ids_img)
    raw_land = ids > 0
    generalise = level_index in SPECKLE_LEVELS
    facts = {"generalised": generalise}
    isle = np.zeros((h, w), dtype=bool)
    if generalise:
        # Enclosed water specks (lakes or holes not touching the frame) smaller than LAKE_MIN_PX become land
        # of the surrounding sphere: at 1.5-3 px/deg they are one- or two-pixel holes, not readable lakes.
        wlab, wsizes, wborder = components(ids == 0, eight=False)
        small = np.array([(not wborder[i]) and 0 < wsizes[i] < LAKE_MIN_PX[level_index] for i in range(len(wsizes))])
        fill = small[wlab] & (ids == 0)
        facts["lake_specks_filled_px"] = int(fill.sum())
        facts["lake_specks_filled_components"] = int(small.sum())
        for _ in range(12):
            if not fill.any():
                break
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
                nb = shift(ids, dx, dy, 0)
                take = fill & (ids == 0) & (nb > 0)
                ids[take] = nb[take]
            fill &= ids == 0
        land_now = ids > 0
        llab, lsizes, _ = components(land_now, eight=True)
        tiny = np.array([0 < s < ISLE_MIN_PX[level_index] for s in lsizes])
        isle = tiny[llab] & land_now
        facts["tiny_islands"] = int(tiny.sum())
        facts["tiny_island_px"] = int(isle.sum())
    land = ids > 0
    lake = (np.array(lake_img) > 0) & ~land if generalise else np.zeros((h, w), dtype=bool)
    facts["land_px_raw"] = int(raw_land.sum())
    facts["land_px_final"] = int(land.sum())
    yy, xx = np.mgrid[0:h, 0:w]

    layers = []
    # 1 ocean base
    ocean = new_layer(w, h)
    ocean[:] = rgba("ocean_deep")
    layers.append(("ocean-deep", ocean))
    # Shelf bands come from the land mask opened by one pixel (erode, then dilate), so islands of one or
    # two pixels get no shore halo; they keep their own rim.
    eroded = land & ~distance_bands(~land, 1).astype(bool)
    opened = dilate(eroded) & land
    water_dist = distance_bands(opened, 3)
    water_dist[land] = 0
    water_dist[lake] = 0
    open_water = (~land) & ~lake & (water_dist == 0)
    # 2 ocean texture: sparse horizontal wave ticks, open water only
    ticks = new_layer(w, h)
    tick_mask = open_water & (yy % 5 == 2) & (((xx + (yy // 5) * 7) % 13) < 2) & (hash01(xx // 13, yy // 5, 11) > 0.55)
    paint(ticks, tick_mask, rgba("ocean_tick"))
    layers.append(("ocean-texture", ticks))
    # 3 graticule every 30 deg, dotted, open water only; equator brighter
    grat = new_layer(w, h)
    gl = np.zeros((h, w), dtype=bool)
    for lon in range(-180, 181, 30):
        x = int(math.floor((lon + 180.0) * scale))
        if 0 <= x < w:
            gl[:, x] = True
    for lat in range(-60, 61, 30):
        y = int(math.floor((90.0 - lat) * scale))
        if 0 <= y < h and lat != 0:
            gl[y, :] = True
    paint(grat, open_water & gl & ((xx + yy) % 3 == 0), rgba("graticule"))
    eq = np.zeros((h, w), dtype=bool)
    eq[int(math.floor(90.0 * scale)), :] = True
    paint(grat, open_water & eq & (xx % 2 == 0), rgba("equator"))
    layers.append(("graticule-30deg", grat))
    # 4 shelf: two shore bands
    shelf = new_layer(w, h)
    paint(shelf, (water_dist >= 2) & (water_dist <= 3), rgba("shelf_far"))
    paint(shelf, water_dist == 1, rgba("shelf_near"))
    layers.append(("shore-shelf", shelf))
    # 4b lakes (generalised levels only): one flat tone, no shelf bands, ticks or graticule inside them
    lakes_layer = new_layer(w, h)
    paint(lakes_layer, lake, rgba("lake"))
    layers.append(("lakes-flat", lakes_layer))
    # 5 science glow: the near-shore band of the open sphere (sea side only)
    glow = new_layer(w, h)
    science = ids == SPHERE_IDS["science"]
    sci_dist = distance_bands(science, 1)
    paint(glow, (~land) & ~lake & (sci_dist == 1), rgba("science_glow"))
    layers.append(("science-sphere-shore-glow", glow))
    # 6 land base per sphere
    base = new_layer(w, h)
    for key, sid in SPHERE_IDS.items():
        if sid > 0:
            paint(base, ids == sid, rgba(key, "base"))
    layers.append(("land-sphere-base", base))
    # 7 land texture: restrained ordered dither driven by low-frequency noise; Antarctica gets hatching
    tex = new_layer(w, h)
    noise = value_noise(w, h, max(6.0, 10.0 * scale / 1.49), 7)
    interior = land & ~distance_bands(~land, 1).astype(bool) & ~isle
    lit = interior & (bayer(w, h) < (noise - 0.35) * 0.35)
    for key, sid in SPHERE_IDS.items():
        if sid > 0 and key != "dlc_antarctica":
            paint(tex, lit & (ids == sid), rgba(key, "tex"))
    ice = interior & (ids == SPHERE_IDS["dlc_antarctica"]) & (((xx + yy) % 4) == 0)
    paint(tex, ice, rgba("dlc_antarctica", "tex"))
    layers.append(("land-texture-and-dlc-hatch", tex))
    # 8 relief rim: light on north/west-facing coast pixels, shadow on south/east-facing ones. On generalised
    # levels the rim follows sea coasts only (not lake shores), skips one-pixel spurs, and tiny islands are one
    # flat light tone instead of a light/shadow pair.
    rim = new_layer(w, h)
    water = ~land & ~lake if generalise else ~land
    rim_land = land & ~isle
    if generalise:
        rim_land &= neighbour_count(land) >= 3
    light_edge = rim_land & (shift(water, -1, 0) | shift(water, 0, -1))
    shadow_edge = rim_land & (shift(water, 1, 0) | shift(water, 0, 1)) & ~light_edge
    for key, sid in SPHERE_IDS.items():
        if sid > 0:
            paint(rim, light_edge & (ids == sid), rgba(key, "light"))
            paint(rim, shadow_edge & (ids == sid), rgba(key, "shadow"))
            paint(rim, isle & (ids == sid), rgba(key, "light"))
    layers.append(("coast-relief-rim", rim))
    if generalise:
        # One de-speckle pass: a rim pixel that would differ from all four neighbours reverts to its base tone.
        loose = isolated_mask(composite(w, h, layers)[:, :, :3]) & (rim[:, :, 3] > 0) & ~isle
        rim[loose] = 0
        facts["rim_pixels_despeckled"] = int(loose.sum())
    # 9 sphere borders on land (4-neighbour change of sphere), drawn on the lower/right pixel
    borders = new_layer(w, h)
    diff = np.zeros((h, w), dtype=bool)
    for dx, dy in ((-1, 0), (0, -1)):
        other = shift(ids, dx, dy, 0)
        diff |= land & (other > 0) & (other != ids)
    paint(borders, diff, rgba("sphere_border"))
    layers.append(("sphere-borders", borders))
    return w, h, layers, ids, facts


# ----------------------------------------------------------------------------------------------
# Region.

def render_region(subset, geodata, region, proj, bounds, scale, level_index, default_scale):
    w = int(math.ceil(bounds[2] * scale - 1e-6))
    h = int(math.ceil(bounds[3] * scale - 1e-6))
    bx, by = bounds[0], bounds[1]

    def fn(lon, lat):
        ux, uy = proj.project(lon, lat)
        return ((ux - bx) * scale, (uy - by) * scale)

    land_img = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(land_img)
    rings = geodata["layers"]["regions"][region["geodata_key"]]["land"]["rings"]
    fill_rings(draw, [r["points"] for r in rings if not r["hole"]], fn, 1)
    fill_rings(draw, [r["points"] for r in rings if r["hole"]], fn, 0)
    land = np.array(land_img) > 0
    water = ~land
    yy, xx = np.mgrid[0:h, 0:w]
    sub = subset["us_east"]
    layers = []

    base_water = new_layer(w, h)
    base_water[:] = rgba("r_water")
    layers.append(("water", base_water))

    # graticule: whole degrees, dotted; stronger on water than land
    gl = np.zeros((h, w), dtype=bool)
    clip = US_EAST_CLIP
    for lon in range(int(math.ceil(clip[0])), int(math.floor(clip[2])) + 1):
        x = int(math.floor(fn(lon, 0)[0]))
        if 0 <= x < w:
            gl[:, x] = True
    for lat in range(int(math.ceil(clip[1])), int(math.floor(clip[3])) + 1):
        y = int(math.floor(fn(region["central_meridian"], lat)[1]))
        if 0 <= y < h:
            gl[y, :] = True
    water_dist = distance_bands(land, 3)
    grat_w = new_layer(w, h)
    paint(grat_w, water & (water_dist == 0) & gl & ((xx + yy) % 3 == 0), rgba("r_grat_water"))
    layers.append(("graticule-water", grat_w))

    shelf = new_layer(w, h)
    paint(shelf, (water_dist >= 2) & (water_dist <= 3), rgba("r_shelf_far"))
    paint(shelf, water_dist == 1, rgba("r_shelf_near"))
    layers.append(("shore-shelf", shelf))

    # The NE boundary line is drawn whole; its pixels over lakes get the water style, over land the land style.
    border_all = line_mask(w, h, [b["points"] for b in sub["us_canada_border"]], fn)
    bw_mask = border_all
    bwl = new_layer(w, h)
    paint(bwl, water & dotted(bw_mask, 3), rgba("r_border_water"))
    layers.append(("us-canada-border-water", bwl))

    land_base = new_layer(w, h)
    paint(land_base, land, rgba("r_land"))
    layers.append(("land-science-base", land_base))

    # Zoom bucket: "default" covers the min and default framed levels, "x2" from 2x the default, "x4" from 4x.
    bucket = "x4" if scale >= default_scale * 3.9 else ("x2" if scale >= default_scale * 1.9 else "default")

    tex = new_layer(w, h)
    noise = value_noise(w, h, 9.0, 23 + level_index)
    interior = land & ~distance_bands(water, 1).astype(bool)
    paint(tex, interior & (bayer(w, h) < (noise - 0.4) * 0.3), rgba("r_land_tex"))
    paint(tex, interior & gl & ((xx + yy) % 4 == 0), rgba("r_grat_land"))
    layers.append(("land-texture-and-graticule", tex))

    # Urban areas: only those of at least URBAN_MIN_SQKM[bucket] (NE area_sqkm); one flat tone below 4x, a
    # sparse ordered texture from 4x. No edge line (v01's edge + 2x2 checker read as dotted noise at 640x360).
    urban_img = Image.new("L", (w, h), 0)
    udraw = ImageDraw.Draw(urban_img)
    urban_kept = 0
    for poly in sub["urban"]:
        if poly["area_sqkm"] < URBAN_MIN_SQKM[bucket]:
            continue
        urban_kept += 1
        fill_rings(udraw, poly["rings"][:1], fn, 1)
        fill_rings(udraw, poly["rings"][1:], fn, 0)
    urban = (np.array(urban_img) > 0) & land
    urban_layer = new_layer(w, h)
    paint(urban_layer, urban, rgba("r_urban"))
    if bucket == "x4":
        paint(urban_layer, urban & (bayer(w, h) < 0.125), rgba("r_urban_tex"))
    layers.append(("urban-areas", urban_layer))

    st = new_layer(w, h)
    paint(st, land & dotted(line_mask(w, h, sub["state_lines"], fn), 2), rgba("r_state"))
    layers.append(("state-province-lines", st))

    bl = new_layer(w, h)
    border_land = border_all
    paint(bl, land & border_land & (((xx + yy) % 4) != 3), rgba("r_border_land"))
    layers.append(("us-canada-border-land", bl))

    roads = {tier: [r for r in sub["roads"] if r["tier"] == tier] for tier in ("secondary", "major", "expressway")}
    # Default bucket: backbone expressways only (NE scalerank <= DEFAULT_EXPRESSWAY_MAX_RANK), in a quiet sage
    # tone close to the land so the route connectors and markers stay on top. From 2x: every expressway in muted
    # amber plus the other major highways; from 4x: secondary highways too.
    show_major = bucket != "default"
    show_secondary = bucket == "x4"
    sec = new_layer(w, h)
    if show_secondary:
        paint(sec, land & line_mask(w, h, [r["points"] for r in roads["secondary"]], fn), rgba("r_road_secondary"))
    layers.append(("roads-secondary", sec))
    maj = new_layer(w, h)
    if show_major:
        paint(maj, land & line_mask(w, h, [r["points"] for r in roads["major"]], fn), rgba("r_road_major"))
    layers.append(("roads-major", maj))
    exp = new_layer(w, h)
    if bucket == "default":
        backbone = [r["points"] for r in roads["expressway"] if r["rank"] <= DEFAULT_EXPRESSWAY_MAX_RANK]
        paint(exp, land & line_mask(w, h, backbone, fn), rgba("r_road_quiet"))
        express_drawn = len(backbone)
    else:
        paint(exp, land & line_mask(w, h, [r["points"] for r in roads["expressway"]], fn), rgba("r_road_express"))
        express_drawn = len(roads["expressway"])
    layers.append(("roads-expressway", exp))

    rim = new_layer(w, h)
    light_edge = land & (shift(water, -1, 0) | shift(water, 0, -1))
    shadow_edge = land & (shift(water, 1, 0) | shift(water, 0, 1)) & ~light_edge
    paint(rim, light_edge, rgba("r_land_light"))
    paint(rim, shadow_edge, rgba("r_land_shadow"))
    layers.append(("coast-relief-rim", rim))
    return w, h, layers, land, {"major": show_major, "secondary": show_secondary, "bucket": bucket,
                                "expressway_lines": express_drawn, "urban_areas": urban_kept}


# ----------------------------------------------------------------------------------------------
# Composition, PNG and ORA encoding.

def composite(w, h, layers):
    out = np.zeros((h, w, 4), dtype=np.uint8)
    for _, layer in layers:
        mask = layer[:, :, 3] > 0
        out[mask] = layer[mask]
    return out


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, format="PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def ora_bytes(w, h, layers, merged, view_id):
    buf = io.BytesIO()
    stamp = (1980, 1, 1, 0, 0, 0)
    with zipfile.ZipFile(buf, "w") as z:
        info = zipfile.ZipInfo("mimetype", stamp)
        info.compress_type = zipfile.ZIP_STORED
        z.writestr(info, b"image/openraster")
        stack = ['<?xml version="1.0" encoding="UTF-8"?>',
                 '<image version="0.0.3" w="%d" h="%d">' % (w, h),
                 '<stack name="%s">' % view_id]
        for index, (lname, _) in reversed(list(enumerate(layers))):
            stack.append('<layer name="%02d %s" src="data/%02d-%s.png" x="0" y="0" opacity="1.0" visibility="visible" composite-op="svg:src-over"/>'
                         % (index + 1, lname, index + 1, lname))
        stack.append("</stack>")
        stack.append("</image>")
        entries = [("stack.xml", ("\n".join(stack) + "\n").encode("utf-8"))]
        for index, (lname, layer) in enumerate(layers):
            entries.append(("data/%02d-%s.png" % (index + 1, lname), png_bytes(layer)))
        entries.append(("mergedimage.png", png_bytes(merged)))
        thumb = Image.fromarray(merged, "RGBA")
        thumb.thumbnail((256, 256), Image.NEAREST)
        tb = io.BytesIO()
        thumb.save(tb, format="PNG", optimize=False, compress_level=9)
        entries.append(("Thumbnails/thumbnail.png", tb.getvalue()))
        for fname, data in entries:
            zi = zipfile.ZipInfo(fname, stamp)
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, data)
    return buf.getvalue()


# ----------------------------------------------------------------------------------------------
# Display-only overlay facts for the Godot skin (sphere label anchors are display choices; the
# names come from the registry board names, never new text).

SPHERE_LABEL_ANCHORS = {
    "science": [-104.0, 58.0],
    "magic": [-61.0, -12.0],
    "wuxia": [92.0, 44.0],
    "nature": [134.0, -25.0],
    "culture": [17.0, 12.0],
}


def build_all():
    subset_path = os.path.join(ASSET_DIR, name("ne-derived-subset", "json"))
    with open(subset_path, "r", encoding="utf-8") as fh:
        subset = json.load(fh)
    geodata = load_json(GEODATA_REL)
    registry = load_json(REGISTRY_REL)
    travel = load_json(TRAVEL_REL)
    places = []
    display = {p["id"]: p for p in registry["places"]}
    for loc in travel["locations"]:
        if loc["id"] in display:
            places.append({"id": loc["id"], "lon": loc["coordinates"]["lon"], "lat": loc["coordinates"]["lat"],
                           "region": display[loc["id"]]["geo_region_id"]})

    files = {}  # rel path -> bytes
    meta = {
        "schema": "worlds-between.map-art-candidate.runtime-meta.v1",
        "status": "UNAPPROVED NONRUNTIME map-art candidate; loaded only by the test-only capture tool",
        "tag": TAG,
        "palette": PALETTE,
        "chrome_reference": CHROME,
        "sphere_ids": SPHERE_IDS,
        "sphere_label_anchors_lonlat": SPHERE_LABEL_ANCHORS,
        "views": {},
    }
    stats = {}

    # Globe levels: the live globe's min scale x 1, 2, 4 and its max (7).
    g_min = min(FRAME_W / 360.0, FRAME_H / 180.0)
    g_levels = [g_min * k for k in (1.0, 2.0, 4.0, GLOBAL_ZOOM_RANGE)]
    gview = {"projection": {"central_meridian": 0.0, "standard_parallel": 0.0}, "min_scale": g_min,
             "default_scale": g_min, "max_scale": g_min * GLOBAL_ZOOM_RANGE, "levels": []}
    for index, scale in enumerate(g_levels):
        w, h, layers, ids, gfacts = render_globe(subset, scale, index)
        merged = composite(w, h, layers)
        gfacts["isolated_pixels"] = isolated_pixels(merged[:, :, :3])
        stats["globe_lv%d_generalisation" % index] = gfacts
        fname = name("globe-lv%d-flat" % index, "png")
        files[ASSET_DIR_REL + "/" + fname] = png_bytes(merged)
        gview["levels"].append({"index": index, "scale": scale, "file": fname, "size": [w, h],
                                "unit_rect": [-180.0, -90.0, w / scale, h / scale]})
        if index == 0:
            files[ASSET_DIR_REL + "/" + name("globe-lv0-layered-source", "ora")] = ora_bytes(w, h, layers, merged, "globe-lv0")
            counts = {k: int((ids == v).sum()) for k, v in SPHERE_IDS.items()}
            stats["globe_lv0_sphere_pixels"] = counts
            stats["globe_lv0_layers"] = [n for n, _ in layers]
        stats["globe_lv%d_colors" % index] = int(len(np.unique(merged.reshape(-1, 4), axis=0)))
    meta["views"]["globe"] = gview

    for region in registry["geo_regions"]:
        proj, bounds, mn, default, mx = region_camera(region, places)
        levels = [mn, default, default * 2.0, default * 4.0, mx]
        levels = sorted(set(round(s, 9) for s in levels if mn - 1e-9 <= s <= mx + 1e-9))
        view = {"projection": {"central_meridian": region["central_meridian"], "standard_parallel": region["standard_parallel"]},
                "bounds_unit": list(bounds), "min_scale": mn, "default_scale": default, "max_scale": mx, "levels": []}
        for index, scale in enumerate(levels):
            w, h, layers, land, secondary = render_region(subset, geodata, region, proj, bounds, scale, index, default)
            merged = composite(w, h, layers)
            fname = name("%s-lv%d-flat" % (region["id"].replace("_", "-"), index), "png")
            files[ASSET_DIR_REL + "/" + fname] = png_bytes(merged)
            view["levels"].append({"index": index, "scale": scale, "file": fname, "size": [w, h],
                                   "unit_rect": [bounds[0], bounds[1], w / scale, h / scale],
                                   "zoom_bucket": secondary["bucket"],
                                   "road_tiers_shown": (["expressway rank<=%d" % DEFAULT_EXPRESSWAY_MAX_RANK] if secondary["bucket"] == "default" else ["expressway"])
                                   + [k for k in ("major", "secondary") if secondary[k]],
                                   "urban_min_sqkm": URBAN_MIN_SQKM[secondary["bucket"]]})
            stats["%s_lv%d_declutter" % (region["id"], index)] = {
                "bucket": secondary["bucket"], "expressway_lines": secondary["expressway_lines"],
                "urban_areas": secondary["urban_areas"], "isolated_pixels": isolated_pixels(merged[:, :, :3])}
            if abs(scale - default) < 1e-6:
                files[ASSET_DIR_REL + "/" + name("%s-default-layered-source" % region["id"].replace("_", "-"), "ora")] = \
                    ora_bytes(w, h, layers, merged, region["id"] + "-default")
                stats["%s_default_layers" % region["id"]] = [n for n, _ in layers]
                # Geo-registration facts: each place's default-level pixel and whether it is on land.
                reg = {}
                for p in places:
                    ux, uy = proj.project(p["lon"], p["lat"])
                    px, py = (ux - bounds[0]) * scale, (uy - bounds[1]) * scale
                    ix, iy = int(math.floor(px)), int(math.floor(py))
                    inside = 0 <= ix < w and 0 <= iy < h
                    near_land = False
                    if inside:
                        win = land[max(0, iy - 2):iy + 3, max(0, ix - 2):ix + 3]
                        near_land = bool(win.any())
                    reg[p["id"]] = {"px": [round(px, 3), round(py, 3)], "inside": inside,
                                    "on_land": bool(land[iy, ix]) if inside else None, "land_within_2px": near_land}
                stats["%s_place_registration" % region["id"]] = reg
            stats["%s_lv%d_colors" % (region["id"], index)] = int(len(np.unique(merged.reshape(-1, 4), axis=0)))
        meta["views"][region["id"]] = view

    meta_name = name("runtime-meta", "json")
    files[ASSET_DIR_REL + "/" + meta_name] = dumps(meta)
    return files, stats, meta


def manifest_for(files, stats):
    entries = []
    for path in sorted(files):
        data = files[path]
        is_text = path.endswith(".json") or path.endswith(".md")
        entries.append({"path": path, "bytes": len(data),
                        "hash_algorithm": "sha256-text-lf-v1" if is_text else "sha256-bytes",
                        "sha256": sha256_text_lf(data) if is_text else sha256_bytes(data)})
    subset_rel = ASSET_DIR_REL + "/" + name("ne-derived-subset", "json")
    with open(os.path.join(ROOT, subset_rel), "rb") as fh:
        subset_bytes = fh.read()
    inputs = []
    for path in (subset_rel, GEODATA_REL, REGISTRY_REL, TRAVEL_REL, SELF_REL):
        with open(os.path.join(ROOT, path), "rb") as fh:
            inputs.append({"path": path, "hash_algorithm": "sha256-text-lf-v1", "sha256": sha256_text_lf(fh.read())})
    return {
        "schema": "worlds-between.map-art-candidate.manifest.v1",
        "tag": TAG,
        "status": "UNAPPROVED / NONRUNTIME map-art candidate v02 (separate from v01, which also stays UNAPPROVED / NONRUNTIME). Not creator-accepted. M2 map-art gate stays open; scene quality 0/11 and the MVP meter (35.8%) are unchanged.",
        "previous_candidate_tag": "candidate-unapproved-v01_20261016-164615-f9e453b0 (not read by this builder)",
        "scope": "Global Earth view + US Northeast and US Great Lakes regional views of the existing world map (game/scripts/scifi_world_map.gd geometry).",
        "builder": SELF_REL,
        "inputs": inputs,
        "ne_subset_sources": json.loads(subset_bytes.decode("utf-8"))["sources"],
        "outputs": entries,
        "stats": stats,
    }


def build():
    files, stats, _ = build_all()
    for path, data in files.items():
        full = os.path.join(ROOT, path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as fh:
            fh.write(data)
    manifest = manifest_for(files, stats)
    mpath = os.path.join(ASSET_DIR, name("manifest", "json"))
    with open(mpath, "wb") as fh:
        fh.write(dumps(manifest))
    print("BUILT %d files + manifest %s" % (len(files), rel(mpath)))
    for k, v in stats.items():
        if k.endswith("colors"):
            print("  %s: %d colours" % (k, v))


def check():
    files, stats, _ = build_all()
    problems = []
    for path, data in files.items():
        full = os.path.join(ROOT, path)
        if not os.path.exists(full):
            problems.append("missing " + path)
            continue
        with open(full, "rb") as fh:
            disk = fh.read()
        same = sha256_text_lf(disk) == sha256_text_lf(data) if path.endswith(".json") else disk == data
        if not same:
            problems.append("differs " + path)
    with open(os.path.join(ASSET_DIR, name("manifest", "json")), "rb") as fh:
        manifest = json.loads(fh.read().decode("utf-8"))
    expected = manifest_for(files, stats)
    if [e["sha256"] for e in expected["outputs"]] != [e["sha256"] for e in manifest["outputs"]]:
        problems.append("manifest output hashes differ from a fresh rebuild")
    if [e["sha256"] for e in expected["inputs"]] != [e["sha256"] for e in manifest["inputs"]]:
        problems.append("manifest input hashes differ (builder, subset or game data changed)")
    if problems:
        for p in problems:
            print("FAIL " + p)
        print("MAP_ART_BUILD_CHECK_FAIL %d problems" % len(problems))
        sys.exit(1)
    print("MAP_ART_BUILD_CHECK_OK %d files rebuilt byte-identical; manifest inputs and outputs match" % len(files))


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)
    if args[0] == "extract":
        if "--source-dir" not in args:
            raise SystemExit("extract needs --source-dir DIR")
        extract(args[args.index("--source-dir") + 1])
    elif args[0] == "build":
        build()
    elif args[0] == "check":
        check()
    else:
        raise SystemExit(__doc__)
