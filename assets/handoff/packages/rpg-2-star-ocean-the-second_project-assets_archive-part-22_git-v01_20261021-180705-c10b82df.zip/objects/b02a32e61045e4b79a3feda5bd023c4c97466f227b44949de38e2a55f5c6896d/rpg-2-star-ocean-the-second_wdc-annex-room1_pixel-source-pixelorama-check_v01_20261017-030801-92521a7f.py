"""Exact pixel, source and Pixelorama checks for the Washington survey annex room 1 native scene pilot.

Usage: python -I <this file> <before capture dir> <after capture dir> [--pixelorama <exe>] [--report <json>]
Before captures come from HEAD survey_annex.gd, after captures from the pilot integration, both made by
...wdc-annex-room1_godot-capture-and-check...gd with the same hero poses.
"""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import argparse
import glob
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
AUTHOR = ROOT / "tools/rpg-2-star-ocean-the-second_wdc-annex-room1_capitol-interior-author_unapproved-v01_20261017-030801-65b9618f.py"
OLD_PLATE = ROOT / "game/assets/environments/rpg-2-star-ocean-the-second_scifi-ruins-survey-annex-room-01_environment-background_m8-concept_20261014-142840-0ce7a91b.png"
CLUES = [(163, 165), (320, 165), (477, 165)]
EXIT, NEXT = (57, 257), (580, 257)
OFFSET = (-32, 2)
LABEL_RECTS = [(x - 48, y - 45, x + 48, y - 9) for x, y in CLUES]
DOOR_LABEL_RECTS = [(EXIT[0] - 41, EXIT[1] - 55, EXIT[0] + 72, EXIT[1] - 31), (NEXT[0] - 36, NEXT[1] - 55, NEXT[0] + 40, NEXT[1] - 31)]
LANE = (16, 236, 624, 290)
HERO_BOXES = {"start": (60, 212, 115, 270), "lane-index": (293, 189, 348, 247), "after-load": (375, 213, 430, 271)}


def load_author():
    spec = spec_from_file_location("wdc_room1_author", AUTHOR)
    mod = module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def rgba(src):
    if isinstance(src, bytes):
        src = io.BytesIO(src)
    return np.array(Image.open(src).convert("RGBA"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def one(folder, pattern):
    hits = glob.glob(os.path.join(folder, pattern))
    if len(hits) != 1:
        raise SystemExit(f"expected one {pattern} in {folder}, got {hits}")
    return hits[0]


def check_asset(item, names, layers):
    flat = np.array(author_mod.merged(layers))
    files = {ext: (ROOT / item["files"][ext]["file"]).read_bytes() for ext in ("png", "ora", "pxo")}
    runtime = (ROOT / item["runtime_png"]["file"]).read_bytes()
    r = {"hashes_match_manifest": all(sha(files[e]) == item["files"][e]["sha256"] for e in files) and sha(runtime) == item["runtime_png"]["sha256"],
         "runtime_png_equals_source_png": runtime == files["png"],
         "png_equals_rebuilt_layers": rgba(files["png"]).tobytes() == flat.tobytes(),
         "size": list(Image.open(io.BytesIO(files["png"])).size)}
    with zipfile.ZipFile(io.BytesIO(files["ora"])) as z:
        stack = ET.fromstring(z.read("stack.xml"))
        r["ora_mimetype_first_stored"] = z.infolist()[0].filename == "mimetype" and z.infolist()[0].compress_type == zipfile.ZIP_STORED
        by_name = {el.get("name"): el.get("src") for el in stack.iter("layer")}
        r["ora_layers_top_to_bottom"] = [el.get("name") for el in stack.iter("layer")]
        r["ora_layers_exact"] = all(rgba(z.read(by_name[n])).tobytes() == np.array(img).tobytes() for n, img in zip(names, layers))
        r["ora_merged_exact"] = rgba(z.read("mergedimage.png")).tobytes() == flat.tobytes()
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        data = json.loads(z.read("data.json"))
        r["pxo_version"] = data["pxo_version"]
        r["pxo_size"] = [data["size_x"], data["size_y"]]
        r["pxo_layers_bottom_to_top"] = [l["name"] for l in data["layers"]]
        r["pxo_layers_exact"] = all(z.read(f"image_data/frames/1/layer_{i}") == img.tobytes() for i, img in enumerate(layers, start=1))
    r["exact"] = all([r["hashes_match_manifest"], r["runtime_png_equals_source_png"], r["png_equals_rebuilt_layers"], r["ora_mimetype_first_stored"],
                      r["ora_layers_exact"], r["ora_merged_exact"], r["pxo_layers_exact"], r["pxo_layers_bottom_to_top"] == names,
                      r["ora_layers_top_to_bottom"] == list(reversed(names))])
    return r, flat


def source_checks(manifest):
    A = author_mod
    palette = {tuple(int(v[i:i + 2], 16) for i in (1, 3, 5)) for v in A.PAL.values()}
    rep = {}
    scene_layers = A.build_scene()
    r, flat = check_asset(manifest["scene_asset"], A.SCENE_LAYERS, scene_layers)
    r["layer_alpha_binary"] = all(set(np.unique(np.array(l)[..., 3]).tolist()) <= {0, 255} for l in scene_layers)
    r["merged_fully_opaque"] = bool((flat[..., 3] == 255).all())
    colours = {tuple(c) for c in flat[..., :3].reshape(-1, 3).tolist()}
    r["unique_colours"] = len(colours)
    r["colours_all_in_palette"] = colours <= palette
    r["pixels_per_layer"] = {n: int((np.array(l)[..., 3] > 0).sum()) for n, l in zip(A.SCENE_LAYERS, scene_layers)}
    rep["scene"] = r
    rep["fixtures"] = {}
    fixture_flats = []
    for (slug, fn, _, _), item in zip(A.FIXTURES, manifest["fixtures"]):
        layers = [Image.fromarray(l) for l in fn()]
        fr, fflat = check_asset(item, A.FIXTURE_LAYERS, layers)
        shadow_alpha = np.array(layers[0])[..., 3]
        fr["only_semi_alpha_is_contact_shadow"] = set(np.unique(shadow_alpha).tolist()) <= {0, 0xA8} and all(
            set(np.unique(np.array(l)[..., 3]).tolist()) <= {0, 255} for l in layers[1:])
        opaque = {tuple(c) for c in fflat[fflat[..., 3] == 255][:, :3].tolist()}
        fr["opaque_colours_all_in_palette"] = opaque <= palette
        rows = np.nonzero(fflat[..., 3] > 0)[0]
        fr["opaque_rows_local"] = [int(rows.min()), int(rows.max())]
        rep["fixtures"][slug] = fr
        fixture_flats.append(fflat)
    again = A.merged(A.build_scene()).tobytes()
    rep["rebuild_deterministic"] = again == Image.fromarray(flat).tobytes() and all(
        A.merged([Image.fromarray(l) for l in fn()]).tobytes() == Image.fromarray(ff).tobytes() for (_, fn, _, _), ff in zip(A.FIXTURES, fixture_flats))
    return rep, flat, fixture_flats


def not_pasted_check(flat):
    """The old painted plate is a composition reference only: no resampled pixels may survive."""
    old = Image.open(OLD_PLATE).convert("RGB")
    new = flat[..., :3]
    rep = {"old_plate_size": list(old.size)}
    for name, method in (("nearest", Image.NEAREST), ("bilinear", Image.BILINEAR), ("box", Image.BOX), ("lanczos", Image.LANCZOS)):
        o = np.array(old.resize((640, 360), method))
        exact = (o == new).all(axis=2)
        near = (np.abs(o.astype(int) - new.astype(int)).max(axis=2) <= 4)
        rep[name] = {"identical_pixels": int(exact.sum()), "within_4_levels": int(near.sum()), "fraction_within_4": round(float(near.mean()), 4)}
    o = np.array(old.resize((640, 360), Image.BOX))
    rep["old_plate_unique_colours_at_640"] = len({tuple(c) for c in o.reshape(-1, 3).tolist()})
    return rep


def markers_mask():
    yy, xx = np.mgrid[0:360, 0:640]
    m = np.zeros((360, 640), bool)
    for cx, cy in CLUES + [EXIT, NEXT]:
        m |= np.hypot(xx + 0.5 - cx, yy + 0.5 - cy) <= 17.0
    return m


def rect_mask(rects, pad=0):
    m = np.zeros((360, 640), bool)
    for x0, y0, x1, y1 in rects:
        m[max(0, y0 - pad):min(360, y1 + pad), max(0, x0 - pad):min(640, x1 + pad)] = True
    return m


def capture_checks(before_dir, after_dir, plate, fixtures):
    rep = {}
    yy, xx = np.mgrid[0:360, 0:640]
    frects = [(x + OFFSET[0], y + OFFSET[1], x + OFFSET[0] + 64, y + OFFSET[1] + 64) for x, y in CLUES]
    falpha = np.zeros((360, 640), np.uint8)
    frgb = np.zeros((360, 640, 3), np.int16)
    for (x0, y0, x1, y1), f in zip(frects, fixtures):
        falpha[y0:y1, x0:x1] = f[..., 3]
        frgb[y0:y1, x0:x1] = f[..., :3]
    ui = (yy < 62) | (yy >= 318)
    labels = rect_mask(LABEL_RECTS, 3) | rect_mask(DOOR_LABEL_RECTS, 3)
    markers = markers_mask()
    ring = np.zeros((360, 640), bool)
    for cx, cy in CLUES + [EXIT, NEXT]:
        d = np.hypot(xx + 0.5 - cx, yy + 0.5 - cy)
        ring |= (d >= 13.2) & (d <= 14.8)
    for lang in ("zh", "en"):
        for pose in ("start", "lane-index"):
            shot = f"{lang}-{pose}"
            a = rgba(one(after_dir, f"*pilot-godot-{shot}-640x360_*.png")).astype(np.int16)
            b = rgba(one(before_dir, f"*baseline-head-godot-{shot}-640x360_*.png")).astype(np.int16)
            hero = rect_mask([HERO_BOXES[pose]])
            plain = ~ui & ~labels & ~markers & ~hero & (falpha == 0)
            r = {"size": [a.shape[1], a.shape[0]],
                 "plate_pixels_checked": int(plain.sum()),
                 "plate_pixels_exact": int(((a[..., :3] == plate[..., :3]) & plain[..., None]).all(axis=2).sum())}
            free = (falpha == 255) & ~markers & ~hero
            r["opaque_fixture_pixels_checked"] = int(free.sum())
            r["opaque_fixture_pixels_exact"] = int(((a[..., :3] == frgb).all(axis=2) & free).sum())
            semi = (falpha == 0xA8) & ~markers & ~hero
            expect = (plate[..., :3].astype(float) * (255 - 0xA8) + frgb * 0xA8) / 255.0
            r["shadow_pixels_checked"] = int(semi.sum())
            r["shadow_blend_max_channel_error"] = float(np.abs(a[..., :3] - expect)[semi].max()) if semi.any() else 0.0
            # UI chrome (header, footer, marker rings) is unchanged by the new art.
            r["ui_header_footer_changed"] = int(((a != b).any(axis=2) & ui).sum())
            r["marker_ring_pixels_changed"] = int(((a != b).any(axis=2) & ring).sum())
            # Hero texels: where the baseline pose shot differs from the baseline at the other pose.
            other = "lane-index" if pose == "start" else "start"
            b_other = rgba(one(before_dir, f"*baseline-head-godot-{lang}-{other}-640x360_*.png")).astype(np.int16)
            texels = (b != b_other).any(axis=2) & hero
            a_other = rgba(one(after_dir, f"*pilot-godot-{lang}-{other}-640x360_*.png")).astype(np.int16)
            hero_after = (a != a_other).any(axis=2) & hero
            r["hero_texels_baseline"] = int(texels.sum())
            r["hero_texels_after"] = int(hero_after.sum())
            # Where the hero covers the plate in both runs, the pixel colours must agree (hero drawn on top, unhidden).
            both = texels & hero_after & ((b[..., :3] != plate[..., :3]).any(axis=2))
            r["hero_texels_identical_to_baseline"] = int(((a == b).all(axis=2) & both).sum())
            r["hero_texels_compared"] = int(both.sum())
            rep[shot] = r
    fa = falpha > 0
    rep["fixture_rows_screen"] = [int(yy[fa].min()), int(yy[fa].max())]
    rep["fixture_pixels_in_label_rects"] = int((fa & rect_mask(LABEL_RECTS)).sum())
    rep["fixture_pixels_in_walk_lane"] = int(fa[LANE[1]:LANE[3], LANE[0]:LANE[2]].sum())
    rep["other_rooms_unchanged"] = {}
    for other in ("city-room1", "outskirts-room1", "ruins-room2"):
        a = rgba(one(after_dir, f"*pilot-godot-zh-other-{other}-640x360_*.png"))
        b = rgba(one(before_dir, f"*baseline-head-godot-zh-other-{other}-640x360_*.png"))
        rep["other_rooms_unchanged"][other] = int((a != b).any(axis=2).sum())
    load = rgba(one(after_dir, "*pilot-godot-en-after-load-640x360_*.png"))
    plain = ~ui & ~labels & ~markers & ~rect_mask([HERO_BOXES["after-load"]]) & (falpha == 0)
    rep["after_load_plate_exact"] = int(((load[..., :3] == plate[..., :3]).all(axis=2) & plain).sum()) == int(plain.sum())
    return rep


def run_pixelorama(exe, args, appdata):
    env = dict(os.environ)
    env["APPDATA"] = appdata
    return subprocess.run([exe, "--headless", "--quit", "--"] + args, capture_output=True, text=True, timeout=240, env=env)


def real_pixelorama_snapshot():
    root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    snap = {}
    if os.path.isdir(root):
        for d, _, files in os.walk(root):
            for f in files:
                rel = os.path.relpath(os.path.join(d, f), root).replace("\\", "/")
                if rel != ".running":
                    snap[rel] = sha(open(os.path.join(d, f), "rb").read())
    return snap


def pixelorama_checks(exe, manifest):
    A = author_mod
    rep = {}
    before = real_pixelorama_snapshot()
    tmp = tempfile.mkdtemp(prefix="wb-wdc-r1-pxo-")
    assets = [("scene", A.SCENE_LAYERS, A.build_scene(), manifest["scene_asset"])]
    for (slug, fn, _, _), item in zip(A.FIXTURES, manifest["fixtures"]):
        assets.append((slug, A.FIXTURE_LAYERS, [Image.fromarray(l) for l in fn()], item))
    try:
        for slug, names, layers, item in assets:
            flat = np.array(A.merged(layers)).astype(np.int16)
            for ext in ("pxo", "ora"):
                src = os.path.join(tmp, f"{slug}.{ext}")
                shutil.copyfile(ROOT / item["files"][ext]["file"], src)
                r = {}
                for mode in ("split", "flat"):
                    appdata = os.path.join(tmp, f"app-{slug}-{ext}-{mode}")
                    od = os.path.join(tmp, f"out-{slug}-{ext}-{mode}")
                    os.makedirs(appdata)
                    os.makedirs(od)
                    args = ["--export"] + (["--split-layers"] if mode == "split" else []) + ["-o", os.path.join(od, "f.png"), src]
                    p = run_pixelorama(exe, args, appdata)
                    outs = sorted(os.listdir(od))
                    if mode == "split":
                        exact = {}
                        for n, img in zip(names, layers):
                            hit = [o for o in outs if f"({n})" in o]
                            exact[n] = len(hit) == 1 and rgba(os.path.join(od, hit[0])).tobytes() == np.array(img).tobytes()
                        r["split"] = {"exit": p.returncode, "pngs": len(outs), "layers_exact": exact}
                    else:
                        got = rgba(os.path.join(od, outs[0])).astype(np.int16) if len(outs) == 1 else None
                        r["flat"] = {"exit": p.returncode, "pngs": len(outs),
                                     "exact": got is not None and got.tobytes() == flat.tobytes(),
                                     "differing_texels": int((got != flat).any(axis=2).sum()) if got is not None else None,
                                     "max_channel_delta": int(np.abs(got - flat).max()) if got is not None else None}
                r["source_unchanged_by_cli"] = open(src, "rb").read() == (ROOT / item["files"][ext]["file"]).read_bytes()
                rep[f"{slug}.{ext}"] = r
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    after = real_pixelorama_snapshot()
    changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
    gui = [k for k in changed if k.startswith("backups/") and "/(untitled backup)-" in k]
    rep["real_appdata_gui_autosave_changes_excluded"] = gui
    rep["real_appdata_pixelorama_changed"] = [k for k in changed if k not in gui]
    return rep


def main():
    global author_mod
    ap = argparse.ArgumentParser()
    ap.add_argument("before")
    ap.add_argument("after")
    ap.add_argument("--pixelorama", default=str(ROOT / "work/tooling/pixelorama-1-2-3/Pixelorama-Windows-64bit/Pixelorama.exe"))
    ap.add_argument("--report")
    a = ap.parse_args()
    author_mod = load_author()
    manifest = json.loads(Path(one(str(author_mod.OUT), "*scene-and-fixtures-manifest*.json")).read_text(encoding="utf-8"))
    src, plate, fixtures = source_checks(manifest)
    rep = {"sources": src, "not_pasted_from_old_plate": not_pasted_check(plate), "captures": capture_checks(a.before, a.after, plate, fixtures)}
    if os.path.isfile(a.pixelorama):
        rep["pixelorama_cli"] = pixelorama_checks(a.pixelorama, manifest)
    s, c, p, n = rep["sources"], rep["captures"], rep.get("pixelorama_cli", {}), rep["not_pasted_from_old_plate"]
    shots = [v for k, v in c.items() if k in ("zh-start", "en-start", "zh-lane-index", "en-lane-index")]
    gates = {
        "S1_sources_exact": s["scene"]["exact"] and s["scene"]["size"] == [640, 360] and len(s["scene"]["pxo_layers_bottom_to_top"]) == 8
                            and all(v["exact"] and v["size"] == [64, 64] and len(v["pxo_layers_bottom_to_top"]) == 4 for v in s["fixtures"].values()),
        "S2_palette_and_alpha": s["scene"]["colours_all_in_palette"] and s["scene"]["layer_alpha_binary"] and s["scene"]["merged_fully_opaque"]
                                and all(v["opaque_colours_all_in_palette"] and v["only_semi_alpha_is_contact_shadow"] for v in s["fixtures"].values()),
        "S3_rebuild_deterministic": s["rebuild_deterministic"],
        "S4_not_pasted_from_old_plate": all(n[m]["identical_pixels"] < 640 * 360 * 0.01 and n[m]["fraction_within_4"] < 0.05 for m in ("nearest", "bilinear", "box", "lanczos")),
        "C1_plate_renders_native_1to1": all(v["plate_pixels_exact"] == v["plate_pixels_checked"] > 120000 for v in shots) and c["after_load_plate_exact"],
        "C2_fixtures_native_exact": all(v["opaque_fixture_pixels_exact"] == v["opaque_fixture_pixels_checked"] and v["shadow_blend_max_channel_error"] <= 1.0 for v in shots),
        "C3_labels_lane_ui_clear": c["fixture_pixels_in_label_rects"] == 0 and c["fixture_pixels_in_walk_lane"] == 0
                                   and all(v["ui_header_footer_changed"] == 0 and v["marker_ring_pixels_changed"] == 0 for v in shots),
        "C4_hero_visible_unhidden": all(v["hero_texels_after"] > 300 and v["hero_texels_identical_to_baseline"] == v["hero_texels_compared"] > 300 for v in shots),
        "C5_other_rooms_pixel_identical": all(v == 0 for v in c["other_rooms_unchanged"].values()),
        "P1_pixelorama_split_layers_exact": bool(p) and all(v["split"]["exit"] == 0 and all(v["split"]["layers_exact"].values()) and v["source_unchanged_by_cli"]
                                                            for k, v in p.items() if isinstance(v, dict)),
        "P2_pixelorama_scene_flat_export_exact": bool(p) and p["scene.pxo"]["flat"]["exact"] and p["scene.ora"]["flat"]["exact"],
        "P3_pixelorama_real_appdata_untouched": bool(p) and not p["real_appdata_pixelorama_changed"],
    }
    rep["gates"] = gates
    rep["report_only_fixture_flat_export_exact"] = {k: v["flat"]["exact"] for k, v in p.items() if isinstance(v, dict) and not k.startswith("scene.")}
    rep["result"] = "PASS" if all(gates.values()) else "FAIL"
    text = json.dumps(rep, indent=1, ensure_ascii=False)
    if a.report:
        Path(a.report).write_text(text + "\n", encoding="utf-8")
    print(text)
    print("GATES", sum(gates.values()), "/", len(gates), rep["result"])
    return 0 if rep["result"] == "PASS" else 1


author_mod = None

if __name__ == "__main__":
    sys.exit(main())
