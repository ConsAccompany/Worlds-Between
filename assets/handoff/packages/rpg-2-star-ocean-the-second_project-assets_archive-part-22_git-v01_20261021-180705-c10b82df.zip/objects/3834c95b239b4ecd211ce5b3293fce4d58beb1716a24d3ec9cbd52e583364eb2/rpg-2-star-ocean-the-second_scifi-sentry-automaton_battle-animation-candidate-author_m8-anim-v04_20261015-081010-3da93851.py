"""Author the UNAPPROVED native-pixel sentry automaton battle ANIMATION candidate, revision v4 (21 frames, facing left).

v4 is an isolated technical-art candidate. v2 stays the battle_arena.gd runtime default (unapproved, awaiting human
review) and v3 stays a historical test-only candidate. Nothing of v1/v2/v3 is modified; the v3 author is imported
unchanged (which imports the v2 author unchanged) for the rig, poses, palette, compositor and the v3 wind-up lens.

What v4 changes, art only (combat rules, timing, positions and the 21-frame state map are untouched):
  1. Strike (frames 14-15). v3 hid a short physical lunge behind a broad cyan claw-arc (177 hero body pixels
     covered at the 53 px AI spacing, v2 86) and the metal still stopped short at 69 px. v4 drops the arc and
     the v2 head lunge. The head stays home (so it no longer covers the hero's hands at 53 px) while the near
     claw limb fires a slim two-stage piston at chest height: a sleeve under the eye housing, a 4-row first
     stage over the empty gap between the fighters, a 2-row second stage and a compact brass talon whose tip
     reaches enemy_x + CLAW_TIP_REL. The only effect accent is a short dim streak on the sentry side of the
     gap (it never lies over a hero at 53-69 px and is not counted as contact). Frame 15 retracts the piston
     and lowers the claw on the v2 leg.
  2. Gait (frames 4-11). The v2 distance-locked gait is kept (8 steps of 4 px, every stance foot +4 px per
     step, so planted feet still do not slip), but both near feet now stroke 6 px either side of their idle
     spot (v2: near-front 0..+12, near-rear -12..0). Leaving the gait for an idle / wind-up / hit pose (all
     feet on their idle spots) therefore pops a planted foot by at most 6 px instead of 12-13.
  3. Wind-up lens (frames 12-13): the v3 lens paint, unchanged (luma/contrast only; the tint still warms it).
  4. Defeat (frames 18-20): the v3 Bayer-dithered shadow is replaced by a flat, undithered contact shadow in
     palette 'o': the floor row between the feet plus two rows under it, rounded at the ends.

The cell is the v2 cell placed LEFT px further from the left edge (room for the piston), with RIGHT px more behind it
(room for the centred rear foot), on a 4 px taller canvas.
The runtime anchor and body centre move with the margin, so every frame draws where v2 draws it.

Usage (bundled Python/Pillow runtime, run with -I):
  python <this file> --out DIR      -> scratch strip + frames + 8x inspection crops for iteration, no manifest
  python <this file> --final DIR
      -> new uniquely named strip PNG, one PNG per frame (in a .gdignore folder) and a manifest in DIR.
         Never overwrites. No contact sheet, collage or GIF is produced here; review uses real Godot captures.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import uuid
from datetime import datetime
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
V3_AUTHOR = HERE / "rpg-2-star-ocean-the-second_scifi-sentry-automaton_battle-animation-pilot-author_m8-anim-v03_20261015-041413-21ec8744.py"
V3_STRIP = HERE / "rpg-2-star-ocean-the-second_scifi-sentry-automaton_battle-animation-strip-left_m8-anim-v03_20261015-041706-53479e75.png"
V3_STRIP_SHA256 = "47db0317f1beadd44ca3463a080c9cc81240497e4a4fd1c8790baba9d30369b2"
V2_STRIP = HERE / "rpg-2-star-ocean-the-second_scifi-sentry-automaton_battle-animation-strip-left_m8-anim-v02_20261014-230329-ffefdc6f.png"
V2_MANIFEST = HERE / "rpg-2-star-ocean-the-second_scifi-sentry-automaton_battle-animation-manifest_m8-anim-v02_20261014-230329-ffefdc6f.json"
V2_STRIP_SHA256 = "26d1fb1c0d13371f348ec04c27b35901bd8a06701694446374dae6f27c35e52e"
# The target the strike is designed against: the male hero's hit frame (what the target shows during the impact frame).
HERO_HIT = [
    HERE.parents[1] / "characters/combat-prototypes/rpg-2-star-ocean-the-second_protagonist-male_sideview-hit-right-phase-01_m8-prototype_20261014-142325-206158cd.png",
    HERE.parents[1] / "characters/combat-prototypes/rpg-2-star-ocean-the-second_protagonist-male_sideview-hit-right-phase-02_m8-prototype_20261014-142325-c63abe8c.png",
]
HERO_ANCHOR = (30, 73)

_spec = importlib.util.spec_from_file_location("sentry_v3_author", V3_AUTHOR)
v3 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v3)
v2 = v3.v2
static = v2.static

SLUG = v2.SLUG
PALETTE = v2.PALETTE
V2_W, V2_H = v2.SIZE
V2_MARGIN = v2.MARGIN
LEFT = 24
BOTTOM = 4
# Room behind the rear foot: the centred gait strokes the near-rear foot 6 px further back than v2 does.
RIGHT = 8
W, H = V2_W + LEFT + RIGHT, V2_H + BOTTOM
SIZE = (W, H)
# Static plate x -> v4 cell x.
P = V2_MARGIN + LEFT
ANCHOR_ROW = v2.ANCHOR_ROW
RUNTIME_ANCHOR = (v2.RUNTIME_ANCHOR[0] + LEFT, ANCHOR_ROW)
BODY_CENTER_X = v2.BODY_CENTER_X + LEFT
# Static x of enemy_x (the runtime anchor): world x = enemy_x + (static x - STATIC_ANCHOR_X).
STATIC_ANCHOR_X = v2.RUNTIME_ANCHOR[0] - V2_MARGIN
STATES = v2.STATES
GAIT_STEP = v2.GAIT_STEP
GAIT_FRAMES = v2.GAIT_FRAMES

# Widen the v2 rig and the static compositor to the v4 canvas: every plate is drawn at static x + P directly, so parts
# may reach left of the v2 cell and still get their outline. (Asserted below: unchanged poses equal the v2 cells.)
static.SIZE, static.W, static.H = SIZE, W, H
v2.SIZE, v2.W, v2.H, v2.MARGIN = SIZE, W, H, P

# Leading edge of the physical claw (talon tip), relative to enemy_x. The unchanged strike reach is 69 px.
CLAW_TIP_REL = -64
TIP = STATIC_ANCHOR_X + CLAW_TIP_REL  # static x of the talon tip


def rgb(key: str) -> tuple:
    h = PALETTE[key]
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16))


# --- 2. Gait: v2's distance lock, both near feet centred on their idle spot -------------------------------
SWING_X = v2.SWING_X
GAIT_LEGS = {
    # leg: (stance start step, stance start x, swing lift peak); v2 had (0, 0) / (0, -6) / (4, -12) / (4, -6).
    # Each pair lands one step earlier than in v2, so the first gait frame (step 0, where every walk starts) already
    # has the near-front foot 4 px into its stance, 2 px from its idle spot.
    "nfl": (7, -6, 4),
    "frl": (7, -6, 3),
    "nrl": (3, -6, 4),
    "ffl": (3, -6, 3),
}
GAIT_LANDING_STEPS = (3, 7)


def gait_foot(leg: str, step: int):
    start, x0, peak = GAIT_LEGS[leg]
    k = (step - start) % GAIT_FRAMES
    if k < 4:
        return (x0 + GAIT_STEP * k, 0), True
    j = k - 4
    lift = (peak // 2, peak, peak, peak // 2)[j]
    return (x0 + SWING_X[j], -lift), False


def gait_pose(step: int) -> dict:
    # As v2: the body dips 1 px as each pair lands; the knee follows the foot halfway forward and most of the way up.
    dy = 1 if step in GAIT_LANDING_STEPS else 0
    legs = {}
    for leg in GAIT_LEGS:
        (fx, fy), _ = gait_foot(leg, step)
        legs[leg] = ((fx // 2 if fx >= 0 else -((-fx) // 2), dy + (fy * 3) // 4), (fx, fy))
    return v2.pose(body=(0, dy), head=(0, dy), pupil=(-1, 0), **legs)


# --- 1. Strike: slim physical claw piston ----------------------------------------------------------------
Z = (0, 0)
STRIKE_HEAD = (0, 1)
# Impact: the body leans 3 px into the thrust and the hind legs brace with their feet planted; the head stays home.
IMPACT_POSE = v2.pose(body=(-3, 1), head=STRIKE_HEAD, fin=(1, 1), nfl=(Z, Z), nrl=((-2, -1), Z), ffl=((-3, 1), Z),
                      frl=((-2, 0), Z), eye="flash", pupil=(-1, 0), lights="bright")
# Recoil: the piston has snapped back and the claw drops on the v2 leg, a little ahead of its idle spot.
RECOIL_POSE = v2.pose(body=(-1, 1), head=STRIKE_HEAD, nfl=((-3, -3), (-4, -5)), nrl=((-1, 0), Z), ffl=((-1, 1), Z),
                      frl=((-1, 0), Z), eye="charge1", pupil=(-1, 0))

# Piston rows (static y): stage 1 occupies rows 30-33 (outlined), stage 2 rows 31-32 (no outline: slim).
STAGE1_X = (-15, -2)
STAGE2_ROWS = (31, 32)


def claw_arm_part(head: tuple) -> v2.Rig:
    """The near-front leg as a claw limb, in the leg's slot (behind the eye housing): thigh from the hip, the brass knee,
    a shin that rises to chest height and the first piston stage over the empty gap between the fighters."""
    r = v2.Rig("near_claw_limb", {"h": head, "a": Z}, "a")
    # Thigh: from the hip (which follows the head, as the v2 leg) forward and down, under the eye housing, to the knee.
    r.poly([(30, 33, "h"), (36, 37, "h"), (11, 44), (5, 38)], "4")
    r.clip_poly([(30, 33, "h"), (32, 34, "h"), (7, 40), (5, 38)], "5")
    r.clip_poly([(35, 37, "h"), (36, 37, "h"), (11, 44), (10, 43)], "3")
    # Shin: from the knee, below the housing's bevel, up to the piston collar at chest height.
    r.poly([(7, 37), (3, 43), (-2, 33), (-2, 30)], "4")
    r.clip_poly([(7, 37), (5, 38), (-2, 31), (-2, 30)], "5")
    r.clip_poly([(4, 42), (3, 43), (-2, 33), (-2, 32)], "3")
    # Stage 1: a slate tube with a brass collar where stage 2 slides out.
    x0, x1 = STAGE1_X
    r.rect(x0, 30, x1, 33, "4")
    r.clip_rect(x0, 30, x1, 30, "5")
    r.clip_rect(x0, 33, x1, 33, "3")
    r.clip_rect(x0, 30, x0 + 1, 33, "c")
    r.clip_rect(x0, 30, x0 + 1, 30, "d")
    r.clip_rect(x0, 33, x0 + 1, 33, "b")
    # Knee joint (brass), as the v2 knee plates, just below the housing's lower-left bevel.
    r.oval(3, 36, 11, 44, "c")
    r.clip_oval(3, 36, 9, 42, "d")
    r.oval(5, 38, 9, 42, "b")
    r.px([(5, 37), (6, 37)], "e")
    r.px([(7, 40)], "a")
    return r


# Pincer (static x relative to TIP, static y): a crab-style brass claw opening toward the target. The longer upper jaw
# hooks down at chest height and leads; the short lower jaw stays behind it. Explicit pixels with their own 1 px outline.
PINCER = [
    (1, 27, "o"), (2, 27, "o"), (3, 27, "o"), (4, 27, "o"),
    (0, 28, "o"), (1, 28, "e"), (2, 28, "d"), (3, 28, "d"), (4, 28, "c"), (5, 28, "o"),
    (0, 29, "o"), (1, 29, "d"), (2, 29, "c"), (3, 29, "b"), (4, 29, "c"), (5, 29, "b"),
    (0, 30, "o"), (1, 30, "b"), (2, 30, "o"), (3, 30, "o"), (4, 30, "c"), (5, 30, "b"),
    (3, 31, "o"), (4, 31, "c"), (5, 31, "b"),
    (2, 32, "o"), (3, 32, "d"), (4, 32, "c"), (5, 32, "b"),
    (1, 33, "o"), (2, 33, "c"), (3, 33, "b"), (4, 33, "b"), (5, 33, "o"),
    (2, 34, "o"), (3, 34, "o"), (4, 34, "o"),
]
PINCER_WRIST_END = 5


def claw_pixels() -> list:
    """Cell-space (x, y, key) pixels of the stage-2 rod and the pincer (the physical claw beyond stage 1)."""
    out = []
    for sx in range(TIP + PINCER_WRIST_END + 1, STAGE1_X[0]):
        out.append((sx + P, STAGE2_ROWS[0], "5"))
        out.append((sx + P, STAGE2_ROWS[1], "2"))
    for dx, sy, key in PINCER:
        out.append((TIP + dx + P, sy, key))
    return out


def accent_pixels() -> list:
    """No effect accent in v4: the lens flash is the strike's only light cue, so no effect pixel can stand in for contact."""
    return []


def render_impact() -> tuple[Image.Image, list, list]:
    parts = v2.build_parts(IMPACT_POSE)
    names = [p.name for p in parts]
    parts[names.index("near_front_leg")] = claw_arm_part(STRIKE_HEAD)
    img = static.composite(parts)
    px = img.load()
    claw, accent = [], []
    for x, y, key in claw_pixels():
        px[x, y] = rgb(key) + (255,)
        claw.append((x, y))
    for x, y, key in accent_pixels():
        if px[x, y][3] == 0:
            px[x, y] = rgb(key) + (255,)
            accent.append((x, y))
    return img, claw, accent


# --- 4. Defeat contact shadow ------------------------------------------------------------------------------
SHADOW_KEY = "o"
# Half width of the shadow under the floor row per defeat frame; it widens as the body settles (sinks 3 / 7 / 9 px).
SHADOW = {18: 26, 19: 32, 20: 36}


def shadow_pixels(img: Image.Image, frame: int) -> list:
    """A flat, undithered contact shadow centred on the body centre: the transparent floor-row pixels between the feet
    (row 60), a full row under them (61) and a shorter row below (62), so the ends round off. Transparent pixels only."""
    half = SHADOW[frame]
    cx = BODY_CENTER_X
    px = img.load()
    out = []
    for y, h in ((60, half - 2), (61, half), (62, half - 7)):
        for x in range(cx - h, cx + h):
            if 0 <= x < W and not px[x, y][3]:
                out.append((x, y, SHADOW_KEY))
    return out


# --- Frames -------------------------------------------------------------------------------------------------
def v4_poses() -> list:
    frames = []
    for i, (state, p) in enumerate(v2.FRAMES):
        p = dict(p)
        if state == "move":
            p = gait_pose(i - 4)
        elif i == 12:
            p["eye"] = "charge1v3"
        elif i == 13:
            p["eye"] = "charge2v3"
        elif i == 14:
            p = IMPACT_POSE
        elif i == 15:
            p = RECOIL_POSE
        frames.append((state, p))
    return frames


FRAMES = v4_poses()
CLAW_FRAMES = {14}
IDENTICAL_TO_V2 = [0, 1, 2, 3, 16, 17]
IDENTICAL_TO_V3 = [0, 1, 2, 3, 12, 13, 16, 17]


def render_all() -> tuple[list, dict]:
    frames, classes = [], {}
    for i, (state, p) in enumerate(FRAMES):
        if i == 14:
            img, claw, accent = render_impact()
            classes[i] = {"claw": claw, "accent": accent}
        else:
            img = v2.render(p)
        if i in SHADOW:
            pixels_ = shadow_pixels(img, i)
            px = img.load()
            for x, y, key in pixels_:
                px[x, y] = rgb(key) + (255,)
            classes[i] = {"shadow": [(x, y) for x, y, _ in pixels_]}
        frames.append(img)
    expected = [s for s, n, _, _ in STATES for _ in range(n)]
    assert [s for s, _ in FRAMES] == expected and len(frames) == 21, "frame order must match the v2 state map"
    return frames, classes


def pixels(img: Image.Image) -> list:
    return list(img.get_flattened_data() if hasattr(img, "get_flattened_data") else img.getdata())


def ground_runs(img: Image.Image, row: int = ANCHOR_ROW) -> list:
    runs, start = [], None
    for x in range(W + 1):
        on = x < W and img.getpixel((x, row))[3] > 0
        if on and start is None:
            start = x
        elif not on and start is not None:
            runs.append((start, x - 1))
            start = None
    return runs


# --- Target overlay estimate (the Godot capture test measures the real render) ------------------------------
def hero_overlay(frame: Image.Image, classes: dict, distance: int, hero: Image.Image) -> dict:
    """Overlay the hero hit frame at `distance` px from enemy_x, in world pixels relative to enemy_x, as the runtime draws them.
    hiddenHeroPx: hero pixels (above the bottom 6 rows) covered by any sentry pixel (the strike draws in front).
    clawContactPx / clawTorsoContactPx: hero pixels covered by physical claw pixels (stage 2 rod + talon) / of those, the
    ones inside the torso band (hero x <= hero_x + 8). accentOverHeroPx: hero pixels covered by effect accent pixels."""
    claw = set(classes.get("claw", []))
    accent = set(classes.get("accent", []))
    fx = frame.load()
    hx = hero.load()
    hidden = contact = torso = acc = 0
    for y in range(hero.height):
        for x in range(hero.width):
            if hx[x, y][3] < 128:
                continue
            # world relative to enemy_x: hero origin = -distance - HERO_ANCHOR.x; sentry cell origin = -RUNTIME_ANCHOR.x
            wx = -distance - HERO_ANCHOR[0] + x
            wy = ARENA_FLOOR - HERO_ANCHOR[1] + y
            cx, cy = wx + RUNTIME_ANCHOR[0], wy - (ARENA_FLOOR - ANCHOR_ROW)
            if not (0 <= cx < W and 0 <= cy < H) or cy > ANCHOR_ROW - 6 or fx[cx, cy][3] == 0:
                continue
            hidden += 1
            if (cx, cy) in claw:
                contact += 1
                if x - HERO_ANCHOR[0] <= 8:
                    torso += 1
            if (cx, cy) in accent:
                acc += 1
    lead = frame.getbbox()[0] - RUNTIME_ANCHOR[0]
    claw_lead = (min(x for x, _ in claw) - RUNTIME_ANCHOR[0]) if claw else None
    return {"distance": distance, "hiddenHeroPx": hidden, "clawContactPx": contact, "clawTorsoContactPx": torso,
            "accentOverHeroPx": acc, "leadRelEnemyX": lead, "clawLeadRelEnemyX": claw_lead,
            "clawLeadRelTargetX": None if claw_lead is None else claw_lead + distance}


ARENA_FLOOR = 272


def check(frames: list, classes: dict) -> dict:
    assert hashlib.sha256(V2_STRIP.read_bytes()).hexdigest() == V2_STRIP_SHA256, "v2 strip changed"
    assert hashlib.sha256(V3_STRIP.read_bytes()).hexdigest() == V3_STRIP_SHA256, "v3 strip changed"
    v2_strip = Image.open(V2_STRIP).convert("RGBA")
    v3_strip = Image.open(V3_STRIP).convert("RGBA")
    v2_cells = [v2_strip.crop((i * V2_W, 0, (i + 1) * V2_W, V2_H)) for i in range(21)]
    v3w, v3h = v3.SIZE
    v3_cells = [v3_strip.crop((i * v3w, 0, (i + 1) * v3w, v3h)) for i in range(21)]
    palette = {rgb(k) for k in PALETTE}
    report = []
    for i, img in enumerate(frames):
        state = FRAMES[i][0]
        # The v2 cell sits LEFT px in; the v3 cell (v2 cell at 20 px) sits LEFT - 20 px in.
        v2_window = img.crop((LEFT, 0, LEFT + V2_W, V2_H))
        outside_v2 = sum(1 for y in range(H) for x in range(W) if (x < LEFT or x >= LEFT + V2_W or y >= V2_H) and img.getpixel((x, y))[3])
        same_v2 = v2_window.tobytes() == v2_cells[i].tobytes() and outside_v2 == 0
        k = LEFT - v3.LEFT
        same_v3 = img.crop((k, 0, k + v3w, v3h)).tobytes() == v3_cells[i].tobytes() and all(
            img.getpixel((x, y))[3] == 0 for y in range(H) for x in range(W) if not (k <= x < k + v3w and y < v3h))
        if i in IDENTICAL_TO_V2:
            assert same_v2, ("frame must equal v2", i)
        if i in IDENTICAL_TO_V3:
            assert same_v3, ("frame must equal v3", i)
        bbox = img.getbbox()
        body = img.copy()
        if i in SHADOW:
            bp = body.load()
            for x, y in classes[i]["shadow"]:
                bp[x, y] = (0, 0, 0, 0)
        assert body.getbbox()[3] - 1 == ANCHOR_ROW, (i, body.getbbox())
        if i not in SHADOW:
            assert bbox[3] - 1 == ANCHOR_ROW, (i, bbox)
        colours = {c[:3] for c in pixels(img) if c[3]}
        assert colours <= palette, (i, colours - palette)
        assert {c[3] for c in pixels(img)} <= {0, 255}
        assert bbox[0] >= 1, ("frame touches the left cell edge", i, bbox)
        report.append({"index": i, "state": state, "opaqueBBox": list(bbox), "colourCount": len(colours),
                       "opaquePixels": sum(1 for c in pixels(img) if c[3]), "equalsV2Cell": same_v2, "equalsV3Cell": same_v3,
                       "anchorRowRuns": ground_runs(img)})
    # Gait lock (as v2): every foot in stance on consecutive steps moves exactly +GAIT_STEP px in the cell, and the
    # grounded near-foot runs on the anchor row move by the same amount.
    lock = []
    for step in range(GAIT_FRAMES):
        nxt = (step + 1) % GAIT_FRAMES
        for leg in GAIT_LEGS:
            (x0, _), s0 = gait_foot(leg, step)
            (x1, _), s1 = gait_foot(leg, nxt)
            if s0 and s1:
                assert x1 - x0 == GAIT_STEP, (leg, step, x0, x1)
                lock.append({"leg": leg, "step": step, "cellShiftPx": x1 - x0})
        a, b = ground_runs(frames[4 + step]), ground_runs(frames[4 + nxt])
        for leg in ("nfl", "nrl"):
            if gait_foot(leg, step)[1] and gait_foot(leg, nxt)[1]:
                ra = [r for r in a if ((r[0] + r[1]) / 2 < BODY_CENTER_X) == (leg == "nfl")]
                rb = [r for r in b if ((r[0] + r[1]) / 2 < BODY_CENTER_X) == (leg == "nfl")]
                assert len(ra) == 1 and len(rb) == 1, (leg, step, a, b)
                assert rb[0][0] - ra[0][0] == GAIT_STEP and rb[0][1] - ra[0][1] == GAIT_STEP, (leg, step, ra, rb)
        assert any(gait_foot(leg, step)[1] for leg in ("nfl", "nrl")), step
    # Planted-foot offset from the idle spot (what a gait exit pops by), per near foot, v4 vs v2.
    idle_runs = ground_runs(frames[0])
    idle = {("nfl" if (r[0] + r[1]) / 2 < BODY_CENTER_X else "nrl"): r[0] for r in idle_runs}
    offsets = {"nfl": [], "nrl": []}
    for step in range(GAIT_FRAMES):
        for r in ground_runs(frames[4 + step]):
            leg = "nfl" if (r[0] + r[1]) / 2 < BODY_CENTER_X else "nrl"
            offsets[leg].append(r[0] - idle[leg])
    v2_offsets = {"nfl": [], "nrl": []}
    for step in range(GAIT_FRAMES):
        for leg, (start, x0, _) in v2.GAIT_LEGS.items():
            if leg in v2_offsets:
                (fx_, _), stance = v2.gait_foot(leg, step)
                if stance:
                    v2_offsets[leg].append(fx_)
    # Strike claw: classes, reach, overlay estimates against the hero hit frames.
    claw = classes[14]["claw"]
    accent = classes[14]["accent"]
    claw_lead = min(x for x, _ in claw) - RUNTIME_ANCHOR[0]
    assert claw_lead == CLAW_TIP_REL, claw_lead
    assert frames[14].getbbox()[0] - RUNTIME_ANCHOR[0] == CLAW_TIP_REL, "the claw, not an effect, is the leading pixel"
    accent_lead = (min(x for x, _ in accent) - RUNTIME_ANCHOR[0]) if accent else None
    overlay = {}
    for phase, path in enumerate(HERO_HIT, start=1):
        hero = Image.open(path).convert("RGBA")
        for d in (53, 62, 69):
            overlay[f"hitPhase{phase}_d{d}_f14"] = hero_overlay(frames[14], classes[14], d, hero)
            overlay[f"hitPhase{phase}_d{d}_f15"] = hero_overlay(frames[15], {}, d, hero)
            overlay[f"hitPhase{phase}_d{d}_v2f14"] = v2_overlay(v2_cells[14], d, hero)
            overlay[f"hitPhase{phase}_d{d}_v3f14"] = v3_overlay(v3_cells[14], d, hero)
    lens = {}
    for i in (12, 13):
        head = FRAMES[i][1]["head"]
        lens[f"v4_f{i}_tinted"] = v3.lens_metrics(_as_v3_cell(frames[i]), head, v3.WINDUP_TINT)
    shadow = {i: {"pixels": len(classes[i]["shadow"]), "belowFloorRowPx": sum(1 for _, y in classes[i]["shadow"] if y > ANCHOR_ROW),
                  "halfWidthRow61": SHADOW[i]} for i in SHADOW}
    return {"frames": report, "gaitLock": lock, "plantedFootOffsetFromIdlePx": {"v4": offsets, "v2": v2_offsets},
            "clawLeadRelEnemyX": claw_lead, "clawPixels": len(claw), "accentPixels": len(accent), "accentLeadRelEnemyX": accent_lead,
            "heroOverlayEstimate": overlay, "lens": lens, "shadow": shadow}


def _as_v3_cell(img: Image.Image) -> Image.Image:
    # v3.lens_metrics reads v3 cell coordinates (static x + 36); shift the v4 cell onto that grid.
    k = LEFT - v3.LEFT
    return img.crop((k, 0, k + v3.W, v3.H))


def v2_overlay(cell: Image.Image, d: int, hero: Image.Image) -> dict:
    img = Image.new("RGBA", SIZE, (0, 0, 0, 0))
    img.paste(cell, (LEFT, 0))
    r = hero_overlay(img, {}, d, hero)
    return {"hiddenHeroPx": r["hiddenHeroPx"], "leadRelEnemyX": r["leadRelEnemyX"]}


def v3_overlay(cell: Image.Image, d: int, hero: Image.Image) -> dict:
    img = Image.new("RGBA", SIZE, (0, 0, 0, 0))
    img.paste(cell, (LEFT - v3.LEFT, 0))
    r = hero_overlay(img, {}, d, hero)
    return {"hiddenHeroPx": r["hiddenHeroPx"], "leadRelEnemyX": r["leadRelEnemyX"]}


def strip_of(frames):
    strip = Image.new("RGBA", (W * len(frames), H), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        strip.paste(f, (i * W, 0))
    return strip


def inspection(frame: Image.Image, d: int, hero: Image.Image, scale: int = 8) -> Image.Image:
    """Scratch-only nearest-neighbour inspection crop of one frame over a flat floor with the hero at d (never shipped)."""
    # Canvas origin in world pixels relative to (enemy_x, floor): x0 left of the hero cell, y0 at the hero cell's top.
    x0 = -d - HERO_ANCHOR[0] - 4
    y0 = -HERO_ANCHOR[1] - 2
    bg = Image.new("RGBA", (W - RUNTIME_ANCHOR[0] - x0 + 4, HERO_ANCHOR[1] + 2 + (H - ANCHOR_ROW) + 2), (88, 92, 98, 255))
    bg.alpha_composite(hero, (-d - HERO_ANCHOR[0] - x0, -HERO_ANCHOR[1] - y0))
    bg.alpha_composite(frame, (-RUNTIME_ANCHOR[0] - x0, -ANCHOR_ROW - y0))
    return bg.resize((bg.width * scale, bg.height * scale), Image.NEAREST)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--final", type=Path, default=None)
    args = ap.parse_args()
    frames, classes = render_all()
    report = check(frames, classes)
    summary = {k: report[k] for k in ("clawLeadRelEnemyX", "clawPixels", "accentPixels", "accentLeadRelEnemyX", "plantedFootOffsetFromIdlePx", "lens", "shadow")}
    summary["heroOverlayEstimate"] = {k: v for k, v in report["heroOverlayEstimate"].items() if "hitPhase1" in k}
    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        strip_of(frames).save(args.out / "strip.png")
        body = [f.copy() for f in frames]
        for i in SHADOW:
            bp = body[i].load()
            for x, y in classes[i]["shadow"]:
                bp[x, y] = (0, 0, 0, 0)
        strip_of(body).save(args.out / "strip_body.png")
        for i, f in enumerate(frames):
            f.save(args.out / f"f{i:02d}.png")
        hero = Image.open(HERO_HIT[0]).convert("RGBA")
        for d in (53, 69):
            inspection(frames[14], d, hero).save(args.out / f"insp_f14_d{d}.png")
        print(json.dumps(summary, indent=1))
        return
    out_dir: Path = args.final
    root = out_dir.resolve().parents[3]
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    token = uuid.uuid4().hex[:8]
    tag = "m8-anim-v04"
    path = out_dir / f"{SLUG}_scifi-sentry-automaton_battle-animation-candidate-strip-left_{tag}_{stamp}-{token}.png"
    mpath = out_dir / f"{SLUG}_scifi-sentry-automaton_battle-animation-candidate-manifest_{tag}_{stamp}-{token}.json"
    # Short folder and file names: the full Windows path must stay under 260 characters.
    fdir = out_dir / f"frames_{tag}_{token}"
    for p in (path, mpath, fdir):
        assert not p.exists(), p
    strip = strip_of(frames)
    strip.save(path)
    # One file per frame. The .gdignore keeps Godot from importing these review copies; the runtime reads the strip.
    fdir.mkdir()
    (fdir / ".gdignore").write_text("", encoding="utf-8")
    frame_files = []
    counters = {}
    for i, f in enumerate(frames):
        state = FRAMES[i][0]
        counters[state] = counters.get(state, -1) + 1
        fpath = fdir / f"{SLUG}_sentry_anim-f{i:02d}-{state}{counters[state]}_{tag}_{stamp}-{token}.png"
        f.save(fpath)
        frame_files.append(fpath)
    rel = lambda p: str(p.resolve().relative_to(root)).replace("\\", "/")
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    for i, fpath in enumerate(frame_files):
        assert strip.crop((i * W, 0, (i + 1) * W, H)).tobytes() == Image.open(fpath).convert("RGBA").tobytes(), fpath
    script = Path(__file__).resolve()
    states = {}
    cursor = 0
    for name, count, frame_time, mode in STATES:
        states[name] = {"frames": list(range(cursor, cursor + count)), "frameTime": frame_time, "mode": mode}
        cursor += count
    states["move"]["stepPx"] = GAIT_STEP
    manifest = {
        "project": SLUG,
        "asset": "scifi sentry automaton battle animation candidate v4 (science-region ruins enemy)",
        "revision": tag,
        "basedOn": {"v2Manifest": rel(V2_MANIFEST), "v2Strip": rel(V2_STRIP), "v2StripSha256": V2_STRIP_SHA256,
                    "v3Strip": rel(V3_STRIP), "v3StripSha256": V3_STRIP_SHA256,
                    "note": "v2 stays the battle_arena.gd runtime default and v3 stays test-only; v1/v2/v3 files are unchanged; v4 is an isolated candidate"},
        "status": "animation_candidate_unapproved",
        "artAccepted": False,
        "artAcceptanceCount": 0,
        "humanReview": "pending - v2, v3 and v4 all await Codex/human review; this is not animation acceptance or integration",
        "runtimeWiring": "not wired: battle_arena.gd still points ENEMY_SPRITE_ANIMATIONS['sentry'] at v2. The test-only v4 helper applies the entry below to single battle instances.",
        "runtimeEntry": {"cell": [W, H], "anchor": list(RUNTIME_ANCHOR), "body_center_x": BODY_CENTER_X,
                         "unchangedFromV2": ["states", "frame_time", "gait_step_px", "move_grace", "front_states"]},
        "file": rel(path),
        "sha256": sha(path),
        "sha256Algorithm": "sha256-bytes",
        "stripSize": list(strip.size),
        "cellSize": list(SIZE),
        "frameCount": len(frames),
        "v2CellOffsetInCell": [LEFT, 0],
        "staticPlateOffsetInCell": [P, 0],
        "runtimeAnchor": list(RUNTIME_ANCHOR),
        "bodyCenterX": BODY_CENTER_X,
        "runtimeAnchorNote": "draw the cell at (enemy_x - %d, 272 - %d): the same screen placement as v2 (cell x %d = v2 cell x %d). The ring and contact shadow centre on cell x %d (enemy_x + %d), as in v2." % (RUNTIME_ANCHOR[0], ANCHOR_ROW, RUNTIME_ANCHOR[0], v2.RUNTIME_ANCHOR[0], BODY_CENTER_X, BODY_CENTER_X - RUNTIME_ANCHOR[0]),
        "facing": "left (toward party)",
        "states": states,
        "changesFromV2": {
            "strike": "frame 14: no head lunge and no v2 head sparks; the near claw limb fires a slim two-stage piston at chest height whose brass talon tip (a physical claw pixel, the strike's leading pixel) reaches enemy_x %d. A short dim accent streak (palette 'y') sits above/below stage 1 on the sentry side of the gap. Frame 15: piston retracted, claw lowered on the v2 leg, head home." % CLAW_TIP_REL,
            "gait": "frames 4-11: v2 distance lock (8 steps of 4 px, stance feet +4 px per step), with both near feet stroking 6 px either side of their idle spot (v2 near-front 0..+12, near-rear -12..0), and each pair landing one step earlier so the first gait frame has the near-front foot 2 px from its idle spot",
            "windupLens": "frames 12-13: the v3 lens paint, unchanged (equal to the v3 cells)",
            "defeatShadow": "frames 18-20: a flat, undithered contact shadow in palette 'o' (floor row 60 between the feet, row 61, and a shorter row 62) replaces the v3 Bayer dither; only transparent pixels are filled",
            "identicalToV2": IDENTICAL_TO_V2,
            "identicalToV3": IDENTICAL_TO_V3,
        },
        "pixelClasses": {
            "note": "cell coordinates of frame 14 pixels by class, so captures can tell the physical claw from the effect accent",
            "frame14ClawStage2AndTalon": [list(p) for p in classes[14]["claw"]],
            "frame14EffectAccent": [list(p) for p in classes[14]["accent"]],
            "defeatShadow": {str(i): [list(p) for p in classes[i]["shadow"]] for i in SHADOW},
        },
        "rowRule": "row 60 is the last opaque body row of every frame; only the defeat shadow uses rows 61-62",
        "gaitLock": report["gaitLock"],
        "plantedFootOffsetFromIdlePx": report["plantedFootOffsetFromIdlePx"],
        "clawLeadRelEnemyX": report["clawLeadRelEnemyX"],
        "heroOverlayEstimate": {"note": "python overlay of the male hero hit frames against the cells (pre-Godot estimate; the capture test measures real renders)", **report["heroOverlayEstimate"]},
        "lensUnderWindupTint": report["lens"],
        "defeatShadow": report["shadow"],
        "frameReport": report["frames"],
        "frameFiles": [{"index": i, "state": FRAMES[i][0], "file": rel(p), "sha256": sha(p)} for i, p in enumerate(frame_files)],
        "palette": PALETTE,
        "alphaValues": [0, 255],
        "method": "The v3 author (and through it the v2 author and the static pilot author) is imported unchanged for the rig, poses, palette, compositor and v3 lens paint; its canvas globals are widened to the v4 cell. v4 re-poses the gait (stance x only), re-poses the strike with an explicit claw-arm part and explicitly placed rod/talon/accent pixels, and adds explicit shadow pixels. No image is read, traced, resampled, resized or generated by AI (the hero frames are read only to measure overlap).",
        "authorScript": rel(script),
        "authorScriptSha256": sha(script),
        "v3AuthorScript": rel(V3_AUTHOR),
        "v3AuthorScriptSha256": sha(V3_AUTHOR),
        "previews": "none here: no contact sheet, collage or GIF; review uses separate real 1280x720 Godot captures and a Godot-render loop GIF",
        "scope": "sentry enemy only; candidate asset, not referenced by battle_arena.gd",
        "createdAt": datetime.now().isoformat(timespec="seconds"),
    }
    mpath.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(path)
    print(mpath)
    print(fdir)
    print("sha256", manifest["sha256"], "strip", strip.size)
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
