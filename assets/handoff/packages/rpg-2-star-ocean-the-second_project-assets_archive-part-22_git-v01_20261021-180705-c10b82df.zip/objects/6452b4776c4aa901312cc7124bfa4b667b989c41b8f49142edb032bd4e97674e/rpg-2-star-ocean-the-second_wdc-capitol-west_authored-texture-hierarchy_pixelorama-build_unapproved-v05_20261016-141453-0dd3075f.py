"""UNAPPROVED / NONRUNTIME v05 candidate of the Washington (U.S. Capitol west grounds) exploration scene: an
authored-texture and visual-hierarchy pass over the v04 scene (run wdc-capitol-west-v04_20261016-004457-a17af0a6).

Deterministic Python tool authored and run by Claude (Claude Code, Opus 5.5, claude.ai Max firstParty). It writes ONE
1280x720 pixel-art exploration scene from the same fixed 47-colour palette as v04 into a 13-layer stack. The output is
a native Pixelorama .pxo (pxo_version 7), an .ora, a flattened PNG, a walkability JSON and a manifest. Nothing here is
accepted art, and nothing is wired into the game runtime.

SOURCE. v04 is the source and is never modified. This tool loads the v04 build tool read-only (its text sha256 is
pinned below; any change to it stops the build), reuses its geometry, collision, collars, Y-sort sprites, props and
gates, and replaces the parts the 2026-10-16 Codex review of v04 called repetitive, procedural, planar and without
hierarchy. `check` re-hashes the six v04 candidate files and the v04 tool.

AUTHORING ROUTE. This is NOT a Pixelorama GUI paint pass. No desktop or computer-use access to the Pixelorama GUI was
available in this session, so the art is set down by this tool. The v05 changes are hand-written tables
(LAWN_FORMS, SWALES, DESIRE_LINES, RUTS, DRY_MEADOWS, RUSH_BEDS, BURN_SCAR, SOIL_CORES, LITTER_DRIFTS, STREAKS,
DAMP_BANDS, IVY, FIRE_BREACH, CHIP_FANS, NEAR_CANOPIES, FRONDS, SHADE_POOLS) turned into pixels by v05 painters:
  * lawn: a hand-placed relief (knolls, hollows, swales, tussock domes) lit from the upper left and quantised into
    calm tone bands. Band and material edges are cut as grass-blade teeth, so the nearer (lower) sward overlaps the
    farther one. This replaces v04's even blade dither and uniform tuft scatter.
  * terrain-patches (new layer): worn desire lines with pebbles and grass islands, a handcart's twin ruts to the
    survey post, uncut seed-head meadow, rush beds in the wet hollows, a burn scar, survey soil cores, leaf drifts and
    a mossy wall-foot bed.
  * facade light: front faces (West Front, balustrade, terrace wall) sit one value step under the lit tops (deck,
    treads, lawn); lit ledge lips keep their highlight.
  * facade-weathering (new layer): hand-placed rain and soot streaks (v04's per-column random streaks are removed),
    rising damp, ivy as massed curtains with lobed hems (v04's thin vine strings are removed), and a fire breach in
    the south wing above the collapse.
  * cast shadows are projected from the actual silhouettes (tree crowns, trunks, props, rubble, the survey post,
    newels) with a dark contact line, so the post no longer drops detached ovals.
  * depth framing: dark near-camera crowns enter the bottom corners, low fronds sit on the bottom edge (never on the
    axial walk), and their shade pools darken the frame foot so the eye travels up the axis to the stairs.
  * v04's random pale chip scatter is replaced by mid-tone chip fans at the ruin edges only.
Camera, scale (48 px heroine), walkable mask, pins, collars, Y-sort pivots and props are v04's.

Every file this tool writes is named <project slug>_<area>_<purpose>_unapproved-v05_<stamp>-<run id>.<ext>. Each QA
view is a separate image; no combined collage or comparison image is made.

Modes
  preview <dir>   render everything into <dir> (outside the repo); writes nothing in the repo
  build           write candidate files (game/assets/environments/candidates/<RUN>/) and QA previews (outputs/<RUN>/);
                  refuses to overwrite a different existing file
  check           technical gates on the built files, plus (unless switched off) Pixelorama 1.2.3 headless
                  flat/--split-layers exports of temp copies with APPDATA redirected, and a throwaway Godot project in
                  temp for layer loading, runtime-stack stills, 640x360 camera windows and a physics collision probe.
                  --write-report writes the JSON report and evidence PNGs into outputs/<RUN>/ (never overwrites).

Run: python -I -B <this file> preview <tempdir> | build | check [--write-report] [--no-pixelorama] [--no-godot]
"""
import argparse, hashlib, importlib.util, io, json, math, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image

sys.dont_write_bytecode = True                     # importing the v04 tool must not leave a __pycache__ in tools/

_HERE = os.path.dirname(os.path.abspath(__file__))
V04_TOOL_REL = ("tools/rpg-2-star-ocean-the-second_washington-capitol_west-grounds-scene-candidate_pixelorama-build_"
                "unapproved-v04_20261016-004457-a17af0a6.py")
V04_TOOL_SHA256_TEXT_LF = "a473df85717616c8a9bdb6c2b10ef5eb0a757085207a14279dc9e6bcc1bb0be5"


def _load_v04():
    p = os.path.abspath(os.path.join(_HERE, "..", *V04_TOOL_REL.split("/")))
    with open(p, "rb") as f:
        b = f.read()
    if hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest() != V04_TOOL_SHA256_TEXT_LF:
        raise SystemExit("the v04 source tool changed; v05 is pinned to text sha256 " + V04_TOOL_SHA256_TEXT_LF)
    spec = importlib.util.spec_from_file_location("wdc_cw_v04_tool", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


v4 = _load_v04()
globals().update({k: v for k, v in vars(v4).items() if not k.startswith("__")})

# ============================================================================ v05 identity (patched into v04 too)
VER = "unapproved-v05"
STAMP = "20261016-141453"
RUN_ID = "0dd3075f"
RUN = f"wdc-cw-v05t_{STAMP}-{RUN_ID}"
V04_RUN = "wdc-capitol-west-v04_20261016-004457-a17af0a6"
CAND_REL = f"game/assets/environments/candidates/{RUN}"
OUT_REL = f"outputs/{RUN}"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))
EXPORT_STEM = f"{SLUG}_{AREA}_pixelorama-export_{VER}_{STAMP}-{RUN_ID}"
DT = (2026, 10, 16, 14, 14, 52)
LAYERS = ["ground-base", "terrain-patches", "paving-walks", "terrace-walls", "facade-weathering", "ground-detail",
          "cast-shadows", "props-low", "stair-lamps-ysort", "fountain-ysort", "survey-post", "fg-occlusion",
          "guides"]                                                                # bottom -> top
ART_LAYERS = LAYERS[:12]                                                           # guides: hidden, locked
BASE_LAYERS = LAYERS[:8]                                                           # merged into one base at runtime
for _k in ("VER", "STAMP", "RUN_ID", "RUN", "CAND_REL", "OUT_REL", "TOOL_REL", "EXPORT_STEM", "DT", "LAYERS",
           "ART_LAYERS", "BASE_LAYERS"):
    setattr(v4, _k, globals()[_k])

V04_CAND_REL = f"game/assets/environments/candidates/{V04_RUN}"
V04_OUT_REL = f"outputs/{V04_RUN}"
V04_SHA256 = {  # bytes, hashed 2026-10-16 14:14 before any v05 work
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-editable-11layer_unapproved-v04_20261016-004457-a17af0a6.ora":
        "640225cbfc5e51d13e257d3f0315227411b375c4118f903a38dc36565d1ab0a2",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-editable-11layer_unapproved-v04_20261016-004457-a17af0a6.pxo":
        "d440328c701e793818900dd933afeb091332a0f4bc2b82552e2a3ff0bcf87c2e",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-flat-art_unapproved-v04_20261016-004457-a17af0a6.png":
        "3dd46a8422a97a8dfc4f0e905770b1ba24e526c312042917f166a693a742ab91",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-manifest_unapproved-v04_20261016-004457-a17af0a6.json":
        "5a2e557d14425f382352c5295e9a84a0dc8f412abc9a138faca314a9c25bbabc",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-palette_unapproved-v04_20261016-004457-a17af0a6.gpl":
        "16679b800d34703365601f4795cc8248b34769267dacecbebe683fac2df9e12f",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-walkability_unapproved-v04_20261016-004457-a17af0a6.json":
        "3eba0e326cdbab16955152fb48d0a88c26bcfc5254cb0d0b9e6908b8d74d7dc5",
}
V04_FLAT_NAME = "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-flat-art_unapproved-v04_20261016-004457-a17af0a6.png"

LIGHT = np.array([-0.62, -0.5, 0.6]); LIGHT = LIGHT / np.linalg.norm(LIGHT)   # upper-left key, as v04's arrises
SUN_X, SUN_Y = 0.55, 0.26          # ground shadow offset per px of height (lower right, as v04's shadow ellipses)

# ============================================================================ v05 hand-authored tables
# Positions in logical px, top = east (Capitol), bottom = west. Every entry below was written by hand for v05.

# --- lawn relief (feeds the light; +height = rise, -height = hollow) ----------------------------------------------
LAWN_FORMS = [  # (cx, cy, rx, ry, height px, material)
    (812, 470, 72, 30, 9.0, "dry"),       # right-panel knoll: sun-dried crown beside the survey flag grid
    (522, 636, 54, 20, 5.0, "dry"),       # low rise south of the left quadrat
    (176, 296, 46, 18, 4.0, "dry"),       # north strip crown in front of the slump
    (330, 434, 52, 20, -5.0, "damp"),     # left-panel hollow that holds rain: rushes
    (300, 696, 76, 26, -6.0, "damp"),     # foot hollow beside the left walk
    (968, 608, 56, 22, -5.0, "damp"),     # the uprooted oak's pit drains into this
    (1104, 302, 40, 16, -3.0, "damp"),    # wet foot of the collapse spill
    (744, 682, 44, 16, 3.0, "normal"),
    (430, 562, 40, 16, 2.5, "normal"),
    (900, 380, 34, 14, 2.0, "normal"),
]
SWALES = [  # (cubic Bezier control points, half width, depth px): shallow drainage channels
    ([(706, 384), (748, 470), (842, 556), (936, 640)], 15, 3.5),
    ([(252, 470), (292, 560), (318, 640), (332, 720)], 13, 3.0),
]
PANEL_CROWNS = [(430, 150, 6.0), (858, 160, 6.0)]   # (centre x, half width, height): lawn panels are crowned

# --- terrain patches -----------------------------------------------------------------------------------------------
DESIRE_LINES = [  # (cubic Bezier, half width, wear 0..1): where boots have worn the sward to soil
    ([(548, 354), (530, 392), (512, 430), (478, 470)], 4.5, 1.0),   # forecourt -> survey post (the crew's track)
    ([(430, 500), (404, 532), (392, 566), (384, 606)], 3.0, 0.7),   # post -> lower patrol loop
    ([(372, 650), (430, 684), (520, 690), (598, 672)], 2.6, 0.5),   # loop -> back onto the axis
    ([(905, 300), (906, 288), (908, 274), (912, 262)], 2.6, 0.7),   # forecourt end -> collapse sensors
    ([(682, 418), (700, 414), (720, 412), (742, 414)], 2.0, 0.45),  # axis -> flag grid
    ([(1054, 504), (1048, 510), (1042, 516), (1036, 524)], 2.4, 0.6),  # right walk -> look at the root plate
]
RUTS = ([(244, 404), (300, 420), (372, 452), (420, 478)], 4.5)       # survey handcart: centre curve, half gauge
RUT_MUD = (0.52, 0.7)                                                # dried puddle along this stretch of the ruts
DRY_MEADOWS = [  # (cx, cy, rx, ry, kind): uncut grass. tussock = dense standing clump with a shaded front;
    # drift = long low band along a walk edge; seedheads = flowering grass heads standing in the sward, no clump
    (282, 600, 30, 20, "tussock"), (150, 292, 36, 13, "tussock"), (1016, 652, 44, 9, "drift"),
    (1186, 292, 40, 8, "drift"), (814, 462, 50, 16, "seedheads"), (560, 548, 26, 11, "seedheads"),
    (726, 610, 20, 8, "seedheads")]
RUSH_BEDS = [(330, 438, 30, 11), (300, 700, 40, 13), (966, 612, 30, 11), (1104, 306, 18, 7), (842, 560, 16, 7)]
BURN_SCAR = (902, 446, 30, 13)             # something burned on the lawn here (game fiction), already regrowing
SOIL_CORES = [(548, 604), (559, 608), (570, 611), (581, 615)]       # survey soil-core holes with their lifted plugs
LITTER_DRIFTS = [  # (cx, cy, rx, ry): leaf litter blown against belt margins and under specific crowns
    (236, 362, 26, 9), (178, 468, 30, 11), (206, 640, 24, 9), (1112, 420, 30, 11), (1100, 560, 26, 9),
    (1122, 702, 30, 9), (96, 600, 40, 14), (1196, 520, 40, 14), (62, 390, 34, 12), (1220, 640, 34, 12),
    (980, 548, 20, 7)]

# --- facade --------------------------------------------------------------------------------------------------------
STREAKS = [  # (kind, x, y0, length, width): rain runs from sills and courses, soot, rust from iron cramps
    ("rain", 20, 31, 6, 1), ("rain", 66, 31, 9, 2), ("rain", 300, 31, 5, 1), ("rain", 344, 31, 11, 2),
    ("rain", 432, 31, 7, 1), ("rain", 851, 31, 12, 2), ("rain", 983, 31, 8, 2), ("rain", 1175, 31, 10, 1),
    ("rain", 1261, 31, 6, 1),
    ("rain", 44, 40, 22, 2), ("rain", 128, 40, 14, 1), ("rain", 210, 40, 26, 2), ("rain", 286, 40, 9, 1),
    ("rain", 366, 40, 18, 2), ("rain", 455, 40, 12, 1), ("rain", 830, 40, 20, 2), ("rain", 918, 40, 27, 3),
    ("rain", 1160, 40, 16, 1), ("rain", 1250, 40, 24, 2), ("rain", 742, 46, 14, 1), ("rain", 540, 50, 10, 1),
    ("soot", 893, 2, 10, 4), ("soot", 981, 2, 9, 3), ("soot", 1142, 40, 18, 3),
    ("rain", 120, 146, 30, 2), ("rain", 250, 146, 44, 2), ("rain", 300, 146, 18, 1), ("rain", 186, 146, 24, 1),
    ("rain", 60, 146, 36, 2), ("rain", 1186, 146, 40, 2), ("rain", 1144, 146, 22, 1), ("rain", 908, 146, 30, 2),
    ("rust", 190, 160, 22, 1), ("rust", 1206, 168, 16, 1), ("rust", 96, 172, 12, 1),
    ("rain", 560, 132, 26, 1), ("rain", 700, 128, 34, 2), ("rain", 742, 134, 18, 1),
]
ASHLAR_PATCHES = [  # (x, y, w, h, tone): replaced (new, paler) and weathered (dark) blocks, algae-stained courses
    (8, 6, 10, 6, "dark"), (52, 18, 12, 6, "new"), (90, 0, 9, 6, "dark"), (150, 12, 14, 6, "new"),
    (176, 24, 10, 6, "dark"), (236, 6, 12, 6, "new"), (262, 30, 9, 5, "dark"), (330, 12, 10, 6, "dark"),
    (372, 24, 14, 6, "new"), (410, 0, 8, 6, "dark"), (488, 18, 12, 6, "dark"), (530, 6, 10, 6, "new"),
    (566, 24, 9, 6, "dark"), (612, 12, 12, 6, "new"), (668, 0, 10, 6, "dark"), (704, 18, 14, 6, "new"),
    (752, 6, 9, 6, "dark"), (790, 24, 10, 6, "new"), (828, 12, 12, 6, "dark"), (870, 0, 10, 6, "new"),
    (944, 18, 12, 6, "dark"), (1092, 6, 10, 6, "new"), (1120, 24, 12, 6, "dark"), (1160, 12, 9, 6, "new"),
    (1196, 0, 12, 6, "dark"), (1240, 18, 10, 6, "new"), (1270, 30, 8, 5, "dark"),
    (30, 46, 16, 6, "dark"), (118, 52, 14, 6, "green"), (196, 58, 18, 6, "green"), (272, 46, 12, 6, "new"),
    (350, 58, 16, 6, "green"), (444, 52, 12, 6, "dark"), (520, 46, 14, 6, "new"), (600, 58, 20, 6, "green"),
    (690, 52, 12, 6, "dark"), (760, 58, 16, 6, "green"), (842, 46, 12, 6, "new"), (930, 58, 18, 6, "green"),
    (1010, 52, 14, 6, "dark"), (1104, 58, 16, 6, "green"), (1180, 46, 12, 6, "new"), (1252, 52, 14, 6, "dark"),
    (500, 76, 22, 8, "dark"), (590, 80, 16, 6, "new"), (690, 78, 20, 7, "dark"), (760, 82, 14, 5, "new"),
    # central pavilion basement: each arch bay weathered differently
    (476, 40, 12, 6, "dark"), (506, 52, 10, 6, "new"), (548, 40, 14, 6, "green"), (578, 64, 12, 5, "dark"),
    (626, 40, 10, 6, "new"), (650, 64, 14, 5, "green"), (676, 46, 12, 6, "dark"), (722, 40, 10, 6, "new"),
    (742, 64, 12, 5, "dark"), (778, 46, 14, 6, "green"),
    # deck slabs: replaced slabs and old stains
    (470, 92, 18, 8, "dark"), (530, 100, 24, 10, "new"), (610, 94, 16, 8, "dark"), (650, 108, 20, 8, "new"),
    (720, 96, 18, 9, "dark"), (780, 104, 14, 8, "new"), (40, 100, 20, 8, "dark"), (150, 96, 24, 9, "new"),
    (260, 104, 18, 8, "dark"), (330, 98, 16, 8, "new"), (900, 100, 20, 8, "new"), (1180, 96, 22, 9, "dark"),
    (1240, 104, 16, 8, "new"),
    # balustrade runs and the forecourt below the stairs
    (20, 128, 24, 16, "dark"), (180, 128, 20, 16, "green"), (300, 128, 26, 16, "dark"), (1140, 128, 22, 16, "dark"),
    (480, 302, 20, 10, "dark"), (560, 320, 18, 9, "new"), (700, 306, 22, 10, "dark"), (790, 318, 16, 9, "new"),
    (420, 330, 18, 8, "new"), (860, 304, 20, 9, "dark")]
DAMP_BANDS = [  # (x0, x1, base row, max height): rising damp and biofilm at the foot of a face
    (0, 128, 75, 5), (128, 300, 75, 3), (300, 476, 75, 6), (804, 1003, 75, 4), (1151, 1280, 75, 7),
    (0, 110, 219, 12), (110, 222, 219, 8), (222, 334, 219, 5), (334, 390, 219, 14), (889, 945, 219, 9),
    (1113, 1169, 219, 6), (1169, 1225, 219, 10), (1225, 1280, 219, 16)]
IVY = [  # (cx, anchor row, half width, length, limit row, growth): ivy masses built from stems and leaf clusters.
    # "up" climbs from a planted foot; "down" cascades from the deck planting over a coping
    (106, 74, 16, 70, 0, "up"), (24, 74, 9, 34, 0, "up"), (1214, 74, 20, 76, 0, "up"), (1262, 74, 12, 50, 0, "up"),
    (884, 74, 8, 30, 36, "up"), (322, 74, 5, 16, 40, "up"),
    (366, 127, 28, 80, 218, "down"), (140, 127, 11, 38, 218, "down"), (1188, 128, 8, 26, 218, "down"),
    (1252, 218, 24, 84, 126, "up"), (60, 218, 10, 36, 150, "up"),
    (397, 127, 7, 150, 278, "down")]
EXEDRA_IVY = (520, 604, 66)                # cascade over the exedra's shaded left half: x0, x1, max length
FIRE_BREACH = [(1014, 8), (1022, 4), (1031, 6), (1040, 3), (1051, 5), (1060, 9), (1066, 16), (1063, 24), (1066, 31),
               (1052, 34), (1040, 32), (1028, 35), (1016, 31), (1011, 22), (1015, 15)]   # gutted south-wing bay
CHIP_FANS = [  # (x, y, count, spread x, spread y): mid-tone stone chips spat out by the ruins
    (960, 214, 9, 26, 10), (1060, 300, 12, 40, 14), (1132, 270, 6, 14, 10), (190, 236, 7, 18, 8), (880, 290, 5, 12, 8),
    (1020, 100, 6, 20, 6)]

# --- depth framing -------------------------------------------------------------------------------------------------
NEAR_CANOPIES = [(8, 744, 108, 0.74), (1274, 750, 114, 0.66)]    # (cx, cy, r, squash): crowns just in front of camera
FRONDS = [  # (x, base row, height, blades, lean): low foreground grass/fern fronds on the frame's bottom edge
    (300, 719, 18, 7, 0.35), (338, 719, 12, 5, -0.2), (546, 719, 14, 5, 0.3), (742, 719, 15, 6, -0.3),
    (906, 719, 20, 8, 0.25), (952, 719, 11, 4, -0.1), (1000, 719, 9, 4, 0.2)]
SHADE_POOLS = [  # (cx, cy, rx, ry): shade from the near crowns and the belts on the lower lawn
    (150, 712, 170, 40), (1150, 708, 180, 46), (360, 728, 120, 20), (930, 726, 130, 22)]

NEAR = [I[n] for n in ("ink", "f0", "f0", "f1", "f2", "e2")]       # near-camera crowns: dark silhouette, cool rim
LAWN_LUT = {  # material -> colour per tone band 0..4
    "normal": ["g1", "g2", "g3", "g4", "g5"],
    "damp": ["f1", "e2", "g2", "g3", "g4"],
    "dry": ["g2", "g3", "g4", "g5", "g5"],
    "mown": ["g2", "g3", "g4", "g4", "g5"],
    "belt": ["f0", "g0", "g1", "g2", "g3"],
}
MATS = ["normal", "damp", "dry", "mown", "belt"]


# ============================================================================ v05 helpers
LUM = (RGB[:, 0] * 0.2126 + RGB[:, 1] * 0.7152 + RGB[:, 2] * 0.0722) / 255.0


def below(a, k):
    """Array whose row y holds a's row y+k (edge rows repeat)."""
    out = np.empty_like(a)
    out[:H - k] = a[k:]
    out[H - k:] = a[H - 1:]
    return out


def blade_teeth(key, maxlen, band=6):
    """Per-texel blade length for grass-edge teeth: runs of pointed clumps (2-5 px wide, peak 1..maxlen) with gaps;
    each 6-row band has its own run so stacked edges never repeat one pattern."""
    r = rng_for("teeth-v05", key, maxlen, band)
    nb = H // band + 2
    rows = []
    for _ in range(nb):
        out = np.zeros(W + 64, np.int16)
        x = int(r.integers(0, 3))
        while x < W + 64:
            w = int(r.integers(2, 6))
            peak = int(r.integers(max(1, maxlen // 2), maxlen + 1))
            c = (w - 1) / 2.0
            prof = [max(1, int(round(peak * (1 - abs(i - c) / (c + 1.0))))) for i in range(w)]
            out[x:x + w] = prof[:max(0, min(w, W + 64 - x))]
            x += w + int(r.integers(0, 3))
        rows.append(out)
    rows = np.stack(rows)
    shifts = r.integers(0, 64, nb)
    yb = np.arange(H) // band
    return rows[yb[:, None], np.arange(W)[None, :] + shifts[yb][:, None]]


def displace_up(a, teeth, valid):
    """a'(y, x) = a(y + t, x): the nearer (lower) sward's blades overlap the farther one along every boundary."""
    out = a.copy()
    for k in range(1, int(teeth.max()) + 1):
        m = (teeth == k) & valid & below(valid, k)
        out[m] = below(a, k)[m]
    return out


def curve_dist(pts, pad):
    """Distance (px) to a cubic Bezier and the curve parameter 0..1 of the nearest sample, inside its bbox + pad."""
    c, seg = bezier(pts, 700)
    d = np.full((H, W), np.inf, np.float32)
    t = np.zeros((H, W), np.float32)
    x0 = int(max(0, c[:, 0].min() - pad)); x1 = int(min(W, c[:, 0].max() + pad + 1))
    y0 = int(max(0, c[:, 1].min() - pad)); y1 = int(min(H, c[:, 1].max() + pad + 1))
    if x0 >= x1 or y0 >= y1:
        return d, t
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    best = np.full(yy.shape, np.inf, np.float32)
    bt = np.zeros(yy.shape, np.float32)
    for k in range(0, len(c), 3):
        dd = np.hypot(xx - c[k, 0], yy - c[k, 1])
        tk = dd < best
        best[tk] = dd[tk]
        bt[tk] = seg[k] / seg[-1]
    d[y0:y1, x0:x1] = best
    t[y0:y1, x0:x1] = bt
    return d, t


def samples_dist(c, pad):
    """Distance (px) to a dense polyline of samples c (N x 2), inside its bbox + pad."""
    d = np.full((H, W), np.inf, np.float32)
    x0 = int(max(0, c[:, 0].min() - pad)); x1 = int(min(W, c[:, 0].max() + pad + 1))
    y0 = int(max(0, c[:, 1].min() - pad)); y1 = int(min(H, c[:, 1].max() + pad + 1))
    if x0 >= x1 or y0 >= y1:
        return d
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    best = np.full(yy.shape, np.inf, np.float32)
    for k in range(0, len(c), 2):
        np.minimum(best, np.hypot(xx - c[k, 0], yy - c[k, 1]), out=best)
    d[y0:y1, x0:x1] = best
    return d


def blob_e(cx, cy, rx, ry, key, wob=0.35, pad=1.6):
    """Warped-ellipse field (< 1 inside) in a full-frame array (inf outside the bbox): hand blobs get irregular edges."""
    e = np.full((H, W), np.inf, np.float32)
    x0, x1 = int(max(0, cx - rx * pad - 2)), int(min(W, cx + rx * pad + 3))
    y0, y1 = int(max(0, cy - ry * pad - 2)), int(min(H, cy + ry * pad + 3))
    if x0 >= x1 or y0 >= y1:
        return e
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    n1 = vnoise(("blob5", key), 9, y1 - y0, x1 - x0)
    n2 = vnoise(("blob5b", key), 4, y1 - y0, x1 - x0)
    e[y0:y1, x0:x1] = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2 + (n1 - 0.5) * wob + (n2 - 0.5) * wob * 0.35
    return e


def scatter(mask, spacing, key, keep=1.0):
    """Jittered-grid points inside `mask` (one per cell, kept with probability `keep`, which may be a field)."""
    r = rng_for("scatter-v05", key, spacing)
    pts = []
    for gy in range(0, H, spacing):
        for gx in range(0, W, spacing):
            x = gx + int(r.integers(0, spacing)); y = gy + int(r.integers(0, spacing))
            p = keep[min(H - 1, y), min(W - 1, x)] if isinstance(keep, np.ndarray) else keep
            if x < W and y < H and mask[y, x] and r.random() < p:
                pts.append((x, y))
    return pts


def tuft_texels(r, kind):
    """One hand-drawn style grass/rush tuft as (dx, dy, palette name) texels, base at dy = 0. Blades fan out from the
    base and lean; the left (lit) blades are a step lighter; tips carry the kind's head colour."""
    spec = {"seed": (3, 5, 5, 9, ("g2", "g3", "g4", "g5"), "d1"),
            "rush": (4, 6, 6, 10, ("f1", "g1", "e2", "e3"), "d0"),
            "long": (3, 5, 4, 7, ("g2", "g3", "g4", "g5"), "g6"),
            "short": (2, 4, 2, 4, ("g2", "g3", "g4", "g4"), "g5")}[kind]
    nmin, nmax, hmin, hmax, ramp, tip = spec
    n = int(r.integers(nmin, nmax + 1))
    out = []
    for i in range(n):
        bx = i - n // 2
        h = int(r.integers(hmin, hmax + 1))
        lean = (bx * 0.18 + float(r.uniform(-0.25, 0.25))) * (0.4 if kind == "rush" else 1.0)
        lit = 1 if bx < 0 else 0
        for j in range(h):
            x = bx + int(round(lean * (j ** 1.25) / max(1, h ** 0.25)))
            k = min(3, (j * 4) // h + lit)
            out.append((x, -j, ramp[k]))
        if kind == "seed" and r.random() < 0.45:
            x = bx + int(round(lean * ((h - 1) ** 1.25) / max(1, h ** 0.25)))
            out += [(x, -h, tip), (x + 1, -h + 1, "g7"), (x, -h + 1, tip)]
        elif r.random() < 0.3:
            x = bx + int(round(lean * ((h - 1) ** 1.25) / max(1, h ** 0.25)))
            out.append((x, -h, tip))
    return out, n


def paint_tufts(layer, comp, pts, kind, key, mask=None):
    """Draw tufts back to front (north first) so nearer tufts overlap farther ones; each gets a 1-row contact
    shade on the ground under its base."""
    r = rng_for("tufts-v05", key, kind)
    for (x, y) in sorted(pts, key=lambda p: (p[1], p[0])):
        tex, n = tuft_texels(r, kind)
        for i in range(-(n // 2) - 1, n - n // 2 + 1):
            xx, yy = x + i, y + 1
            if 0 <= xx < W and 0 <= yy < H and (mask is None or mask[yy, xx]) and comp[yy, xx] >= 0:
                layer[yy, xx] = SHADE_LUT[comp[yy, xx]]
        for dx, dy, c in tex:
            xx, yy = x + dx, y + dy
            if 0 <= xx < W and 0 <= yy < H and (mask is None or mask[yy, xx]):
                layer[yy, xx] = I[c]


def lut_shift(ramp, d):
    lut = np.arange(len(ALL_PAL), dtype=np.int16)
    for k, v in enumerate(ramp):
        lut[v] = ramp[max(0, min(len(ramp) - 1, k + d))]
    return lut


STONE_DOWN = lut_shift(STONE, -1)


def project_shadow(mask, ground, out, core=None, contact=3):
    """Forward-project texels of a standing object onto the ground: a texel at screen (X, Y) whose column ground
    row is g stands z = g - Y above it, and its shadow lands at (X + SUN_X z, g + SUN_Y z). The lowest `contact`
    rows of every column also mark `core` (the dark contact line under the object)."""
    ys, xs = np.nonzero(mask)
    if not len(ys):
        return
    g = ground[ys, xs].astype(np.float32)
    z = np.maximum(0.0, g - ys)
    sx = np.round(xs + SUN_X * z).astype(int)
    sy = np.round(g + SUN_Y * z).astype(int)
    ok = (sx >= 0) & (sx < W) & (sy >= 0) & (sy < H)
    out[sy[ok], sx[ok]] = True
    # close 1 px gaps left by rounding in the shear
    sx2 = np.round(xs + SUN_X * z + 0.5).astype(int)
    ok2 = (sx2 >= 0) & (sx2 < W) & ok
    out[sy[ok2], sx2[ok2]] = True
    if core is not None:
        c = ok & (z < contact)
        core[sy[c], sx[c]] = True
        core[np.minimum(H - 1, sy[c] + 1), sx[c]] = True


# ============================================================================ the v05 scene
class SceneV05(v4.Scene):
    """v04's scene with the v05 authored passes. Geometry, collision, pins, Y-sort sprites and props are v04's."""

    def build(self):
        self.ground_base()                                      # v04: masks and the deck (lawn repainted below)
        gb0 = self.L["ground-base"].copy()
        self.paving()
        self.terrace()                                          # facade() is the v05 override (no random streaks)
        self.ground_edits = self.L["ground-base"] != gb0        # collapse / slump spill written into ground-base
        self.v5_lawn()
        self.v5_terrain()
        self.trees()
        self.props()
        self.survey_post()
        self.v5_facade_light()
        self.detail()                                           # v05 override
        self.v5_weathering()
        self.v5_fg_frame()
        self.shadows()                                          # v05 override
        self.guides()
        assert (self.L["ground-base"] >= 0).all()
        return self

    # ------------------------------------------------------------------ lawn: relief, light, bands, blade edges
    def v5_relief(self):
        """Height field (px) of the lawn: crowned panels, hand-placed knolls and hollows, swales, root mounds in the
        belts and tussock domes where the grass grows long. Also returns the material map and long-grass weight."""
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        Hh = np.zeros((H, W), np.float32)
        lawn_rows = yy >= FORE[3]
        for cx, hw, ht in PANEL_CROWNS:
            Hh += ht * np.exp(-((xx - cx) / hw) ** 2) * np.clip((yy - FORE[3]) / 90.0, 0, 1) * lawn_rows
        mat = np.zeros((H, W), np.int8)
        for k, (cx, cy, rx, ry, ht, m) in enumerate(LAWN_FORMS):
            e = blob_e(cx, cy, rx, ry, ("form", k), wob=0.4, pad=2.0)
            fall = np.clip(1 - e, 0, 1)
            Hh += ht * fall ** 1.5
            if m != "normal":
                mat[e < 0.7] = MATS.index(m)
        for k, (pts, hw, dep) in enumerate(SWALES):
            d, _ = curve_dist(pts, hw + 4)
            prof = np.clip(1 - d / hw, 0, 1)
            Hh -= dep * prof ** 1.3
        self.mown_v5 = self.mown & (mat == 0)
        mat[self.mown_v5] = MATS.index("mown")
        belt = self.belt
        mat[belt] = MATS.index("belt")
        for (x, y, r, fam, brk, lean) in TREES:                 # root mounds round every trunk
            e = blob_e(x + 3, y + 2, 0.55 * r, 0.3 * r, ("root", x, y), wob=0.5)
            Hh += 3.0 * np.clip(1 - e, 0, 1) ** 1.2
        # long-grass weight: belt margins, walk edges, the wall foot, verges, dry crowns; little on the open sward
        dbelt = dist_coarse(belt)
        near_walk = dist_coarse(self.walk_mask)
        lg = 0.0 + 0.75 * np.clip(1 - dbelt / 34.0, 0, 1) * ~belt + 0.5 * np.clip(1 - near_walk / 8.0, 0, 1)
        lg += 0.55 * np.clip(1 - (yy - FOOT_Y) / 28.0, 0, 1) * (yy >= FOOT_Y)
        lg += 0.6 * self.meadow
        lg[self.mown_v5] = 0.0
        lg = np.clip(lg, 0, 1)
        r = rng_for("tussock-v05")
        tus = np.zeros((H, W), np.float32)
        for gy in range(FOOT_Y, H + 12, 11):
            for gx in range(-6, W + 6, 13):
                cx = gx + float(r.uniform(-4, 4)); cy = gy + float(r.uniform(-3, 3))
                ix, iy = int(min(W - 1, max(0, cx))), int(min(H - 1, max(0, cy)))
                w_ = lg[iy, ix]
                if w_ < 0.32 or r.random() > 0.3 + 0.7 * w_ or self.mown[iy, ix]:
                    continue
                rx = float(r.uniform(4.0, 7.5)) * (0.6 + 0.6 * w_)
                ry = rx * float(r.uniform(0.5, 0.7))
                x0, x1 = int(max(0, cx - rx - 1)), int(min(W, cx + rx + 2))
                y0, y1 = int(max(0, cy - ry - 1)), int(min(H, cy + ry + 2))
                if x0 >= x1 or y0 >= y1:
                    continue
                Y, X = np.mgrid[y0:y1, x0:x1].astype(np.float32)
                d2 = ((X - cx) / rx) ** 2 + ((Y - cy) / ry) ** 2
                dome = np.sqrt(np.clip(1 - d2, 0, 1)) * rx * 0.7 * (0.55 + w_)
                sub = tus[y0:y1, x0:x1]
                np.maximum(sub, dome, out=sub)
        Hh += tus
        return Hh, mat, lg

    def v5_lawn(self):
        g = self.L["ground-base"]
        yy, xx = np.mgrid[0:H, 0:W]
        Hh, mat, lg = self.v5_relief()
        self.relief, self.mat, self.long_grass = Hh, mat, lg
        gy_, gx_ = np.gradient(Hh)
        n = np.sqrt(gx_ ** 2 + gy_ ** 2 + 1)
        shade = (-gx_ * LIGHT[0] - gy_ * LIGHT[1] + LIGHT[2]) / n - LIGHT[2]
        f = 0.5 + 1.9 * shade
        # value hierarchy: the frame foot and the belt margins sit lower; the lawn below the forecourt is brightest
        f -= 0.10 * np.clip((yy - 440) / 280.0, 0, 1) ** 1.2
        f += 0.06 * np.clip(1 - (yy - FORE[3]) / 90.0, 0, 1) * (yy >= FORE[3])
        dbelt = dist_coarse(self.belt)
        f -= 0.07 * np.clip(1 - dbelt / 40.0, 0, 1) * ~self.belt
        f += (vnoise("lawn-v05-broad", 180) - 0.5) * 0.08
        # sward patches: large irregular clumps (16-24 px) so tone edges wander as patches, not contour rings
        f += (vnoise("lawn-v05-clump", 20) - 0.5) * 0.16 + (vnoise("lawn-v05-clump2", 8) - 0.5) * 0.05
        belt = self.belt
        f[belt] = 0.42 + 1.6 * shade[belt] + (vnoise("belt-v05", 60)[belt] - 0.5) * 0.18
        B = np.digitize(f, [0.18, 0.37, 0.63, 0.8]).astype(np.int16)
        region = (yy >= FOOT_Y) & ~self.ground_edits
        maxlen = np.choose(mat.astype(np.int64), [4, 4, 5, 1, 3]).astype(np.int16)
        maxlen = np.maximum(maxlen, (lg * 5).astype(np.int16)) * (mat != MATS.index("mown"))
        maxlen[mat == MATS.index("mown")] = 1
        T6 = blade_teeth("lawn", 6)
        teeth = np.minimum(T6, maxlen).astype(np.int16)
        code = mat.astype(np.int16) * 8 + B
        code = displace_up(code, teeth, region)
        code = despeckle(code, 2, valid=region)
        lut = np.zeros(len(MATS) * 8, np.int16)
        for mi, mname in enumerate(MATS):
            for b, cname in enumerate(LAWN_LUT[mname]):
                lut[mi * 8 + b] = I[cname]
        col = lut[code]
        g[region] = col[region]
        self.lawn_code = np.where(region, code, -1)

    # ------------------------------------------------------------------ terrain-patches layer
    def v5_terrain(self):
        t = self.L["terrain-patches"]
        gb = self.L["ground-base"]
        walk = self.walk_mask
        tw = self.L["terrace-walls"]
        yy, xx = np.mgrid[0:H, 0:W]
        ground = (yy >= FOOT_Y) & ~walk & (tw < 0) & ~self.ground_edits
        self.terrain_patch_area = {}

        def area(name, m):
            self.terrain_patch_area[name] = self.terrain_patch_area.get(name, 0) + int(m.sum())

        # wall-foot bed: dark soil with moss cushions and dead leaves (was a noise strip in v04)
        strip = (yy >= FOOT_Y) & (yy < FOOT_Y + 13 + (vnoise("bed-v05", 7) * 4).astype(int)) & ground
        for sx0, sx1 in STAIRS:
            strip &= ~((xx >= sx0 - CHEEK_W - 2) & (xx <= sx1 + CHEEK_W + 2))
        strip &= ~((xx >= EXEDRA[0]) & (xx <= EXEDRA[1]))
        bn = vnoise("bedtone-v05", 5)
        t[strip] = np.where(bn[strip] < 0.45, I["s0"], I["s1"])
        moss = strip & (vnoise("bedmoss-v05", 4) > 0.6)
        moss = majority(moss, 1, 1) & strip
        t[moss] = I["e2"]
        t[moss & ~below(moss, 1)] = I["f1"]
        t[moss & ~np.roll(moss, 1, 0)] = I["e3"]
        area("wall_foot_bed", strip)
        # leaf-litter drifts: overlapping 2-3 px leaves (warm browns) thickening toward each drift's core
        lit_m = np.zeros((H, W), bool)
        for k, (cx, cy, rx, ry) in enumerate(LITTER_DRIFTS):
            e = blob_e(cx, cy, rx, ry, ("litter", k), wob=0.6)
            lit_m |= (e < 1.2) & (ground | self.belt)
        r = rng_for("litter-v05")
        ys, xs = np.nonzero(lit_m)
        for i in r.permutation(len(ys))[: len(ys) // 7]:
            y, x = int(ys[i]), int(xs[i])
            a, b = (("s2", "s3"), ("o0", "s2"), ("s1", "s2"), ("d1", "s3"), ("s3", "s4"))[int(r.integers(0, 5))]
            t[y, x] = I[a]
            if x + 1 < W and lit_m[y, x + 1]:
                t[y, x + 1] = I[b]
            if y + 1 < H and lit_m[y + 1, x] and t[y + 1, x] < 0:
                t[y + 1, x] = SHADE_LUT[gb[y + 1, x]]
        area("leaf_litter", lit_m)
        # worn desire lines: soil core with a lit crown, a shaded lower edge, pebbles with contact shade, grass
        # islands, and a fringe of trampled olive sward
        worn = np.zeros((H, W), bool); crown = np.zeros((H, W), bool); fringe = np.zeros((H, W), bool)
        wobble = vnoise("desire-w-v05", 7)
        for k, (pts, hw, wear) in enumerate(DESIRE_LINES):
            d, tt = curve_dist(pts, hw + 8)
            taper = np.clip(np.minimum(tt, 1 - tt) / 0.12, 0.35, 1)
            w_ = hw * taper * (0.8 + 0.45 * wobble)
            worn |= (d < w_) & ground
            crown |= (d < w_ * 0.45) & (wear > 0.55) & ground
            fringe |= (d >= w_) & (d < w_ + 2.5 + 2 * wear) & ground
        # the survey post apron (boots, crates) and the bench-front scuffs from v04's scuff list
        px, py = POST
        e = blob_e(px, py - 3, 38, 16, "apron", wob=0.5)
        worn |= (e < 1) & ground
        crown |= (e < 0.4) & ground
        fringe |= (e >= 1) & (e < 1.7) & ground
        for k, (cx, cy, rx, ry) in enumerate(scuff_list()):
            e = blob_e(cx, cy, rx * 1.1, ry * 1.2, ("scuff", k), wob=0.6)
            worn |= (e < 0.85) & ground
            fringe |= (e >= 0.85) & (e < 1.5) & ground
        worn = majority(worn, 1, 1) & ground
        fringe &= ~worn
        fr_teeth = blade_teeth("fringe", 3)
        fr = displace_up(fringe.astype(np.int8), fr_teeth, ground).astype(bool)
        t[fr & ~worn] = np.where(gb[fr & ~worn] == I["g2"], I["d0"],
                                 np.where((xx + yy // 2)[fr & ~worn] % 5 == 0, I["d1"], I["d0"]))
        t[worn] = I["s2"]
        t[worn & crown] = I["s3"]
        lower_edge = worn & ~below(worn, 1)
        t[lower_edge] = I["s1"]
        t[worn & ~np.roll(worn, 1, 0) & (xx % 3 != 0)] = I["s1"]       # broken upper bank line
        r = rng_for("pebbles-v05")
        for (x, y) in scatter(worn, 6, "pebble", keep=0.55):
            if worn[y, x] and x + 1 < W and y + 1 < H:
                t[y, x] = I["m2"]; t[y, x + 1] = I["m1"] if r.random() < 0.6 else I["m2"]
                t[y + 1, x] = I["s0"]; t[y + 1, x + 1] = I["s0"]
                if r.random() < 0.3 and y > 0:
                    t[y - 1, x] = I["m3"]
        for (x, y) in scatter(worn & ~crown, 9, "island", keep=0.35):
            for (i, j, c) in ((0, 0, "g3"), (1, 0, "g3"), (-1, 1, "g2"), (0, 1, "g2"), (1, 1, "g2"), (0, -1, "g4"),
                              (2, 1, "s1")):
                if 0 <= x + i < W and 0 <= y + j < H and worn[y + j, x + i]:
                    t[y + j, x + i] = I[c]
        area("worn_earth", worn); area("trampled_fringe", fr & ~worn)
        self.worn = worn
        # handcart ruts from the left walk to the post: twin compacted tracks with crushed sward between them and a
        # dried puddle where the ground dips
        pts, half = RUTS
        d, tt = curve_dist(pts, half + 6)
        c, _ = bezier(pts, 700)
        tang = np.gradient(c, axis=0); tang /= np.linalg.norm(tang, axis=1, keepdims=True)
        between = (d < half - 1.2) & ground & ~worn
        t[between & ((xx * 3 + yy) % 4 != 0)] = I["d0"]
        rut = np.zeros((H, W), bool)
        for side in (-1, 1):
            off = c + np.stack([-tang[:, 1], tang[:, 0]], 1) * side * half
            dr = samples_dist(off, 4)
            rut |= (dr < 1.1) & ground
        t[rut] = I["s1"]
        t[rut & ~below(rut, 1)] = I["s0"]
        t[rut & ~np.roll(rut, 1, 0)] = I["s2"]
        mud = (d < half + 2.5) & (tt > RUT_MUD[0]) & (tt < RUT_MUD[1]) & ground & ~worn
        mud &= blob_e(*c[int(0.61 * 699)], 15, 6, "mud", wob=0.5) < 1
        t[mud] = I["s1"]
        crack = mud & ((np.abs((xx - yy * 2) % 9) < 1) | (np.abs((xx + yy) % 11) < 1))
        t[crack] = I["s0"]
        t[mud & ~np.roll(mud, 1, 0)] = I["s3"]
        area("handcart_ruts", rut | between); area("dried_puddle", mud)
        # burn scar (game fiction): charred core with ash, a scorched ring, green regrowth pushing through
        bx, by, brx, bry = BURN_SCAR
        e = blob_e(bx, by, brx, bry, "burn", wob=0.7)
        core = (e < 0.55) & ground
        ring = (e >= 0.55) & (e < 1.0) & ground
        scorch = (e >= 1.0) & (e < 1.45) & ground
        t[scorch] = np.where(vnoise("burn-s", 4)[scorch] > 0.55, I["d0"], I["s2"])
        t[ring] = np.where(vnoise("burn-r", 3)[ring] > 0.55, I["s0"], I["s1"])
        t[core] = np.where(vnoise("burn-c0", 4)[core] > 0.5, I["s0"], I["s1"])
        ash = core & (vnoise("burn-c", 3) > 0.62)
        t[majority(ash, 1, 1) & core] = I["m1"]
        for (x, y) in scatter(core, 6, "char", keep=0.5):        # charred sticks: short dark strokes
            for i in range(3):
                if core[y, min(W - 1, x + i)]:
                    t[y, x + i] = I["ink"] if i < 2 else I["s0"]
        for (x, y) in scatter(core | ring, 5, "regrow", keep=0.5):
            for (i, j, c_) in ((0, 0, "g3"), (0, -1, "g4"), (1, 0, "g2"), (-1, 0, "g2")):
                if 0 <= x + i < W and 0 <= y + j < H:
                    t[y + j, x + i] = I[c_]
        area("burn_scar", core | ring | scorch)
        # survey soil cores beside the left quadrat: a neat row of holes, each plug lifted out and laid beside it
        for (x, y) in SOIL_CORES:
            for (i, j, c_) in ((0, 0, "ink"), (1, 0, "s0"), (0, 1, "s0"), (1, 1, "s0"), (-1, 0, "s1"), (2, 0, "s2"),
                               (3, -2, "s3"), (4, -2, "s2"), (3, -1, "s1"), (4, -1, "s1"), (3, -3, "g3"),
                               (4, -3, "g4")):
                setpx(t, x + i, y + j, I[c_])
        self.terrain_patch_area["soil_cores"] = 12 * len(SOIL_CORES)
        # uncut seed-head meadow and rush beds: dense overlapping tufts, drawn back to front
        comp = composite_idx(self.L, ["ground-base", "terrain-patches"])
        meadow = np.zeros((H, W), bool)
        heads = np.zeros((H, W), bool)
        for k, (cx, cy, rx, ry, kind) in enumerate(DRY_MEADOWS):
            m_ = (blob_e(cx, cy, rx, ry, ("meadow", k), wob=0.5 if kind != "drift" else 0.9) < 1) & ground & ~worn
            if kind == "seedheads":
                heads |= m_
            else:
                meadow |= m_
        base = meadow & ~below(meadow, 2)                         # the clump's front: a shaded band under the stems
        t[meadow] = np.where(((xx * 7 + yy * 3) % 5 == 0)[meadow], I["g2"], I["g3"])
        t[base] = I["g1"]
        paint_tufts(t, comp, scatter(meadow, 4, "meadow-pts", keep=0.85), "seed", "meadow", mask=ground)
        r = rng_for("seedheads-v05")
        for (x, y) in scatter(heads, 5, "head-pts", keep=0.5):     # heads only: a stalk and a 2-3 px head
            if heads[y, x] and y > 6:
                hh = int(r.integers(2, 6)); lean = int(r.integers(-1, 2))
                for j in range(1, hh):
                    t[y - j, min(W - 1, max(0, x + (lean if j > hh // 2 else 0)))] = I["g3"] if j < hh - 1 else I["d0"]
                hx = min(W - 2, max(0, x + lean))
                t[y - hh, hx] = I["d1"]
                if r.random() < 0.6:
                    t[y - hh + int(r.integers(0, 2)), hx + 1] = I["g7"] if r.random() < 0.4 else I["d1"]
                t[y, x] = SHADE_LUT[gb[y, x]]
        area("tussock_meadow", meadow); area("flowering_grass_heads", heads)
        self.v5_meadow = meadow
        rush = np.zeros((H, W), bool)
        for k, (cx, cy, rx, ry) in enumerate(RUSH_BEDS):
            rush |= (blob_e(cx, cy, rx, ry, ("rush", k), wob=0.6) < 1) & ground & ~worn
        t[rush] = np.where(((xx * 5 + yy) % 4 == 0)[rush], I["e2"], I["g2"])
        paint_tufts(t, comp, scatter(rush, 4, "rush-pts", keep=0.8), "rush", "rush", mask=ground)
        area("rush_bed", rush)
        self.v5_rush = rush

    # ------------------------------------------------------------------ west front without random streaks
    def facade(self, tw):
        """v04's West Front painter minus its per-column random rain streaks (v05 places streaks by hand in the
        facade-weathering layer)."""
        t = np.zeros((FACADE_Y1, W), np.int16)
        t[:BELT_Y] = self.ashlar_rows(0, BELT_Y, "wing", ch=6)
        for y, c in zip(range(BELT_Y, BASE_Y0), ("m5", "m4", "m3", "m1")):
            t[y, :] = I[c]
        t[BASE_Y0:PLINTH_Y] = self.rusticated_rows(BASE_Y0, PLINTH_Y, "wing")
        for y, c in zip(range(PLINTH_Y, FACADE_Y1), ("m5", "m4", "m3", "m3", "m2", "m1")):
            t[y, :] = I[c]
        tw[:FACADE_Y1, :] = t
        for x in WING_PILASTERS:
            self.pilaster(tw, x, 0, BELT_Y, ("wing", x))
        for (cx, main, ped, base) in FACADE_BAYS:
            self.main_window(tw, cx, main, ped, ("w", cx))
            self.basement_arch(tw, cx, BASE_Y0 + 7, PLINTH_Y - 1, 14, base, ("wb", cx))
        for pi, (s0, s1) in enumerate(SUBP):
            self.wing_pavilion(tw, pi, s0, s1)
        self.central_pavilion(tw)
        for (x, y, w, kind) in FACADE_DAMAGE:
            seg = tw[y:y + 4, x:x + w]
            ok = ~np.isin(seg, [I["k0"], I["k1"], I["ink"], I["k2"]])
            if kind == "missing":
                seg[ok] = I["m1"]
                tw[y, x:x + w] = I["m0"]
                tw[y + 1:y + 4, x] = I["m0"]
                tw[y + 3, x + 1:x + w] = I["m4"]
                tw[y + 1:y + 3, x + 2:x + w - 1] = np.where((np.arange(2)[:, None] + np.arange(w - 3)[None, :]) % 3,
                                                            I["s1"], I["m0"])
            elif kind == "spall":
                seg[ok] = ramp_shift_arr(seg, STONE, -1)[ok]
                tw[y, x + 1:x + w - 1] = I["m1"]
                tw[y + 1, x + 2:x + w - 2] = I["m0"]
                tw[y + 2, x + 2:x + w - 2] = I["m4"]
            else:
                cx = x
                for yy in range(y, min(FACADE_Y1 - 6, y + 18)):
                    tw[yy, cx] = I["ink"]
                    if yy % 3 == 0:
                        cx += 1
        for (sx, hgt, hw) in SCORCH:
            for x in range(sx - hw, sx + hw + 1):
                if not 0 <= x < W or PAV[0] - 2 <= x <= PAV[1] + 2:
                    continue
                u = abs(x - sx) / float(hw + 1)
                ln = int(hgt * (1 - u ** 1.6) * (0.85 + 0.15 * math.sin(x * 0.9)))
                for yv in range(max(0, FACADE_Y1 - 1 - ln), FACADE_Y1 - 1):
                    c = tw[yv, x]
                    if c in (I["m5"], I["m4"], I["m3"], I["m2"]):
                        tw[yv, x] = ramp_shift(c, STONE, -2 if yv > FACADE_Y1 - 1 - ln // 2 else -1)

    # ------------------------------------------------------------------ facade light: faces below tops
    def v5_facade_light(self):
        """Front faces (West Front, balustrade, terrace-wall face, exedra wall) drop one value step on the stone ramp
        so the lit tops (deck, stair treads, lawn) read as horizontal planes in front of them. A lit ledge lip (a pale
        texel over a texel two or more steps darker) keeps its highlight, which sharpens every cornice and sill."""
        tw = self.L["terrace-walls"]
        yy, xx = np.mgrid[0:H, 0:W]
        face = np.zeros((H, W), bool)
        face[:PAV_Y1] = True
        face[EDGE_Y - BAL_H:FOOT_Y] = True
        for sx0, sx1 in STAIRS:                                  # treads and landings are tops: leave them lit
            face[EDGE_Y - BAL_H:STAIR_BOT + 1, sx0:sx1 + 1] = False
        face &= ~self.piece_mask & ~self.fixture_mask & ~self.fountain_mask
        face &= ~((xx >= COLLAPSE[0]) & (xx <= COLLAPSE[1]) & (yy >= EDGE_Y - BAL_H - 24))
        rank = np.full(len(ALL_PAL), -9, np.int16)
        for k, v in enumerate(STONE):
            rank[v] = k
        r0 = np.where(tw >= 0, rank[np.maximum(tw, 0)], -9)
        r1 = below(r0, 1)
        ledge = np.isin(tw, [I["m4"], I["m5"]]) & (r1 >= 0) & (r1 <= r0 - 2)
        shift = face & np.isin(tw, [I["m2"], I["m3"], I["m4"], I["m5"]]) & ~ledge
        tw[shift] = STONE_DOWN[tw[shift]]
        # broad flat fields (same colour above and below) drop a second step to m3, so the face reads as one
        # shaded plane carrying crisp light lines (arrises, sills, cornice lips) rather than a white sheet
        up_, dn_ = np.roll(tw, 1, 0), below(tw, 1)
        lf_, rt_ = np.roll(tw, 1, 1), np.roll(tw, -1, 1)
        field = face & (tw == I["m4"]) & (up_ == tw) & (dn_ == tw) & (lf_ == tw) & (rt_ == tw) & (yy < PAV_Y1)
        tw[field] = I["m3"]
        shift |= field
        self.face_mask = face
        self.face_shifted = int(shift.sum())

    # ------------------------------------------------------------------ facade-weathering layer
    def v5_weathering(self):
        wl = self.L["facade-weathering"]
        tw = self.L["terrace-walls"]
        comp = composite_idx(self.L, ["ground-base", "terrain-patches", "paving-walks", "terrace-walls"])
        stone = np.isin(comp, STONE) & (tw >= 0)
        r = rng_for("weathering-v05")
        # streaks: each its own length and width, broken at the tail, never a per-column rule
        for (kind, x, y0, ln, w) in STREAKS:
            for j in range(ln):
                y = y0 + j
                if y >= H:
                    break
                tail = j > ln * 0.62
                if tail and (j + x) % 3 == 0:
                    continue
                ww = w - (1 if tail and w > 1 else 0)
                for i in range(ww):
                    xi = x + i
                    if not (0 <= xi < W) or not stone[y, xi]:
                        continue
                    c = comp[y, xi]
                    if kind == "rain":
                        wl[y, xi] = STONE_DOWN[c] if c != I["m1"] else I["m1"]
                    elif kind == "soot":
                        wl[y, xi] = I["k1"] if j < ln * 0.5 else I["m1"]
                    else:
                        wl[y, xi] = I["s2"] if j < ln * 0.4 else I["s3"] if c in (I["m4"], I["m5"]) else I["s2"]
        # hand-placed block repairs and weathering (breaks the identical bay-to-bay rhythm of the courses)
        stone_up = lut_shift(STONE, 1)
        pave_up, pave_down = lut_shift(PAVE, 1), lut_shift(PAVE, -1)
        hard = np.isin(comp, STONE + PAVE)
        hard[FOOT_Y:FORE[1]] = stone[FOOT_Y:FORE[1]]
        hard[FORE[3]:] = False
        for (x, y, w, h, tone) in ASHLAR_PATCHES:
            sub = hard[y:y + h, x:x + w] & (wl[y:y + h, x:x + w] < 0) & ~np.isin(comp[y:y + h, x:x + w],
                                                                                  [I["ink"], I["m0"]])
            c = comp[y:y + h, x:x + w]
            tgt = wl[y:y + h, x:x + w]
            onp = sub & np.isin(c, PAVE) & ~np.isin(c, STONE)
            ons = sub & np.isin(c, [I["m2"], I["m3"], I["m4"], I["m5"]])
            if tone == "new":
                tgt[ons & (c != I["m5"])] = stone_up[c[ons & (c != I["m5"])]]
                tgt[onp] = pave_up[c[onp]]
            else:
                tgt[ons] = STONE_DOWN[c[ons]]
                tgt[onp] = pave_down[c[onp]]
                if tone == "green":
                    jj, ii = np.mgrid[0:h, 0:w]
                    gm = sub & (jj >= h - 2) & ((ii + jj) % 3 != 0)
                    tgt[gm] = np.where((ii[gm] % 4) == 0, I["g1"], I["e2"])
        # soot tongues rising from the broken / scorched window heads (fire went up the face)
        for (x, y0, ln, w) in ((893, 10, 12, 9), (981, 10, 10, 7)):
            for j in range(ln):
                hw = int(w * (1 - j / ln) ** 0.7 / 2)
                for i in range(-hw, hw + 1):
                    y = y0 - j
                    if 0 <= y < H and stone[y, x + i] and ((i + j) % 4 != 0 or j < ln // 2):
                        wl[y, x + i] = I["k1"] if j < ln // 2 else STONE_DOWN[STONE_DOWN[comp[y, x + i]]]
        # rising damp / biofilm: irregular top edge, moss line at the very foot
        for k, (x0, x1, yb, hmax) in enumerate(DAMP_BANDS):
            prof = vnoise(("damp", k), 6, 1, x1 - x0 + 1)[0]
            for i, x in enumerate(range(x0, min(W, x1))):
                hh = int(round(hmax * (0.45 + 0.55 * prof[i])))
                for j in range(hh):
                    y = yb - j
                    if not stone[y, x]:
                        continue
                    if j < 2 and (x + j) % 3 != 1:
                        wl[y, x] = I["e2"] if j == 0 else I["g1"]
                    elif j < hh - 1 or (x % 2 == 0):
                        wl[y, x] = STONE_DOWN[comp[y, x]]
        # ivy: stems with leaf clusters (the exedra cascade follows the curved rim)
        ivy = np.zeros((H, W), bool)
        for k, (cx, anchor, hw, ln, limit, grow) in enumerate(IVY):
            self.ivy_mass(wl, ivy, cx, anchor, hw, ln, limit, grow, ("ivy", k))
        e0, e1, lmax = EXEDRA_IVY
        r = rng_for("exivy-v05")
        for s, x in enumerate(range(e0 + 3, e1 - 2, 6)):
            u = (x - e0) / float(e1 - e0)
            top = self.rim[x] - BAL_H + 2
            ln = int(lmax * (0.45 + 0.55 * math.sin(min(1.0, u * 1.15) * math.pi) ** 0.5) * float(r.uniform(0.7, 1.0)))
            self.ivy_stem(wl, ivy, x + float(r.uniform(-2, 2)), top, min(top + ln, self.floor_y[x] - 2), +1, 2.6,
                          ("exivy", s), lit=0.35)
        # the mass throws a 1 px shadow onto the stone at its lower right
        sh = np.zeros((H, W), bool)
        sh[1:, 1:] = ivy[:-1, :-1]
        sh &= ~ivy & stone & (wl < 0)
        wl[sh] = STONE_DOWN[comp[sh]]
        self.ivy_mask = ivy
        self.v5_breach(wl, comp)
        self.ivy_texels = int(ivy.sum())

    def ivy_leaf(self, layer, ivy, x, y, rc, lit):
        """One leaf cluster: a small squashed disc lit from the upper left (g4 only on the lit rim of upper clusters),
        body g2/g3, the shaded lower-right edge g1."""
        xi, yi = int(round(x)), int(round(y))
        R = int(math.ceil(rc)) + 1
        for j in range(-R, R + 1):
            for i in range(-R, R + 1):
                d = (i / (rc * 1.15)) ** 2 + (j / (rc * 0.85)) ** 2
                if d >= 1:
                    continue
                px_, py_ = xi + i, yi + j
                if not (0 <= px_ < W and 0 <= py_ < H):
                    continue
                v = -(i * 0.7 + j * 0.7) / (rc + 0.5)
                c = I["g1"] if v < -0.45 else I["g2"] if v < 0.15 else I["g3"]
                if v > 0.5 and lit > 0.5 and d > 0.25:
                    c = I["g4"]
                if d > 0.72 and v < -0.2:
                    c = I["f1"]
                layer[py_, px_] = c
                ivy[py_, px_] = True

    def ivy_stem(self, layer, ivy, x, y0, y1, dirn, rc0, key, lit=0.5):
        """A stem running from y0 toward y1 (dirn +1 down / -1 up), wandering sideways, with leaf clusters set
        alternately left and right every 2-4 px; clusters shrink toward the growing tip."""
        r = rng_for("ivystem-v05", key)
        n = abs(int(y1) - int(y0))
        if n < 3:
            return
        dx = 0.0
        y = float(y0)
        t_next = 0
        side = 1 if r.random() < 0.5 else -1
        for t in range(n):
            dx = max(-0.6, min(0.6, dx + float(r.normal(0, 0.18))))
            x += dx * 0.5
            y += dirn
            xi, yi = int(round(x)), int(round(y))
            if 0 <= xi < W and 0 <= yi < H and not ivy[yi, xi]:
                layer[yi, xi] = I["s1"] if t % 5 else I["g1"]
                ivy[yi, xi] = True
            if t >= t_next:
                f = 1 - 0.6 * t / n
                self.ivy_leaf(layer, ivy, x + side * float(r.uniform(1.0, 2.6)), y + float(r.uniform(-1, 1)),
                              max(1.3, rc0 * f * float(r.uniform(0.8, 1.2))), lit * (1.2 - t / n))
                side = -side
                t_next = t + int(r.integers(2, 5))

    def ivy_mass(self, layer, ivy, cx, anchor, hw, ln, limit, grow, key):
        """An ivy mass: several stems from a shared foot (or coping), long in the middle and short at the flanks,
        so the outline is lobed and stone shows between the outer stems."""
        r = rng_for("ivymass-v05", key)
        dirn = -1 if grow == "up" else 1
        ns = max(3, hw // 2)
        for s in range(ns):
            u = (s + 0.5) / ns * 2 - 1 + float(r.uniform(-0.12, 0.12))
            x = cx + u * hw
            L = ln * (1 - u * u) ** 0.6 * float(r.uniform(0.55, 1.05))
            y1 = anchor + dirn * L
            y1 = max(limit, y1) if dirn < 0 else min(limit, y1)
            self.ivy_stem(layer, ivy, x, anchor - dirn * float(r.uniform(0, 2)), y1, dirn,
                          2.4 + 0.9 * (1 - abs(u)), (key, s), lit=0.7 - 0.3 * u)

    def v5_breach(self, wl, comp):
        """Game fiction: one gutted bay of the south wing above the collapse. The hole follows the ashlar courses
        (blocks fall out whole, so its edge steps along the joints); inside, the burnt interior with a fallen floor
        edge and charred joist stubs; the hole's lower and right inner faces catch light; soot stains climb from it
        as solid two-step clusters, never a dither."""
        from PIL import ImageDraw as _D
        im = Image.new("L", (W, H), 0)
        _D.Draw(im).polygon(FIRE_BREACH, fill=255)
        poly = np.array(im) > 0
        hole = np.zeros((H, W), bool)
        r = rng_for("breach-v05")
        loose = []
        for cy0 in range(0, BELT_Y, 6):                               # whole ashlar blocks: in if most is inside
            bx0 = 984 - int(r.integers(0, 9))
            while bx0 < 1094:
                bw = int(r.integers(7, 15))
                blk = poly[cy0:cy0 + 6, bx0:bx0 + bw]
                cov = blk.mean() if blk.size else 0.0
                if cov > 0.45 + float(r.uniform(-0.2, 0.2)):
                    hole[cy0:cy0 + 6, bx0:bx0 + bw] = True
                elif cov > 0.0 and r.random() < 0.35:
                    loose.append((bx0, cy0, bw))
                bx0 += bw
        for (bx0, cy0, bw) in loose:                                  # blocks shaken loose: dark gap, dropped face
            hole[cy0 + 1:cy0 + 3, bx0 + 1:bx0 + bw - 1] = True
        p = np.pad(hole, 1)
        lower_face = hole & ~p[2:, 1:-1]                              # sill of the hole (top face of broken course)
        right_face = hole & ~p[1:-1, 2:]
        top_face = hole & ~p[:-2, 1:-1]
        yy, xx = np.mgrid[0:H, 0:W]
        wl[hole] = I["ink"]
        wl[hole & (yy >= 20) & (yy <= 21)] = I["k0"]                 # the fallen floor's broken edge
        wl[hole & (yy == 19) & ((xx * 7) % 9 != 0)] = I["k1"]
        for (jy, ja, jb) in ((10, 1014, 1030), (11, 1046, 1062), (27, 1024, 1046)):   # charred joist stubs
            seg = hole[jy, ja:jb]
            wl[jy, ja:jb][seg] = I["s0"]
            wl[jy + 1, ja:jb][hole[jy + 1, ja:jb]] = I["ink"]
        for f in (lower_face, below(lower_face, 1) & hole & ~top_face):
            wl[f] = I["m2"]
        wl[lower_face & (xx % 4 == 1)] = I["m3"]
        wl[right_face] = I["m1"]
        wl[top_face] = I["ink"]
        # broken block faces round the rim: lit chipped top-left arrises outside the hole
        rim = np.zeros((H, W), bool)
        rim[:-1] |= hole[1:]; rim[:, :-1] |= hole[:, 1:]
        rim &= ~hole & np.isin(comp, STONE)
        wl[rim] = I["m1"]
        # soot: two solid stain shapes rising from the hole (darker core)
        outer = np.zeros((H, W), bool); inner = np.zeros((H, W), bool)
        for (cx, cy, rx, ry, m_) in ((1040, 0, 40, 12, outer), (1074, 8, 16, 16, outer), (1004, 14, 10, 12, outer),
                                     (1036, 0, 26, 6, inner), (1072, 4, 8, 10, inner), (1008, 6, 5, 8, inner)):
            m_ |= blob_e(cx, cy, rx, ry, ("soot", cx, cy), wob=0.7) < 1
        stain = np.isin(comp, STONE) & ~hole & ~rim
        wl[outer & stain & (wl < 0)] = STONE_DOWN[comp[outer & stain & (wl < 0)]]
        wl[inner & stain] = I["m1"]
        # fallen blocks on the plinth and the deck's back edge below the gap (flat chips, under 3 px)
        for (x, y) in ((1022, 76), (1031, 78), (1046, 77), (1055, 79), (1038, 81)):
            for (i, j, c) in ((0, 0, "m3"), (1, 0, "m3"), (2, 0, "m2"), (0, 1, "m2"), (1, 1, "m1"), (2, 1, "m0"),
                              (3, 1, "s0")):
                wl[y + j, x + i] = I[c]
        self.breach_mask = hole

    # ------------------------------------------------------------------ ground-detail (v04 painter, v05 edits)
    def detail(self):
        """v04's ground-detail painter with v05 edits: tufts follow the authored long-grass weight (none on the mown
        pad, sparse on the open sward) instead of an even scatter; bay ivy strings, the facade vine strings and the
        left cheek strings are gone (ivy is massed in facade-weathering); the random pale chip scatter is replaced by
        mid-tone chip fans at the ruin edges; leaf litter lives in terrain-patches (hand-placed branches stay)."""
        d = self.L["ground-detail"]
        comp = composite_idx(self.L, ["ground-base", "terrain-patches", "paving-walks", "terrace-walls"])
        rng = rng_for("tufts-v04")
        walk = self.walk_mask
        tw = self.L["terrace-walls"]
        yy = np.arange(H)[:, None]
        lawn = ~walk & (yy >= FOOT_Y) & (tw < 0)
        self.lawn = lawn
        near_walk = np.zeros((H, W), bool)
        wm = walk.copy()
        for k in range(1, 9):
            near_walk[k:, :] |= wm[:-k, :]; near_walk[:-k, :] |= wm[k:, :]
            near_walk[:, k:] |= wm[:, :-k]; near_walk[:, :-k] |= wm[:, k:]
        near_walk &= ~walk
        self.near_walk = near_walk
        meadow = self.meadow & lawn
        tp = self.L["terrain-patches"] >= 0
        rv = rng_for("tufts-v05")
        dens = 0.008 + 0.62 * self.long_grass
        for gy in range(FOOT_Y, H, 5):
            for gx in range(0, W, 6):
                x = gx + int(rv.integers(0, 5)); y = gy + int(rv.integers(0, 4))
                if not (0 <= x < W and 0 <= y < H) or not lawn[y, x] or tp[y, x]:
                    continue
                if self.mown_v5[y, x] or rv.random() > dens[y, x]:
                    continue
                tall = (near_walk[y, x] or meadow[y, x] or self.belt[y, x]) and rv.random() < 0.6
                self.tuft(d, comp, x, y, "long" if tall else "short")
        deck_lo = EDGE_Y - BAL_H - 3
        for x in range(2, W - 6, 6):
            if rng.random() < 0.38 and tw[deck_lo, x] < 0:
                self.tuft(d, comp, x, deck_lo - int(rng.integers(0, 3)), "short")
        for x in range(2, W - 6, 9):
            yb = (PAV_Y1 if PAV[0] - 4 <= x <= PAV[1] + 4 else SUBP_Y1 if any(a_ - 1 <= x <= b_ + 1 for a_, b_ in SUBP)
                  else FACADE_Y1) + 1
            if rng.random() < 0.3 and tw[yb, x] < 0:
                self.tuft(d, comp, x, yb + 3, "short")
        gb = self.L["ground-base"]
        for (mx, my, mr) in DECK_MOSS:
            for j in range(-mr, mr + 1):
                for i in range(-mr * 2, mr * 2 + 1):
                    y_, x_ = my + j, mx + i
                    if (i / (2.0 * mr)) ** 2 + (j / float(mr)) ** 2 < 1 and gb[y_, x_] == I["m1"] and tw[y_, x_] < 0:
                        d[y_, x_] = I["g2"] if (i + j) % 3 else I["g3"]
        edge = np.zeros((H, W), bool)
        for k in (1, 2, 3):
            edge[k:, :] |= lawn[:-k, :]; edge[:-k, :] |= lawn[k:, :]
            edge[:, k:] |= lawn[:, :-k]; edge[:, :-k] |= lawn[:, k:]
        edge &= walk
        ov = edge & (vnoise("overhang-v04", 3) > 0.42)
        d[ov] = np.where(vnoise("ovtone-v04", 2)[ov] > 0.5, I["g3"], I["g2"])
        d[:] = despeckle(d, 1, valid=edge)
        self.meadow_edges(d, lawn & ~tp)
        self.verge(d, rng, lawn)
        self.lawn_features(d, rng, lawn)
        self.recess_overgrowth(d, comp)
        skip = [(sx0 - CHEEK_W - 6, sx1 + CHEEK_W + 6) for sx0, sx1 in STAIRS] + \
               [(EXEDRA[0], EXEDRA[1]), (COLLAPSE[0] - 8, COLLAPSE[1] + 10), (SLUMP[0] - 6, SLUMP[1] + 30)]
        for x in range(4, W, 22):
            if any(a <= x <= b for a, b in skip):
                continue
            if rng.random() < 0.72:
                self.shrub(d, x + int(rng.integers(-4, 5)), FOOT_Y + 6 + int(rng.integers(0, 4)),
                           int(rng.integers(7, 12)), ("wallshrub-v04", x), ramp=BOX if x % 3 else None)
        bp = np.pad(self.belt, 20)
        margin = self.belt & ~(bp[40:, 20:-20] & bp[:-40, 20:-20] & bp[20:-20, 40:] & bp[20:-20, :-40])
        for k in range(200):
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 30, H))
            if margin[y, x] and not walk[y, x]:
                self.shrub(d, x, y, int(rng.integers(6, 13)), ("beltshrub-v04", k), ramp=(FOL, BOX, CON)[k % 3])
        for k, (x, y, r) in enumerate(RUBBLE_SHRUBS):
            self.shrub(d, x, y, r, ("rubbleshrub-v04", k), ramp=GR[:7])
        self.branches_only(d, lawn)
        rub = self.piece_mask & (tw >= 0)
        tops = rub & np.isin(tw, [I["m4"], I["m3"]])
        mo = tops & (vnoise("rubmoss-v04", 3) > 0.74)
        d[mo] = np.where(vnoise("rubmoss2-v04", 2)[mo] > 0.5, I["g3"], I["g4"])
        stone = rub & np.isin(tw, [I["m1"], I["m0"], I["ink"]])
        foot = stone & ~np.roll(stone, -1, axis=0)
        fy, fx = np.nonzero(foot)
        for i in range(0, len(fy), 9):
            if rng.random() < 0.6 and fy[i] >= FOOT_Y:
                self.tuft(d, comp, int(fx[i]), int(fy[i]) + 1, "long")
        for x in range(COLLAPSE[0] + 10, COLLAPSE[1] - 10, 9):
            yt = self.breach_top.get(x, EDGE_Y)
            self.vine(d, x, yt, int(rng.integers(6, 24)), rng)
        sx0 = STAIRS[0][0]
        for x in range(sx0 + 4, STAIRS[0][1] - 4, 7):
            if rng.random() < 0.6:
                self.tuft(d, comp, x, LANDING[1] + 1, "short")
        comp = composite_idx(self.L, ["ground-base", "terrain-patches", "paving-walks", "terrace-walls",
                                      "ground-detail"])
        for k in range(46):
            if k < 18:
                x = int(rng.integers(20, W - 20)); y = int(rng.integers(PAV_Y1 + 4, EDGE_Y - BAL_H - 4))
                if tw[y, x] >= 0:
                    continue
            else:
                x = int(rng.integers(0, W)); y = int(rng.integers(FORE[1], H))
                if not walk[y, x]:
                    continue
            self.crack(d, comp, x, y, int(rng.integers(8, 26)), rng)
        rc = rng_for("chips-v05")
        self.chips = 0
        for (cx, cy, n, sx, sy) in CHIP_FANS:
            for q in range(n):
                x = int(cx + rc.normal(0, sx * 0.5)); y = int(cy + abs(rc.normal(0, sy * 0.5)))
                if not (1 <= x < W - 2 and 1 <= y < H - 2):
                    continue
                big = rc.random() < 0.4
                tex = [(0, 0, "m3"), (1, 0, "m2"), (0, 1, "m1"), (1, 1, "s0")] if big else [(0, 0, "m2"), (0, 1, "s0")]
                for (i, j, c) in tex:
                    d[y + j, x + i] = I[c]
                self.chips += 1
        for (x, y) in SURVEY_TICKS:
            d[y, x:x + 5] = I["o1"]; d[y - 2:y + 3, x + 2] = I["o1"]
        for (x, y, dirn) in SURVEY_ARROWS:
            spr = ["..o..", ".ooo.", "o.o.o", "..o..", "..o.."] if dirn == "up" else \
                  ["..o..", ".o...", "ooooo", ".o...", "..o.."] if dirn == "left" else \
                  ["..o..", "...o.", "ooooo", "...o.", "..o.."]
            stamp(d, x - 2, y, spr, {"o": "o1"})
        (ax_, ay_), (bx_, by_) = TRANSECT
        n = int(max(abs(bx_ - ax_), abs(by_ - ay_)))
        for t in range(n + 1):
            x = int(round(ax_ + (bx_ - ax_) * t / n)); y = int(round(ay_ + (by_ - ay_) * t / n))
            setpx(d, x, y, I["o1"] if t % 6 else I["o2"])
            if t % 36 == 0:
                for (i, j, c) in ((0, -1, "o2"), (1, -1, "o1"), (0, -2, "o1"), (0, 1, "s0")):
                    setpx(d, x + i, y + j, I[c])
        for (a, b) in CABLES:
            n = int(max(abs(b[0] - a[0]), abs(b[1] - a[1])))
            for t in range(n):
                x = int(a[0] + (b[0] - a[0]) * t / n + 2 * math.sin(t / 9))
                y = int(a[1] + (b[1] - a[1]) * t / n)
                setpx(d, x, y, I["k0"])
                if t % 5 == 0:
                    setpx(d, x, y - 1, I["k1"])

    def tuft(self, d, comp, x, y, kind):
        """One generated grass tuft (no two alike; v04 stamped eight fixed sprites) with a contact shade row."""
        if not hasattr(self, "_tuft_rng"):
            self._tuft_rng = rng_for("unique-tufts-v05")
        tex, n = tuft_texels(self._tuft_rng, kind)
        for i in range(-(n // 2) - 1, n - n // 2 + 1):
            xx, yy = x + i, y + 1
            if 0 <= xx < W and 0 <= yy < H and comp[yy, xx] >= 0 and d[yy, xx] < 0:
                d[yy, xx] = SHADE_LUT[comp[yy, xx]]
        for dx, dy, c in tex:
            setpx(d, x + dx, y + dy, I[c])

    def branches_only(self, d, lawn):
        """v04's hand-placed fallen branches (its random leaf-litter scatter is replaced by terrain-patches drifts)."""
        for bx, by, ang, ln in BRANCHES:
            if not lawn[by, bx]:
                continue
            for t in range(ln):
                x = int(round(bx + math.cos(ang) * t)); y = int(round(by + math.sin(ang) * t))
                setpx(d, x, y, I["s2"]); setpx(d, x, y + 1, I["s1"]); setpx(d, x, y + 2, I["s0"])
                if t in (ln // 3, 2 * ln // 3):
                    for q in range(1, 6):
                        setpx(d, x + q, y - q, I["s1"])
                        if q == 5:
                            stamp(d, x + q - 2, y - q - 2, [".c.", "cbc", ".b."], {"c": "g4", "b": "g2"})
            self.prop_shadow.append(("box", bx + 2, by + 3, ln, 2))

    def recess_overgrowth(self, d, comp):
        """v04's overgrown recess minus its vine strings (the shaded half's ivy is a massed curtain in v05)."""
        e0, e1 = EXEDRA
        rng = rng_for("recess-v04")
        yy, xx = np.mgrid[0:H, 0:W]
        floor = np.zeros((H, W), bool)
        for x in range(e0, e1 + 1):
            floor[self.floor_y[x]:FORE[1], x] = True
        floor &= ~self.fountain_mask
        wall_d = np.full((H, W), 999.0, np.float32)
        for x in range(e0, e1 + 1):
            wall_d[:, x] = yy[:, x] - self.floor_y[x]
        cheek_d = np.minimum(np.abs(xx - e0), np.abs(xx - e1)).astype(np.float32)
        dist = np.minimum(wall_d, cheek_d)
        fd = np.hypot((xx - FOUNTAIN[0]) / 1.6, (yy - FOUNTAIN[1]) * 1.2)
        dens = np.clip(1 - dist / 46.0, 0, 1) * 0.85 + np.clip(1 - (fd - 50) / 26.0, 0, 1) * 0.5
        joints = floor & np.isin(comp, [I["p0"], I["s1"], I["s2"]])
        gn = vnoise("recess-grass-v04", 3)
        g = joints & (gn < dens)
        d[g] = np.where(gn[g] < dens[g] * 0.5, I["g2"], I["g3"])
        ys, xs = np.nonzero(floor)
        for k in rng.permutation(len(ys))[: len(ys) // 190]:
            y, x = int(ys[k]), int(xs[k])
            if rng.random() < dens[y, x]:
                self.tuft(d, comp, x, y, "long" if dens[y, x] > 0.6 else "short")
        for k, (x, y, r, ramp) in enumerate(EXEDRA_SHRUBS):
            self.shrub(d, x, y, r, ("exedrashrub-v04", k), ramp={"box": BOX, "elm": ELM, "fol": FOL}[ramp])
        for k, (x, y, r, kind) in enumerate(BASIN_PLANTS):
            if kind == "box":
                self.shrub(d, x, y, r, ("basin-v04", k), ramp=BOX)
            elif kind == "grass":
                for q in range(r):
                    self.tuft(d, comp, x + int(rng.integers(-6, 7)), y + int(rng.integers(-3, 3)) + 3, "long")
            elif kind == "flower":
                for q in range(r):
                    fx, fy = x + int(rng.integers(-7, 8)), y + int(rng.integers(-3, 4))
                    setpx(d, fx, fy, I["y0"]); setpx(d, fx + 1, fy, I["o2"]); setpx(d, fx, fy + 1, I["g2"])
        cop = self.fountain_mask & (self.L["terrace-walls"] >= 0) & (vnoise("copmoss-v04", 3) > 0.7) & \
            (yy < FOUNTAIN[1])
        d[cop] = I["g2"]
        for ang in (2.6, 3.3, 0.2, 0.8, 1.9):
            x, y = FOUNTAIN[0] + math.cos(ang) * 52, FOUNTAIN[1] + math.sin(ang) * 28
            for t in range(int(rng.integers(12, 26))):
                xi, yi = int(round(x)), int(round(y))
                if 0 <= yi < H and 0 <= xi < W and floor[yi, xi]:
                    d[yi, xi] = ramp_shift(comp[yi, xi], PAVE, -2) if comp[yi, xi] in PAVE else I["p0"]
                ang += float(rng.normal(0, 0.3))
                x += math.cos(ang); y += math.sin(ang) * 0.6

    # ------------------------------------------------------------------ depth framing (fg-occlusion additions)
    def v5_fg_frame(self):
        fg = self.L["fg-occlusion"]
        before = fg >= 0
        for k, (cx, cy, r, sq) in enumerate(NEAR_CANOPIES):
            m, idx, (x0, y0) = self.canopy_raster(cx, cy, r, ("near-v05", k), ramp=NEAR, squash=sq, tex_cell=5)
            sub = fg[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
            sub[m] = idx[m]
        rr = rng_for("fronds-v05")
        for (x, yb, h, n, lean) in FRONDS:
            for i in range(n):
                a = lean + (i - n / 2) * 0.22 + float(rr.uniform(-0.1, 0.1))
                hh = int(h * float(rr.uniform(0.6, 1.0)))
                bx = x + (i - n // 2) * 2
                for j in range(hh):
                    px_ = int(round(bx + a * j + 0.02 * a * j * j)); py_ = yb - j
                    if 0 <= px_ < W and 0 <= py_ < H:
                        fg[py_, px_] = I["f0"] if j < hh * 0.6 else I["f1"]
                        if j > hh * 0.5 and (j + i) % 3 == 0 and 0 <= px_ + 1 < W:
                            fg[py_, px_ + 1] = I["f1"]
                tip = (int(round(bx + a * hh + 0.02 * a * hh * hh)), yb - hh)
                if 0 <= tip[0] < W and 0 <= tip[1] < H:
                    fg[tip[1], tip[0]] = I["e2"]
        self.fg_frame_mask = (fg >= 0) & ~before
        band = np.zeros((H, W), bool)
        band[FORE[3] + 1:H, AXIS[0] + 3:AXIS[1] - 2] = True
        assert not (self.fg_frame_mask & band).any(), "a v05 foreground texel lies over the axial walk"
        fails = visibility_fails(fg >= 0, self.walkable_mask(), heroine_48()[..., 3] == 255, step=2)
        assert not fails, f"v05 foreground framing hides more than 2/3 of the actor at {fails[:5]}"

    # ------------------------------------------------------------------ cast shadows (projected silhouettes)
    def shadows(self):
        cs = self.L["cast-shadows"]
        comp = composite_idx(self.L, ["ground-base", "terrain-patches", "paving-walks", "terrace-walls",
                                      "facade-weathering", "ground-detail"])
        m1 = np.zeros((H, W), bool)
        m2 = np.zeros((H, W), bool)
        yy, xx = np.mgrid[0:H, 0:W]
        noise = vnoise("shedge-v04", 3)
        # architecture onto the deck and the lawn (v04 rules)
        wing = (yy >= FACADE_Y1) & (yy < FACADE_Y1 + 9 + (vnoise("wing-v05", 11) * 4).astype(int))
        m1 |= wing; m2 |= (yy >= FACADE_Y1) & (yy < FACADE_Y1 + 3)
        for a, b, ybot in [(PAV[0] - 4, PAV[1] + 4, PAV_Y1)] + [(s0, s1, SUBP_Y1) for s0, s1 in SUBP]:
            sh = (yy >= ybot) & (yy < ybot + 7) & (xx >= a + 3 + (yy - ybot)) & (xx <= b + 4 + (yy - ybot) * 1.2)
            m1 |= sh; m2 |= sh & (yy < ybot + 3)
            m1 |= (xx > b) & (xx <= b + 7) & (yy >= FACADE_Y1) & (yy < ybot + 3)
        band = (yy >= FOOT_Y) & (yy < FOOT_Y + 10 + (vnoise("wsh-v05", 9) * 8).astype(int))
        for sx0, sx1 in STAIRS:
            band &= ~((xx >= sx0 - CHEEK_W - 2) & (xx <= sx1 + CHEEK_W + 2))
        band &= ~((xx >= EXEDRA[0]) & (xx <= EXEDRA[1]))
        m1 |= band; m2 |= band & (yy < FOOT_Y + 3)
        cxm = (EXEDRA[0] + EXEDRA[1]) / 2.0
        hw = (EXEDRA[1] - EXEDRA[0]) / 2.0
        for x in range(EXEDRA[0], EXEDRA[1] + 1):
            fl = self.floor_y[x]
            dep = int(6 + 12 * max(0.0, (cxm - x) / hw) + 3 * noise[fl, x])
            m1[fl:fl + dep, x] = True
            m2[fl:fl + 3 + dep // 4, x] = True
        for sx0, sx1 in STAIRS:
            for x0 in (sx0, sx1 + CHEEK_W + 3):
                cw = (xx >= x0) & (xx < x0 + 6) & (yy >= EDGE_Y - 2) & (yy <= STAIR_BOT + 6)
                m1 |= cw; m2 |= cw & (xx < x0 + 2)
            # outer cheek walls throw a wedge onto the lawn at their foot
            xo = sx1 + CHEEK_W + 1
            wedge = (xx >= xo) & (xx < xo + 9 - (yy - FOOT_Y) // 12) & (yy >= FOOT_Y) & (yy <= STAIR_BOT)
            m1 |= wedge
        fm = self.fountain_mask
        fsh = np.zeros((H, W), bool)
        fsh[4:, 6:] = fm[:-4, :-6]
        m1 |= fsh & ~fm
        m2 |= np.roll(np.roll(fm, 2, 0), 3, 1) & ~fm
        # tree crowns: each crown's own silhouette laid on the ground at its height, offset by the sun
        self.crown_shadow = np.zeros((H, W), bool)
        for (tx, ty, r, fam) in self.tree_list:
            m, idx, (x0, y0) = self.tree_raster(tx, ty, r, fam)
            ys, xs = np.nonzero(m)
            if not len(ys):
                continue
            ccx, ccy, _ = self.canopy_centre(fam, tx, ty, r)
            zc = max(4.0, ty - ccy)
            if fam == "snag":
                gr = np.full((H, W), ty, np.int32)
                tmp = np.zeros((H, W), bool)
                mm = np.zeros((H, W), bool)
                mm[y0:y0 + m.shape[0], x0:x0 + m.shape[1]] = m
                project_shadow(mm, gr, tmp)
                self.crown_shadow |= tmp
                continue
            Xs = xs + x0 + SUN_X * zc
            Ys = ty + SUN_Y * zc + (ys + y0 - ccy) * 0.72
            ok = (Xs >= 0) & (Xs < W - 1) & (Ys >= 0) & (Ys < H)
            self.crown_shadow[Ys[ok].astype(int), Xs[ok].astype(int)] = True
            self.crown_shadow[Ys[ok].astype(int), Xs[ok].astype(int) + 1] = True
            m2[max(0, ty - 1):min(H, ty + 3), max(0, tx - 7):min(W, tx + 9)] = True      # trunk-base contact
        self.crown_shadow = majority(self.crown_shadow, 1, 1)
        m1 |= self.crown_shadow
        # standing objects: v04 base-layer tall items (props, trunks, rubble, fallen urns, the fallen oak) projected
        # from their per-column ground rows; Y-sorted sprites from their pivots
        proj = np.zeros((H, W), bool)
        core = np.zeros((H, W), bool)
        project_shadow(self.tall_mask, self.tall_ground, proj, core)
        for n in ("stair-lamps-ysort", "fountain-ysort", "survey-post"):
            lm = self.L[n] >= 0
            gr = np.full((H, W), YSORT[n], np.int32)
            if n == "fountain-ysort":
                gr[self.fountain_tree_mask] = self.fountain_tree[1]
            project_shadow(lm, gr, proj, core)
        proj = majority(proj, 1, 1) | proj & below(proj, 1)
        m1 |= proj
        m2 |= core
        for kind, *a in self.prop_shadow:                        # small ground plants keep v04's soft ellipses
            if kind == "shrub":
                cx, cy, r = a
                for (mm, sx, sy, rx, ry) in ((m1, 0.5, 1, 0.95, 0.45), (m2, 0.3, 0, 0.5, 0.22)):
                    e = blob_e(cx + sx * r, cy + sy, rx * r, ry * r, ("shr", cx, cy, rx), wob=0.25)
                    mm |= e < 1
        mm_ = self.mound_mask
        m1 |= np.roll(np.roll(mm_, 6, 0), 9, 1) & ~mm_
        m2 |= np.roll(np.roll(mm_, 2, 0), 3, 1) & ~mm_
        # shade pools under the near crowns and belts (frame foot)
        for k, (cx, cy, rx, ry) in enumerate(SHADE_POOLS):
            m1 |= blob_e(cx, cy, rx, ry, ("pool", k), wob=0.5) < 1
        m1 &= (yy >= FACADE_Y1)
        tw = self.L["terrace-walls"]
        stairs = np.zeros((H, W), bool)
        for sx0, sx1 in STAIRS:
            stairs[:, sx0:sx1 + 1] = True
        walls = (tw >= 0) & (yy < FOOT_Y) & (yy >= PAV_Y1) & ~self.mound_mask & ~(stairs & (yy >= EDGE_Y - 2))
        front = (tw >= 0) & (yy < PAV_Y1)
        bad = walls | front | self.piece_mask | self.fixture_mask
        m1 &= ~bad; m2 &= ~bad
        colsh = np.zeros((H, W), bool)
        for (sx, sy, fr) in self.col_shadows:
            colsh |= (yy >= sy) & (yy < fr) & (xx >= sx + (yy - sy) * 0.8 - 1) & (xx < sx + (yy - sy) * 0.8 + 5)
        colsh &= (tw >= 0) & ~np.isin(tw, [I["m0"], I["ink"]])
        m1 |= colsh
        # grass breaks a shadow's edge into blades (the lower sward overlaps): displace on lawn texels only
        grass = self.lawn & (yy >= FOOT_Y)
        teeth = blade_teeth("shadow", 3)
        m1 = np.where(grass, displace_up(m1.astype(np.int8), teeth, grass).astype(bool), m1)
        m2 &= m1
        cs[m1] = SHADE_LUT[comp[m1]]
        cs[m2] = SHADE_LUT[SHADE_LUT[comp[m2]]]


# ============================================================================ artefacts, metrics, previews
def artefacts():
    sc = SceneV05().build()
    rgba = {n: to_rgba(sc.L[n]) for n in LAYERS}
    flat = composite_rgba(rgba, ART_LAYERS)
    flat_png = png_bytes(flat)
    files = {"pxo": make_pxo(rgba, flat_png), "ora": make_ora(rgba, flat_png), "flat": flat_png, "gpl": make_gpl()}
    return sc, rgba, flat, files


def names():
    return {"pxo": fname("scene-editable-13layer", "pxo"), "ora": fname("scene-editable-13layer", "ora"),
            "flat": fname("scene-flat-art", "png"), "gpl": fname("scene-palette", "gpl"),
            "manifest": fname("scene-manifest", "json"), "walk": fname("scene-walkability", "json")}


def v04_flat():
    return np.array(Image.open(io.BytesIO(read_bytes(os.path.join(rp(V04_CAND_REL), V04_FLAT_NAME)))).convert("RGBA"))


def v04_untouched():
    d = rp(V04_CAND_REL)
    files_ok = all(sha(read_bytes(os.path.join(d, n))) == h for n, h in V04_SHA256.items())
    return bool(files_ok and sha_text(read_bytes(rp(V04_TOOL_REL))) == V04_TOOL_SHA256_TEXT_LF)


ZONES = {  # (x0, y0, x1, y1) for the value-hierarchy readout
    "facade_band": (0, 0, W, FACADE_Y1), "deck": (0, PAV_Y1 + 2, W, EDGE_Y - BAL_H),
    "focal_stairs_exedra_forecourt": (372, 126, 908, 352), "left_panel": (240, 360, 600, 600),
    "right_panel": (680, 360, 1040, 600), "frame_foot": (0, 640, W, H),
    "left_belt": (0, 360, 180, H), "right_belt": (1110, 360, W, H)}


def texture_stats(flat, mask):
    """Speckle and structure inside `mask`: isolated texels (no same-colour 4-neighbour), thin texels (<= 1 same
    neighbour), mean horizontal same-colour run length and the colour count."""
    idx = flat_index(flat)
    p = np.pad(idx, 1, mode="edge")
    same = (idx == p[:-2, 1:-1]).astype(int) + (idx == p[2:, 1:-1]) + (idx == p[1:-1, :-2]) + (idx == p[1:-1, 2:])
    m = mask
    runs = []
    for y in range(0, H, 2):
        row = idx[y]
        rm = m[y]
        ch = np.nonzero(np.diff(row) != 0)[0]
        starts = np.r_[0, ch + 1]; ends = np.r_[ch, W - 1]
        for s, e in zip(starts, ends):
            if rm[s:e + 1].all():
                runs.append(e - s + 1)
    lum = LUM[np.maximum(idx, 0)]
    return {"texels": int(m.sum()), "isolated_ratio": round(float(((same == 0) & m).sum() / m.sum()), 4),
            "thin_ratio_le1_same_neighbour": round(float(((same <= 1) & m).sum() / m.sum()), 4),
            "mean_horizontal_run_px": round(float(np.mean(runs)) if runs else 0.0, 2),
            "distinct_colours": int(len(np.unique(idx[m]))),
            "luminance_mean": round(float(lum[m].mean()), 4), "luminance_std": round(float(lum[m].std()), 4)}


def hierarchy(flat):
    idx = flat_index(flat)
    lum = LUM[np.maximum(idx, 0)]
    out = {}
    for k, (x0, y0, x1, y1) in ZONES.items():
        z = lum[y0:y1, x0:x1]
        out[k] = {"luminance_mean": round(float(z.mean()), 4), "luminance_std": round(float(z.std()), 4)}
    out["deck_minus_facade"] = round(out["deck"]["luminance_mean"] - out["facade_band"]["luminance_mean"], 4)
    out["focal_minus_frame_foot"] = round(out["focal_stairs_exedra_forecourt"]["luminance_mean"] -
                                          out["frame_foot"]["luminance_mean"], 4)
    return out


def lawn_mask(sc):
    """Open lawn texels in the flat image: lawn, not paved, not under a terrace piece, prop, tree crown or survey kit."""
    m = sc.lawn & ~sc.belt
    for n in ("props-low", "stair-lamps-ysort", "fountain-ysort", "survey-post", "fg-occlusion"):
        m &= sc.L[n] < 0
    return m


def comparisons(sc, rgba, flat):
    old = v04_flat()
    lm = lawn_mask(sc)
    fac = np.zeros((H, W), bool); fac[:FACADE_Y1] = True
    wallf = np.zeros((H, W), bool); wallf[EDGE_Y:FOOT_Y] = True
    wallf &= sc.face_mask
    return {
        "repetition": {"v05_flat": repetition_stats(flat), "v04_flat": repetition_stats(old),
                       "v05_facade_band_rows_0_87": repetition_stats(flat, (0, PAV_Y1)),
                       "v04_facade_band_rows_0_87": repetition_stats(old, (0, PAV_Y1)),
                       "v05_lawn_rows_352_720": repetition_stats(flat, (FORE[3], H)),
                       "v04_lawn_rows_352_720": repetition_stats(old, (FORE[3], H))},
        "texture_open_lawn": {"v05": texture_stats(flat, lm), "v04": texture_stats(old, lm)},
        "texture_facade_band": {"v05": texture_stats(flat, fac), "v04": texture_stats(old, fac)},
        "texture_terrace_wall_face": {"v05": texture_stats(flat, wallf), "v04": texture_stats(old, wallf)},
        "value_hierarchy": {"v05": hierarchy(flat), "v04": hierarchy(old)},
        "texels_changed_vs_v04": int((flat != old).any(axis=2).sum()),
        "texels_changed_ratio_vs_v04": round(float((flat != old).any(axis=2).mean()), 4),
    }


def walk_same_as_v04(sc):
    """The v05 walkable mask must equal the one rebuilt by the untouched v04 tool (collision preserved)."""
    s4 = v4.Scene().build()
    a, b = sc.walkable_mask(), s4.walkable_mask()
    return {"identical": bool((a == b).all()), "differing_texels": int((a != b).sum()),
            "block_identical": bool((sc.block == s4.block).all())}


def previews(sc, rgba, flat):
    """QA views, each its own image (no collage, no side-by-side comparison)."""
    spr = heroine_48()
    out = {}
    scale = flat.copy()
    for k in SCALE_CASES:
        paste(scale, spr, *actor_cases()[k])
    out["preview-heroine48-scale"] = scale
    out["preview-guides-overlay"] = guide_overlay(flat, rgba["guides"])
    for name in ("entry", "axis_mid", "left_stair_mid", "right_stair_rubble", "recess_side", "fountain_behind",
                 "fountain_front", "newel_behind", "newel_front", "post_behind", "post_front", "portico",
                 "deck_south_wing", "fallen_tree", "lower_left_panel"):
        foot = actor_cases()[name]
        st = runtime_stack_still(rgba, spr, foot)
        out["cam2x-" + name.replace("_", "-")] = camera_view(st, foot)
    for qn, (x0, y0) in (("tl", (0, 0)), ("tr", (CAM_W, 0)), ("bl", (0, CAM_H)), ("br", (CAM_W, CAM_H))):
        out["cam2x-quad-" + qn] = zoom(flat[y0:y0 + CAM_H, x0:x0 + CAM_W], 2)
    for k, (x0, y0, x1, y1) in ZOOM_CROPS.items():
        out[f"zoom{ZOOM_K[k]}x-{k}"] = zoom(flat[y0:y1, x0:x1], ZOOM_K[k])
    for n in ("terrain-patches", "facade-weathering", "cast-shadows"):
        out[f"layer-only-{n}"] = rgba[n]
    return out


ZOOM_CROPS = {"facade-south-wing-breach": (900, 0, 1280, 120), "facade-north-wing-ivy": (0, 0, 380, 120),
              "terrace-wall-left-ivy": (300, 110, 520, 300), "post-ruts-desire-line": (220, 340, 560, 560),
              "right-knoll-burn-scar": (700, 360, 1060, 560), "left-hollow-rushes-meadow": (180, 400, 460, 720),
              "frame-foot-near-crowns": (0, 560, 420, 720), "fallen-oak-root-pit": (880, 500, 1100, 700),
              "lawn-texture-detail": (440, 380, 600, 480), "exedra-ivy-fountain": (500, 110, 780, 320)}
ZOOM_K = {"lawn-texture-detail": 6, "facade-south-wing-breach": 3, "facade-north-wing-ivy": 3,
          "terrace-wall-left-ivy": 4, "post-ruts-desire-line": 3, "right-knoll-burn-scar": 3,
          "left-hollow-rushes-meadow": 3, "frame-foot-near-crowns": 3, "fallen-oak-root-pit": 4,
          "exedra-ivy-fountain": 3}


def manifest(sc, rgba, flat, files, met, cmp_, walk_cmp):
    nm = names()
    return {
        "status": "UNAPPROVED + NONRUNTIME candidate. Not accepted art; not wired to any scene, data or default.",
        "run": RUN, "stamp": STAMP, "run_id": RUN_ID, "author": "Claude (Claude Code, Opus 5.5, claude.ai Max)",
        "source": {"v04_run": V04_RUN, "v04_tool": V04_TOOL_REL, "v04_tool_sha256_text_lf": V04_TOOL_SHA256_TEXT_LF,
                   "v04_files_sha256": V04_SHA256,
                   "how": "the v04 tool is imported read-only; v05 subclasses its Scene and replaces the lawn, "
                          "terrain, facade light, weathering, ivy, chips, cast shadows and depth framing"},
        "authoring_route": "NOT a Pixelorama GUI pass: deterministic Python tool with hand-written v05 tables; "
                           "Pixelorama 1.2.3 verifies the .pxo/.ora headless. A GUI polish pass can start from the "
                           "13 named layers.",
        "tool": TOOL_REL,
        "canvas": [W, H], "palette": "the v04/v03 47-colour palette, unchanged",
        "layers_bottom_to_top": LAYERS, "new_layers_vs_v04": ["terrain-patches", "facade-weathering"],
        "runtime_draw_order_proposal": "base layers 1-8 merged -> {stair-lamps-ysort, fountain-ysort, survey-post, "
                                       "actors} by pivot row -> fg-occlusion",
        "ysort_pivots": dict(YSORT),
        "files": {k: {"name": nm[k], "sha256": sha(files[k])} for k in files},
        "v05_tables": {"lawn_forms": len(LAWN_FORMS), "swales": len(SWALES), "desire_lines": len(DESIRE_LINES),
                       "dry_meadows": len(DRY_MEADOWS), "rush_beds": len(RUSH_BEDS), "litter_drifts":
                       len(LITTER_DRIFTS), "streaks": len(STREAKS), "damp_bands": len(DAMP_BANDS),
                       "ivy_masses": len(IVY) + 1, "chip_fans": len(CHIP_FANS), "near_canopies": len(NEAR_CANOPIES),
                       "fronds": len(FRONDS), "shade_pools": len(SHADE_POOLS)},
        "terrain_patch_texels": sc.terrain_patch_area,
        "facade_face_texels_shifted_one_step": sc.face_shifted,
        "lighting": {"key": "upper left (same convention as v04 arrises and shadows)", "light_vector": LIGHT.tolist(),
                     "shadow_offset_per_px_height": [SUN_X, SUN_Y]},
        "metrics": met["_summary"], "comparisons_vs_v04": cmp_, "walkable_vs_v04": walk_cmp,
        "fidelity": "Site cues are v04's (paired stairs, exedra, dry fountain, paired-column pavilion, Olmsted "
                    "terrace balustrade). The breach, burn scar, ruts, soil cores and fallen oak are game fiction.",
    }


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def walkability_json5(sc):
    j = walkability_json(sc)
    j["run"] = RUN
    j["status"] = "UNAPPROVED + NONRUNTIME candidate data derived from the guides layer; identical to v04's mask"
    j["ysort_draw_order"] = ("base layers 1-8 merged -> {stair-lamps-ysort, fountain-ysort, survey-post, actors} "
                             "sorted by pivot row -> fg-occlusion")
    return j


def build(preview_dir=None):
    sc, rgba, flat, files = artefacts()
    met = metrics(sc, rgba, flat)
    met["_ysort"] = ysort_check(sc, rgba)
    met["_depth"] = depth_audit(sc, rgba)
    met["_paths"] = path_checks(sc)
    cmp_ = comparisons(sc, rgba, flat)
    pv = previews(sc, rgba, flat)
    if preview_dir:
        os.makedirs(preview_dir, exist_ok=True)
        Image.fromarray(flat, "RGBA").save(os.path.join(preview_dir, "flat.png"))
        for k, a in pv.items():
            Image.fromarray(a, "RGBA").save(os.path.join(preview_dir, k + ".png"))
        for n in LAYERS:
            Image.fromarray(rgba[n], "RGBA").save(os.path.join(preview_dir, f"layer-{n}.png"))
        print(json.dumps({"summary": met["_summary"], "ysort_ok": {k: v["ok"] for k, v in met["_ysort"].items()},
                          "depth_ok": met["_depth"]["ok"], "paths_ok": met["_paths"]["ok"],
                          "widths": met["_paths"]["widths"], "cmp": cmp_,
                          "terrain": sc.terrain_patch_area}, indent=1, default=str))
        return 0
    if artefacts()[3] != files:
        raise SystemExit("build is not deterministic")
    walk_cmp = walk_same_as_v04(sc)
    cand, out = rp(CAND_REL), rp(OUT_REL)
    os.makedirs(_fs(cand), exist_ok=True)
    os.makedirs(_fs(out), exist_ok=True)
    nm = names()
    for k in ("pxo", "ora", "flat", "gpl"):
        print(write_new(os.path.join(cand, nm[k]), files[k]), nm[k])
    wj = (json.dumps(walkability_json5(sc), indent=1) + "\n").encode()
    files["walk"] = wj
    print(write_new(os.path.join(cand, nm["walk"]), wj), nm["walk"])
    man = manifest(sc, rgba, flat, files, met, cmp_, walk_cmp)
    for k in ("_ysort", "_depth", "_paths"):
        man[k.strip("_") + "_check"] = met[k]
    man["qa_previews_dir"] = OUT_REL
    print(write_new(os.path.join(cand, nm["manifest"]), (json.dumps(man, indent=2, default=str) + "\n").encode()),
          nm["manifest"])
    for k, a in pv.items():
        print(write_new(os.path.join(out, fname(k, "png")), png_bytes(a)), k)
    return 0


# ============================================================================ Pixelorama isolation guard (v05)
def run_isolated_v05(exe, args, fake_appdata, real_root):
    """v04's isolated headless run, with one change: the creator's open Pixelorama GUI autosaves into
    %APPDATA%\\pixelorama\\backups about every 62 s and rewrites .running every 15 s. Those two paths are the GUI's
    own and are reported, not treated as a breach; any other change in the real dir still kills the run."""
    env = dict(os.environ)
    env["APPDATA"] = fake_appdata
    before = snapshot_dir(real_root)
    t0 = time.time()
    p = subprocess.Popen([exe, "--headless", "--quit", "--"] + args, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    killed = False

    def foreign(k):
        return k != ".running" and not k.startswith("backups/")
    while p.poll() is None:
        now = snapshot_dir(real_root)
        changed = {k for k in set(before) | set(now) if before.get(k) != now.get(k) and foreign(k)}
        if changed or (".running" in before and ".running" not in now):
            p.kill(); killed = True
            break
        if time.time() - t0 > 240:
            p.kill(); killed = True
            break
        time.sleep(0.01)
    so, se = p.communicate()
    after = snapshot_dir(real_root)
    noise = ("shader_compiler", "custom_samplers", "Condition \"!actions")
    tail = [l for l in so.splitlines() + se.splitlines() if l.strip() and not any(s in l for s in noise)]
    diff = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
    return {"args": [os.path.basename(a) if os.path.isabs(a) else a for a in args], "exit_code": p.returncode,
            "seconds": round(time.time() - t0, 1), "killed_by_guard": killed,
            "fake_user_dir_created": os.path.isdir(os.path.join(fake_appdata, "pixelorama")),
            "real_dir_changed_except_running": [k for k in diff if foreign(k)],
            "real_dir_gui_own_changes": [k for k in diff if not foreign(k)],
            "real_running_marker_present_after": ".running" in after, "output_tail": tail[-5:]}


v4.run_isolated = run_isolated_v05

# ============================================================================ Godot collision probe (test-only)
GODOT_COLLISION_SCRIPT = r'''extends SceneTree
# Test-only, nonruntime: build a StaticBody2D from the documented blocked mask (one RectangleShape2D per merged
# rectangle of blocked texels, exact to the texel), then ask Godot's physics for (a) shape queries with an 11x3 px
# foot box at probe feet and (b) a CharacterBody2D sweep up the axial walk with move_and_collide.
var dir: String
var frames := 0
var body: CharacterBody2D
func _initialize():
	dir = OS.get_cmdline_user_args()[0]
	var rects = JSON.parse_string(FileAccess.get_file_as_string(dir + "/rects.json"))
	var sb = StaticBody2D.new()
	root.add_child(sb)
	for r in rects:
		var cs = CollisionShape2D.new()
		var sh = RectangleShape2D.new()
		sh.size = Vector2(float(r[2]), float(r[3]))
		cs.shape = sh
		cs.position = Vector2(float(r[0]) + float(r[2]) / 2.0, float(r[1]) + float(r[3]) / 2.0)
		sb.add_child(cs)
	body = CharacterBody2D.new()
	var bcs = CollisionShape2D.new()
	var bsh = RectangleShape2D.new()
	bsh.size = Vector2(10.6, 2.6)
	bcs.shape = bsh
	body.add_child(bcs)
	root.add_child(body)
func _physics_process(_delta):
	frames += 1
	if frames < 4:
		return false
	var cases = JSON.parse_string(FileAccess.get_file_as_string(dir + "/probes.json"))
	var space = root.get_world_2d().direct_space_state
	var q = PhysicsShapeQueryParameters2D.new()
	var foot = RectangleShape2D.new()
	foot.size = Vector2(10.6, 2.6)
	q.shape = foot
	q.exclude = [body.get_rid()]
	var out = {"probes": {}, "sweeps": {}}
	for p in cases["probes"]:
		q.transform = Transform2D(0.0, Vector2(float(p[0]) + 0.5, float(p[1]) + 0.5))
		out["probes"][str(int(p[0])) + "," + str(int(p[1]))] = space.intersect_shape(q, 1).size() > 0
	for s in cases["sweeps"]:
		body.global_position = Vector2(float(s[0]) + 0.5, float(s[1]) + 0.5)
		body.force_update_transform()
		var col = body.move_and_collide(Vector2(float(s[2]), float(s[3])), true)
		var res = {"hit": col != null}
		if col != null:
			res["travel"] = [col.get_travel().x, col.get_travel().y]
		out["sweeps"][s[4]] = res
	var f = FileAccess.open(dir + "/collision_report.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("GODOT_COLLISION_DONE")
	return true
'''


def blocked_rects(blocked):
    """Exact cover of the blocked mask by rectangles: horizontal runs per row, merged downward while identical."""
    rects = []
    open_ = {}
    for y in range(H + 1):
        runs = set()
        if y < H:
            row = blocked[y]
            ch = np.nonzero(np.diff(np.r_[0, row.astype(np.int8), 0]))[0]
            runs = {(int(a), int(b)) for a, b in zip(ch[::2], ch[1::2])}
        nxt = {}
        for run, y0 in open_.items():
            if run in runs:
                nxt[run] = y0
            else:
                rects.append((run[0], y0, run[1] - run[0], y - y0))
        for run in runs:
            if run not in nxt:
                nxt[run] = y
        open_ = nxt
    return rects


def collision_cases(sc):
    walk = sc.walkable_mask()
    blocked = ~walk
    foot_hit = np.zeros((H, W), bool)                          # python expectation for the 11x3 foot box
    for dy in (-1, 0, 1):
        for dx in range(-5, 6):
            foot_hit |= np.roll(np.roll(blocked, -dy, 0), -dx, 1)
    foot_hit[:1] = True; foot_hit[-1:] = True; foot_hit[:, :5] = True; foot_hit[:, -5:] = True
    probes = []
    for k, (x, y) in sc.pins().items():
        if k != "survey_post_pivot":
            probes.append([int(x), int(min(H - 2, y))])
    for (ax, ay), (bx, by) in zip(PATROL, PATROL[1:] + PATROL[:1]):
        n = int(max(abs(bx - ax), abs(by - ay)) // 6)
        for i in range(n + 1):
            probes.append([int(round(ax + (bx - ax) * i / max(1, n))), int(round(ay + (by - ay) * i / max(1, n)))])
    blocked_probes = [[LAMP_X[0], STAIR_BOT - 2], [LAMP_X[3], STAIR_BOT - 2], [FOUNTAIN[0], FOUNTAIN[1]],
                      [POST[0], POST[1] - 2], [FOUNTAIN[0] - 30, FOUNTAIN[1] + 8], [300, 40], [1000, 40],
                      [(COLLAPSE[0] + COLLAPSE[1]) // 2, EDGE_Y + 20]]
    for (tx, ty, r, fam) in sc.tree_list[:6]:
        if 6 <= tx < W - 6 and 2 <= ty < H - 2:
            blocked_probes.append([int(tx), int(ty - 2)])
    probes += blocked_probes
    expect = {f"{x},{y}": bool(foot_hit[y, x]) for x, y in probes}
    # sweep north up the axis from the entry: python's first blocked foot row
    x0, y0 = ENTRY
    y = y0
    while y > 0 and not foot_hit[y - 1, x0]:
        y -= 1
    sweeps = [[x0, y0, 0, -(y0 - 40), "axis_north_from_entry"], [x0, y0, 0, -(y0 - y - 3), "axis_north_short"]]
    sweep_expect = {"axis_north_from_entry": {"hit": True, "travel_y": -(y0 - y)},
                    "axis_north_short": {"hit": False}}
    return blocked_rects(blocked), probes, expect, sweeps, sweep_expect, len(blocked_probes)


def godot_collision_gate(godot, sc):
    tmp = tempfile.mkdtemp(prefix="wb-wdcgodot5c-")
    proj_name = f"wdc-collision-gate-v05-{RUN_ID}"
    rep = {"godot": godot, "godot_sha256": sha(read_bytes(godot))}
    try:
        proj = os.path.join(tmp, "proj"); os.makedirs(proj)
        data = os.path.join(tmp, "data"); os.makedirs(data)
        fake = os.path.join(tmp, "appdata"); os.makedirs(fake)
        with open(os.path.join(proj, "project.godot"), "w", newline="\n") as f:
            f.write(f'config_version=5\n\n[application]\nconfig/name="{proj_name}"\n')
        with open(os.path.join(proj, "collide.gd"), "w", newline="\n") as f:
            f.write(GODOT_COLLISION_SCRIPT)
        rects, probes, expect, sweeps, sweep_expect, nb = collision_cases(sc)
        with open(os.path.join(data, "rects.json"), "w") as f:
            json.dump(rects, f)
        with open(os.path.join(data, "probes.json"), "w") as f:
            json.dump({"probes": probes, "sweeps": sweeps}, f)
        env = dict(os.environ); env["APPDATA"] = fake
        p = subprocess.run([godot, "--headless", "--path", proj, "--script", "collide.gd", "--", data],
                           capture_output=True, text=True, timeout=600, env=env, encoding="utf-8", errors="replace")
        rep["exit_code"] = p.returncode
        rep["printed_done"] = "GODOT_COLLISION_DONE" in p.stdout
        gr = json.load(open(os.path.join(data, "collision_report.json")))
        mism = [k for k, v in expect.items() if gr["probes"].get(k) != v]
        rep["rectangles"] = len(rects)
        rep["probes"] = len(expect)
        rep["probes_expected_blocked"] = sum(expect.values())
        rep["probe_mismatches"] = mism[:20]
        sw = {}
        for k, e in sweep_expect.items():
            g = gr["sweeps"].get(k, {})
            ok = g.get("hit") == e["hit"]
            if e["hit"] and ok:
                ok = abs(g["travel"][1] - e["travel_y"]) <= 1.0
            sw[k] = {"godot": g, "python": e, "ok": ok}
        rep["sweeps"] = sw
        rep["verdicts"] = {"godot_collision_probes_match_mask": rep["exit_code"] == 0 and not mism,
                           "godot_collision_sweep_matches": all(v["ok"] for v in sw.values()),
                           "godot_collision_wrote_nothing_outside_temp": not os.path.isdir(os.path.join(
                               os.environ.get("APPDATA", ""), "Godot", "app_userdata", proj_name))}
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    return rep


# ============================================================================ check
def check(exe, write_report, use_pixelorama, godot=None):
    sc, rgba, flat, files = artefacts()
    nm = names()
    cand = rp(CAND_REL)
    for k in ("pxo", "ora", "flat", "gpl"):
        if read_bytes(os.path.join(cand, nm[k])) != files[k]:
            raise SystemExit(f"{nm[k]} on disk differs from a fresh rebuild")
    met = metrics(sc, rgba, flat)
    ys = ysort_check(sc, rgba)
    dep = depth_audit(sc, rgba)
    pth = path_checks(sc)
    ax = axial_clear(sc, rgba)
    cmp_ = comparisons(sc, rgba, flat)
    wcmp = walk_same_as_v04(sc)
    rep = {"run": RUN, "gates": {}, "metrics": met["_summary"], "ysort": ys, "depth_audit": dep, "paths": pth,
           "axial_walk": ax, "comparisons_vs_v04": cmp_, "walkable_vs_v04": wcmp,
           "terrain_patch_texels": sc.terrain_patch_area}
    s = met["_summary"]
    gates = rep["gates"]
    rpt = cmp_["repetition"]
    tl = cmp_["texture_open_lawn"]
    hv = cmp_["value_hierarchy"]
    gates["canvas_1280x720_rgba"] = all(rgba[n].shape == (H, W, 4) for n in LAYERS)
    gates["ground_base_opaque"] = met["ground-base"]["opaque_texels"] == W * H
    gates["binary_alpha_all_layers"] = all(met[n]["semi_alpha_texels"] == 0 for n in ART_LAYERS) and \
        not ((rgba["guides"][..., 3] > 0) & (rgba["guides"][..., 3] < 255)).any()
    gates["art_layers_use_only_palette"] = all(met[n]["colours_outside_art_palette"] == 0 for n in ART_LAYERS)
    gates["palette_38_to_47_in_flat"] = 38 <= s["distinct_colours_in_flat"] <= 47
    gates["fg_occlusion_le_12pct_walkable"] = s["fg_occlusion_over_walkable_ratio"] <= 0.12
    gates["actor_visible_ge_one_third_everywhere"] = s["actor_visibility_below_one_third"] == 0
    gates["ysort_behind_front_stills_all_layers"] = all(v["ok"] for v in ys.values())
    gates["depth_audit_zero_wrong_order"] = dep["ok"]
    gates["paths_entry_to_all_pins_foot11"] = all(pth["foot11"].values())
    gates["stairs_ge_40px_clear_fountain_sides_ge_32px"] = pth["ok"]
    gates["fountain_dry_no_water_colours"] = s["water_colour_texels_in_fountain_footprint"] == 0
    gates["axial_walk_clear_and_walkable"] = ax["ok"]
    gates["walkable_and_block_masks_identical_to_v04"] = wcmp["identical"] and wcmp["block_identical"]
    gates["v04_files_and_tool_untouched"] = v04_untouched()
    # comparative quality indicators against v04: reported with both values, NOT gates (a worse value is shown,
    # not hidden or tuned away)
    def ind(v5, v4_, better):
        return {"v05": v5, "v04": v4_, "better_than_v04": bool(better)}
    v4_iso = 0.0502
    rep["quality_indicators_vs_v04"] = {
        "isolated_single_texel_ratio_whole_frame": ind(s["isolated_single_texel_ratio"], v4_iso,
                                                       s["isolated_single_texel_ratio"] < v4_iso),
        "open_lawn_isolated_ratio": ind(tl["v05"]["isolated_ratio"], tl["v04"]["isolated_ratio"],
                                        tl["v05"]["isolated_ratio"] < tl["v04"]["isolated_ratio"]),
        "open_lawn_mean_horizontal_run_px": ind(tl["v05"]["mean_horizontal_run_px"],
                                                tl["v04"]["mean_horizontal_run_px"],
                                                tl["v05"]["mean_horizontal_run_px"] > tl["v04"]["mean_horizontal_run_px"]),
        "repetition_whole_frame": ind(rpt["v05_flat"]["repeated_share"], rpt["v04_flat"]["repeated_share"],
                                      rpt["v05_flat"]["repeated_share"] <= rpt["v04_flat"]["repeated_share"]),
        "repetition_lawn_rows_352_720": ind(rpt["v05_lawn_rows_352_720"]["repeated_share"],
                                            rpt["v04_lawn_rows_352_720"]["repeated_share"],
                                            rpt["v05_lawn_rows_352_720"]["repeated_share"] <=
                                            rpt["v04_lawn_rows_352_720"]["repeated_share"]),
        "repetition_facade_band_rows_0_87": ind(rpt["v05_facade_band_rows_0_87"]["repeated_share"],
                                                rpt["v04_facade_band_rows_0_87"]["repeated_share"],
                                                rpt["v05_facade_band_rows_0_87"]["repeated_share"] <=
                                                rpt["v04_facade_band_rows_0_87"]["repeated_share"]),
        "deck_minus_facade_luminance": ind(hv["v05"]["deck_minus_facade"], hv["v04"]["deck_minus_facade"],
                                           hv["v05"]["deck_minus_facade"] > hv["v04"]["deck_minus_facade"]),
        "focal_minus_frame_foot_luminance": ind(hv["v05"]["focal_minus_frame_foot"],
                                                hv["v04"]["focal_minus_frame_foot"],
                                                hv["v05"]["focal_minus_frame_foot"] > hv["v04"]["focal_minus_frame_foot"]),
    }
    gates["terrain_patch_kinds_ge_8"] = sum(1 for v in sc.terrain_patch_area.values() if v > 0) >= 8
    gates["survey_post_ge_2x_actor"] = s["survey_post_height_px"] >= 96
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        dj = json.loads(z.read("data.json"))
    gates["pxo_layer_stack_is_v05_13_layers"] = [l["name"] for l in dj["layers"]] == LAYERS and \
        [l["visible"] for l in dj["layers"]] == [n != "guides" for n in LAYERS] and len(LAYERS) == 13
    gates["build_deterministic"] = artefacts()[3] == files
    evidence = {}
    if use_pixelorama:
        rep["pixelorama"] = pixelorama_gate(exe, files, rgba, flat)
        gates.update(rep["pixelorama"]["verdicts"])
        fp = rep["pixelorama"].pop("_flat_png", None)
        if fp is not None:
            evidence[fname("pixelorama-pxo-flat-export", "png")] = fp
    if godot:
        rep["godot"], stills = godot_gate(godot, files, rgba)
        gates.update(rep["godot"]["verdicts"])
        for k, b in stills.items():
            evidence[fname("godot-" + k.replace("_", "-"), "png")] = b
        rep["godot_collision"] = godot_collision_gate(godot, sc)
        gates.update(rep["godot_collision"]["verdicts"])
    rep["result"] = "PASS" if all(gates.values()) else "FAIL"
    rep["gate_count"] = len(gates)
    rep["note"] = "Technical gates only. Passing them does not make the art accepted; acceptance is creator review."
    text = json.dumps(rep, indent=2, default=str) + "\n"
    print(text)
    if write_report:
        out = rp(OUT_REL)
        print(write_new(os.path.join(out, fname("technical-check-report", "json")), text.encode()))
        for name, b in evidence.items():
            print(write_new(os.path.join(out, name), b), name)
    return 0 if rep["result"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("dir", nargs="?")
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    ap.add_argument("--write-report", action="store_true")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--godot", default=rp(GODOT_REL))
    ap.add_argument("--no-godot", action="store_true")
    a = ap.parse_args()
    if a.mode == "preview":
        if not a.dir or os.path.abspath(a.dir).startswith(REPO):
            raise SystemExit("preview needs a directory outside the repo")
        return build(a.dir)
    if a.mode == "build":
        return build()
    if not a.no_pixelorama and not os.path.isfile(a.pixelorama):
        raise SystemExit(f"Pixelorama not found: {a.pixelorama}")
    godot = None
    if not a.no_godot:
        if not os.path.isfile(a.godot):
            raise SystemExit(f"Godot not found: {a.godot} (or pass --no-godot)")
        godot = os.path.abspath(a.godot)
    return check(os.path.abspath(a.pixelorama), a.write_report, not a.no_pixelorama, godot)


if __name__ == "__main__":
    sys.exit(main())
