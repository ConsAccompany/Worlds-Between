"""Chicago Loop arrival block, State St x Lake St, native 640x360 pixel scene (UNAPPROVED candidate v01).

Camera faces north up State St. The 1895 Lake Street elevated (State/Lake station) crosses the
upper half: riveted plate-girder fascia, two open-tie tracks, the north side platform edge and
eight columns. Under it: warm brick and cream terra-cotta storefronts, the shaded Lake St lane and
a bright vista up State St. Below: the sunlit Lake St south sidewalk and the State St corner plaza
with honey locust planters, two ornamental lamps with Chicago-flag banners, a teal info kiosk and a
parked survey car. Real street names and grid numbers are runtime labels, not baked text.

Everything is hand-placed primitives (rects, lines, polygons, a seeded per-slab tone pick); no
image generation, resampling or filtering. Layers are bottom to top; y-sort layers carry a pivot
row: the runtime draws them over the hero only while the hero's feet are above (north of) it.
Writes runtime PNGs, a merged preview, the walk-mask guide, an OpenRaster and a Pixelorama .pxo,
and a hash manifest. Geometry constants must match the runtime scene script (checked in Godot).
"""

from __future__ import annotations

from pathlib import Path
import hashlib
import io
import json
import random
import sys
import zipfile
import xml.etree.ElementTree as ET

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
STAMP = "20261017-031308-26d71e3c"
PREFIX = "rpg-2-star-ocean-the-second_chicago-loop_state-lake"
OUT = ROOT / "outputs" / "chicago-loop-state-lake-v01"
RUNTIME = ROOT / "game" / "assets" / "environments" / "chicago-loop-state-lake-v01"
W, H = 640, 360
PIXELORAMA_VERSION = "v1.2.3-stable"

# --- Geometry shared with the runtime scene script (x, y, w, h; right/bottom edge exclusive). ---
WALK = (8, 178, 624, 138)
COLUMNS_X = (80, 240, 400, 560)
CAR = (406, 184, 68, 22)
LAMPS = ((250, 247), (390, 247))
KIOSK = (438, 263)
PLANTERS = ((68, 268, 96, 36), (476, 268, 96, 36))
BLOCKS = [CAR] + [(x - 6, 207, 12, 12) for x in COLUMNS_X] + [(x - 3, y - 5, 7, 7) for x, y in LAMPS] + [(KIOSK[0] - 10, KIOSK[1] - 11, 21, 12)] + list(PLANTERS)
DECK_BOTTOM = 132   # last fascia row; the walk top leaves a 44 px figure below it
NORTH_CURB, SOUTH_CURB = 174, 213
LAYERS = [  # name, y-sort pivot (None = always under the hero)
    ("ground-far", None),
    ("ysort-car", 205.5),
    ("ysort-l-columns", 213.5),
    ("ysort-lamps", 247.5),
    ("ysort-kiosk", 263.5),
    ("ysort-planter-trees", 297.5),
]
GUIDE = "guides-walkmask"

C = {
    "ink": "#151a17", "gap": "#191c19",
    "sky": "#cdd6cc", "sky_low": "#b9c5bd", "haze": "#8f9690", "haze_dark": "#7b837e", "haze_lit": "#a9aea4",
    "brick_dark": "#5c3427", "brick": "#7b4532", "brick_lit": "#9a5b3f", "mortar": "#6a4a3a",
    "tc_dark": "#a99b7e", "tc": "#c9b896", "tc_lit": "#e6d6b0",
    "stone_dark": "#6f5c48", "stone": "#8d7559", "stone_lit": "#a8906c", "stone_hi": "#c3b086",
    "pave": "#9c8a6e", "pave_alt": "#a8957a", "pave_lo": "#927f63", "joint": "#7a6a55", "pave_lit": "#b8a586",
    "mall": "#857561", "mall_alt": "#8f7f69", "mall_joint": "#6b5d4c",
    "shade": "#4a4339", "shade_alt": "#544c40", "shade_lo": "#3e3830", "shade_joint": "#332e28",
    "road": "#403c35", "road_lo": "#35322c", "road_lit": "#4e4940", "paint_dim": "#8e897a", "paint": "#d8d2bc",
    "steel_dark": "#1c2420", "steel": "#2e3a33", "steel_mid": "#3e4c42", "steel_lit": "#5a6a5a", "rivet": "#76866f",
    "rust": "#6a4630", "rust_lit": "#8a5a3a",
    "tie": "#3a2e24", "tie_lit": "#4c3c2c", "rail": "#8d948a", "rail_dark": "#5c625b",
    "concrete": "#a9a291", "concrete_dark": "#7f796b", "safety": "#c9a646",
    "teal_dark": "#1b5c68", "teal": "#4fa5a2", "glow": "#8be9d7",
    "warm_hi": "#f0c879", "warm": "#d9a65a", "warm_dim": "#a8743e", "interior": "#5a4632", "interior_dark": "#3d3026",
    "glass": "#3a4a4a", "glass_lit": "#4f6260", "glint": "#7f9690", "bronze": "#674927", "bronze_lit": "#a67b3d",
    "leaf_dark": "#2f3f24", "leaf": "#4f6a2f", "leaf_lit": "#7d9142", "leaf_hi": "#a9b860",
    "trunk": "#4a3a2a", "trunk_dark": "#2e241b", "soil": "#3a2f25",
    "car_dark": "#2c3f42", "car": "#4c6a6c", "car_lit": "#7a9a96", "car_glass": "#20302f", "car_glint": "#8fb2ab",
    "flag_white": "#eef0ea", "flag_blue": "#8cc4e6", "flag_red": "#d23a32", "bloom_red": "#c4553f", "bloom_gold": "#d9b44a",
    "lamp_green": "#24342b", "lamp_lit": "#3f5446", "wood": "#514031", "wood_lit": "#806247",
}
# Cast-shadow ramp for ground pixels (opaque palette swap, no alpha blending).
SHADOW = {"pave": "pave_lo", "pave_alt": "pave_lo", "pave_lit": "pave", "pave_lo": "joint", "joint": "shade_alt",
          "mall": "mall_joint", "mall_alt": "mall", "mall_joint": "shade", "stone_hi": "stone_lit", "stone_lit": "stone",
          "road": "road_lo", "road_lit": "road", "paint": "paint_dim", "teal": "teal_dark", "glow": "teal"}


def rgba(name):
    value = C.get(name, name).lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


class Layer:
    def __init__(self, opaque=False):
        self.img = Image.new("RGBA", (W, H), rgba("ink") if opaque else (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)

    def rect(self, x0, y0, x1, y1, fill, outline=None):
        self.d.rectangle((x0, y0, x1, y1), fill=rgba(fill), outline=rgba(outline) if outline else None)

    def line(self, points, fill, width=1):
        self.d.line(points, fill=rgba(fill), width=width)

    def poly(self, points, fill):
        self.d.polygon(points, fill=rgba(fill))

    def px(self, points, fill):
        for x, y in points:
            if 0 <= x < W and 0 <= y < H:
                self.img.putpixel((x, y), rgba(fill))

    def shadow(self, points):
        """Palette-swap the ground under a cast-shadow polygon."""
        mask = Image.new("L", (W, H), 0)
        ImageDraw.Draw(mask).polygon(points, fill=255)
        reverse = {rgba(k): rgba(v) for k, v in SHADOW.items()}
        box = mask.getbbox()
        if not box:
            return
        for y in range(box[1], box[3]):
            for x in range(box[0], box[2]):
                if mask.getpixel((x, y)):
                    here = self.img.getpixel((x, y))
                    self.img.putpixel((x, y), reverse.get(here, here))


# ---------------------------------------------------------------- ground and far planes
def paving(g, rng, x0, y0, x1, y1, slab_w, slab_h, tones, joint, bond=True):
    for row, y in enumerate(range(y0, y1 + 1, slab_h)):
        shift = (slab_w // 2) if (bond and row % 2) else 0
        for x in range(x0 - shift, x1 + 1, slab_w):
            g.rect(max(x, x0), y, min(x + slab_w - 2, x1), min(y + slab_h - 2, y1), rng.choice(tones))
        g.line([(x0, min(y + slab_h - 1, y1)), (x1, min(y + slab_h - 1, y1))], joint)
        for x in range(x0 - shift, x1 + 1, slab_w):
            if x0 <= x + slab_w - 1 <= x1:
                g.line([(x + slab_w - 1, y), (x + slab_w - 1, min(y + slab_h - 1, y1))], joint)


def chicago_window(g, x, y0, y1, frame, lit_rows):
    """Chicago window: wide fixed pane flanked by two narrow sashes."""
    g.rect(x, y0, x + 41, y1, frame)
    for px0, px1 in ((x + 2, x + 8), (x + 11, x + 30), (x + 33, x + 39)):
        g.rect(px0, y0 + 2, px1, y1, "interior_dark")
        g.rect(px0, y1 - lit_rows, px1, y1, "warm_dim")
        g.line([(px0, y0 + 2), (px1, y0 + 2)], "glint")


def far_planes(g):
    # Sky and the State St vista north of Lake St (mostly under the header; rows 62-81 visible).
    g.rect(0, 0, W - 1, 81, "sky")
    g.rect(248, 40, 392, 81, "sky_low")
    for x0, x1, top, tone in ((250, 282, 30, "haze_lit"), (286, 316, 44, "haze"), (322, 352, 22, "haze_lit"), (356, 390, 38, "haze")):
        g.rect(x0, top, x1, 81, tone)
        for wy in range(top + 4, 80, 5):
            for wx in range(x0 + 3, x1 - 2, 5):
                g.px([(wx, wy), (wx + 1, wy)], "haze_dark")
    g.rect(334, 18, 336, 22, "teal")
    # West building: brick with Chicago windows and a sandstone sill course.
    g.rect(0, 0, 247, 81, "brick")
    for y in range(3, 82, 4):
        g.line([(0, y), (247, y)], "mortar")
    for x in range(0, 240, 52):
        chicago_window(g, x + 6, 42, 74, "brick_dark", 4)
        g.rect(x + 2, 40, x + 5, 81, "brick_lit")
    g.rect(0, 76, 247, 79, "stone_hi")
    g.line([(0, 80), (247, 80)], "stone_dark")
    g.rect(244, 0, 247, 81, "brick_dark")
    # East building: cream terra cotta, spandrel band and Chicago windows (platform covers most).
    g.rect(393, 0, W - 1, 81, "tc")
    for x in range(393, W, 50):
        chicago_window(g, x + 5, 38, 70, "tc_dark", 3)
        g.rect(x + 1, 36, x + 3, 81, "tc_lit")
    g.rect(393, 72, W - 1, 75, "tc_lit")
    g.line([(393, 76), (W - 1, 76)], "tc_dark")
    g.rect(393, 0, 395, 81, "tc_dark")


def storefronts(g):
    """Ground floors under the deck, rows 133-160, warm lit glass behind stone and terra cotta piers."""
    g.rect(0, 133, W - 1, 160, "interior_dark")
    for x0, x1, pier, pier_lit, step in ((0, 247, "brick_dark", "brick", 40), (393, W - 1, "tc_dark", "tc", 38)):
        g.rect(x0, 133, x1, 137, "steel_dark")
        for x in range(x0, x1 + 1, step):
            g.rect(x, 133, x + 5, 160, pier)
            g.line([(x + 1, 138), (x + 1, 158)], pier_lit)
            gx0, gx1 = x + 6, min(x + step - 1, x1)
            if gx1 - gx0 < 6:
                continue
            g.rect(gx0, 139, gx1, 157, "interior")
            g.rect(gx0, 150, gx1, 157, "warm_dim")
            g.rect(gx0 + 2, 152, gx1 - 2, 156, "warm")
            g.line([(gx0 + 3, 154), (gx1 - 3, 154)], "warm_hi")
            g.line([((gx0 + gx1) // 2, 139), ((gx0 + gx1) // 2, 157)], "bronze")
            g.line([(gx0, 139), (gx1, 139)], "bronze_lit")
            for sx in range(gx0 + 3, gx1 - 2, 4):
                g.px([(sx, 135)], "warm_dim")
        g.rect(x0, 158, x1, 160, "stone_dark")
    # State St vista north under the L: shaded corner piers, then bright daylight beyond the deck.
    g.rect(248, 133, 392, 173, "road_lo")
    g.rect(262, 133, 378, 149, "pave_lit")
    for x0, x1, tone in ((262, 280, "tc"), (284, 300, "brick_lit"), (340, 356, "tc_lit"), (360, 378, "brick")):
        g.rect(x0, 133, x1, 143, tone)
        for wx in range(x0 + 2, x1 - 1, 4):
            g.px([(wx, 136), (wx, 140)], "interior")
    g.rect(300, 140, 340, 149, "pave")
    g.poly([(248, 173), (262, 150), (276, 150), (268, 173)], "shade")
    g.poly([(392, 173), (378, 150), (364, 150), (372, 173)], "shade")
    g.line([(268, 173), (276, 150)], "stone_lit")
    g.line([(372, 173), (364, 150)], "stone_lit")
    g.rect(276, 150, 364, 173, "road")
    g.rect(318, 153, 321, 172, "paint_dim")
    g.rect(244, 133, 247, 173, "brick_dark")
    g.rect(393, 133, 396, 173, "tc_dark")


def lake_street(g, rng):
    # North sidewalk in deep shade, then the roadway under the deck with slatted light.
    paving(g, rng, 0, 161, 247, 172, 16, 6, ["shade", "shade_alt", "shade_lo"], "shade_joint")
    paving(g, rng, 397, 161, W - 1, 172, 16, 6, ["shade", "shade_alt", "shade_lo"], "shade_joint")
    for x0, x1 in ((0, 255), (385, W - 1)):
        g.rect(x0, 173, x1, 174, "stone")
        g.line([(x0, 175), (x1, 175)], "steel_dark")
    g.rect(0, 176, W - 1, 211, "road")
    for y in range(176, 186):
        g.line([(0, y), (W - 1, y)], "road_lo")
    for x in range(0, W, 6):
        for y in range(188, 210):
            if (x // 6 + y // 3) % 2 == 0:
                g.px([(x, y)], "road_lit")
    for x in range(10, W, 28):
        g.rect(x, 194, x + 13, 194, "paint_dim")
    for cx in (263, 377):
        for y in range(177, 211, 4):
            g.rect(cx - 7, y, cx + 7, y + 1, "paint_dim")
    g.d.ellipse((150, 197, 159, 201), fill=rgba("road_lo"), outline=rgba("steel_mid"))
    # South curb in daylight.
    g.rect(0, 212, W - 1, 213, "stone_hi")
    g.line([(0, 211), (W - 1, 211)], "stone_dark")


def south_side(g, rng):
    paving(g, rng, 0, 214, W - 1, 243, 20, 10, ["pave", "pave_alt", "pave", "pave_lit"], "joint")
    # State St corner plaza: granite slabs framed by sett bands; a stone transit lane with teal seams.
    paving(g, rng, 0, 246, W - 1, 359, 16, 8, ["mall", "mall_alt", "mall", "pave_lo", "mall_alt"], "mall_joint")
    g.rect(0, 244, W - 1, 245, "stone_lit")
    g.line([(0, 246), (W - 1, 246)], "mall_joint")
    for x0, x1 in ((8, 196), (444, 631)):
        g.rect(x0, 252, x1, 253, "stone_lit")
        g.line([(x0, 254), (x1, 254)], "mall_joint")
    # Guideway: smooth basalt with long joints and a dashed teal centre line (reads as a lane, not steps).
    g.rect(292, 247, 348, 359, "stone_dark")
    g.rect(292, 247, 294, 359, "shade_alt")
    g.rect(346, 247, 348, 359, "shade_alt")
    for x in (306, 334):
        g.line([(x, 249), (x, 359)], "stone")
    for y in range(252, 360, 9):
        g.line([(320, y), (320, y + 4)], "teal_dark")
    g.rect(292, 247, 348, 247, "stone_lit")
    for x in (291, 349):
        g.line([(x, 247), (x, 359)], "mall_joint")
        for y in range(252, 360, 10):
            g.line([(x, y), (x, y + 5)], "teal")
            g.px([(x, y + 2)], "glow")
    # Wear and fallen honey locust leaflets.
    for _ in range(90):
        x, y = rng.randint(8, 631), rng.randint(216, 315)
        if 291 <= x <= 349:
            continue
        g.px([(x, y)], rng.choice(["pave_lit", "joint", "mall_joint"]))
    for px0, py0 in ((116, 240), (524, 240)):
        for _ in range(26):
            x, y = px0 + rng.randint(-60, 70), py0 + rng.randint(-20, 70)
            if 0 <= x < W and 214 <= y < 318:
                g.px([(x, y)], rng.choice(["leaf_lit", "leaf_hi", "bloom_gold"]))
    # Cast shadows (light from the upper left): columns, lamps, kiosk, car, planters.
    for x in COLUMNS_X:
        g.shadow([(x - 4, 214), (x + 5, 214), (x + 21, 230), (x + 12, 230)])
    for x, y in LAMPS:
        g.shadow([(x - 1, y), (x + 2, y), (x + 14, y + 10), (x + 11, y + 10)])
    g.shadow([(KIOSK[0] - 8, KIOSK[1]), (KIOSK[0] + 9, KIOSK[1]), (KIOSK[0] + 19, KIOSK[1] + 8), (KIOSK[0] + 2, KIOSK[1] + 8)])
    for x, y, w, h in PLANTERS:
        g.shadow([(x + 4, y + h), (x + w, y + h), (x + w + 10, y + h + 8), (x + 14, y + h + 8)])
    g.d.ellipse((CAR[0] - 2, CAR[1] + CAR[3] - 4, CAR[0] + CAR[2] + 3, CAR[1] + CAR[3] + 3), fill=rgba("road_lo"))


def deck(g):
    """Lake Street elevated: north platform edge, two open-tie tracks and the plate-girder fascia."""
    # Station platform on the north side (State/Lake), concrete with a safety edge.
    g.rect(412, 64, W - 1, 81, "concrete")
    for x in range(412, W, 8):
        g.line([(x, 64), (x, 79)], "concrete_dark")
    g.rect(412, 80, W - 1, 81, "safety")
    for x in range(424, W, 46):
        g.rect(x, 52, x + 2, 79, "steel_mid")
        g.line([(x, 52), (x, 79)], "steel_lit")
    g.rect(462, 66, 516, 77, "ink", "steel_lit")
    g.rect(412, 62, W - 1, 63, "steel_mid")
    # Track bed.
    g.rect(0, 82, W - 1, 121, "gap")
    g.rect(0, 82, W - 1, 84, "steel_mid")
    g.line([(0, 82), (W - 1, 82)], "steel_lit")
    g.rect(0, 100, W - 1, 103, "steel_mid")
    for x in range(0, W, 3):
        g.px([(x, 101)], "steel_dark")
    for y0, y1, rails in ((86, 98, (89, 95)), (104, 116, (107, 113))):
        for x in range(0, W, 5):
            g.rect(x, y0, x + 1, y1, "tie")
            g.px([(x, y0)], "tie_lit")
        for ry in rails:
            g.line([(0, ry), (W - 1, ry)], "rail")
            g.line([(0, ry + 1), (W - 1, ry + 1)], "rail_dark")
    g.rect(0, 118, W - 1, 121, "steel_mid")
    g.line([(0, 118), (W - 1, 118)], "steel_lit")
    # Fascia: riveted plate girder with stiffeners, rust weeping and restrained teal status lights.
    g.rect(0, 122, W - 1, 130, "steel")
    g.line([(0, 122), (W - 1, 122)], "steel_lit")
    g.rect(0, 131, W - 1, 132, "steel_dark")
    for x in range(4, W, 10):
        g.line([(x, 123), (x, 130)], "steel_mid")
        g.px([(x - 2, 124), (x - 2, 129)], "rivet")
    for x in (36, 118, 197, 289, 351, 466, 523, 611):
        g.line([(x, 124), (x, 130)], "rust")
        g.px([(x, 131), (x + 1, 125)], "rust_lit")
    for x in COLUMNS_X:
        g.rect(x - 7, 122, x + 7, 132, "steel_mid")
        g.line([(x - 7, 122), (x + 7, 122)], "steel_lit")
        g.px([(x - 5, 125), (x + 5, 125), (x - 5, 129), (x + 5, 129)], "rivet")
    for x in (160, 320, 480):
        g.rect(x - 2, 131, x + 2, 133, "steel_dark")
        g.line([(x - 1, 133), (x + 1, 133)], "warm_hi")
    for x in (120, 520):
        g.px([(x, 127)], "glow")
        g.px([(x, 126)], "teal")


def north_columns(g):
    for x in COLUMNS_X:
        g.rect(x - 3, 133, x + 3, 170, "steel_dark")
        g.line([(x - 2, 133), (x - 2, 168)], "steel")
        g.rect(x - 5, 168, x + 5, 173, "stone_dark")
        g.line([(x - 5, 168), (x + 5, 168)], "stone")


# ---------------------------------------------------------------- y-sorted layers
def columns_layer():
    c = Layer()
    for x in COLUMNS_X:
        # Built-up column (lattice-laced channels) from the curb to the girder, with knee braces.
        c.rect(x - 4, 133, x + 4, 210, "steel")
        c.line([(x - 4, 133), (x - 4, 210)], "steel_lit")
        c.line([(x - 3, 133), (x - 3, 210)], "steel_mid")
        c.line([(x + 4, 133), (x + 4, 210)], "steel_dark")
        for y in range(138, 205, 8):
            c.line([(x - 2, y), (x + 2, y + 6)], "steel_dark")
            c.line([(x + 2, y), (x - 2, y + 6)], "steel_mid")
        c.line([(x - 4, 150), (x - 14, 133)], "steel_mid", 2)
        c.line([(x + 4, 150), (x + 14, 133)], "steel_dark", 2)
        c.px([(x - 13, 133), (x + 13, 133)], "rivet")
        c.rect(x - 5, 133, x + 5, 136, "steel_mid")
        c.rect(x - 5, 160, x + 5, 162, "steel_mid")
        c.line([(x - 5, 160), (x + 5, 160)], "steel_lit")
        c.px([(x - 3, 161), (x + 3, 161)], "rivet")
        c.line([(x - 1, 176), (x - 1, 196)], "rust")
        c.px([(x - 1, 190), (x, 197)], "rust_lit")
        # Granite plinth and anti-strike collar at the curb.
        c.rect(x - 6, 206, x + 6, 216, "stone", "stone_dark")
        c.line([(x - 5, 207), (x + 5, 207)], "stone_hi")
        c.line([(x - 5, 208), (x - 5, 215)], "stone_lit")
        c.rect(x - 5, 200, x + 5, 205, "safety")
        c.line([(x - 5, 202), (x + 5, 202)], "steel_dark")
    # Survey beacon on the State St west column, the only active teal device on the structure.
    c.rect(234, 172, 238, 178, "steel_dark")
    c.px([(236, 174)], "glow")
    c.px([(236, 175)], "teal")
    return c


def car_layer():
    c = Layer()
    x0, y0, w, h = CAR
    x1, base = x0 + w - 1, y0 + h - 1
    c.rect(x0 + 2, base - 5, x0 + 13, base, "ink")
    c.rect(x1 - 14, base - 5, x1 - 3, base, "ink")
    c.rect(x0 + 1, 182, x1 - 1, base - 3, "car", "car_dark")
    c.line([(x0 + 2, 183), (x1 - 2, 183)], "car_lit")
    c.rect(x0 + 1, 194, x1 - 1, 196, "car_dark")
    c.line([(x0 + 4, 191), (x1 - 4, 191)], "teal")
    c.px([(x0 + 4, 191), (x1 - 4, 191)], "glow")
    # Cabin: roof seen from above, south window band.
    c.rect(x0 + 10, 166, x1 - 12, 181, "car_dark")
    c.rect(x0 + 12, 167, x1 - 14, 173, "car_lit")
    c.line([(x0 + 13, 168), (x1 - 15, 168)], "rail")
    c.rect(x0 + 12, 175, x1 - 14, 181, "car_glass")
    c.line([(x0 + 13, 176), (x0 + 22, 176)], "car_glint")
    c.line([(x0 + 34, 175), (x0 + 34, 181)], "car_dark")
    c.rect(x1 - 2, 185, x1, 188, "warm_hi")
    c.rect(x0, 185, x0 + 1, 188, "bloom_red")
    for wx in (x0 + 7, x1 - 8):
        c.d.ellipse((wx - 5, base - 7, wx + 5, base), fill=rgba("ink"))
        c.d.ellipse((wx - 2, base - 5, wx + 2, base - 2), fill=rgba("steel_lit"))
    return c


def lamps_layer():
    c = Layer()
    for x, y in LAMPS:
        c.rect(x - 3, y - 4, x + 3, y, "lamp_green")
        c.line([(x - 3, y - 4), (x + 3, y - 4)], "lamp_lit")
        c.rect(x - 1, y - 52, x + 1, y - 5, "lamp_green")
        c.line([(x - 1, y - 52), (x - 1, y - 5)], "lamp_lit")
        c.rect(x - 4, y - 61, x + 4, y - 53, "lamp_green")
        c.rect(x - 3, y - 60, x + 3, y - 54, "warm")
        c.line([(x - 2, y - 59), (x + 2, y - 59)], "warm_hi")
        c.rect(x - 2, y - 64, x + 2, y - 62, "lamp_green")
        # Chicago flag banner: white field, two light-blue stripes, four red stars.
        side = -1 if x < 320 else 1
        bx = x + side * 3
        c.line([(x, y - 46), (bx + side * 9, y - 46)], "lamp_green")
        fx0, fx1 = (bx, bx + 8) if side > 0 else (bx - 8, bx)
        c.rect(fx0, y - 45, fx1, y - 31, "flag_white")
        c.rect(fx0, y - 42, fx1, y - 41, "flag_blue")
        c.rect(fx0, y - 35, fx1, y - 34, "flag_blue")
        c.px([(fx0 + 1, y - 38), (fx0 + 3, y - 38), (fx0 + 5, y - 38), (fx0 + 7, y - 38)], "flag_red")
        c.line([(fx0, y - 31), (fx1, y - 31)], "tc_dark")
        # Hanging flower basket.
        c.line([(x, y - 28), (x - side * 6, y - 28)], "lamp_green")
        bx = x - side * 6
        c.rect(bx - 4, y - 26, bx + 4, y - 21, "leaf")
        c.line([(bx - 4, y - 26), (bx + 4, y - 26)], "leaf_lit")
        c.px([(bx - 3, y - 25), (bx + 1, y - 24), (bx + 3, y - 26), (bx - 1, y - 22)], "bloom_red")
        c.px([(bx, y - 26), (bx + 2, y - 23), (bx - 2, y - 24)], "bloom_gold")
        c.px([(bx - 4, y - 20), (bx + 3, y - 19), (bx + 4, y - 20)], "leaf_dark")
    return c


def kiosk_layer():
    c = Layer()
    x, y = KIOSK
    c.rect(x - 9, y - 4, x + 9, y, "steel_dark")
    c.line([(x - 9, y - 4), (x + 9, y - 4)], "steel_mid")
    c.rect(x - 7, y - 36, x + 7, y - 5, "steel", "steel_dark")
    c.line([(x - 6, y - 35), (x - 6, y - 6)], "steel_lit")
    c.rect(x - 8, y - 39, x + 8, y - 36, "bronze")
    c.line([(x - 8, y - 39), (x + 8, y - 39)], "bronze_lit")
    # Screen: a glowing loop rectangle around two crossing streets.
    c.rect(x - 5, y - 33, x + 5, y - 19, "teal_dark")
    c.rect(x - 3, y - 31, x + 3, y - 22, "teal_dark", "glow")
    c.line([(x - 4, y - 27), (x + 4, y - 27)], "teal")
    c.line([(x, y - 32), (x, y - 20)], "teal")
    c.px([(x, y - 27)], "warm_hi")
    c.rect(x - 5, y - 16, x + 5, y - 14, "teal")
    c.px([(x - 3, y - 10), (x + 3, y - 10)], "glow")
    return c


def crown(c, rng, cx, top, w, h):
    """Honey locust: airy fine-leaf clusters with sky gaps, lit from the upper left."""
    # Vase/umbrella outline: a wide, flat-bottomed ellipse of small leaf clusters, no stray lobes.
    blobs = []
    ecx, ecy, rx, ry = cx, top + h * 0.45, w / 2 - 5, h / 2 - 6
    while len(blobs) < 52:
        bx, by = cx + rng.randint(-w // 2, w // 2), top + rng.randint(0, h)
        if ((bx - ecx) / rx) ** 2 + ((by - ecy) / ry) ** 2 <= 1:
            blobs.append((bx, by, rng.randint(3, 5)))
    # Branches show through the gaps.
    for bx, by, _ in blobs[::4]:
        c.line([(cx, top + h - 2), (bx, by + 2)], "trunk_dark")
    for bx, by, r in blobs:
        c.d.ellipse((bx - r, by - r + 1, bx + r, by + r), fill=rgba("leaf_dark"))
    for bx, by, r in blobs:
        c.d.ellipse((bx - r + 1, by - r + 1, bx + r - 1, by + r - 2), fill=rgba("leaf"))
    for bx, by, r in blobs:
        if bx - cx < by - top - 4:
            continue
        c.d.ellipse((bx - r + 1, by - r + 1, bx + 1, by), fill=rgba("leaf_lit"))
    for _ in range(70):
        x, y = cx + rng.randint(-w // 2 + 2, w // 2 - 2), top + rng.randint(2, h - 6)
        if c.img.getpixel((x, y))[3]:
            lit = (x - cx) < (y - top - 6)
            c.px([(x, y)], "leaf_hi" if (not lit and rng.random() < 0.5) else "leaf_dark")
    # Ground and sky gaps through the lacy canopy (2x1 holes, never single pixels).
    for _ in range(22):
        x, y = cx + rng.randint(-w // 2 + 6, w // 2 - 7), top + rng.randint(6, h - 10)
        c.d.rectangle((x, y, x + 1, y), fill=(0, 0, 0, 0))


def planter_layer(rng):
    c = Layer()
    for x, y, w, h in PLANTERS:
        x1, y1 = x + w - 1, y + h - 1
        c.rect(x, y, x1, y1, "stone", "stone_dark")
        c.rect(x + 1, y, x1 - 1, y + 3, "stone_hi")
        c.rect(x + 3, y + 4, x1 - 3, y + 14, "soil")
        c.rect(x + 1, y + 15, x1 - 1, y1 - 1, "stone_lit")
        c.line([(x + 1, y + 15), (x1 - 1, y + 15)], "stone_hi")
        for sx in range(x + 24, x1, 24):
            c.line([(sx, y + 16), (sx, y1 - 1)], "stone")
        c.line([(x + 1, y1 - 1), (x1 - 1, y1 - 1)], "stone_dark")
        # Bench along the planter's south face: wood slats on bronze brackets.
        c.rect(x + 2, y + 29, x1 - 2, y1, "stone_dark")
        c.rect(x + 4, y + 28, x1 - 4, y + 30, "wood_lit")
        c.rect(x + 4, y + 31, x1 - 4, y + 33, "wood")
        c.line([(x + 4, y + 28), (x1 - 4, y + 28)], "tc_lit")
        for bx in (x + 8, x1 - 8):
            c.rect(bx - 1, y + 28, bx + 1, y1, "bronze")
        # Ground cover and flowers, then the trunk and crown.
        for gx in range(x + 4, x1 - 3, 3):
            c.px([(gx, y + 5 + (gx % 4)), (gx + 1, y + 9 + (gx % 3))], "leaf")
            c.px([(gx, y + 12)], "leaf_dark")
        for gx in range(x + 6, x1 - 5, 7):
            c.px([(gx, y + 7), (gx + 1, y + 7)], "bloom_red" if (gx // 7) % 2 else "bloom_gold")
        cx = x + w // 2
        c.rect(cx - 2, y - 26, cx + 2, y + 9, "trunk")
        c.line([(cx - 2, y - 26), (cx - 2, y + 9)], "stone_dark")
        c.line([(cx + 2, y - 26), (cx + 2, y + 9)], "trunk_dark")
        c.line([(cx, y - 24), (cx - 8, y - 36)], "trunk", 2)
        c.line([(cx + 1, y - 22), (cx + 9, y - 34)], "trunk_dark", 2)
        crown(c, rng, cx, y - 64, 58, 44)
    return c


# ---------------------------------------------------------------- guides, files
def walkable(x, y):
    def inside(r):
        return r[0] <= x < r[0] + r[2] and r[1] <= y < r[1] + r[3]
    return inside(WALK) and not any(inside(b) for b in BLOCKS)


def walkmask():
    img = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    for y in range(WALK[1], WALK[1] + WALK[3]):
        for x in range(WALK[0], WALK[0] + WALK[2]):
            if walkable(x, y):
                img.putpixel((x, y), (255, 255, 255, 255))
    return img


def build_layers():
    rng = random.Random(0x26D71E3C)
    g = Layer(opaque=True)
    far_planes(g)
    storefronts(g)
    lake_street(g, rng)
    north_columns(g)
    south_side(g, rng)
    deck(g)
    layers = {
        "ground-far": g.img,
        "ysort-car": car_layer().img,
        "ysort-l-columns": columns_layer().img,
        "ysort-lamps": lamps_layer().img,
        "ysort-kiosk": kiosk_layer().img,
        "ysort-planter-trees": planter_layer(random.Random(0x509A5E64)).img,
    }
    return layers


def png_bytes(img):
    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def merged(layers):
    out = layers["ground-far"].copy()
    for name, _ in LAYERS[1:]:
        out.alpha_composite(layers[name])
    return out


def ora_bytes(layers, guide, flat):
    root = ET.Element("image", {"w": str(W), "h": str(H), "name": PREFIX, "version": "0.0.3"})
    stack = ET.SubElement(root, "stack")
    buf = io.BytesIO()
    dt = (2026, 10, 17, 3, 13, 8)
    entries = [(name, layers[name], "visible") for name, _ in LAYERS] + [(GUIDE, guide, "hidden")]
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype", dt), "image/openraster", compress_type=zipfile.ZIP_STORED)
        z.writestr(zipfile.ZipInfo("mergedimage.png", dt), png_bytes(flat), compress_type=zipfile.ZIP_DEFLATED)
        for i, (name, img, vis) in reversed(list(enumerate(entries))):
            src = f"data/layer{i:02d}.png"
            z.writestr(zipfile.ZipInfo(src, dt), png_bytes(img), compress_type=zipfile.ZIP_DEFLATED)
            ET.SubElement(stack, "layer", {"name": name, "src": src, "x": "0", "y": "0", "opacity": "1.0", "visibility": vis, "composite-op": "svg:src-over"})
        z.writestr(zipfile.ZipInfo("stack.xml", dt), ET.tostring(root, encoding="utf-8", xml_declaration=True), compress_type=zipfile.ZIP_DEFLATED)
    return buf.getvalue()


def pxo_bytes(layers, guide, flat):
    entries = [(name, layers[name], True, False) for name, _ in LAYERS] + [(GUIDE, guide, False, True)]
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": locked, "metadata": {}, "name": name,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": visible} for name, _, visible, locked in entries]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0} for _ in entries],
                    "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps("chicago-loop-state-lake-v01"),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": len(LAYERS) - 1,
            "export_profile": export_profile, "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json,
            "license": "", "metadata": {}, "next_keyframe_id": 0, "palettes": [],
            "pixelorama_version": PIXELORAMA_VERSION, "project_current_palette_name": "", "pxo_version": 7,
            "reference_images": [], "size_x": W, "size_y": H, "symmetry_points": [W - 1.0, H - 1.0], "tags": [],
            "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0, "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H,
            "tilesets": [], "user_data": "", "vanishing_points": []}
    buf = io.BytesIO()
    dt = (2026, 10, 17, 3, 13, 8)
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def put(name, payload):
            z.writestr(zipfile.ZipInfo(name, dt), payload, zipfile.ZIP_DEFLATED)
        put("data.json", json.dumps(data, separators=(",", ":")))
        put("mimetype", "application/x-pixelorama")
        put("preview.png", png_bytes(flat))
        put("image_data/frames/1/", b"")
        for i, (_, img, _, _) in enumerate(entries, start=1):
            put(f"image_data/frames/1/layer_{i}", img.tobytes())
            put(f"image_data/frames/1/indices_layer_{i}", b"\x00")
    return buf.getvalue()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rel(path):
    path = Path(path).resolve()
    return str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path).replace("\\", "/")


def build(out=OUT, runtime=RUNTIME):
    out.mkdir(parents=True, exist_ok=True)
    runtime.mkdir(parents=True, exist_ok=True)
    layers = build_layers()
    guide = walkmask()
    flat = merged(layers)
    files = {}
    for name, pivot in LAYERS:
        data = png_bytes(layers[name])
        path = runtime / f"{PREFIX}_{name}_unapproved-v01_{STAMP}.png"
        path.write_bytes(data)
        files[name] = {"file": rel(path), "sha256": sha(data), "hash_algorithm": "sha256-bytes", "ysort_pivot_row": pivot}
    extra = {
        "merged-preview": (f"{PREFIX}_merged-preview_unapproved-v01_{STAMP}.png", png_bytes(flat)),
        "walkmask-guide": (f"{PREFIX}_{GUIDE}_unapproved-v01_{STAMP}.png", png_bytes(guide)),
        "openraster": (f"{PREFIX}_layered-source_unapproved-v01_{STAMP}.ora", ora_bytes(layers, guide, flat)),
        "pixelorama": (f"{PREFIX}_layered-source_unapproved-v01_{STAMP}.pxo", pxo_bytes(layers, guide, flat)),
    }
    for key, (name, data) in extra.items():
        (out / name).write_bytes(data)
        files[key] = {"file": rel(out / name), "sha256": sha(data), "hash_algorithm": "sha256-bytes"}
    colours = sorted({px[:3] for img in layers.values() for px in zip(*[iter(img.tobytes())] * 4) if px[3]})
    manifest = {
        "project": "Worlds Between", "scene": "Chicago Loop arrival block: State St x Lake St under the Lake Street elevated (State/Lake)",
        "status": "UNAPPROVED candidate v01 for Codex visual review; creator has not reviewed; scene-visual counters unchanged (3/12, 40.8%)",
        "canon": "The exact intersection is an art-pilot choice, not a creator-approved landmark; do not add it to the Game Bible as canon.",
        "authorship": "Hand-placed primitives in this tool by Claude (Claude Code, signed-in Claude Max, firstParty); no image generation, resampling or filtering.",
        "canvas": [W, H], "visible_art_rows": [62, 317], "palette_colours": len(colours),
        "layers_bottom_to_top": [{"name": n, "ysort_pivot_row": p} for n, p in LAYERS] + [{"name": GUIDE, "hidden": True, "locked": True}],
        "geometry": {"walk": WALK, "blocks": BLOCKS, "columns_x": COLUMNS_X, "car": CAR, "lamps": LAMPS, "kiosk": KIOSK,
                     "planters": PLANTERS, "deck_bottom_row": DECK_BOTTOM, "curbs": [NORTH_CURB, SOUTH_CURB]},
        "pixelorama": "pxo_version 7, color_mode 5, 1 frame x 7 layers (guides-walkmask hidden + locked); ORA lists the same 7 layers",
        "files": files,
        "source": rel(Path(__file__).resolve()),
    }
    path = out / f"{PREFIX}_layer-manifest_unapproved-v01_{STAMP}.json"
    path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(path)
    return manifest


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--preview":
        # Iteration aid: write only a merged preview to the given path.
        merged(build_layers()).save(sys.argv[2])
    else:
        build()
