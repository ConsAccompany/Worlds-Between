"""Author the UNAPPROVED native-pixel patrol automaton battle pilot (one idle frame, facing left).

Every plate, joint, light and grime pixel below is an explicitly placed shape or
pixel on the final 64x92 canvas. No concept image is opened, sampled, traced or
resized; the two unapproved concepts were used only as visual reference:
  outputs/rpg-2-star-ocean-the-second_scifi-patrol-automaton_character-sheet-unapproved_m8-v01_20261014-210242-914af608.png
  outputs/rpg-2-star-ocean-the-second_scifi-patrol-automaton_single-sprite-style-concept-unapproved_m8-v02_20261014-211647-c322cc8a.png

Parts are composited back to front. Each part gets a 1px dark ring, so a front
part leaves a seam where it overlaps a back part and the outer silhouette is
outlined. Top/left exterior outline pixels are then softened (selective outline).
The ground-contact anchor (29, 90) is the sole outline row, centred toe-to-heel.

Usage (bundled Python/Pillow runtime):
  python <this file>                -> new uniquely named PNG + manifest in game/assets/enemies/patrol-automaton-pilot/
  python <this file> --out DIR      -> scratch render (PNG + 6x preview) for iteration, no manifest
Re-running never overwrites an existing asset.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import uuid
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "game" / "assets" / "enemies" / "patrol-automaton-pilot"
SLUG = "rpg-2-star-ocean-the-second"
SIZE = (64, 92)
ANCHOR = (29, 90)
CONCEPTS = [
    "outputs/rpg-2-star-ocean-the-second_scifi-patrol-automaton_character-sheet-unapproved_m8-v01_20261014-210242-914af608.png",
    "outputs/rpg-2-star-ocean-the-second_scifi-patrol-automaton_single-sprite-style-concept-unapproved_m8-v02_20261014-211647-c322cc8a.png",
]

# Dark slate ramp, aged brass ramp, cyan sensor ramp, one grime tone.
PALETTE = {
    "o": "#101217",
    "1": "#1b1f26", "2": "#282e37", "3": "#384049", "4": "#4c5562", "5": "#67717e", "6": "#8b95a1",
    "a": "#36291b", "b": "#5a462b", "c": "#806439", "d": "#a6864f", "e": "#cbb077",
    "r": "#4b3627",
    "x": "#0c363c", "y": "#188a92", "z": "#4bd5d2", "w": "#c6fff6",
}
INDEX = {key: i + 1 for i, key in enumerate(PALETTE)}
KEYS = {v: k for k, v in INDEX.items()}
BRASS = set("abcde")
W, H = SIZE


class Part:
    """One plate group drawn into its own index layer; later paints clip to the part mask."""

    def __init__(self, name: str):
        self.name = name
        self.layer = Image.new("L", SIZE, 0)
        self.draw = ImageDraw.Draw(self.layer)

    def poly(self, pts, key):
        self.draw.polygon(pts, fill=INDEX[key])

    def rect(self, x0, y0, x1, y1, key):
        self.draw.rectangle((x0, y0, x1, y1), fill=INDEX[key])

    def oval(self, x0, y0, x1, y1, key):
        self.draw.ellipse((x0, y0, x1, y1), fill=INDEX[key])

    def px(self, pts, key):
        for p in pts:
            self.layer.putpixel(p, INDEX[key])

    def _clip(self, shape_fn, key):
        mask = Image.new("L", SIZE, 0)
        shape_fn(ImageDraw.Draw(mask))
        src = self.layer.load()
        m = mask.load()
        for y in range(H):
            for x in range(W):
                if m[x, y] and src[x, y]:
                    src[x, y] = INDEX[key]

    def clip_rect(self, x0, y0, x1, y1, key):
        self._clip(lambda d: d.rectangle((x0, y0, x1, y1), fill=255), key)

    def clip_poly(self, pts, key):
        self._clip(lambda d: d.polygon(pts, fill=255), key)

    def clip_oval(self, x0, y0, x1, y1, key):
        self._clip(lambda d: d.ellipse((x0, y0, x1, y1), fill=255), key)

    def rim(self, lit: str, mid: str, dark: str):
        """Recolour the part's own border: top/left-facing edge lit, bottom/right dark."""
        src = self.layer.load()
        inside = {(x, y) for y in range(H) for x in range(W) if src[x, y]}
        changes = {}
        for x, y in inside:
            up, left = (x, y - 1) not in inside, (x - 1, y) not in inside
            down, right = (x, y + 1) not in inside, (x + 1, y) not in inside
            if up or left:
                changes[(x, y)] = lit
            elif down or right:
                changes[(x, y)] = dark
        for (x, y), key in changes.items():
            src[x, y] = INDEX[key if key != "mid" else mid]


def build_parts() -> list[Part]:
    parts = []

    # Far-side arm, mostly hidden behind the torso and rear shoulder.
    p = Part("rear_arm")
    p.rect(48, 38, 54, 46, "1")
    p.rect(48, 38, 48, 46, "2")
    p.oval(47, 45, 55, 52, "b")
    p.oval(47, 45, 53, 50, "c")
    p.px([(49, 46), (50, 46)], "d")
    p.poly([(48, 51), (55, 51), (55, 58), (49, 58)], "2")
    p.clip_rect(53, 51, 55, 58, "1")
    p.rect(48, 57, 55, 58, "b")
    p.px([(49, 57)], "c")
    p.rect(49, 59, 55, 61, "1")
    p.rect(49, 62, 50, 64, "2")
    p.rect(53, 62, 54, 63, "1")
    parts.append(p)

    # Tall sensor mast rising from the far shoulder.
    p = Part("mast")
    p.poly([(48, 2), (50, 2), (52, 7), (52, 30), (46, 30), (46, 7)], "2")
    p.clip_rect(51, 2, 52, 30, "1")
    p.clip_rect(46, 2, 46, 30, "c")
    p.clip_rect(47, 2, 47, 30, "d")
    p.clip_rect(46, 2, 52, 4, "c")
    p.clip_rect(47, 2, 49, 2, "e")
    p.px([(50, 4), (51, 5)], "b")
    p.rect(48, 7, 49, 21, "z")
    p.rect(49, 7, 49, 21, "y")
    p.px([(48, 7), (49, 7), (48, 21), (49, 21)], "x")
    p.px([(48, 10), (48, 11)], "w")
    p.rect(50, 7, 50, 25, "3")
    p.px([(47, 16), (47, 23)], "b")
    p.rect(46, 25, 52, 27, "b")
    p.rect(47, 25, 50, 25, "c")
    p.px([(51, 27), (52, 26)], "a")
    parts.append(p)

    # Compact far shoulder block with a brass joint.
    p = Part("rear_shoulder")
    p.poly([(41, 26), (52, 26), (55, 29), (55, 36), (52, 39), (40, 39), (37, 35), (38, 29)], "2")
    p.clip_rect(37, 26, 55, 28, "3")
    p.clip_rect(40, 26, 51, 26, "4")
    p.clip_rect(53, 28, 55, 39, "1")
    p.clip_rect(37, 37, 55, 39, "1")
    p.oval(44, 31, 50, 37, "b")
    p.oval(44, 31, 49, 36, "c")
    p.px([(45, 32), (46, 32), (45, 33)], "d")
    p.px([(46, 34), (47, 34)], "a")
    p.px([(54, 33)], "r")
    parts.append(p)

    # Far leg, set back and one value darker.
    p = Part("rear_leg")
    p.poly([(35, 54), (45, 54), (47, 64), (38, 65)], "2")
    p.clip_rect(44, 54, 47, 65, "1")
    p.clip_rect(36, 55, 37, 63, "3")
    p.rect(37, 59, 45, 59, "1")
    p.oval(38, 63, 45, 70, "a")
    p.oval(38, 63, 44, 69, "b")
    p.oval(39, 64, 42, 67, "c")
    p.px([(40, 65)], "d")
    p.poly([(39, 70), (48, 70), (49, 82), (40, 82)], "2")
    p.clip_rect(46, 70, 49, 82, "1")
    p.clip_rect(40, 71, 40, 80, "3")
    p.px([(43, 76), (44, 77)], "r")
    p.rect(39, 81, 49, 83, "b")
    p.rect(40, 81, 47, 81, "c")
    p.poly([(34, 85), (38, 83), (49, 83), (51, 86), (51, 89), (33, 89)], "2")
    p.clip_rect(35, 83, 46, 84, "3")
    p.clip_rect(48, 83, 51, 88, "1")
    p.rect(33, 86, 37, 88, "b")
    p.rect(34, 86, 37, 86, "c")
    p.rect(33, 89, 51, 89, "1")
    p.px([(x, 89) for x in range(35, 51, 3)], "o")
    parts.append(p)

    # Exposed waist: ribbed spine between brass pistons.
    p = Part("waist")
    p.rect(25, 41, 40, 48, "1")
    for y in (43, 45):
        p.rect(29, y, 36, y, "2")
        p.px([(29, y)], "3")
    p.rect(32, 42, 33, 47, "3")
    p.px([(32, 42), (32, 44), (32, 46)], "4")
    for x in (27, 38):
        p.rect(x, 42, x, 47, "b")
        p.px([(x, 42)], "d")
        p.px([(x, 43)], "c")
    parts.append(p)

    # Barrel torso: lit front plane, strap at the pauldron edge, shadowed side plane with vents.
    p = Part("torso")
    p.poly([(19, 24), (44, 24), (47, 28), (47, 36), (42, 42), (26, 43), (19, 37), (17, 28)], "3")
    p.clip_poly([(17, 24), (37, 24), (36, 43), (17, 43)], "4")
    p.clip_rect(17, 24, 38, 25, "5")
    p.clip_poly([(39, 24), (48, 24), (48, 44), (38, 44)], "2")
    p.clip_rect(37, 26, 38, 43, "3")
    p.clip_rect(17, 40, 36, 43, "3")
    p.clip_rect(37, 40, 48, 43, "1")
    p.rect(31, 25, 31, 41, "d")
    p.rect(32, 25, 32, 41, "c")
    p.rect(33, 25, 33, 41, "b")
    p.px([(32, 28), (32, 36)], "e")
    p.px([(33, 28), (33, 36)], "a")
    p.px([(31, 33), (32, 39)], "b")
    p.rect(39, 34, 46, 34, "1")
    p.rect(39, 35, 45, 35, "3")
    for x in (40, 42, 44):
        p.rect(x, 27, x, 31, "1")
        p.px([(x, 32)], "3")
    p.px([(43, 38), (41, 39), (46, 30)], "r")
    p.px([(35, 27), (36, 27), (24, 24), (25, 24)], "6")
    p.px([(41, 33), (43, 32)], "r")
    parts.append(p)

    # Hip block with brass belt and the cyan core cell.
    p = Part("pelvis")
    p.poly([(20, 47), (45, 47), (44, 55), (38, 57), (26, 57), (21, 55)], "3")
    p.clip_rect(39, 47, 46, 57, "2")
    p.clip_rect(19, 54, 46, 57, "2")
    p.rect(19, 47, 46, 50, "c")
    p.rect(19, 47, 40, 47, "d")
    p.rect(19, 50, 46, 50, "b")
    p.rect(41, 47, 46, 49, "b")
    p.px([(22, 48), (36, 49)], "b")
    p.rect(26, 46, 36, 52, "b")
    p.rect(26, 46, 35, 46, "c")
    p.rect(27, 47, 35, 51, "o")
    p.rect(28, 48, 34, 50, "y")
    p.rect(28, 48, 34, 48, "z")
    p.px([(29, 48), (30, 48)], "w")
    p.px([(28, 50), (34, 50), (34, 49)], "x")
    p.rect(37, 47, 39, 51, "d")
    p.rect(39, 47, 39, 51, "b")
    p.px([(37, 47)], "e")
    p.rect(29, 53, 36, 53, "4")
    parts.append(p)

    # Near leg: brass knee cap, lit greave, broad sabaton with brass toe cap and tread.
    p = Part("front_leg")
    p.poly([(22, 54), (32, 54), (31, 64), (23, 65)], "3")
    p.clip_rect(22, 54, 25, 65, "4")
    p.clip_rect(29, 54, 32, 65, "2")
    p.rect(23, 59, 30, 59, "2")
    p.rect(24, 60, 28, 60, "5")
    p.oval(19, 63, 28, 72, "b")
    p.oval(19, 63, 27, 71, "c")
    p.oval(20, 64, 24, 68, "d")
    p.px([(21, 65), (22, 65), (21, 66)], "e")
    p.px([(24, 68), (25, 68), (24, 69)], "b")
    p.px([(24, 68)], "a")
    p.px([(26, 70)], "b")
    p.poly([(18, 72), (30, 72), (31, 82), (19, 82)], "3")
    p.clip_rect(18, 72, 21, 82, "4")
    p.clip_rect(19, 73, 19, 80, "5")
    p.clip_rect(28, 72, 31, 82, "2")
    p.rect(22, 74, 22, 80, "2")
    p.rect(23, 74, 23, 80, "5")
    p.px([(25, 78), (26, 79), (20, 77)], "r")
    p.rect(18, 81, 31, 83, "b")
    p.rect(19, 81, 29, 81, "c")
    p.px([(18, 81)], "d")
    p.poly([(7, 85), (11, 83), (32, 83), (33, 86), (33, 89), (7, 89)], "3")
    p.clip_rect(7, 83, 30, 84, "4")
    p.clip_rect(12, 83, 20, 83, "5")
    p.clip_rect(29, 85, 33, 88, "2")
    p.rect(7, 86, 16, 88, "c")
    p.rect(8, 86, 15, 86, "d")
    p.rect(7, 88, 16, 88, "b")
    p.px([(9, 86), (10, 86)], "e")
    p.px([(13, 87)], "b")
    p.rect(7, 89, 33, 89, "1")
    p.px([(x, 89) for x in range(9, 33, 3)], "o")
    parts.append(p)

    # Hanging hip plate over the front thigh.
    p = Part("tasset")
    p.poly([(18, 51), (25, 51), (24, 58), (19, 58)], "4")
    p.clip_rect(18, 51, 25, 51, "5")
    p.clip_rect(23, 52, 25, 58, "3")
    p.rect(19, 57, 24, 58, "b")
    p.rect(19, 57, 23, 57, "c")
    p.px([(20, 53)], "6")
    parts.append(p)

    # Brass neck pistons between head and chest.
    p = Part("neck")
    p.rect(21, 19, 31, 26, "1")
    for x in (23, 28):
        p.rect(x, 19, x, 25, "c")
        p.rect(x + 1, 19, x + 1, 25, "b")
        p.px([(x, 20)], "e")
    p.px([(26, 22), (26, 23)], "2")
    parts.append(p)

    # Compact camera head, single cyan lens in a brass bezel facing left.
    p = Part("head")
    p.poly([(17, 8), (29, 8), (32, 11), (32, 18), (30, 20), (17, 20), (15, 18), (15, 10)], "3")
    p.clip_rect(15, 8, 32, 10, "4")
    p.clip_rect(17, 8, 28, 8, "5")
    p.px([(20, 8), (21, 8)], "6")
    p.clip_rect(15, 18, 32, 20, "2")
    p.clip_rect(30, 11, 32, 20, "2")
    p.clip_rect(19, 15, 32, 15, "c")
    p.clip_rect(19, 16, 32, 16, "b")
    p.px([(20, 15)], "e")
    p.px([(29, 13), (30, 13), (29, 14)], "d")
    p.px([(30, 14)], "b")
    p.px([(24, 12), (25, 12)], "2")
    p.rect(11, 10, 18, 18, "c")
    p.rect(11, 10, 18, 10, "d")
    p.rect(11, 10, 11, 18, "d")
    p.rect(12, 18, 18, 18, "b")
    p.rect(18, 11, 18, 18, "b")
    p.px([(11, 10)], "e")
    p.rect(12, 11, 17, 17, "o")
    p.oval(12, 11, 17, 16, "x")
    p.oval(13, 12, 16, 15, "y")
    p.rect(14, 13, 15, 14, "z")
    p.px([(14, 13)], "w")
    parts.append(p)

    # Near forearm and three-claw hand, hanging forward of the hip.
    p = Part("front_arm")
    p.rect(9, 40, 17, 48, "2")
    p.rect(9, 40, 10, 48, "3")
    p.oval(8, 46, 17, 54, "b")
    p.oval(8, 46, 16, 53, "c")
    p.oval(9, 47, 12, 50, "d")
    p.px([(10, 47)], "e")
    p.poly([(8, 53), (17, 53), (17, 61), (7, 61)], "3")
    p.clip_rect(7, 53, 9, 61, "4")
    p.clip_rect(8, 54, 8, 59, "5")
    p.clip_rect(15, 53, 17, 61, "2")
    p.rect(12, 55, 12, 58, "2")
    p.rect(7, 60, 17, 61, "b")
    p.rect(7, 60, 16, 60, "c")
    p.rect(6, 62, 16, 65, "2")
    p.rect(6, 62, 15, 62, "3")
    p.px([(8, 63), (11, 63), (14, 63)], "4")
    p.rect(5, 66, 7, 69, "3")
    p.px([(5, 66), (6, 66)], "4")
    p.rect(5, 69, 6, 69, "2")
    p.rect(9, 66, 11, 70, "3")
    p.rect(10, 69, 11, 70, "2")
    p.rect(13, 66, 15, 68, "2")
    p.rect(3, 62, 4, 65, "2")
    p.px([(3, 62)], "3")
    parts.append(p)

    # Lower lame of the near pauldron, overlapped by the cap.
    p = Part("pauldron_lame")
    p.poly([(6, 37), (28, 37), (26, 43), (20, 46), (10, 46), (6, 42)], "3")
    p.clip_rect(6, 37, 28, 39, "4")
    p.clip_poly([(28, 40), (28, 47), (6, 47), (9, 44), (22, 43)], "2")
    p.rim("c", "c", "b")
    p.px([(12, 44), (18, 45)], "r")
    parts.append(p)

    # Broad near pauldron cap: brass rim, brass roundel with slot, worn plate.
    p = Part("pauldron")
    p.poly([(10, 24), (24, 24), (29, 28), (30, 34), (28, 39), (8, 40), (5, 37), (4, 29), (6, 26)], "3")
    p.clip_oval(2, 21, 24, 39, "4")
    p.clip_rect(8, 25, 22, 26, "5")
    p.clip_rect(5, 29, 6, 35, "5")
    p.clip_poly([(31, 30), (31, 41), (8, 41), (12, 38), (24, 36), (28, 32)], "2")
    p.rim("d", "c", "b")
    p.oval(11, 27, 21, 37, "b")
    p.oval(11, 27, 20, 36, "c")
    p.oval(12, 28, 16, 32, "d")
    p.px([(13, 29), (14, 29)], "e")
    p.rect(15, 30, 15, 34, "a")
    p.rect(16, 30, 16, 34, "b")
    p.px([(8, 28), (26, 29), (26, 36)], "6")
    p.px([(23, 37), (9, 37)], "r")
    p.px([(22, 27), (23, 28)], "6")
    parts.append(p)

    return parts


def composite(parts: list[Part]) -> Image.Image:
    grid = [[0] * W for _ in range(H)]
    for part in parts:
        src = part.layer.load()
        inside = {(x, y) for y in range(H) for x in range(W) if src[x, y]}
        for x, y in inside:
            for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in inside:
                    grid[ny][nx] = INDEX["o"]
        for x, y in inside:
            grid[y][x] = src[x, y]
    # Selective outline: soften exterior outline on lit top/left edges.
    soft = {}
    for y in range(H):
        for x in range(W):
            if grid[y][x] != INDEX["o"]:
                continue
            exterior = any(
                not (0 <= nx < W and 0 <= ny < H) or grid[ny][nx] == 0
                for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1))
            )
            if not exterior:
                continue
            for nx, ny in ((x + 1, y), (x, y + 1)):
                if 0 <= nx < W and 0 <= ny < H:
                    key = KEYS.get(grid[ny][nx])
                    if key in ("d", "e"):
                        soft[(x, y)] = "a"
                    elif key in ("5", "6"):
                        soft[(x, y)] = "1"
    for (x, y), key in soft.items():
        grid[y][x] = INDEX[key]
    img = Image.new("RGBA", SIZE, (0, 0, 0, 0))
    out = img.load()
    for y in range(H):
        for x in range(W):
            if grid[y][x]:
                h = PALETTE[KEYS[grid[y][x]]]
                out[x, y] = (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), 255)
    return img


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()
    img = composite(build_parts())
    bbox = img.getbbox()
    colours = sorted({c for c in img.getdata() if c[3]})
    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        img.save(args.out / "pilot.png")
        bg = Image.new("RGBA", SIZE, (118, 122, 128, 255))
        bg.alpha_composite(img)
        bg.resize((W * 6, H * 6), Image.NEAREST).save(args.out / "pilot_6x.png")
        print("scratch", args.out, "bbox", bbox, "colours", len(colours))
        return
    OUT.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    token = uuid.uuid4().hex[:8]
    name = f"{SLUG}_scifi-patrol-automaton_battle-idle-left_m8-pilot-v01_{stamp}-{token}.png"
    path = OUT / name
    assert not path.exists()
    img.save(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest = {
        "project": SLUG,
        "asset": "scifi patrol automaton battle sprite pilot",
        "status": "pilot_unapproved",
        "artAccepted": False,
        "artAcceptanceCount": 0,
        "file": str(path.relative_to(ROOT)).replace("\\", "/"),
        "sha256": digest,
        "size": list(SIZE),
        "opaqueBBox": list(bbox),
        "groundAnchor": list(ANCHOR),
        "facing": "left (toward party)",
        "frames": ["idle (single static frame; wind-up is shown in engine by tint, telegraph ring and label)"],
        "displayScale": "1 native px = 1 logical px in the 640x360 view = 2x2 physical px at 1280x720",
        "colourCount": len(colours),
        "palette": PALETTE,
        "method": "Hand-authored in code: explicit plate polygons, joints, light clusters and grime pixels on the final canvas, composited with per-part outline seams and a top/left selective outline. No concept image is read, traced or resampled.",
        "authorScript": str(Path(__file__).resolve().relative_to(ROOT)).replace("\\", "/"),
        "referenceConcepts": CONCEPTS,
        "scope": "patrol enemy only; sentry keeps the placeholder block",
        "runtimeSwitch": "game/scripts/battle_arena.gd ENEMY_SPRITE_PILOT_ENABLED (false, or a missing texture, restores the placeholder block)",
        "createdAt": datetime.now().isoformat(timespec="seconds"),
    }
    mpath = OUT / f"{SLUG}_scifi-patrol-automaton_battle-pilot-manifest_m8-pilot-v01_{stamp}-{token}.json"
    mpath.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(path.relative_to(ROOT))
    print(mpath.relative_to(ROOT))
    print("sha256", digest, "bbox", bbox, "colours", len(colours))


if __name__ == "__main__":
    main()
