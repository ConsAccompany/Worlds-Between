"""Native-pixel Washington, D.C. survey annex room 1 (遗址外环 / Ruin Outer Ring), UNAPPROVED v01.

Replaces the rejected m8-concept painted plate (desert arches, generic ruin) with a hand-placed
640x360 limited-palette scene: a damaged neoclassical civic interior near the Capitol grounds
(Ionic pilasters, dentil cornice, statue niches, Minton-style encaustic tile bands), a west window
with the dome in view, a partial collapse that shows the Washington Monument on the horizon, ivy
and a sapling in the rubble, and an active survey station (teal light rail, wall scanner, beacon,
floodlight, steel shore). Three 64x64 clue fixtures sit at the unchanged clue sites.

The old plate was used only as a composition reference (wall band on top, three clue sites,
side doors at y~257, clear central lane); no pixels are copied from it.

Writes, for the scene and each fixture: merged PNG, layered OpenRaster (.ora) and Pixelorama
(.pxo, pxo_version 7) sources plus a manifest with sha256 hashes, and the runtime PNG copies.
Every primitive is placed by this script; no image generation, resampling or filtering.
"""

from __future__ import annotations

from pathlib import Path
import hashlib
import io
import json
import random
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
STAMP = "20261017-030801-65b9618f"
PREFIX = "rpg-2-star-ocean-the-second_wdc-annex-room1"
OUT = ROOT / "outputs/wdc-sr1-v01_65b9618f"
RUNTIME_SCENE_DIR = ROOT / "game/assets/environments/wdc-survey-room1"
RUNTIME_PROP_DIR = ROOT / "game/assets/props/wdc-annex-room1"
PIXELORAMA_VERSION = "v1.2.3-stable"
W, H = 640, 360
FW = FH = 64
CLUES = [(163, 165), (320, 165), (477, 165)]
FIXTURE_OFFSET = (-32, 2)

PAL = {
    # outlines and darkness
    "ink": "#1a1612", "void": "#14110e", "void2": "#211c17",
    # warm sandstone / plaster wall ramp
    "stone_0": "#2a241e", "stone_1": "#3f362c", "stone_2": "#5a4e3f", "stone_3": "#776a55",
    "stone_4": "#958670", "stone_5": "#b3a58b", "stone_6": "#cfc3a8", "stone_7": "#e6dcc5",
    "stone_teal": "#93a99b",
    # marble floor ramp
    "floor_0": "#2f2924", "floor_1": "#4b4237", "floor_2": "#675b4b", "floor_3": "#83765f",
    "floor_4": "#9d9077", "floor_5": "#b6aa90", "floor_teal": "#62807a", "floor_teal_l": "#7d9b93",
    # Minton-style encaustic tile
    "terra_d": "#5e2e22", "terra": "#8e4630", "terra_l": "#a8583a",
    "buff_dd": "#6e5430", "buff_d": "#8f6d3e", "buff": "#b8955a", "buff_l": "#d2b277",
    "navy_d": "#1f2d3b", "navy": "#2b3f52", "navy_l": "#45627a",
    # wood, metal, brass
    "wood_d": "#3b2a1c", "wood": "#5f4328", "wood_l": "#86603a",
    "steel_d": "#262f33", "steel": "#45545a", "steel_l": "#6f8288", "steel_hi": "#a3b5b5",
    "brass_d": "#5c4424", "brass": "#93723c", "brass_l": "#c9a35e",
    # survey technology light
    "teal_d": "#173f47", "teal": "#2f7f80", "teal_l": "#5fb9ac", "glow": "#a6ead8",
    "red": "#b8483a", "lamp": "#f2e6c4",
    # vegetation
    "leaf_0": "#1c2a1a", "leaf_1": "#2c4224", "leaf_2": "#43602d", "leaf_3": "#5f7e38", "leaf_4": "#86a14a",
    "moss": "#5a6436",
    # exterior: sky, distant city, lawn
    "sky_0": "#7f9cad", "sky_1": "#a2bccb", "sky_2": "#c6d7dd", "glass": "#b4ccd0",
    "dome_shadow": "#8b949c", "dome": "#c7ccce", "dome_hi": "#eceeea",
    "lawn_d": "#3d5a2c", "lawn": "#5d7c3a", "lawn_l": "#86a050",
    "paper": "#d9cba8", "paper_d": "#a99b7e",
}
RGB = {k: tuple(int(v[i:i + 2], 16) for i in (1, 3, 5)) for k, v in PAL.items()}
SHADOW_RGBA = (18, 15, 12, 0xA8)

RAMPS = [
    ["floor_0", "floor_1", "floor_2", "floor_3", "floor_4", "floor_5", "stone_7"],
    ["void", "stone_0", "stone_1", "stone_2", "stone_3", "stone_4", "stone_5", "stone_6", "stone_7"],
    ["terra_d", "terra", "terra_l"],
    ["buff_dd", "buff_d", "buff", "buff_l"],
    ["navy_d", "navy", "navy_l"],
    ["leaf_0", "leaf_1", "leaf_2", "leaf_3", "leaf_4"],
    ["teal_d", "teal", "teal_l", "glow"],
]
STEP = {}
for ramp in RAMPS:
    for i, name in enumerate(ramp):
        STEP[name] = (ramp[i - 1] if i > 0 else name, ramp[i + 1] if i + 1 < len(ramp) else name)
TEAL_TINT = {"floor_2": "floor_teal", "floor_3": "floor_teal", "floor_4": "floor_teal_l", "floor_5": "floor_teal_l",
             "floor_1": "teal_d", "stone_5": "stone_teal", "stone_4": "stone_teal", "stone_6": "stone_teal"}

SCENE_LAYERS = ["sky-and-exterior", "floor-marble-minton", "back-wall-masonry", "pilasters-cornice-niches",
                "collapse-rubble", "ivy-vegetation", "survey-station-tech", "light-and-shadow"]
FIXTURE_LAYERS = ["contact-shadow", "structure", "lit-edges", "clue-detail"]


# ---------------------------------------------------------------- pixel helpers (numpy RGBA)

def canvas(w=W, h=H):
    return np.zeros((h, w, 4), np.uint8)


def put(a, x, y, c):
    if 0 <= x < a.shape[1] and 0 <= y < a.shape[0]:
        a[y, x] = (*RGB[c], 255)


def box(a, x0, y0, x1, y1, c):
    """Filled inclusive rectangle."""
    h, w = a.shape[:2]
    x0, x1 = max(0, min(x0, x1)), min(w - 1, max(x0, x1))
    y0, y1 = max(0, min(y0, y1)), min(h - 1, max(y0, y1))
    if x0 <= x1 and y0 <= y1:
        a[y0:y1 + 1, x0:x1 + 1] = (*RGB[c], 255)


def frame(a, x0, y0, x1, y1, c):
    box(a, x0, y0, x1, y0, c)
    box(a, x0, y1, x1, y1, c)
    box(a, x0, y0, x0, y1, c)
    box(a, x1, y0, x1, y1, c)


def seg(a, pts, c, width=1):
    img = Image.new("L", (a.shape[1], a.shape[0]), 0)
    ImageDraw.Draw(img).line(pts, fill=255, width=width)
    a[np.array(img) > 0] = (*RGB[c], 255)


def poly_mask(pts, w=W, h=H):
    img = Image.new("L", (w, h), 0)
    ImageDraw.Draw(img).polygon(pts, fill=255)
    return np.array(img) > 0


def ellipse_mask(bb, w=W, h=H):
    img = Image.new("L", (w, h), 0)
    ImageDraw.Draw(img).ellipse(bb, fill=255)
    return np.array(img) > 0


def fill(a, mask, c):
    a[mask] = (*RGB[c], 255)


def checker(h=H, w=W, phase=0):
    yy, xx = np.mgrid[0:h, 0:w]
    return ((xx + yy + phase) % 2) == 0


def dilate(mask, r):
    out = mask.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if dx * dx + dy * dy <= r * r:
                out |= np.roll(np.roll(mask, dy, 0), dx, 1)
    return out


def leaf_clump(a, cx, cy, r, rng, density=0.8):
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if d > r + 0.3 or rng.random() > density + (0.2 if d < r * 0.6 else 0.0):
                continue
            # light from the upper right breach and window
            t = (x - cx) - (y - cy)
            if d > r - 0.8 and y > cy:
                c = "leaf_0"
            elif t > r * 0.6:
                c = "leaf_4" if rng.random() < 0.6 else "leaf_3"
            elif t > -r * 0.2:
                c = "leaf_3" if rng.random() < 0.7 else "leaf_2"
            else:
                c = "leaf_2" if rng.random() < 0.6 else "leaf_1"
            put(a, x, y, c)


def hanging_vine(a, x, y0, y1, rng, leaves=True):
    cx = x
    for y in range(y0, y1 + 1):
        if rng.random() < 0.25:
            cx += rng.choice((-1, 1))
        put(a, cx, y, "leaf_1")
        if leaves and rng.random() < 0.45:
            side = rng.choice((-1, 1))
            put(a, cx + side, y, "leaf_3" if side > 0 else "leaf_2")
            if rng.random() < 0.4:
                put(a, cx + 2 * side, y - 1, "leaf_2")
    for _ in range(2):
        put(a, cx + rng.choice((-1, 0, 1)), y1 + 1, "leaf_2")


def tuft(a, x, y, rng, h=3):
    for dx in (-1, 0, 1):
        hh = rng.randint(1, h)
        for k in range(hh):
            put(a, x + dx, y - k, "leaf_3" if k == hh - 1 else "leaf_2")
    put(a, x, y, "leaf_1")


def digit(a, x, y, ch, c):
    glyphs = {"4": ["1.1", "1.1", "111", "..1", "..1"], "7": ["111", "..1", "..1", ".1.", ".1."]}
    for j, row in enumerate(glyphs[ch]):
        for i, v in enumerate(row):
            if v == "1":
                put(a, x + i, y + j, c)


# ---------------------------------------------------------------- scene geometry

FLOOR_TOP = 138
LANE_BANDS = [(242, 249), (282, 289)]
PILASTERS = [132, 230, 410, 508]
WIN = (274, 366, 121)  # x0, x1, sill y


def window_mask():
    yy, xx = np.mgrid[0:H, 0:W]
    x0, x1, sill = WIN
    cx, half = (x0 + x1) / 2, (x1 - x0) / 2
    top = 97 - 11 * np.sqrt(np.clip(1 - ((xx - cx) / half) ** 2, 0, 1))
    return (xx >= x0) & (xx <= x1) & (yy >= top) & (yy <= sill)


def niche_mask(cx, top=86, bottom=121, half=15):
    yy, xx = np.mgrid[0:H, 0:W]
    spring = top + half
    arch = (yy < spring) & (((xx - cx) ** 2 + (yy - spring) ** 2) <= half * half)
    body = (yy >= spring) & (yy <= bottom) & (np.abs(xx - cx) <= half)
    return arch | body


BREACH = [(536, 61), (640, 61), (640, 122), (626, 126), (614, 119), (603, 124), (590, 117), (578, 121),
          (566, 113), (556, 116), (548, 104), (541, 95), (544, 84), (537, 74), (540, 66)]
PILE = [(512, 178), (518, 160), (530, 142), (546, 124), (560, 112), (578, 106), (596, 110), (612, 118),
        (628, 128), (640, 140), (640, 188), (612, 192), (580, 188), (548, 186)]


# ---------------------------------------------------------------- scene layers

def layer_sky_exterior(rng):
    a = canvas()
    box(a, 0, 0, W - 1, H - 1, "void")
    yy, xx = np.mgrid[0:H, 0:W]
    # Sky, used through the west window and the breach: three bands with dithered seams.
    sky = np.full((H, W), "sky_1", object)
    sky[yy < 80] = "sky_0"
    sky[yy >= 98] = "sky_2"
    seam1 = (yy >= 78) & (yy < 82) & checker()
    sky[seam1] = "sky_1"
    sky[(yy >= 96) & (yy < 98) & checker()] = "sky_2"
    for name in ("sky_0", "sky_1", "sky_2"):
        fill(a, sky == name, name)
    # Thin cloud streaks.
    for x0, y, n in [(286, 90, 14), (340, 93, 10), (560, 74, 20), (600, 82, 14)]:
        box(a, x0, y, x0 + n, y, "sky_2")
        box(a, x0 + 3, y - 1, x0 + n - 4, y - 1, "dome_hi")
    # Distant tree line and grounds behind the window.
    for x in range(260, 380):
        top = 113 - int(2.5 + 2.5 * np.sin(x * 0.35) + (1 if x % 7 == 0 else 0))
        box(a, x, top, x, 121, "leaf_1")
        put(a, x, top, "leaf_2")
        if x % 3 == 0:
            put(a, x, top + 1, "leaf_2")
    # U.S. Capitol dome (west front view through the window): wings, drum colonnade, dome, lantern.
    box(a, 296, 110, 344, 116, "dome_shadow")
    box(a, 296, 110, 344, 110, "dome")
    for x in range(298, 344, 3):
        box(a, x, 112, x, 115, "sky_0")
    box(a, 307, 101, 333, 110, "dome")
    box(a, 307, 101, 333, 101, "dome_hi")
    for x in range(308, 333, 3):
        box(a, x, 103, x, 109, "dome_shadow")
    box(a, 330, 102, 333, 110, "dome_shadow")
    dm = ellipse_mask((308, 89, 332, 112)) & (yy <= 100)
    fill(a, dm, "dome")
    fill(a, dm & (xx >= 326), "dome_shadow")
    fill(a, dm & (xx <= 312) & (yy <= 97), "dome_hi")
    for rib in (314, 320, 326):
        for y in range(91, 101):
            if dm[y, rib]:
                put(a, rib, y, "dome_shadow")
    # breach in the dome's south shoulder (2537 ruin)
    for x, y0, y1 in [(323, 94, 97), (324, 93, 98), (325, 94, 99), (326, 95, 98)]:
        box(a, x, y0, x, y1, "void2")
    box(a, 317, 84, 323, 89, "dome")
    box(a, 322, 84, 323, 89, "dome_shadow")
    box(a, 318, 85, 318, 88, "dome_shadow")
    box(a, 320, 80, 320, 83, "steel_d")
    put(a, 320, 79, "steel")
    # Breach view (upper right): sky, Mall tree line, Washington Monument on the horizon.
    for x in range(536, 640):
        top = 112 - int(2 + 2 * np.sin(x * 0.29) + (2 if 596 < x < 612 else 0))
        box(a, x, top, x, 126, "leaf_1")
        put(a, x, top, "leaf_2")
    box(a, 584, 76, 587, 112, "dome")
    box(a, 586, 76, 587, 112, "dome_shadow")
    put(a, 585, 74, "dome")
    put(a, 586, 74, "dome_shadow")
    box(a, 585, 75, 586, 75, "dome")
    box(a, 584, 94, 587, 94, "dome_shadow")  # the monument's two-tone stone line
    box(a, 556, 108, 566, 112, "sky_0")      # low distant ruins
    box(a, 559, 105, 562, 112, "sky_0")
    # Left doorway: daylight on the west terrace outside.
    box(a, 0, 202, 21, 300, "stone_7")
    box(a, 0, 202, 21, 214, "sky_2")
    box(a, 0, 215, 21, 222, "leaf_2")
    for x in range(0, 22):
        put(a, x, 214 - (x * 3 % 3), "leaf_3")
    box(a, 0, 223, 21, 226, "lawn_l")
    box(a, 0, 258, 21, 300, "stone_6")
    for y in range(230, 300, 9):
        box(a, 0, y, 21, y, "stone_5")
    box(a, 0, 286, 9, 300, "lawn")
    box(a, 0, 286, 9, 286, "lawn_l")
    # Right doorway: the darker records chamber, lit by the survey crew's teal rail.
    box(a, 618, 202, 639, 300, "void")
    box(a, 618, 202, 639, 300, "void2")
    box(a, 618, 202, 639, 230, "void")
    box(a, 630, 214, 631, 288, "teal_l")
    box(a, 629, 214, 629, 288, "teal")
    box(a, 632, 214, 633, 288, "teal_d")
    box(a, 618, 289, 639, 300, "floor_1")
    for x in range(620, 640, 2):
        put(a, x, 290 + (x % 4 == 0), "floor_teal")
    return a


def layer_floor(rng):
    a = canvas()
    # Two-tone marble checker (square slabs foreshortened to 40x24), veined, with fine joints.
    rows = [(146, 169), (170, 193), (194, 217), (218, 241), (250, 281), (290, 310)]
    for r, (y0, y1) in enumerate(rows):
        for ci, x in enumerate(range(0, W, 40)):
            light = (ci + r) % 2 == 0
            base = "floor_4" if light else "floor_3"
            if rng.random() < 0.12:
                base = STEP[base][0]
            box(a, x, y0, x + 39, y1, base)
            box(a, x, y0, x + 39, y0, "floor_2")
            box(a, x, y0, x, y1, "floor_2")
            box(a, x + 1, y0 + 1, x + 39, y0 + 1, STEP[base][1])
            for _ in range(rng.randint(1, 3)):
                vx, vy = x + rng.randint(3, 30), y0 + rng.randint(4, max(4, y1 - y0 - 4))
                vc = STEP[base][0] if rng.random() < 0.7 else STEP[base][1]
                dy = rng.choice((-1, 1))
                for k in range(rng.randint(4, 9)):
                    put(a, vx + k, vy + dy * (k // 3), vc)
    # Dark serpentine marble strips with buff inlay dots frame the walking lane.
    for y0, y1 in LANE_BANDS:
        box(a, 0, y0, W - 1, y1, "floor_1")
        box(a, 0, y0, W - 1, y0, "floor_2")
        box(a, 0, y0 + 1, W - 1, y0 + 1, "floor_5")
        box(a, 0, y1 - 1, W - 1, y1 - 1, "floor_5")
        box(a, 0, y1, W - 1, y1, "floor_0")
        for x in range(4, W, 10):
            box(a, x, y0 + 3, x + 1, y0 + 4, "buff")
            put(a, x, y0 + 3, "buff_l")
    # Compass star inlay at the room's centre (a nod to the Capitol crypt's marker).
    cx, cy = 320, 266
    fill(a, ellipse_mask((cx - 19, cy - 14, cx + 19, cy + 14)), "buff_d")
    fill(a, ellipse_mask((cx - 18, cy - 13, cx + 18, cy + 13)), "floor_1")
    fill(a, ellipse_mask((cx - 16, cy - 11, cx + 16, cy + 11)), "navy_d")
    star = [(cx, cy - 11), (cx + 3, cy - 3), (cx + 16, cy), (cx + 3, cy + 3), (cx, cy + 11), (cx - 3, cy + 3), (cx - 16, cy), (cx - 3, cy - 3)]
    fill(a, poly_mask(star), "stone_6")
    for pts in [[(cx, cy - 11), (cx, cy), (cx - 3, cy - 3)], [(cx + 16, cy), (cx, cy), (cx + 3, cy - 3)],
                [(cx, cy + 11), (cx, cy), (cx + 3, cy + 3)], [(cx - 16, cy), (cx, cy), (cx - 3, cy + 3)]]:
        fill(a, poly_mask(pts), "stone_4")
    fill(a, poly_mask([(cx, cy - 6), (cx + 6, cy), (cx, cy + 6), (cx - 6, cy)]) & ~poly_mask(star), "buff")
    put(a, cx, cy, "stone_7")
    # Minton-style encaustic tile band along the wall base.
    for y0, y1 in [(FLOOR_TOP, 145)]:
        box(a, 0, y0, W - 1, y1, "navy")
        for x in range(0, W, 8):
            t = (x // 8) % 2
            box(a, x + 1, y0 + 1, x + 6, y1 - 1, "terra" if t == 0 else "buff_d")
            cx, cy = x + 3, (y0 + y1) // 2
            if t == 0:
                for dx, dy in [(0, -1), (-1, 0), (1, 0), (0, 1), (0, 0)]:
                    put(a, cx + dx + (1 if dx >= 0 else 0) * 0, cy + dy, "buff_l" if (dx, dy) == (0, 0) else "buff")
            else:
                box(a, cx, cy - 1, cx + 1, cy, "navy")
                put(a, x + 1, y0 + 1, "buff")
                put(a, x + 6, y1 - 1, "buff_dd")
        box(a, 0, y0, W - 1, y0, "navy_l" if y0 != FLOOR_TOP else "navy")
        box(a, 0, y1, W - 1, y1, "navy_d")
    # Foreground step edge (mostly under the footer).
    box(a, 0, 311, W - 1, 311, "floor_4")
    box(a, 0, 312, W - 1, H - 1, "floor_1")
    box(a, 0, 316, W - 1, H - 1, "floor_0")
    # Damage: lifted slabs, missing tiles with subfloor and brick showing.
    holes = [((30, 150), (62, 150), (66, 162), (52, 172), (34, 168)),
             ((96, 242), (114, 242), (114, 249), (96, 249)),
             ((420, 282), (440, 282), (438, 289), (421, 289)),
             ((470, 298), (494, 296), (500, 306), (478, 309))]
    for pts in holes:
        m = poly_mask(list(pts))
        fill(a, m, "stone_1")
        fill(a, m & ~dilate(~m, 2), "void2")
        ys, xs = np.nonzero(m)
        for x, y in zip(xs[::11], ys[::11]):
            if rng.random() < 0.6:
                box(a, x, y, x + 2, y + 1, rng.choice(["terra_d", "stone_2", "floor_2"]))
        edge = dilate(m, 1) & ~m
        fill(a, edge & (np.mgrid[0:H, 0:W][0] < ys.mean()), "floor_5")
    # Cracks: one long crack from the collapse toward the room centre, a few short ones.
    for start, steps in [((516, 160), 70), ((70, 176), 26), ((300, 300), 22), ((196, 262), 14), ((610, 214), 18)]:
        x, y = start
        for _ in range(steps):
            put(a, x, y, "floor_1")
            if rng.random() < 0.3:
                put(a, x, y + 1, "floor_0")
            x += rng.choice((-1, -1, -2, 0)) if start[0] > 300 else rng.choice((1, 1, 2, 0))
            y += rng.choice((0, 1, 1))
    # The side doorways open onto the sky layer's exterior / records-chamber views.
    a[202:301, 0:22] = 0
    a[202:301, 618:640] = 0
    # Painted survey reference crosses.
    for cx, cy in [(96, 214), (250, 302), (402, 302), (556, 232), (262, 160)]:
        box(a, cx - 2, cy, cx + 2, cy, "teal")
        box(a, cx, cy - 1, cx, cy + 1, "teal")
        put(a, cx, cy, "teal_l")
    return a


def layer_back_wall(rng):
    a = canvas()
    box(a, 0, 0, W - 1, 61, "stone_1")
    # Plaster / dressed sandstone wall field.
    box(a, 0, 80, W - 1, 121, "stone_5")
    for y in (93, 107):
        box(a, 0, y, W - 1, y, "stone_4")
    for ci, (y0, y1) in enumerate([(80, 92), (94, 106), (108, 121)]):
        off = 17 if ci % 2 else 0
        for x in range(off, W, 34):
            box(a, x, y0, x, y1, "stone_4")
            box(a, x + 1, y0, x + 1, y1, "stone_6")
    # grime at the base and water streaks from the cornice
    yy, xx = np.mgrid[0:H, 0:W]
    fill(a, (yy >= 116) & (yy <= 121) & checker() & (xx < 536), "stone_4")
    fill(a, (yy >= 119) & (yy <= 121) & (xx < 536), "stone_4")
    for x in (48, 104, 196, 252, 388, 446, 492):
        L = rng.randint(10, 26)
        for y in range(84, 84 + L):
            if rng.random() < 0.8:
                put(a, x, y, "stone_4")
    # Dado: chair rail over a dark marble wainscot (quiet backing for the clue name labels).
    box(a, 0, 122, W - 1, 122, "stone_6")
    box(a, 0, 123, W - 1, 123, "stone_3")
    box(a, 0, 124, W - 1, 124, "floor_1")
    box(a, 0, 125, W - 1, 132, "floor_2")
    edges = [0] + PILASTERS + [W]
    for x0, x1 in zip(edges, edges[1:]):
        span = x1 - x0
        n = max(1, round(span / 46))
        for k in range(n):
            px0 = x0 + 12 + k * (span - 16) // n
            px1 = x0 + 4 + (k + 1) * (span - 16) // n
            box(a, px0, 126, px1, 126, "floor_1")
            box(a, px0, 126, px0, 131, "floor_1")
            box(a, px0 + 1, 131, px1, 131, "floor_3")
            box(a, px1, 127, px1, 131, "floor_3")
    box(a, 0, 133, W - 1, 133, "floor_2")
    box(a, 0, 134, W - 1, 137, "floor_1")
    box(a, 0, 137, W - 1, 137, "floor_0")
    # Cracks in the plaster spreading from the collapse and in bay B.
    for start, steps, dx in [((536, 90), 40, -1), ((536, 104), 24, -1), ((206, 82), 20, -1)]:
        x, y = start
        for _ in range(steps):
            put(a, x, y, "stone_2")
            if rng.random() < 0.3:
                put(a, x + 1, y, "stone_3")
            x += dx if rng.random() < 0.7 else 0
            y += rng.choice((0, 1, 1, -1))
            y = max(81, min(120, y))
    # Openings: west window (shows the dome) and statue niches.
    a[window_mask()] = 0
    for cx in (77, 459):
        m = niche_mask(cx)
        fill(a, m, "stone_2")
        fill(a, m & (yy < 101), "stone_1")
        fill(a, m & (yy >= 101) & (yy < 104) & checker(), "stone_1")
        fill(a, m & (xx > cx + 9), "stone_1")
        box(a, cx - 15, 118, cx + 15, 121, "stone_3")
    # The breach removes the wall entirely (the sky layer shows through).
    a[poly_mask(BREACH)] = 0
    return a


def layer_pilasters_cornice(rng):
    a = canvas()
    yy, xx = np.mgrid[0:H, 0:W]
    breach = poly_mask(BREACH)
    # Entablature: corona, dentils, frieze with rosettes, architrave.
    box(a, 0, 62, W - 1, 62, "stone_7")
    box(a, 0, 63, W - 1, 64, "stone_6")
    box(a, 0, 65, W - 1, 65, "stone_4")
    box(a, 0, 66, W - 1, 66, "stone_2")
    for x in range(0, W):
        put(a, x, 67, "stone_6" if x % 5 < 3 else "stone_2")
        put(a, x, 68, "stone_5" if x % 5 < 3 else "stone_2")
        put(a, x, 69, "stone_5" if x % 5 < 3 else "stone_1")
    box(a, 0, 70, W - 1, 70, "stone_3")
    box(a, 0, 71, W - 1, 76, "stone_5")
    box(a, 0, 71, W - 1, 71, "stone_6")
    for x in range(17, W, 34):
        box(a, x - 1, 73, x + 1, 74, "stone_6")
        put(a, x, 73, "stone_7")
        put(a, x + 1, 75, "stone_4")
    box(a, 0, 77, W - 1, 77, "stone_6")
    box(a, 0, 78, W - 1, 78, "stone_4")
    box(a, 0, 79, W - 1, 79, "stone_3")
    # Ionic pilasters with plinths running through the dado.
    for c in PILASTERS:
        box(a, c - 8, 84, c + 7, 121, "stone_2")
        box(a, c - 7, 84, c + 6, 121, "stone_6")
        box(a, c - 7, 84, c - 7, 121, "stone_7")
        box(a, c + 6, 84, c + 6, 121, "stone_4")
        for f in (c - 4, c - 1, c + 2):
            box(a, f, 88, f, 118, "stone_5")
        box(a, c - 10, 80, c + 9, 80, "stone_7")
        box(a, c - 10, 81, c + 9, 81, "stone_5")
        box(a, c - 9, 82, c + 8, 83, "stone_6")
        for vx in (c - 9, c + 8):
            box(a, vx - 1, 82, vx + 1, 84, "stone_6")
            put(a, vx, 83, "stone_3")
            put(a, vx + (1 if vx > c else -1), 84, "stone_4")
        box(a, c - 7, 85, c + 6, 85, "stone_4")
        box(a, c - 10, 122, c + 9, 137, "stone_5")
        box(a, c - 10, 122, c + 9, 122, "stone_7")
        box(a, c - 10, 123, c - 10, 137, "stone_6")
        box(a, c + 9, 123, c + 9, 137, "stone_3")
        box(a, c - 10, 134, c + 9, 134, "stone_4")
        box(a, c - 10, 137, c + 9, 137, "stone_2")
    # West window: moulded surround, keystone, sill, steel mullions with broken panes.
    wm = window_mask()
    ring = dilate(wm, 3) & ~wm & (yy <= WIN[2])
    fill(a, ring, "stone_6")
    fill(a, dilate(wm, 1) & ~wm & (yy <= WIN[2]), "stone_3")
    fill(a, ring & ~dilate(wm, 2) & (xx < 320), "stone_7")
    box(a, 315, 81, 325, 88, "stone_6")
    box(a, 315, 81, 325, 81, "stone_7")
    box(a, 325, 82, 325, 88, "stone_4")
    box(a, 316, 88, 324, 88, "stone_3")
    box(a, 268, 121, 372, 122, "stone_7")
    box(a, 268, 123, 372, 124, "stone_4")
    for mx in (297, 343):
        top = int(97 - 11 * np.sqrt(max(0.0, 1 - ((mx - 320) / 46) ** 2)))
        box(a, mx, top, mx, 120, "steel_d")
        box(a, mx + 1, top, mx + 1, 120, "steel")
    box(a, 275, 106, 342, 106, "steel_d")
    box(a, 275, 107, 342, 107, "steel")
    box(a, 344, 106, 350, 106, "steel_d")   # transom snapped on the right
    seg(a, [(350, 106), (354, 110)], "steel_d")
    # leftover glass in pane corners
    for pts in [((275, 108), (281, 108), (275, 116)), ((296, 99), (290, 99), (296, 104)),
                ((345, 120), (352, 120), (345, 113)), ((298, 108), (302, 108), (298, 112))]:
        fill(a, poly_mask(list(pts)) & wm, "glass")
    put(a, 276, 109, "dome_hi")
    put(a, 346, 118, "dome_hi")
    # Niches: rims, a statue in the east niche, an empty plinth with feet in the west niche.
    for cx in (77, 459):
        m = niche_mask(cx)
        rim = dilate(m, 2) & ~m & (yy <= 121)
        fill(a, rim, "stone_6")
        fill(a, rim & (xx > cx + 4), "stone_4")
        box(a, cx - 17, 121, cx + 17, 121, "stone_7")
    # west niche (bay A): toppled statue - plinth, feet and drapery stump
    box(a, 69, 110, 85, 120, "stone_6")
    box(a, 69, 110, 85, 110, "stone_7")
    box(a, 83, 111, 85, 120, "stone_4")
    box(a, 72, 104, 81, 109, "stone_6")
    seg(a, [(72, 104), (75, 102), (78, 104), (81, 101)], "stone_5")
    box(a, 80, 105, 81, 109, "stone_4")
    put(a, 71, 109, "stone_3")
    # east niche (bay D): standing figure in a toga, right arm broken off
    box(a, 451, 112, 467, 120, "stone_6")
    box(a, 451, 112, 467, 112, "stone_7")
    box(a, 465, 113, 467, 120, "stone_4")
    box(a, 455, 94, 463, 111, "stone_6")
    box(a, 454, 98, 455, 108, "stone_6")
    box(a, 461, 95, 463, 111, "stone_5")
    seg(a, [(456, 99), (461, 108)], "stone_5")
    seg(a, [(458, 97), (462, 104)], "stone_5")
    box(a, 457, 89, 461, 93, "stone_7")
    box(a, 460, 90, 461, 93, "stone_5")
    box(a, 464, 96, 465, 97, "stone_4")   # broken shoulder stump
    put(a, 456, 111, "stone_4")
    # Side piers with doorways (west: outside; east: records chamber).
    for x0, x1, inner in [(0, 21, 21), (618, 639, 618)]:
        box(a, x0, 62, x1, 317, "stone_5")
        for y in range(70, 318, 14):
            box(a, x0, y, x1, y, "stone_4")
        box(a, inner, 62, inner, 317, "stone_3" if inner == 21 else "stone_6")
        box(a, x0, 62, x1, 64, "stone_6")
        a[202:301, x0:x1 + 1] = 0
        box(a, x0, 194, x1, 201, "stone_6")
        box(a, x0, 194, x1, 194, "stone_7")
        box(a, x0, 201, x1, 201, "stone_3")
        kx = 15 if inner == 21 else 624
        box(a, kx - 2, 192, kx + 2, 201, "stone_7")
        box(a, kx + 2, 193, kx + 2, 201, "stone_4")
        jx = inner - 2 if inner == 21 else inner
        box(a, jx, 202, jx + 2, 300, "stone_3" if inner == 21 else "stone_4")
        box(a, x0, 301, x1, 304, "stone_6")
        box(a, x0, 305, x1, 317, "stone_4")
    # The breach cuts the entablature and the side pier top too.
    a[breach & (yy < 122) & (xx >= 536)] = 0
    return a


def layer_collapse(rng):
    a = canvas()
    yy, xx = np.mgrid[0:H, 0:W]
    breach = poly_mask(BREACH)
    wall_zone = (yy >= 62) & (yy <= 121) & (xx >= 520)
    # Broken edge: brick core behind the sandstone facing, three pixels deep.
    edge = dilate(breach, 5) & ~breach & wall_zone
    fill(a, edge, "stone_3")
    core = dilate(breach, 3) & ~breach & wall_zone
    fill(a, core, "terra")
    fill(a, core & (yy % 3 == 2), "buff_d")
    fill(a, core & (yy % 3 != 2) & ((xx + (yy // 3) * 3) % 6 == 0), "buff_d")
    fill(a, core & (yy % 3 == 0) & (xx % 2 == 0), "terra_d")
    fill(a, dilate(breach, 1) & ~breach & wall_zone, "stone_1")
    # Dangling cornice chunk and a timber header with a steel shore under it.
    chunk = poly_mask([(536, 62), (546, 62), (552, 70), (549, 80), (541, 76), (536, 70)])
    fill(a, chunk, "stone_6")
    fill(a, chunk & (yy >= 72), "stone_4")
    for x in range(538, 550, 3):
        put(a, x, 71, "stone_2")
    seg(a, [(536, 62), (546, 62), (552, 70), (549, 80)], "stone_2")
    box(a, 504, 80, 548, 84, "wood")
    box(a, 504, 80, 548, 80, "wood_l")
    box(a, 504, 84, 548, 84, "wood_d")
    for x in (510, 540):
        put(a, x, 82, "brass_l")
    # Rubble pile spilling in from the breach.
    pile = poly_mask(PILE)
    fill(a, pile, "stone_2")
    speckle = np.array([[rng.random() < 0.22 for _ in range(W)] for _ in range(H)])
    fill(a, pile & speckle, "stone_1")
    fill(a, pile & (yy > 176), "stone_1")
    blocks = []
    for _ in range(140):
        x = rng.randint(508, 636)
        y = rng.randint(104, 188)
        if not pile[min(y, H - 1), min(x, W - 1)]:
            continue
        blocks.append((y, x, rng.randint(6, 15), rng.randint(4, 8), rng.choice(["stone_4", "stone_5", "stone_5", "stone_6", "stone_3"])))
    for y, x, w, h, c in sorted(blocks):
        m = np.zeros((H, W), bool)
        m[y:y + h, x:x + w] = True
        m &= dilate(pile, 2)
        fill(a, m, c)
        fill(a, m & (yy == y), STEP[c][1])
        fill(a, m & (yy == y + h - 1), "stone_1")
        fill(a, m & (xx == x + w - 1), STEP[c][0])
        fill(a, m & (xx == x), "stone_2")
    for _ in range(14):  # brick lumps from the wall core
        x, y = rng.randint(516, 630), rng.randint(120, 184)
        if pile[y, x]:
            box(a, x, y, x + 4, y + 2, "terra")
            box(a, x, y + 2, x + 4, y + 2, "terra_d")
    # Fallen cornice section with dentils lying on the pile front.
    box(a, 520, 160, 548, 166, "stone_6")
    box(a, 520, 160, 548, 160, "stone_7")
    for x in range(521, 548, 4):
        box(a, x, 167, x + 1, 169, "stone_5")
        put(a, x + 2, 167, "stone_2")
    box(a, 520, 166, 548, 166, "stone_3")
    # Fallen fluted column drum on the floor in front of the pile.
    box(a, 532, 182, 580, 196, "stone_5")
    box(a, 532, 182, 580, 182, "stone_7")
    box(a, 532, 183, 580, 183, "stone_6")
    for y in (186, 189, 192):
        box(a, 533, y, 579, y, "stone_4")
    box(a, 532, 195, 580, 196, "stone_3")
    box(a, 532, 182, 532, 196, "stone_2")
    end = ellipse_mask((575, 180, 589, 198))
    fill(a, end, "stone_6")
    fill(a, end & ~dilate(~end, 2), "stone_5")
    fill(a, ellipse_mask((580, 186, 584, 192)), "stone_4")
    fill(a, end & ~dilate(~end, 1) & (xx > 584), "stone_4")
    # Scattered chips over the floor near the collapse.
    for _ in range(46):
        x = int(rng.triangular(470, 630, 560))
        y = int(rng.triangular(146, 214, 170))
        if pile[y, x] or (532 <= x <= 590 and 180 <= y <= 198):
            continue
        c = rng.choice(["stone_4", "stone_5", "stone_6", "terra"])
        box(a, x, y, x + rng.randint(0, 2), y + rng.randint(0, 1), c)
        put(a, x + 1, y + 2, "floor_1")
    for x, y in [(44, 178), (60, 160), (112, 150), (226, 152), (396, 148), (300, 226), (128, 300), (360, 306)]:
        box(a, x, y, x + 1, y, "stone_5")
        put(a, x + 1, y + 1, "floor_1")
    return a


def layer_vegetation(rng):
    a = canvas()
    # Ivy pouring through the breach and over the cornice break.
    for cx, cy, r in [(530, 66, 6), (552, 64, 5), (520, 74, 5), (541, 90, 4), (612, 124, 5), (600, 128, 4),
                      (572, 116, 4), (626, 132, 5), (556, 122, 3), (536, 136, 4), (520, 150, 3)]:
        leaf_clump(a, cx, cy, r, rng)
    for x, y0, y1 in [(512, 70, 108), (518, 72, 120), (526, 74, 98), (534, 76, 114), (508, 86, 134)]:
        hanging_vine(a, x, y0, y1, rng)
    # Sapling rooted in the rubble, reaching for the open sky.
    seg(a, [(606, 176), (605, 150), (603, 128), (601, 112)], "wood_d", 2)
    seg(a, [(605, 150), (605, 130)], "wood")
    seg(a, [(603, 132), (594, 118)], "wood_d")
    seg(a, [(604, 124), (614, 110)], "wood_d")
    for cx, cy, r in [(600, 104, 9), (590, 112, 6), (614, 104, 7), (606, 94, 6), (594, 98, 5)]:
        leaf_clump(a, cx, cy, r, rng, 0.9)
    # Ivy over the west niche and down the first pilaster.
    for cx, cy, r in [(64, 82, 4), (72, 80, 3), (92, 84, 4), (128, 84, 3), (134, 92, 2)]:
        leaf_clump(a, cx, cy, r, rng)
    for x, y0, y1 in [(60, 82, 104), (95, 84, 100), (131, 86, 112), (66, 82, 96)]:
        hanging_vine(a, x, y0, y1, rng)
    # Ivy creeping over the east doorway lintel and the east niche.
    for cx, cy, r in [(628, 192, 5), (620, 186, 3), (450, 84, 3), (470, 82, 3)]:
        leaf_clump(a, cx, cy, r, rng)
    for x, y0, y1 in [(624, 196, 214), (633, 196, 222), (448, 84, 98)]:
        hanging_vine(a, x, y0, y1, rng)
    # Moss and grass in floor joints, at the wall base and around the damage.
    for x, y in [(26, 140), (40, 172), (56, 150), (64, 166), (110, 250), (98, 244), (150, 138), (236, 139),
                 (382, 139), (470, 140), (496, 152), (510, 176), (488, 190), (600, 200), (612, 206),
                 (426, 288), (436, 283), (476, 304), (496, 300), (24, 304), (612, 304), (300, 312)]:
        tuft(a, x, y, rng)
    for x, y in [(36, 160), (48, 168), (106, 247), (430, 286), (486, 302), (520, 182)]:
        box(a, x, y, x + 2, y, "moss")
    return a


def layer_tech(rng):
    a = canvas()
    # Teal light rail strung under the architrave (the survey crew's working light).
    box(a, 26, 81, 500, 81, "steel_d")
    box(a, 26, 82, 500, 82, "teal_l")
    for x in range(26, 501, 4):
        put(a, x, 82, "glow")
    for x in list(range(40, 500, 52)):
        if 268 <= x <= 372:
            continue
        box(a, x, 79, x + 1, 81, "steel")
    box(a, 500, 81, 503, 83, "steel_d")
    # power drop from the rail end down the shore to the floor
    box(a, 503, 84, 503, 140, "teal_d")
    box(a, 504, 84, 504, 140, "teal")
    # Bay B: wall-mounted strata scanner display bolted to the masonry.
    box(a, 150, 89, 196, 112, "steel_d")
    box(a, 151, 90, 195, 111, "steel")
    box(a, 153, 92, 193, 109, "teal_d")
    for i, (y, c, gaps) in enumerate([(95, "teal_l", (162, 170)), (99, "teal", (176, 181)), (103, "brass_l", ()), (106, "terra_l", ())]):
        for x in range(155, 192):
            if gaps and gaps[0] <= x <= gaps[1]:
                continue
            put(a, x, y, c)
            if c in ("brass_l", "terra_l"):
                put(a, x, y + 1, "buff_d" if c == "brass_l" else "terra")
    box(a, 186, 93, 191, 93, "glow")
    put(a, 191, 110, "red")
    for bx in (152, 194):
        box(a, bx - 1, 112, bx + 1, 114, "brass")
    box(a, 172, 113, 175, 137, "steel_d")
    box(a, 173, 113, 174, 137, "steel")
    # Floor cable along the wall-base band, from the scanner to the shore power drop.
    for x in range(173, 505):
        y = 148 + (1 if 230 < x < 260 or 400 < x < 430 else 0)
        put(a, x, y, "teal_d")
        put(a, x, y - 1, "teal")
    box(a, 172, 140, 174, 147, "teal_d")
    box(a, 503, 140, 505, 147, "teal_d")
    # Steel shore on its timber sole plate holding the header under the broken cornice.
    box(a, 527, 85, 530, 143, "steel_d")
    box(a, 528, 85, 529, 143, "steel_l")
    box(a, 526, 110, 531, 113, "steel")
    put(a, 531, 111, "red")
    box(a, 520, 144, 537, 147, "wood")
    box(a, 520, 144, 537, 144, "wood_l")
    box(a, 520, 147, 537, 147, "wood_d")
    # Survey beacon tripod on the rubble crest.
    for lx in (561, 569, 577):
        seg(a, [(569, 100), (lx, 112 + (2 if lx == 569 else 0))], "steel_d")
    box(a, 568, 92, 569, 100, "steel")
    box(a, 564, 86, 574, 92, "steel_d")
    box(a, 565, 87, 573, 91, "steel")
    box(a, 566, 88, 569, 90, "teal_l")
    put(a, 567, 89, "glow")
    put(a, 573, 86, "red")
    # Floodlight tripod between the first two clue sites, aimed at the layered wall sample.
    for lx, ly in [(236, 216), (256, 216), (247, 218)]:
        seg(a, [(246, 176), (lx, ly)], "steel_d")
    box(a, 245, 160, 247, 177, "steel")
    box(a, 245, 160, 245, 177, "steel_d")
    box(a, 236, 150, 254, 161, "steel_d")
    box(a, 237, 151, 253, 160, "steel")
    box(a, 237, 151, 240, 160, "lamp")
    box(a, 241, 151, 241, 160, "steel_l")
    box(a, 247, 152, 252, 153, "steel_hi")
    seg(a, [(254, 156), (262, 166), (262, 200), (250, 214)], "teal_d")
    # Low hard case with a handheld scanner, parked in the south-west corner out of the clue row.
    box(a, 28, 296, 60, 310, "steel_d")
    box(a, 29, 297, 59, 304, "steel")
    box(a, 29, 297, 59, 297, "steel_l")
    box(a, 29, 300, 59, 300, "teal")
    for x in (33, 53):
        box(a, x, 304, x + 2, 306, "brass")
    box(a, 38, 293, 48, 297, "steel_d")
    box(a, 39, 294, 47, 295, "teal_l")
    put(a, 40, 294, "glow")
    # Field power unit feeding the records chamber through the east doorway.
    box(a, 574, 294, 610, 312, "steel_d")
    box(a, 575, 295, 609, 306, "steel")
    box(a, 575, 295, 609, 295, "steel_l")
    for x in range(579, 597, 3):
        box(a, x, 298, x, 304, "steel_d")
    box(a, 600, 298, 606, 302, "teal_d")
    box(a, 601, 299, 603, 300, "teal_l")
    put(a, 605, 299, "red")
    box(a, 574, 292, 578, 293, "steel")
    seg(a, [(610, 302), (614, 300), (618, 296), (624, 294)], "teal_d", 2)
    seg(a, [(610, 301), (614, 299), (618, 295)], "teal")
    return a


def owner_map(layers):
    owner = np.full((H, W), -1, np.int8)
    for i, l in enumerate(layers):
        owner[l[..., 3] > 0] = i
    return owner


def composite(layers):
    out = np.zeros((H, W, 4), np.uint8)
    for l in layers:
        m = l[..., 3] > 0
        out[m] = l[m]
    return out


def name_map(img):
    lut = {v: k for k, v in RGB.items()}
    names = np.empty((H, W), object)
    flat = img[..., :3].reshape(-1, 3)
    out = names.reshape(-1)
    for i, c in enumerate(map(tuple, flat)):
        out[i] = lut.get(c)
    return names


def layer_light(below):
    a = canvas()
    comp = composite(below)
    names = name_map(comp)
    owner = owner_map(below)
    yy, xx = np.mgrid[0:H, 0:W]
    floor = owner == 1
    wall = owner == 2

    def apply(mask, direction):
        ys, xs = np.nonzero(mask)
        for y, x in zip(ys, xs):
            n = names[y, x]
            if n in STEP:
                t = STEP[n][1 if direction > 0 else 0]
                if t != n:
                    a[y, x] = (*RGB[t], 255)

    # Sunlight through the breach: a slanted shaft over the floor, dithered edges.
    shaft = poly_mask([(522, 146), (622, 146), (566, 312), (444, 312)])
    core = poly_mask([(530, 146), (614, 146), (560, 312), (452, 312)])
    apply(floor & (core | (shaft & checker())), +1)
    # Softer patch below the west window.
    apply(floor & poly_mask([(282, 146), (362, 146), (348, 196), (262, 196)]) & checker(), +1)
    # Daylight spill from the west doorway.
    apply(floor & poly_mask([(21, 204), (21, 300), (70, 300), (40, 204)]) & (checker() | (xx < 32)), +1)
    # Ambient occlusion under the wall and at the near edge, cast shadow under the fallen drum.
    apply(floor & (((yy >= 146) & (yy <= 147)) | ((yy >= 148) & (yy <= 149) & checker())), -1)
    apply(floor & (yy >= 304) & (yy <= 310) & (checker() | (yy >= 307)), -1)
    apply(floor & ellipse_mask((528, 192, 592, 204)), -1)
    apply(floor & ellipse_mask((24, 306, 64, 314)), -1)
    apply(floor & ellipse_mask((570, 306, 616, 316)), -1)
    apply(floor & ellipse_mask((230, 212, 262, 222)) & checker(), -1)
    # Teal light: wash under the rail on the wall, spill from the records chamber doorway.
    for mask in [wall & (yy >= 83) & (yy <= 84) & (xx >= 26) & (xx <= 500),
                 wall & (yy == 85) & (xx >= 26) & (xx <= 500) & checker(),
                 floor & poly_mask([(618, 214), (618, 298), (592, 298), (608, 214)]) & checker(),
                 floor & (xx >= 614) & (yy >= 220) & (yy <= 298)]:
        ys, xs = np.nonzero(mask)
        for y, x in zip(ys, xs):
            t = TEAL_TINT.get(names[y, x])
            if t:
                a[y, x] = (*RGB[t], 255)
    return a


def build_scene():
    rng = random.Random(0x65B9618F)
    layers = [layer_sky_exterior(rng), layer_floor(rng), layer_back_wall(rng), layer_pilasters_cornice(rng),
              layer_collapse(rng), layer_vegetation(rng), layer_tech(rng)]
    layers.append(layer_light(layers))
    return [Image.fromarray(l) for l in layers]


# ---------------------------------------------------------------- clue fixtures (64x64)

def f_layer():
    return np.zeros((FH, FW, 4), np.uint8)


def f_shadow(bb):
    a = f_layer()
    a[ellipse_mask(bb, FW, FH)] = SHADOW_RGBA
    return a


def fixture_layered_wall():
    """分层墙面 / Layered Wall: a cut wall section, old brick under dressed sandstone, both layers
    carrying the same machine age tag; a survey camera photographs the original."""
    shadow = f_shadow((3, 50, 62, 61))
    body = f_layer()
    # timber pallet
    box(body, 5, 52, 46, 57, "wood_d")
    box(body, 6, 52, 45, 55, "wood")
    for x in (8, 24, 41):
        box(body, x, 56, x + 2, 57, "wood")
    # wall section: jagged broken top, front face plus a darker return face on the right
    front = [(8, 25), (12, 21), (16, 23), (21, 18), (26, 22), (30, 19), (35, 23), (38, 21), (38, 52), (8, 52)]
    side = [(38, 21), (44, 25), (44, 54), (38, 52)]
    fm, sm = poly_mask(front, FW, FH), poly_mask(side, FW, FH)
    fill(body, dilate(fm | sm, 1), "ink")
    yy, xx = np.mgrid[0:FH, 0:FW]
    fill(body, fm, "stone_5")
    fill(body, fm & (yy >= 34), "stone_2")
    fill(body, fm & (yy >= 37), "terra")
    fill(body, sm, "stone_3")
    fill(body, sm & (yy >= 37 + (xx - 38) // 2), "terra_d")
    # camera tripod and body, aimed left at the sample
    for lx in (47, 53, 60):
        seg(body, [(53, 38), (lx, 59)], "steel_d")
    box(body, 52, 34, 54, 38, "steel")
    box(body, 47, 26, 60, 34, "ink")
    box(body, 48, 27, 59, 33, "steel")
    box(body, 45, 28, 47, 32, "steel_d")
    lit = f_layer()
    # sunlit broken top edge and the walkway moulding on the upper (later) layer
    for x0, y0, x1, y1 in [(8, 25, 12, 21), (12, 21, 16, 23), (16, 23, 21, 18), (21, 18, 26, 22), (26, 22, 30, 19), (30, 19, 35, 23), (35, 23, 38, 21)]:
        seg(lit, [(x0, y0 + 1), (x1, y1 + 1)], "stone_7")
    box(lit, 8, 27, 38, 27, "stone_6")
    box(lit, 8, 28, 38, 28, "stone_3")
    box(lit, 23, 29, 23, 33, "stone_4")
    box(lit, 9, 30, 9, 33, "stone_6")
    # dark sealing course between the layers
    box(lit, 8, 35, 38, 35, "buff_dd")
    # lower (older) brick: running bond with buff mortar
    for y in range(37, 52, 3):
        off = 0 if ((y - 37) // 3) % 2 else 3
        box(lit, 8, y + 2, 38, y + 2, "buff_d")
        for x in range(8 + off, 39, 6):
            box(lit, x, y, x, y + 1, "buff_d")
    box(lit, 8, 37, 38, 37, "terra_l")
    box(lit, 48, 27, 59, 27, "steel_l")
    box(lit, 6, 52, 45, 52, "wood_l")
    detail = f_layer()
    # identical age tags on both layers (the machine dated them the same)
    for tx, ty in [(27, 29), (12, 41)]:
        box(detail, tx, ty, tx + 6, ty + 4, "paper")
        box(detail, tx, ty, tx + 6, ty, "teal")
        box(detail, tx + 1, ty + 2, tx + 5, ty + 2, "teal_d")
        put(detail, tx + 3, ty - 1, "brass_l")
    # lens and record light
    box(detail, 45, 29, 46, 31, "teal_l")
    put(detail, 45, 30, "glow")
    put(detail, 58, 28, "red")
    # crumbled mortar at the boundary
    for x in (12, 19, 33):
        put(detail, x, 36, "stone_4")
    return [shadow, body, lit, detail]


def fixture_broken_index():
    """残缺索引 / Broken Index: an oak card catalogue with one drawer missing and one pulled out;
    a survey reader beside it lists the identifiers with a visible gap."""
    shadow = f_shadow((4, 50, 62, 61))
    body = f_layer()
    box(body, 9, 15, 42, 57, "ink")
    box(body, 10, 16, 41, 19, "wood_l")
    box(body, 10, 20, 41, 56, "wood")
    for col in range(3):
        for rowi in range(4):
            x0, y0 = 11 + col * 10, 21 + rowi * 9
            box(body, x0, y0, x0 + 8, y0 + 7, "wood_d")
            box(body, x0 + 1, y0 + 1, x0 + 7, y0 + 6, "wood")
    box(body, 11, 57, 14, 59, "wood_d")
    box(body, 37, 57, 40, 59, "wood_d")
    # missing drawer: a dark empty slot
    box(body, 31, 30, 39, 37, "void")
    # pulled-out drawer hanging forward from row 3, centre column
    box(body, 20, 41, 30, 52, "ink")
    box(body, 21, 42, 29, 51, "wood")
    box(body, 21, 42, 29, 44, "paper_d")
    # survey reader on a fold-out stand
    seg(body, [(52, 58), (49, 46)], "steel_d")
    seg(body, [(57, 58), (55, 46)], "steel_d")
    box(body, 44, 25, 61, 46, "ink")
    box(body, 45, 26, 60, 45, "steel")
    box(body, 46, 27, 59, 44, "teal_d")
    lit = f_layer()
    box(lit, 10, 16, 41, 16, "buff_l")
    box(lit, 10, 20, 10, 56, "wood_l")
    for col in range(3):
        for rowi in range(4):
            x0, y0 = 11 + col * 10, 21 + rowi * 9
            if (col, rowi) == (2, 1):
                continue
            box(lit, x0 + 1, y0 + 1, x0 + 7, y0 + 1, "wood_l")
    box(lit, 21, 42, 29, 42, "paper")
    box(lit, 45, 26, 60, 26, "steel_l")
    detail = f_layer()
    for col in range(3):
        for rowi in range(4):
            if (col, rowi) == (2, 1):
                continue
            x0, y0 = 11 + col * 10, 21 + rowi * 9
            box(detail, x0 + 3, y0 + 2, x0 + 5, y0 + 3, "paper")
            box(detail, x0 + 3, y0 + 5, x0 + 5, y0 + 5, "brass_l")
    # index cards standing in the open drawer with gaps, a few on the floor
    for x in (22, 23, 26, 28):
        box(detail, x, 39, x, 43, "paper")
    box(detail, 44, 54, 49, 56, "paper")
    box(detail, 40, 58, 45, 60, "paper")
    box(detail, 44, 54, 49, 54, "paper_d")
    # reader list: identifiers in order with a missing run in amber
    for i, y in enumerate(range(29, 43, 2)):
        if i in (3, 4):
            box(detail, 48, y, 51, y, "brass_l")
            continue
        box(detail, 48, y, 56 - (i % 3), y, "teal_l")
    put(detail, 58, 29, "glow")
    return [shadow, body, lit, detail]


def fixture_code_47():
    """编号四七 / Code Forty-Seven: an old bronze junction box stamped 47 beside a modern relay node
    that also reads 47; the node's cable lies unplugged next to the old box."""
    shadow = f_shadow((2, 50, 62, 61))
    body = f_layer()
    # stone plinth and old bronze box
    box(body, 5, 46, 31, 57, "ink")
    box(body, 6, 47, 30, 56, "stone_4")
    box(body, 7, 20, 29, 46, "ink")
    box(body, 8, 21, 28, 45, "brass_d")
    box(body, 9, 22, 27, 44, "brass")
    box(body, 11, 35, 25, 42, "brass_d")
    box(body, 16, 36, 20, 41, "steel_d")
    # modern relay node on a short tripod
    for lx in (40, 48, 56):
        seg(body, [(48, 46), (lx, 58)], "steel_d")
    box(body, 39, 18, 57, 46, "ink")
    box(body, 40, 19, 56, 45, "steel")
    box(body, 42, 22, 54, 33, "teal_d")
    box(body, 47, 8, 48, 18, "steel_d")
    # its cable, ending in a loose plug beside the old box
    seg(body, [(44, 46), (40, 52), (34, 56), (30, 59)], "teal_d", 2)
    box(body, 26, 58, 30, 60, "brass_d")
    lit = f_layer()
    box(lit, 6, 47, 30, 47, "stone_6")
    box(lit, 8, 21, 28, 21, "brass_l")
    box(lit, 8, 22, 8, 45, "brass_l")
    box(lit, 40, 19, 56, 19, "steel_l")
    box(lit, 40, 20, 40, 45, "steel_l")
    seg(lit, [(44, 45), (40, 51), (34, 55)], "teal")
    box(lit, 27, 58, 29, 58, "brass_l")
    detail = f_layer()
    # rivets and a stamped cream plate reading 47 on the old box
    for x, y in [(10, 23), (26, 23), (10, 43), (26, 43)]:
        put(detail, x, y, "brass_l")
    box(detail, 11, 25, 25, 32, "paper")
    box(detail, 11, 32, 25, 32, "paper_d")
    digit(detail, 13, 26, "4", "ink")
    digit(detail, 19, 26, "7", "ink")
    # the node's glowing display also reads 47
    digit(detail, 44, 25, "4", "glow")
    digit(detail, 50, 25, "7", "glow")
    box(detail, 43, 31, 53, 31, "teal")
    box(detail, 42, 37, 46, 39, "teal_l")
    put(detail, 52, 38, "red")
    put(detail, 47, 7, "teal_l")
    # tarnish on the old bronze
    for x, y in [(14, 37), (22, 39), (12, 44), (27, 30)]:
        put(detail, x, y, "teal")
    return [shadow, body, lit, detail]


FIXTURES = [
    ("layered-wall", fixture_layered_wall, 0,
     "分层墙面 / Layered Wall: cut wall section on a pallet, brick base under sandstone, the same teal age tag on both layers, a survey camera photographing the original"),
    ("broken-index", fixture_broken_index, 1,
     "残缺索引 / Broken Index: oak card catalogue with one drawer slot empty and one drawer pulled out with gaps in its cards, a survey reader listing identifiers with an amber missing run"),
    ("code-47", fixture_code_47, 2,
     "编号四七 / Code Forty-Seven: old bronze junction box stamped 47 next to a modern relay node also reading 47; the node's cable lies unplugged beside the old box"),
]


# ---------------------------------------------------------------- source writers

def merged(layers):
    w, h = layers[0].size
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for img in layers:
        out.alpha_composite(img)
    return out


def png_bytes(img):
    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=False)
    return buf.getvalue()


DT = (2026, 10, 17, 3, 8, 0)


def ora_bytes(name, names, layers, flat):
    w, h = flat.size
    root = ET.Element("image", {"w": str(w), "h": str(h), "name": name, "version": "0.0.3"})
    stack = ET.SubElement(root, "stack")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype", DT), "image/openraster", compress_type=zipfile.ZIP_STORED)
        z.writestr(zipfile.ZipInfo("mergedimage.png", DT), png_bytes(flat), compress_type=zipfile.ZIP_DEFLATED)
        for i, (ln, img) in reversed(list(enumerate(zip(names, layers)))):  # ORA lists top layer first
            src = f"data/layer{i:02d}.png"
            z.writestr(zipfile.ZipInfo(src, DT), png_bytes(img), compress_type=zipfile.ZIP_DEFLATED)
            ET.SubElement(stack, "layer", {"name": ln, "src": src, "x": "0", "y": "0", "opacity": "1.0",
                                           "visibility": "visible", "composite-op": "svg:src-over"})
        z.writestr(zipfile.ZipInfo("stack.xml", DT), ET.tostring(root, encoding="utf-8", xml_declaration=True),
                   compress_type=zipfile.ZIP_DEFLATED)
    return buf.getvalue()


def pxo_bytes(export_name, names, layers, flat):
    w, h = flat.size
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": False, "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": True} for n in names]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0} for _ in names],
                    "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(export_name),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    palette = [{"name": "wdc-annex-room1", "colors": [{"color": PAL[k], "index": i} for i, k in enumerate(PAL)]}]
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": len(names) - 1,
            "export_profile": export_profile, "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json,
            "license": "", "metadata": {"declared_palette": palette}, "next_keyframe_id": 0, "palettes": [],
            "pixelorama_version": PIXELORAMA_VERSION, "project_current_palette_name": "", "pxo_version": 7,
            "reference_images": [], "size_x": w, "size_y": h, "symmetry_points": [w - 1.0, h - 1.0], "tags": [],
            "tile_mode_x_basis_x": w, "tile_mode_x_basis_y": 0, "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": h,
            "tilesets": [], "user_data": "", "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def add(name, payload):
            z.writestr(zipfile.ZipInfo(name, DT), payload, zipfile.ZIP_DEFLATED)
        add("data.json", json.dumps(data, separators=(",", ":")))
        add("mimetype", "application/x-pixelorama")
        add("preview.png", png_bytes(flat))
        add("image_data/frames/1/", b"")
        for i, img in enumerate(layers, start=1):
            add(f"image_data/frames/1/layer_{i}", img.tobytes())
            add(f"image_data/frames/1/indices_layer_{i}", b"\x00")
    return buf.getvalue()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rel(p):
    return str(p.relative_to(ROOT)).replace("\\", "/")


def write_asset(stem, export_name, names, layers, runtime_dir):
    flat = merged(layers)
    files = {"png": png_bytes(flat), "ora": ora_bytes(stem, names, layers, flat), "pxo": pxo_bytes(export_name, names, layers, flat)}
    for ext, data in files.items():
        (OUT / f"{stem}.{ext}").write_bytes(data)
    runtime = runtime_dir / f"{stem}.png"
    runtime.write_bytes(files["png"])
    return {
        "size": list(flat.size), "layers_bottom_to_top": names,
        "files": {ext: {"file": rel(OUT / f"{stem}.{ext}"), "sha256": sha(d), "hash_algorithm": "sha256-bytes"} for ext, d in files.items()},
        "runtime_png": {"file": rel(runtime), "sha256": sha(files["png"]), "hash_algorithm": "sha256-bytes"},
    }


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    RUNTIME_SCENE_DIR.mkdir(parents=True, exist_ok=True)
    RUNTIME_PROP_DIR.mkdir(parents=True, exist_ok=True)
    scene_layers = build_scene()
    scene = write_asset(f"{PREFIX}_capitol-interior-scene_unapproved-v01_{STAMP}", "wdc-annex-room1-scene",
                        SCENE_LAYERS, scene_layers, RUNTIME_SCENE_DIR)
    scene["purpose"] = "room background, drawn at Rect2(0, 0, 640, 360) for scifi.ruins room 1"
    fixtures = []
    for slug, author, clue_index, meaning in FIXTURES:
        layers = [Image.fromarray(l) for l in author()]
        item = write_asset(f"{PREFIX}_{slug}-pixel-fixture_unapproved-v01_{STAMP}", f"wdc-annex-room1-{slug}",
                           FIXTURE_LAYERS, layers, RUNTIME_PROP_DIR)
        item.update({"purpose": slug, "clue": f"scifi.ruins:{clue_index}", "reads_as": meaning,
                     "screen_rect_640x360": f"CLUE_POSITIONS[{clue_index}] + (-32, 2), 64x64, drawn under the clue marker and labels"})
        fixtures.append(item)
    manifest = {
        "project": "rpg-2-star-ocean-the-second",
        "scene": "Washington, D.C. ruins survey annex room 1 (遗址外环 / Ruin Outer Ring), destination scifi.ruins",
        "status": "UNAPPROVED candidate; creator has not reviewed; counters unchanged (scenes 3/12, sprites 0/52, timed playtests 0/2, weighted 40.8%)",
        "replaces_in_runtime": "game/assets/environments/rpg-2-star-ocean-the-second_scifi-ruins-survey-annex-room-01_environment-background_m8-concept_20261014-142840-0ce7a91b.png (composition reference only; no pixels copied)",
        "authorship": "Hand-placed primitives in this tool by Claude (Claude Code, signed-in Claude Max, firstParty); no image generation, resampling or filtering.",
        "palette": PAL, "fixture_contact_shadow_rgba": list(SHADOW_RGBA),
        "pixelorama": f"pxo_version 7, color_mode 5, 1 frame; scene {len(SCENE_LAYERS)} layers, fixtures {len(FIXTURE_LAYERS)} layers; ORA lists the same layers",
        "scene_asset": scene, "fixtures": fixtures, "source": rel(Path(__file__)),
    }
    path = OUT / f"{PREFIX}_scene-and-fixtures-manifest_unapproved-v01_{STAMP}.json"
    path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(rel(path))
    return manifest


if __name__ == "__main__":
    build()
