extends SceneTree
# v02 bounded-correction native poses: real advance() steady states (torso cadence included),
# plus the penultimate and final 60fps stop frames for the stop phase whose last settle
# step changes the most texels (the worst case for a settle pop).
const MODEL_PATH := "res://../tools/rpg-2-star-ocean-the-second_female-east_run-stop-source_unapproved-v02_20261018-190542-52b0e405.gd"
const MODEL := preload(MODEL_PATH)
const TAG := "v02_20261018-190542-52b0e405"
const NAME := "rpg-2-star-ocean-the-second_female-east-run_%s_native_%s.png"
func _initialize() -> void:call_deferred("_run")
func _bounds(image: Image) -> Array:
	var r:=image.get_used_rect()
	return [r.position.x,r.position.y,r.end.x,r.end.y]
func _diff(a: Image,b: Image,from_y: int) -> int:
	var n:=0
	for y in range(from_y,112):
		for x in 80:
			if a.get_pixel(x,y)!=b.get_pixel(x,y):n+=1
	return n
func _state_json(state: Dictionary) -> Dictionary:
	var s:=state.duplicate(true)
	s.body=[s.body.x,s.body.y]
	return s
func _save(folder: String,image: Image,label: String,report: Dictionary,extra: Dictionary) -> void:
	var name:=NAME%[label,TAG]
	image.save_png(folder.path_join(name))
	var entry:={"pose":label,"file":name,"sha256":FileAccess.get_sha256(folder.path_join(name)),"bounds":_bounds(image)}
	entry.merge(extra)
	report.poses.append(entry)
func _run() -> void:
	var args:=OS.get_cmdline_user_args()
	var folder:=args[0]
	var all_folder:=args[1] if args.size()>1 else ""
	DirAccess.make_dir_recursive_absolute(folder)
	var model: RefCounted=MODEL.new()
	var x:=0.
	var poses:={}
	for i in 400:
		x+=.5
		var state: Dictionary=model.advance(1./280.,x,1.)
		if i>=256:poses[int(state.q)]=state
	var report:={"task":"content.char.protagonist-female.walk-east","stage":"v02 bounded correction, before final matrix/PXO packaging","cell":[80,112],"pivot":[40,104],"scale":.5,"cadence":4.375,"strideSourcePixels":128,"contactSourcePixels":38,"bakeTicks":"400 advance() ticks at 1/280s, +0.5 world px each; states kept after tick256","poses":[],"allPhaseBounds":{},"stopSettle60":[],"modelSha256":FileAccess.get_sha256(MODEL_PATH),"artApproved":false,"motionApproved":false}
	var missing:=[]
	for q in 128:
		if not poses.has(q):missing.append(q);continue
		var image: Image=model.render_pose(poses[q]).full
		report.allPhaseBounds[str(q)]=_bounds(image)
		if all_folder!="":
			DirAccess.make_dir_recursive_absolute(all_folder)
			image.save_png(all_folder.path_join("q%03d.png"%q))
	report["missingPhases"]=missing
	for pick in [["contact",0],["passing",19],["flight",51]]:
		var state: Dictionary=poses[pick[1]]
		_save(folder,model.render_pose(state).full,"%s-q%03d"%pick,report,{"q":pick[1],"state":_state_json(state)})
	# 60fps stop from every steady phase: record the last settle step and the frame before it.
	var worst:={"phase":-1,"last":-1,"moveIndex":-1,"moveDiff":-1}
	var final_exact:=true
	for phase in 128:
		var m: RefCounted=MODEL.new()
		m.physical_x=500.;m.render_x=500.;m.origin_x=500.;m.q0=float(phase);m.q=float(phase);m.mode="run";m.age=1.
		m.feet=[m.gait_foot(phase),m.gait_foot(phase+64.)];m.last_body=m.steady_body(float(phase))
		var frames:=[m.render_pose(m.snapshot()).full]
		var states:=[m.snapshot()]
		for t in 30:
			var s: Dictionary=m.advance(1./60.,500.,0.)
			frames.append(m.render_pose(s).full)
			states.append(s)
			if s.mode=="idle":break
		var n:=frames.size()
		var exact: bool=frames[n-1].get_data()==m.original.get_data()
		final_exact=final_exact and exact
		var steps:=[]
		var leg_steps:=[]
		for k in range(1,n):
			steps.append(_diff(frames[k-1],frames[k],0))
			leg_steps.append(_diff(frames[k-1],frames[k],69))
		# Last settle frame that still differs from the exact static.
		var move:=n-1
		while move>0 and frames[move].get_data()==frames[n-1].get_data():move-=1
		var move_diff:=_diff(frames[move],frames[n-1],0)
		report.stopSettle60.append({"phase":phase,"frames":n,"finalExact":exact,"stepChangedTexels":steps,"legRowStepChangedTexels":leg_steps,"penultimateStopAge":states[n-2].stopAge,"lastMovingFrame":move,"lastMovingStopAge":states[move].stopAge,"lastMovingChangedTexelsToFinal":move_diff})
		if steps[-1]>worst.last or (steps[-1]==worst.last and (move>worst.moveIndex or (move==worst.moveIndex and move_diff>worst.moveDiff))):
			worst={"phase":phase,"last":steps[-1],"moveIndex":move,"moveDiff":move_diff,"moving":frames[move],"moveState":states[move],"penultimate":frames[n-2],"final":frames[n-1],"state":states[n-2]}
	_save(folder,worst.moving,"stop-lastmove-60fps-q%03d"%worst.phase,report,{"q":worst.phase,"stopAge":worst.moveState.stopAge,"changedTexelsToFinal":worst.moveDiff,"state":_state_json(worst.moveState)})
	_save(folder,worst.penultimate,"stop-penultimate-60fps-q%03d"%worst.phase,report,{"q":worst.phase,"lastStepChangedTexels":worst.last,"state":_state_json(worst.state)})
	_save(folder,worst.final,"stop-final-60fps-q%03d"%worst.phase,report,{"q":worst.phase,"equalsOriginalEastStatic":worst.final.get_data()==model.original.get_data()})
	report["allStopFinalsExact"]=final_exact
	var f:=FileAccess.open(folder.path_join("rpg-2-star-ocean-the-second_female-east-run_native-poses-report_%s.json"%TAG),FileAccess.WRITE)
	f.store_string(JSON.stringify(report,"  ")+"\n")
	f.close()
	print("EAST NATIVE POSES missing=",missing.size()," saved=",report.poses.size()," worstStopPhase=",worst.phase," lastStep=",worst.last," finalsExact=",final_exact)
	quit(1 if missing.size()>0 or not final_exact else 0)
