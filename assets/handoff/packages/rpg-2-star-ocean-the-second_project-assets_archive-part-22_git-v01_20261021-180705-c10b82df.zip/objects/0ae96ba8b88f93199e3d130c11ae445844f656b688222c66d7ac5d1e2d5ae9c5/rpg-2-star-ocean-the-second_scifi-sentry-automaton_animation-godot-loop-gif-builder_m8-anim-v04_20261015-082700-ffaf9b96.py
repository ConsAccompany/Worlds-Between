"""Assemble the real Godot-render loop frames recorded by the v4 capture test into review GIFs (one GIF per version).

The frames are 1280x720 viewport crops saved by
  game/tests/rpg-2-star-ocean-the-second_sentry-automaton-animation-candidate_battle-check-capture_m8-anim-v04_20261015-081010-b3a19992.gd
when SENTRY_V4_GIF_DIR is set (one sub-folder per version, f0000.png ...). They are real engine renders of real combat calls
(every 3rd frame at 60 fps, so 50 ms per GIF frame). Nothing is redrawn, resized or retimed here; frames are only palettised
(one shared 255-colour palette, no dithering).
Each GIF is a separate file (no contact sheet or collage). A small note JSON records the sources and hashes.

Usage (bundled Python/Pillow runtime, run with -I):
  python <this file> --frames DIR --out OUTPUTS_DIR [--versions v4 v2]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import uuid
from datetime import datetime
from pathlib import Path

from PIL import Image

SLUG = "rpg-2-star-ocean-the-second"
TAG = "m8-anim-v04"
FRAME_MS = 50
LABEL = {"v4": "godot-render-loop-v4-candidate", "v2": "godot-render-loop-v2-runtime-default-compare"}


def build(frames_dir: Path, path: Path) -> dict:
    files = sorted(frames_dir.glob("f*.png"))
    assert len(files) > 30, (frames_dir, len(files))
    frames = [Image.open(f).convert("RGB") for f in files]
    sizes = {f.size for f in frames}
    assert len(sizes) == 1, sizes
    # One shared palette (from a strip of every 8th frame), no dithering, so unchanged background pixels keep the same
    # index from frame to frame and the GIF only stores what moves.
    w, h = frames[0].size
    sample = frames[::8]
    atlas = Image.new("RGB", (w, h * len(sample)))
    for i, f in enumerate(sample):
        atlas.paste(f, (0, i * h))
    palette = atlas.quantize(colors=255, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    pal = [f.quantize(palette=palette, dither=Image.Dither.NONE) for f in frames]
    assert not path.exists(), path
    pal[0].save(path, save_all=True, append_images=pal[1:], duration=FRAME_MS, loop=0, disposal=1, optimize=True)
    return {"frames": len(files), "size": list(frames[0].size), "frameMs": FRAME_MS,
            "sourceFrameSha256": hashlib.sha256(b"".join(hashlib.sha256(f.read_bytes()).digest() for f in files)).hexdigest()}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--versions", nargs="+", default=["v4", "v2"])
    args = ap.parse_args()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    note = {"project": SLUG, "revision": TAG, "status": "review_preview_only", "artAcceptanceCount": 0,
            "method": "real Godot 4.7.2 1280x720 renders of real combat calls (walk in, wind-up, strike at 53 px, hero hits back, wind-up while the hero backs off to 69 px, strike at 69 px, the sentry follows on its gait, defeat hold), every 3rd 60 fps frame, cropped to the fight, palettised only; the result overlay is hidden so the defeat pose stays visible",
            "builderScript": str(Path(__file__).resolve().relative_to(args.out.resolve().parent)).replace("\\", "/"),
            "gifs": []}
    for version in args.versions:
        token = uuid.uuid4().hex[:8]
        path = args.out / f"{SLUG}_scifi-sentry-automaton-animation-candidate_{LABEL[version]}_{TAG}_{stamp}-{token}.gif"
        info = build(args.frames / version, path)
        info.update({"version": version, "file": "outputs/" + path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size})
        note["gifs"].append(info)
        print(path, info["frames"], info["bytes"])
    npath = args.out / f"{SLUG}_scifi-sentry-automaton-animation-candidate_godot-render-loop-note_{TAG}_{stamp}-{uuid.uuid4().hex[:8]}.json"
    assert not npath.exists()
    npath.write_text(json.dumps(note, indent=2) + "\n", encoding="utf-8")
    print(npath)


if __name__ == "__main__":
    main()
