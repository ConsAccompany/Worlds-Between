"""Author the heroine Sea-of-Stars exploration idle+walk source set (four directions).

Deterministic, UNAPPROVED candidate source. Writes only under outputs/hsea-exp02/<run>/.
South idle frame 0 is the approved static bytes copied verbatim (sha256 checked).
South frames reuse that static's upper body (rows < HIP) over newly painted legs;
east/north are painted from layered primitives; west is east mirrored (disclosed).
Usage: python -I <this> [--out-tag TAG]
"""
import hashlib, importlib.util, io, json, sys, zipfile, datetime
import xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
SOUTH = "outputs/hero-sea-exp-v01/rpg-2-star-ocean-the-second_heroine-sea_exploration-native80x112_unapproved-v01_20261020-181941-4449ed55.png"
SOUTH_SHA = "6bf1d688487bd3fcc71eeb2e7c9b7c74f1fe6b6cd6362860b7fa0d42e009e429"
WRITER = "tools/rpg-2-star-ocean-the-second_protagonist-female_south-run-v06-build_m8-w09_20261017-211600-f8e736cc.py"
W, H, PIV = 80, 112, (40, 104)
SOLE = 103          # last opaque row (outline row); boot fill ends at 102
HIP = 66
WALK_MS, IDLE_MS = 60, 600   # 8 x 60 ms = 480 ms per two steps = 4.167 steps/s

# narrow palette sampled from the approved south static
C = dict(
    ol=(13, 12, 21), hair_d=(57, 37, 35), hair=(100, 63, 49), hair_l=(171, 108, 75),
    skin=(232, 179, 140), skin_l=(240, 202, 167), skin_d=(182, 122, 96),
    nav_d=(17, 22, 43), nav=(32, 44, 68), nav_l=(55, 64, 93),
    vest=(182, 162, 148), vest_d=(121, 93, 83),
    teal_d=(11, 68, 86), teal=(18, 97, 110), teal_l=(34, 141, 151),
    pant_d=(26, 35, 51), pant=(45, 52, 65),
    boot_d=(40, 27, 30), boot=(79, 51, 43), boot_l=(110, 69, 52), eye=(17, 22, 43))

# Planned footfalls, side view (x of ankle relative to hip, lift in px), 8 phases.
# p0 contact(lead heel down), p1 loading, p2 midstance/pass, p3 push-off, p4 opposite contact...
SIDE_FOOT = [(15, 0), (8, 0), (1, 0), (-7, 0), (-14, 2), (-6, 6), (4, 7), (12, 3)]
BOB = [1, 0, -1, 0, 1, 0, -1, 0]          # body down at contact, up at passing
ARM = [-9, -5, 0, 5, 9, 5, 0, -5]          # near-arm hand x offset, counter to near leg


def sha(b): return hashlib.sha256(b).hexdigest()
def png(arr):
    b = io.BytesIO(); Image.fromarray(arr).save(b, "PNG", optimize=False); return b.getvalue()
def blank(): return np.zeros((H, W, 4), np.uint8)


def mask_of(fn):
    im = Image.new("L", (W, H), 0); fn(ImageDraw.Draw(im)); return np.array(im) > 0


def fill(layer, m, base, shade=None, light=None, sdx=2, sdy=1):
    """Two/three-tone cluster fill: shadow band on lower-right edge, light band upper-left."""
    layer[m] = (*base, 255)
    if shade:
        sh = m & ~np.roll(np.roll(m, -sdy, 0), -sdx, 1)
        layer[sh] = (*shade, 255)
    if light:
        li = m & ~np.roll(np.roll(m, 1, 0), 1, 1) & ~(m & ~np.roll(np.roll(m, -sdy, 0), -sdx, 1))
        layer[li] = (*light, 255)


def capsule(d, a, b, w):
    d.line([a, b], fill=255, width=w)
    r = w / 2 - 0.5
    for p in (a, b): d.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], fill=255)


def ik(hip, ank, l1=16, l2=16, fwd=1):  # 32 px leg: slight knee at 30 px stance
    hx, hy = hip; ax, ay = ank
    dx, dy = ax - hx, ay - hy; d = max(1e-6, (dx * dx + dy * dy) ** .5); d2 = min(d, l1 + l2 - .01)
    a = (l1 * l1 - l2 * l2 + d2 * d2) / (2 * d2); h = max(0, l1 * l1 - a * a) ** .5
    mx, my = hx + dx * a / d, hy + dy * a / d
    return (mx - dy / d * h * -fwd, my + dx / d * h * -fwd) if fwd else (mx, my)


# ---------------- side (east-facing) painter ----------------
def side_leg(L, hip, foot_dx, lift, near):
    ank = (hip[0] + foot_dx, 96 - lift)
    knee = ik(hip, ank, fwd=1)
    pc, pd = (C["pant"], C["pant_d"]) if near else (C["pant_d"], C["pant_d"])
    m = mask_of(lambda d: (capsule(d, hip, knee, 8), capsule(d, knee, ank, 7)))
    fill(L, m, pc, pd)
    toe_up = 2 if lift == 0 and foot_dx > 10 else 0      # heel strike: toe raised
    heel_up = 2 if lift == 0 and foot_dx < -10 else 0    # push-off: heel raised
    bx, by = ank[0], ank[1]
    def boot(d):
        d.polygon([(bx - 4, by - 8), (bx + 3, by - 8), (bx + 4, by - 2), (bx + 9, by + 1 - toe_up),
                   (bx + 9, by + 6 - toe_up), (bx - 4, by + 6 - heel_up)], fill=255)
    m = mask_of(boot)
    fill(L, m, C["boot"] if near else C["boot_d"], C["boot_d"], C["boot_l"] if near else None)


def side_arm(L, sh, hand_dx, near):
    hand = (sh[0] + hand_dx, sh[1] + 20 - abs(hand_dx) // 3)
    el = ((sh[0] + hand[0]) / 2 - (1 if hand_dx > 0 else -1), (sh[1] + hand[1]) / 2 + 1)
    m = mask_of(lambda d: (capsule(d, sh, el, 7), capsule(d, el, hand, 6)))
    fill(L, m, C["nav_l"] if near else C["nav_d"], C["nav_d"] if near else None)
    hm = mask_of(lambda d: d.ellipse([hand[0] - 2.5, hand[1] - 1, hand[0] + 2.5, hand[1] + 4], fill=255))
    fill(L, hm, C["skin"] if near else C["skin_d"], C["skin_d"])


def paint_side(phase, idle_breath=0):
    b = BOB[phase] if phase is not None else idle_breath
    hip = (40, HIP + (b if phase is not None else 0))
    lay = {k: blank() for k in ("far-arm", "far-leg", "ponytail", "near-leg", "torso", "vest", "scarf", "head", "hair", "near-arm", "outline")}
    if phase is None:
        fa, fl, na, nl = ((-4, 0), 0), ((5, 0), 0), -2, 2
        side_leg(lay["far-leg"], (hip[0] + 1, hip[1]), -4, 0, False)
        side_leg(lay["near-leg"], (hip[0] - 1, hip[1]), 5, 0, True)
        hand_far, hand_near = 2, -2
    else:
        nf = SIDE_FOOT[phase]; ff = SIDE_FOOT[(phase + 4) % 8]
        side_leg(lay["far-leg"], (hip[0] + 1, hip[1]), ff[0], ff[1], False)
        side_leg(lay["near-leg"], (hip[0] - 1, hip[1]), nf[0], nf[1], True)
        hand_near, hand_far = ARM[phase], -ARM[phase]
    tx = 0 if phase is None else (-1 if phase in (3, 7) else 0)    # counter-rotation lean
    sy = hip[1] - 27 + (b if phase is None else 0)
    side_arm(lay["far-arm"], (43 + tx, sy + 4), hand_far, False)
    tm = mask_of(lambda d: d.polygon([(33 + tx, sy + 1), (47 + tx, sy + 1), (49 + tx, sy + 12), (48, hip[1] + 1),
                                      (31, hip[1] + 1), (32 + tx, sy + 12)], fill=255))
    fill(lay["torso"], tm, C["nav"], C["nav_d"], C["nav_l"])
    vm = mask_of(lambda d: d.polygon([(44 + tx, sy + 4), (48 + tx, sy + 5), (48 + tx, hip[1] - 3), (44 + tx, hip[1] - 4)], fill=255))
    fill(lay["vest"], vm & tm, C["vest"], C["vest_d"])
    hy = (HIP - 27) - 17 + (0 if phase is None else b + (b < 0))
    hc = (41 + tx, hy)
    hm = mask_of(lambda d: d.ellipse([hc[0] - 12, hc[1] - 13, hc[0] + 12, hc[1] + 12], fill=255))
    fm = mask_of(lambda d: d.polygon([(hc[0] + 1, hc[1] - 5), (hc[0] + 12, hc[1] - 4), (hc[0] + 13, hc[1] + 3),
                                      (hc[0] + 10, hc[1] + 10), (hc[0] + 3, hc[1] + 13), (hc[0] + 1, hc[1] + 8)], fill=255))
    nk = mask_of(lambda d: d.rectangle([hc[0] - 2, hc[1] + 9, hc[0] + 4, sy + 2], fill=255))
    fill(lay["head"], nk, C["skin_d"])
    fill(lay["head"], fm, C["skin"], C["skin_d"], C["skin_l"])
    hair = hm & ~(fm & ~mask_of(lambda d: d.polygon([(hc[0], hc[1] - 13), (hc[0] + 13, hc[1] - 6), (hc[0] + 12, hc[1] - 2), (hc[0] + 4, hc[1] - 4)], fill=255)))
    fill(lay["hair"], hair, C["hair"], C["hair_d"], C["hair_l"])
    lay["hair"][hc[1] + 1:hc[1] + 3, hc[0] + 7:hc[0] + 8] = (*C["eye"], 255)       # eye
    lay["hair"][hc[1] + 6, hc[0] + 9:hc[0] + 11] = (*C["skin_d"], 255)             # mouth
    sw = 0 if phase is None else [0, 1, 2, 1, 0, 1, 2, 1][phase] - (0 if phase < 4 else 0)
    lag = 0 if phase is None else [1, 0, -1, -1, 1, 0, -1, -1][phase]
    pm = mask_of(lambda d: (d.ellipse([hc[0] - 15, hc[1] - 12, hc[0] - 7, hc[1] - 4], fill=255),
                           d.polygon([(hc[0] - 13, hc[1] - 7), (hc[0] - 8, hc[1] - 6), (hc[0] - 12 - sw, hc[1] + 16),
                                      (hc[0] - 16 - sw + lag, hc[1] + 22), (hc[0] - 15 - sw, hc[1] + 8)], fill=255)))
    fill(lay["ponytail"], pm, C["hair"], C["hair_d"], C["hair_l"])
    scm = mask_of(lambda d: (d.ellipse([33 + tx, sy - 3, 49 + tx, sy + 5], fill=255),
                            d.polygon([(36 + tx, sy + 2), (40 + tx, sy + 2), (35 + tx + lag - sw, sy + 14), (32 + tx + lag - sw, sy + 13)], fill=255)))
    fill(lay["scarf"], scm, C["teal"], C["teal_d"], C["teal_l"])
    side_arm(lay["near-arm"], (39 + tx, sy + 4), hand_near, True)
    return lay


# ---------------- north (back view) painter ----------------
def paint_north(phase, idle_breath=0):
    b = BOB[phase] if phase is not None else idle_breath
    hipy = HIP + (b if phase is not None else 0)
    lay = {k: blank() for k in ("legs", "arms", "torso", "scarf", "head", "hair", "ponytail", "outline")}
    for side, sgn in (("L", -1), ("R", 1)):
        if phase is None: lift, depth = 0, 0
        else:
            # leg R leads phases 0..3 (support), swings 4..7; back view: swing foot lifts, heel shows
            q = (phase + (0 if sgn > 0 else 4)) % 8
            lift = [0, 0, 0, 1, 3, 6, 5, 2][q]; depth = [1, 1, 0, -1, -1, -1, 0, 1][q]
        hx = 40 + sgn * 5; ax = 40 + sgn * 6
        ank = (ax, 96 - lift - max(0, -depth))
        knee = (hx + sgn * 0.5, (hipy + ank[1]) / 2 - (2 if lift > 2 else 0))
        m = mask_of(lambda d: (capsule(d, (hx, hipy), knee, 9), capsule(d, knee, ank, 8)))
        fill(lay["legs"], m, C["pant"], C["pant_d"])
        heel = 2 if lift > 0 else 0
        bm = mask_of(lambda d: d.polygon([(ax - 4, ank[1] - 8), (ax + 4, ank[1] - 8), (ax + 5, ank[1] + 6 - heel),
                                          (ax - 5, ank[1] + 6 - heel)], fill=255))
        fill(lay["legs"], bm, C["boot"], C["boot_d"], C["boot_l"])
    sy = hipy - 27 + (b if phase is None else 0)
    for sgn in (-1, 1):
        sw = 0 if phase is None else ARM[phase] * sgn // 3     # arm forward = hand shorter/higher
        sh = (40 + sgn * 9, sy + 4); hand = (40 + sgn * 11, sy + 22 - abs(sw) // 2 + (sw // 2))
        m = mask_of(lambda d: capsule(d, sh, hand, 7))
        fill(lay["arms"], m, C["nav_l"], C["nav_d"])
        hm = mask_of(lambda d: d.ellipse([hand[0] - 2.5, hand[1] - 1, hand[0] + 2.5, hand[1] + 4], fill=255))
        fill(lay["arms"], hm, C["skin_d"])
    tw = 0 if phase is None else [0, 1, 0, -1, 0, -1, 0, 1][phase]
    tm = mask_of(lambda d: d.polygon([(30 + tw, sy + 1), (50 + tw, sy + 1), (51, sy + 12), (50, hipy + 1), (30, hipy + 1), (29, sy + 12)], fill=255))
    fill(lay["torso"], tm, C["nav"], C["nav_d"], C["nav_l"])
    seam = mask_of(lambda d: d.line([(40, sy + 6), (40, hipy)], fill=255)) & tm
    lay["torso"][seam] = (*C["nav_d"], 255)
    sc = mask_of(lambda d: d.ellipse([31, sy - 4, 49, sy + 5], fill=255))
    fill(lay["scarf"], sc, C["teal"], C["teal_d"], C["teal_l"])
    hy = (HIP - 27) - 16 + (0 if phase is None else b + (b < 0))
    hm = mask_of(lambda d: d.ellipse([28, hy - 13, 52, hy + 12], fill=255))
    nk = mask_of(lambda d: d.rectangle([37, hy + 8, 43, sy + 1], fill=255))
    fill(lay["head"], nk, C["skin_d"])
    ear = mask_of(lambda d: (d.ellipse([26, hy - 1, 30, hy + 5], fill=255), d.ellipse([50, hy - 1, 54, hy + 5], fill=255)))
    fill(lay["head"], ear, C["skin_d"])
    fill(lay["hair"], hm, C["hair"], C["hair_d"], C["hair_l"])
    sw = 0 if phase is None else [0, 1, 1, 0, 0, -1, -1, 0][phase]
    pm = mask_of(lambda d: (d.ellipse([36, hy - 14, 44, hy - 6], fill=255),
                           d.polygon([(36, hy - 9), (44, hy - 9), (44 + sw, hy + 8), (42 + sw, hy + 20), (40 + sw, hy + 24),
                                      (38 + sw, hy + 19), (36 + sw, hy + 8)], fill=255)))
    fill(lay["ponytail"], pm, C["hair"], C["hair_d"], C["hair_l"])
    strand = mask_of(lambda d: d.line([(41, hy - 6), (41 + sw, hy + 18)], fill=255)) & pm
    lay["ponytail"][strand] = (*C["hair_d"], 255)
    part = mask_of(lambda d: (d.arc([31, hy - 11, 49, hy + 9], 200, 340, fill=255), d.line([(33, hy + 3), (31, hy + 9)], fill=255),
                             d.line([(47, hy + 3), (49, hy + 9)], fill=255))) & hm
    lay["hair"][part] = (*C["hair_d"], 255)
    tie = mask_of(lambda d: d.rectangle([38, hy - 9, 42, hy - 8], fill=255))
    lay["ponytail"][tie] = (*C["teal_d"], 255)
    return lay


# ---------------- south (approved upper body + painted legs) ----------------
def paint_south(base, phase):
    b = BOB[phase]
    lay = {k: blank() for k in ("legs", "approved-upper-body", "outline")}
    for sgn in (-1, 1):
        q = (phase + (0 if sgn > 0 else 4)) % 8
        lift = [0, 0, 0, 1, 3, 6, 5, 2][q]; depth = [1, 1, 0, -1, -1, -1, 0, 1][q]
        hx = 40 + sgn * 5; ax = 40 + sgn * 6
        ank = (ax, 96 - lift + max(0, depth) - 1)
        knee = (hx + sgn * 0.5, (HIP + b + ank[1]) / 2 - (2 if lift > 2 else 0))
        m = mask_of(lambda d: (capsule(d, (hx, HIP - 2 + b), knee, 9), capsule(d, knee, ank, 8)))
        fill(lay["legs"], m, C["pant"], C["pant_d"])
        toe = 2 if lift > 0 else 0
        bm = mask_of(lambda d: d.polygon([(ax - 4, ank[1] - 8), (ax + 4, ank[1] - 8), (ax + 5, ank[1] + 6 - toe),
                                          (ax - 5, ank[1] + 6 - toe)], fill=255))
        fill(lay["legs"], bm, C["boot"], C["boot_d"], C["boot_l"])
    up = upper_of(base)
    up = np.roll(up, b, 0); up[:max(0, b)] = 0
    lay["approved-upper-body"] = up
    return lay


def upper_of(base):
    """Approved upper body incl. coat tails/hands outside the leg band (x<=26 or x>=55), rows HIP..HIP+12."""
    up = base.copy(); band = up[HIP:]; band[:, 27:55] = 0; up[HIP + 13:] = 0   # boots/legs below row 78 never kept
    return up


def outline(lay, order):
    comp = composite(lay, order)
    m = comp[..., 3] > 0
    dil = m.copy()
    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)): dil |= np.roll(np.roll(m, dy, 0), dx, 1)
    o = dil & ~m; o[SOLE + 1:] = False; o[:, 0] = o[:, -1] = False; o[0] = False
    lay["outline"][o] = (*C["ol"], 255)


def composite(lay, order):
    out = blank()
    for k in order:
        a = lay[k]; s = a[..., 3] > 0; out[s] = a[s]
    return out


def finalize(lay, order):
    for k in order: lay[k][SOLE + 1:] = 0
    outline(lay, [k for k in order if k != "outline"])
    return composite(lay, order)


SIDE_ORDER = ["outline", "far-arm", "far-leg", "ponytail", "near-leg", "torso", "vest", "scarf", "head", "hair", "near-arm"]
NORTH_ORDER = ["outline", "legs", "arms", "torso", "scarf", "head", "hair", "ponytail"]
SOUTH_ORDER = ["outline", "legs", "approved-upper-body"]


def build():
    raw = (ROOT / SOUTH).read_bytes(); assert sha(raw) == SOUTH_SHA
    base = np.array(Image.open(io.BytesIO(raw)).convert("RGBA"))
    frames = {d: {"idle": [], "walk": []} for d in ("south", "west", "north", "east")}
    layers = {d: [] for d in frames}
    # south: idle0 exact bytes; idle1 = breath (upper body 1 px down over painted legs, no holes)
    frames["south"]["idle"].append(("exact", raw, None))
    up0 = upper_of(base); lay = {"outline": blank()}
    lay["legs"] = np.where((up0[..., 3] == 0)[..., None], base, 0).astype(np.uint8)
    layers["south"].append(None)
    layers["south"][0] = {"legs": lay["legs"].copy(), "approved-upper-body": up0, "outline": blank()}
    assert np.array_equal(composite(layers["south"][0], SOUTH_ORDER), base)
    for p in range(8):
        lay = paint_south(base, p); frames["south"]["walk"].append(("arr", finalize(lay, SOUTH_ORDER), lay)); layers["south"].append(lay)
    for ph in (None, "b"):
        lay = paint_side(None, 0 if ph is None else 1); frames["east"]["idle"].append(("arr", finalize(lay, SIDE_ORDER), lay)); layers["east"].append(lay)
        lay = paint_north(None, 0 if ph is None else 1); frames["north"]["idle"].append(("arr", finalize(lay, NORTH_ORDER), lay)); layers["north"].append(lay)
    for p in range(8):
        lay = paint_side(p); frames["east"]["walk"].append(("arr", finalize(lay, SIDE_ORDER), lay)); layers["east"].append(lay)
        lay = paint_north(p); frames["north"]["walk"].append(("arr", finalize(lay, NORTH_ORDER), lay)); layers["north"].append(lay)
    for act in ("idle", "walk"):
        for kind, arr, lay in frames["east"][act]:
            ml = {k: v[:, ::-1].copy() for k, v in lay.items()}
            frames["west"][act].append(("arr", arr[:, ::-1].copy(), ml)); layers["west"].append(ml)
    return frames, layers


def main():
    tag = sys.argv[sys.argv.index("--out-tag") + 1] if "--out-tag" in sys.argv else datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    run = ROOT / "outputs" / "hsea-exp02" / ("src-" + tag); run.mkdir(parents=True, exist_ok=True)
    uid = sha(tag.encode())[:8]
    frames, layers = build()
    spec = importlib.util.spec_from_file_location("pxo_writer", ROOT / WRITER)
    wr = importlib.util.module_from_spec(spec); spec.loader.exec_module(wr)
    wr.W, wr.H = W, H; wr.to_rgba = lambda a: np.ascontiguousarray(a, np.uint8)
    actions, src_files, checks = {"idle": {}, "walk": {}}, [], []
    pre = "rpg-2-star-ocean-the-second_heroine-sea"
    for d in ("south", "west", "north", "east"):
        durs = []
        for act in ("idle", "walk"):
            actions[act][d] = []
            for i, (kind, data, _) in enumerate(frames[d][act]):
                b = data if kind == "exact" else png(data)
                fn = f"{pre}_explore-{d}-{act}-f{i:02d}_unapproved-v02_{tag}-{uid}.png"
                (run / fn).write_bytes(b)
                ms = IDLE_MS if act == "idle" else WALK_MS
                actions[act][d].append({"file": fn, "duration_ms": ms}); durs.append(ms / 1000)
        order = SOUTH_ORDER if d == "south" else NORTH_ORDER if d == "north" else SIDE_ORDER
        lays = layers[d]
        per = [{k: l[k] for k in order} for l in lays]
        prev = png(composite(per[0], order))
        pxo = f"{pre}_explore-{d}-layers_unapproved-v02_{tag}-{uid}.pxo"
        (run / pxo).write_bytes(wr.make_pxo(per, durs, prev, pxo.replace(".pxo", ".png"), 16, order=order, dt=(2026, 10, 20, 0, 0, 0)))
        ora = f"{pre}_explore-{d}-idle0-layers_unapproved-v02_{tag}-{uid}.ora"
        with zipfile.ZipFile(run / ora, "w") as z:
            z.writestr(zipfile.ZipInfo("mimetype", (2026, 10, 20, 0, 0, 0)), "image/openraster")
            z.writestr(zipfile.ZipInfo("mergedimage.png", (2026, 10, 20, 0, 0, 0)), prev)
            root = ET.Element("image", {"w": str(W), "h": str(H)}); st = ET.SubElement(root, "stack")
            for i, k in enumerate(order[::-1]):
                z.writestr(zipfile.ZipInfo(f"data/l{i}.png", (2026, 10, 20, 0, 0, 0)), png(per[0][k]))
                ET.SubElement(st, "layer", {"name": k, "src": f"data/l{i}.png", "x": "0", "y": "0"})
            z.writestr(zipfile.ZipInfo("stack.xml", (2026, 10, 20, 0, 0, 0)), ET.tostring(root, encoding="utf8"))
        src_files += [{"direction": d, "file": pxo, "format": "pixelorama-pxo", "frames": "idle then walk, manifest order",
                       "sha256": sha((run / pxo).read_bytes())},
                      {"direction": d, "file": ora, "format": "openraster-supplemental-idle0", "sha256": sha((run / ora).read_bytes())}]
    man = {"schema": "worlds-between.exploration-source.v1", "actor_id": "hero:female", "density": 2,
           "frame_size": [W, H], "pivot": list(PIV), "actions": actions, "source_files": src_files,
           "status": "UNAPPROVED test-only candidate; no runtime/default change",
           "author_tool": {"file": str(Path(__file__).relative_to(ROOT)).replace("\\", "/"),
                           "sha256TextLf": sha(Path(__file__).read_bytes().replace(b"\r\n", b"\n"))},
           "gait": {"walk_frames": 8, "frame_ms": WALK_MS, "steps_per_second": round(2000 / (8 * WALK_MS), 3),
                    "side_footfall_plan": SIDE_FOOT, "bob": BOB, "arm_hand_dx": ARM,
                    "contacts": "near leg heel-strike p0, far leg heel-strike p4"},
           "disclosure": ["west = horizontal mirror of east (ponytail/scarf tail side flips)",
                          "south idle = 1 pose, f00 = approved static bytes verbatim (no breath frame: it would break the 96 px idle height); south walk reuses its upper body (rows<66) with bob over newly painted legs; south arms do not swing",
                          "east/north painted from primitives; rendering density is flatter than the generated-art south static"]}
    mp = run / f"{pre}_explore-source-manifest_unapproved-v02_{tag}-{uid}.json"
    mp.write_text(json.dumps(man, indent=1), encoding="utf-8", newline="\n")
    print(mp)


if __name__ == "__main__":
    main()
