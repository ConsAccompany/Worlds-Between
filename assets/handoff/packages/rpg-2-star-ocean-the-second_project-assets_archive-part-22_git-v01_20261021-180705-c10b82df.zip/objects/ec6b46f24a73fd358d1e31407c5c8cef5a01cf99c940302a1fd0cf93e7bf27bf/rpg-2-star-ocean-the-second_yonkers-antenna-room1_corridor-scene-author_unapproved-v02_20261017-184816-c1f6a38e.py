"""Yonkers outskirts survey annex room 1 (天线走廊 / Antenna Walkway): native pixel-art v02 scene.

One 640x360 Pixelorama/OpenRaster project, built only from hand-placed primitives in this file
(rects, lines, ellipses, polygons and seeded pixel texture). No generated, traced, resampled or
palette-reduced image is used anywhere. Every layer has binary alpha.

Layers, bottom to top (runtime export in brackets):
  1-9   sky, back parapet, wall kit, deck, walkway, deck detail, cast shadows, doors, front
        parapet                                                     [flattened -> corridor plate]
  10-12 antenna A lattice Yagi, antenna B dish, antenna C guyed whip [each cropped 128x152 ->
        a y-sorted sprite anchored at (clue x, 210)]
  13    foreground occluder (corner shrubs on the front parapet)     [drawn above the heroine]

Usage: python -I <this file>
"""

from __future__ import annotations

import hashlib
import io
import json
import math
import random
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
STAMP = "20261017-184816-c1f6a38e"
PREFIX = "rpg-2-star-ocean-the-second_yonkers-antenna-room1"
OUT = ROOT / "outputs" / "yonkers-room1-v02_c1f6a38e"
RUNTIME_ENV = ROOT / "game/assets/environments/yonkers-antenna-room1"
RUNTIME_PROPS = ROOT / "game/assets/props/yonkers-antenna-room1"
PIXELORAMA_VERSION = "v1.2.3-stable"
W, H = 640, 360

# Clue x positions are the unchanged runtime CLUE_POSITIONS x; antennas stand on a shared base line.
ANTENNA_X = (163, 320, 477)
BASE_Y = 210  # first deck row in front of every plinth; sprite anchor y (y-sort key)
SPRITE_TOP = 58  # sprites cover y 58..209 (the 62 px header hides the first rows)
SPRITE_W, SPRITE_H = 128, BASE_Y - SPRITE_TOP

HEX = {
    # sky and distant ridge
    "sky0": "#7aa3b4", "sky1": "#93b7c2", "sky2": "#adcbcb", "cloud": "#dbe7df", "cloud_sh": "#b9cdc8",
    "hill_far": "#7f9c98", "hill": "#64837b", "hill_dk": "#4f6c64",
    "tree_far": "#4a6b54", "tree": "#3a5a44", "tree_dk": "#2b4536", "tree_hi": "#628456",
    # warm masonry
    "st_hi": "#c7b996", "st": "#a99c7c", "st_mid": "#8d8369", "st_dk": "#6e6754", "st_deep": "#4f4b3f", "mortar": "#3c3b32",
    # deck slabs (cooler, mossy)
    "dk_hi": "#8f927b", "dk_a": "#7b7f6a", "dk_b": "#737864", "dk_c": "#6b705d", "dk_seam": "#4f5447",
    "dk_sh": "#5a5f50", "dk_sh2": "#4b5044",
    # walkway grating
    "gr_hi": "#86948d", "gr": "#5b6a68", "gr_dk": "#3e4b4b", "gr_hole": "#252f31",
    # restrained teal technology (accepted room 2 kit)
    "ink": "#151d21", "deep": "#263239", "slate": "#34434a", "steel": "#526269", "edge": "#839087",
    "teal_dk": "#1b5c68", "teal": "#4fa5a2", "glow": "#8be9d7",
    "br_dk": "#674927", "br": "#a67b3d", "br_hi": "#d6af64",
    "wood": "#514031", "wood_hi": "#806247",
    # foliage
    "lf_dk": "#223b2a", "lf": "#355a33", "lf_mid": "#4f7a3c", "lf_hi": "#7a9d4c", "moss": "#5c6b3b", "moss_hi": "#7e8b4d",
    "flower": "#e8e2c4",
    # clue accents
    "warn": "#d58b4c", "warn_dk": "#7c4a2f", "frost": "#dcecea", "frost_mid": "#a6c4c8",
    "paper": "#d7c7a5", "paper_dk": "#a99b7e", "rust": "#8a5a3a",
}
RGB = {k: tuple(int(v[i:i + 2], 16) for i in (1, 3, 5)) for k, v in HEX.items()}
RGBA = {k: np.array(v + (255,), np.uint8) for k, v in RGB.items()}

SCENE_LAYERS = [
    "sky-and-ridge", "back-parapet-masonry", "wall-kit-and-ivy", "deck-slabs", "walkway-grating-and-trench",
    "deck-detail-cables-moss", "cast-shadows", "doors-and-side-walls", "front-parapet",
    "antenna-a-lattice-yagi", "antenna-b-dish", "antenna-c-guyed-whip", "foreground-occluder",
]
PLATE_LAYERS = SCENE_LAYERS[:9]
ANTENNA_LAYERS = SCENE_LAYERS[9:12]


class Layer:
    def __init__(self):
        self.a = np.zeros((H, W, 4), np.uint8)

    def px(self, x, y, c):
        x, y = int(round(x)), int(round(y))
        if 0 <= x < W and 0 <= y < H:
            self.a[y, x] = RGBA[c]

    def rect(self, x0, y0, x1, y1, c):
        """Inclusive fill."""
        x0, y0, x1, y1 = max(int(x0), 0), max(int(y0), 0), min(int(x1), W - 1), min(int(y1), H - 1)
        if x1 >= x0 and y1 >= y0:
            self.a[y0:y1 + 1, x0:x1 + 1] = RGBA[c]

    def box(self, x0, y0, x1, y1, fill, outline="ink"):
        self.rect(x0, y0, x1, y1, outline)
        self.rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, fill)

    def hline(self, x0, x1, y, c):
        self.rect(min(x0, x1), y, max(x0, x1), y, c)

    def vline(self, x, y0, y1, c):
        self.rect(x, min(y0, y1), x, max(y0, y1), c)

    def line(self, x0, y0, x1, y1, c):
        x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        while True:
            self.px(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def shape(self, draw_fn, c):
        m = Image.new("L", (W, H), 0)
        draw_fn(ImageDraw.Draw(m))
        self.a[np.array(m) > 0] = RGBA[c]

    def ellipse(self, x0, y0, x1, y1, c):
        self.shape(lambda d: d.ellipse((x0, y0, x1, y1), fill=255), c)

    def poly(self, pts, c):
        self.shape(lambda d: d.polygon([(int(round(x)), int(round(y))) for x, y in pts], fill=255), c)

    def name_at(self, x, y):
        if self.a[y, x, 3] == 0:
            return None
        return NAME_OF[tuple(int(v) for v in self.a[y, x, :3])]


NAME_OF = {v: k for k, v in RGB.items()}


def composite(layers):
    out = np.zeros((H, W, 4), np.uint8)
    for lay in layers:
        m = lay.a[..., 3] == 255
        out[m] = lay.a[m]
    return out


# ----------------------------------------------------------------------------- foliage helpers
def clump_mass(lay, rng, cx, cy, rx, ry, count, light=True, flowers=0):
    """Pixel foliage: dark mass, mid clumps offset up-left, a few lit leaves and optional flowers."""
    clumps = []
    for _ in range(count):
        a = rng.uniform(0, math.tau)
        r = math.sqrt(rng.random())
        clumps.append((cx + math.cos(a) * rx * r, cy + math.sin(a) * ry * r, rng.randint(2, 4)))
    clumps.sort(key=lambda c: c[1])
    for x, y, r in clumps:
        lay.ellipse(x - r, y - r + 1, x + r, y + r, "lf_dk")
    for x, y, r in clumps:
        if r >= 3:
            lay.ellipse(x - r + 1, y - r + 1, x + r - 2, y + r - 2, "lf")
    if light:
        for x, y, r in clumps:
            if y < cy + ry * 0.35:
                lay.px(x - r + 2, y - r + 1, "lf_mid")
                lay.px(x - r + 3, y - r + 1, "lf_mid")
                lay.px(x - r + 2, y - r + 2, "lf_mid")
                if rng.random() < 0.55:
                    lay.px(x - r + 2, y - r + 1, "lf_hi")
    for _ in range(flowers):
        x, y, _r = rng.choice(clumps)
        lay.px(x, y - 1, "flower")


def tendril(lay, rng, x, y, length):
    for i in range(length):
        x += rng.choice((-1, 0, 0, 0, 1)) * (1 if i % 3 == 0 else 0)
        lay.px(x, y + i, "lf_dk")
        if i % 3 == 1:
            side = rng.choice((-1, 1))
            lay.px(x + side, y + i, "lf_mid" if rng.random() < 0.5 else "lf")
            lay.px(x + side, y + i + 1, "lf")
    lay.px(x, y + length, "lf")


# ----------------------------------------------------------------------------- 1 sky and ridge
def sky_layer(rng):
    L = Layer()
    for y in range(0, 104):
        for x in range(W):
            if y < 70:
                c = "sky0" if not (y >= 67 and (x + y) % 2 == 0 and y % 2 == 1) else "sky1"
            elif y < 84:
                c = "sky1" if not (y >= 81 and (x + y) % 2 == 0) else "sky2"
            else:
                c = "sky2"
            L.a[y, x] = RGBA[c]
    # clouds: flat-bottomed puffs
    for cx, cy, w in [(62, 72, 34), (210, 66, 46), (372, 70, 30), (452, 64, 40), (604, 70, 34)]:
        for i in range(5):
            ox = int((i - 2) * w / 5)
            r = int(w / 5) + (3 if i in (1, 2, 3) else 0) - abs(i - 2)
            L.ellipse(cx + ox - r, cy - r, cx + ox + r, cy + 3, "cloud")
        L.rect(cx - w // 2, cy + 2, cx + w // 2, cy + 3, "cloud_sh")
    # far ridge, near ridge
    for x in range(W):
        yf = int(84 + 4 * math.sin(x / 41.0) + 3 * math.sin(x / 17.0 + 1.3))
        L.rect(x, yf, x, 103, "hill_far")
        yn = int(91 + 3 * math.sin(x / 29.0 + 2.0) + 2 * math.sin(x / 11.0))
        L.rect(x, yn, x, 103, "hill")
        if (x * 7) % 5 == 0:
            L.px(x, yn, "hill_far")
    # distant relay towers on the far ridge (the signal network this walkway belongs to)
    for tx, base, ht in [(266, 92, 20), (598, 92, 16), (40, 90, 12)]:
        L.line(tx - 3, base, tx, base - ht, "hill_dk")
        L.line(tx + 3, base, tx, base - ht, "hill_dk")
        for yy in range(base - ht + 3, base, 4):
            half = int(3 * (yy - (base - ht)) / ht)
            L.hline(tx - half, tx + half, yy, "hill_dk")
        L.px(tx, base - ht - 1, "hill_dk")
        L.px(tx + 1, base - ht + 2, "hill_dk")
    # treeline just behind the parapet
    for x in range(-4, W + 6, 5):
        cx, cy, r = x + rng.randint(-2, 2), 97 + rng.randint(-3, 2), rng.randint(4, 6)
        L.ellipse(cx - r, cy - r, cx + r, cy + r + 6, "tree")
    for x in range(-4, W + 6, 7):
        cx, cy, r = x + rng.randint(-2, 2), 95 + rng.randint(-2, 3), rng.randint(2, 3)
        L.ellipse(cx - r, cy - r, cx + r, cy + r, "tree_far")
        L.px(cx - 1, cy - r, "tree_hi")
    for x in range(W):
        for y in range(99, 104):
            if (x + y * 3) % 4 == 0:
                L.px(x, y, "tree_dk")
    return L


# ----------------------------------------------------------------------------- 2 back parapet
PILASTERS = (88, 241, 398, 556)


def masonry(L, rng, x0, x1, y0, y1, course=9, tones=("st", "st", "st_mid", "st_mid", "st_dk"), shade_rows=0):
    y = y0
    row = 0
    while y <= y1:
        h = min(course, y1 - y + 1)
        x = x0 - (rng.randint(0, 12) if row % 2 else 0)
        while x <= x1:
            w = rng.randint(16, 28)
            tone = rng.choice(tones)
            if shade_rows and y > y1 - shade_rows * course:
                tone = {"st": "st_mid", "st_mid": "st_dk", "st_dk": "st_dk"}[tone]
            bx0, bx1 = max(x, x0), min(x + w - 1, x1)
            if bx1 >= bx0:
                L.rect(bx0, y, bx1, y + h - 1, tone)
                L.hline(bx0, bx1, y + h - 1, "mortar")
                if x + w - 1 <= x1:
                    L.vline(bx1, y, y + h - 1, "mortar")
                lit = {"st": "st_hi", "st_mid": "st", "st_dk": "st_mid"}[tone]
                dark = {"st": "st_mid", "st_mid": "st_dk", "st_dk": "st_deep"}[tone]
                L.hline(bx0, bx1 - 1, y, lit)
                L.hline(bx0, bx1 - 1, y + h - 2, dark)
                for _ in range((bx1 - bx0) * h // 14):
                    L.px(rng.randint(bx0, bx1 - 1), rng.randint(y + 1, y + h - 3), dark if rng.random() < 0.7 else lit)
            x += w
        y += h
        row += 1


def parapet_layer(rng):
    L = Layer()
    # coping
    L.rect(0, 100, W - 1, 107, "st")
    L.hline(0, W - 1, 100, "st_hi")
    L.hline(0, W - 1, 101, "st_hi")
    L.hline(0, W - 1, 105, "st_mid")
    L.hline(0, W - 1, 106, "st_dk")
    L.hline(0, W - 1, 107, "st_deep")
    for x in range(9, W, 26):
        L.vline(x, 101, 106, "st_dk")
        L.px(x + 1, 101, "st_hi")
    for _ in range(90):
        L.px(rng.randint(0, W - 1), rng.randint(102, 104), "st_mid")
    # wall courses, darker toward the deck
    masonry(L, rng, 0, W - 1, 108, 151, course=9, shade_rows=2)
    L.rect(0, 152, W - 1, 155, "st_deep")
    L.hline(0, W - 1, 152, "st_dk")
    # pilasters
    for px0 in PILASTERS:
        L.rect(px0 - 2, 94, px0 + 17, 99, "st")
        L.hline(px0 - 2, px0 + 17, 94, "st_hi")
        L.hline(px0 - 2, px0 + 17, 99, "st_deep")
        L.rect(px0, 100, px0 + 15, 155, "st")
        L.vline(px0, 100, 155, "st_hi")
        L.rect(px0 + 12, 100, px0 + 15, 155, "st_mid")
        L.vline(px0 + 15, 100, 155, "st_dk")
        for yy in range(108, 156, 10):
            L.hline(px0, px0 + 15, yy, "st_dk")
            L.px(px0 + 1, yy + 1, "st_hi")
        L.rect(px0 - 1, 150, px0 + 16, 157, "st_mid")
        L.hline(px0 - 1, px0 + 16, 150, "st_hi")
        L.hline(px0 - 1, px0 + 16, 157, "st_deep")
    return L


# ----------------------------------------------------------------------------- 3 wall kit and ivy
JUNCTION_X = (198, 360, 420)  # wall boxes feeding antenna A, B, C


def junction_box(L, x0, y0, light="glow"):
    L.box(x0, y0, x0 + 16, y0 + 20, "slate")
    L.hline(x0 + 1, x0 + 15, y0 + 1, "edge")
    L.vline(x0 + 1, y0 + 2, y0 + 19, "steel")
    L.vline(x0 + 15, y0 + 2, y0 + 19, "deep")
    L.vline(x0 + 8, y0 + 3, y0 + 18, "deep")
    L.rect(x0 + 3, y0 + 4, x0 + 6, y0 + 7, "teal_dk")
    L.px(x0 + 4, y0 + 5, light)
    L.px(x0 + 5, y0 + 5, light)
    L.rect(x0 + 10, y0 + 9, x0 + 11, y0 + 12, "br")
    L.rect(x0 + 6, y0 + 21, x0 + 10, y0 + 22, "deep")  # conduit gland


def wall_kit_layer(rng):
    L = Layer()
    # cable tray along the wall, broken by the pilasters
    spans = [(38, 87), (105, 240), (258, 397), (415, 555), (573, 601)]
    for x0, x1 in spans:
        L.hline(x0, x1, 116, "deep")
        for x in range(x0, x1 + 1):
            if (x // 3) % 3 != 0:
                L.px(x, 115, "ink" if (x // 7) % 2 else "deep")
        L.hline(x0, x1, 117, "edge")
        L.rect(x0, 118, x1, 119, "slate")
        L.hline(x0, x1, 120, "ink")
        for x in range(x0 + 6, x1, 30):
            L.rect(x, 121, x + 1, 124, "br_dk")
            L.px(x, 121, "br")
    # brass service pipe with flanges
    for x0, x1 in [(105, 240), (415, 555)]:
        L.hline(x0, x1, 139, "br_hi")
        L.hline(x0, x1, 140, "br")
        L.hline(x0, x1, 141, "br_dk")
        for x in range(x0 + 10, x1, 34):
            L.rect(x, 138, x + 2, 142, "br")
            L.vline(x, 138, 142, "br_hi")
            L.vline(x + 2, 138, 142, "br_dk")
    # junction boxes and their conduits down to the deck
    for i, x0 in enumerate(JUNCTION_X):
        junction_box(L, x0, 124, "warn" if i == 0 else "glow")
        cx = x0 + 8
        L.vline(cx - 1, 147, 156, "edge")
        L.vline(cx, 147, 156, "steel")
        L.vline(cx + 1, 147, 156, "deep")
    # west patch cabinet
    L.box(46, 112, 72, 153, "teal_dk")
    L.hline(47, 71, 113, "teal")
    L.vline(47, 114, 152, "teal")
    L.vline(59, 115, 151, "ink")
    for yy in range(120, 146, 4):
        L.hline(50, 56, yy, "deep")
        L.hline(62, 69, yy, "deep")
    L.px(51, 116, "glow")
    L.px(53, 116, "glow")
    L.px(64, 116, "warn")
    L.rect(57, 130, 58, 134, "br_hi")
    L.rect(45, 150, 73, 155, "deep")
    # east switch cabinet near the maintenance door
    L.box(574, 110, 598, 154, "slate")
    L.hline(575, 597, 111, "edge")
    L.vline(575, 112, 153, "steel")
    L.rect(578, 116, 594, 128, "teal_dk")
    for i, x in enumerate(range(580, 594, 3)):
        L.rect(x, 118, x + 1, 126 - (i % 3) * 2, "glow" if i < 3 else "teal")
    L.hline(578, 594, 132, "deep")
    for yy in range(136, 150, 3):
        L.hline(579, 593, yy, "deep")
    L.rect(595, 138, 596, 142, "br_hi")
    # enamel sign beside the dish: antenna glyph
    L.box(262, 110, 284, 124, "teal_dk")
    L.hline(263, 283, 111, "teal")
    L.vline(273, 113, 121, "paper")
    L.line(268, 114, 273, 117, "paper")
    L.line(278, 114, 273, 117, "paper")
    L.hline(270, 276, 121, "paper")
    L.px(266, 113, "paper_dk")
    L.px(280, 113, "paper_dk")
    # ivy over the coping and down the wall
    for cx, cy, rx, ry, n, fl in [(12, 103, 16, 6, 18, 2), (128, 103, 18, 5, 18, 1), (300, 104, 14, 5, 12, 0),
                                  (350, 104, 12, 4, 10, 1), (452, 103, 16, 5, 14, 2), (528, 104, 14, 5, 12, 0),
                                  (620, 102, 14, 6, 14, 1)]:
        clump_mass(L, rng, cx, cy, rx, ry, n, flowers=fl)
        for k in range(rng.randint(2, 4)):
            tendril(L, rng, cx + rng.randint(-rx + 3, rx - 3), cy + 3, rng.randint(8, 26))
    for px0 in (88, 556):
        clump_mass(L, rng, px0 + 8, 98, 9, 4, 8)
        tendril(L, rng, px0 + 4, 100, 30)
        tendril(L, rng, px0 + 11, 100, 18)
    # weeds at the wall base
    for x in range(40, 600, 9):
        if rng.random() < 0.55:
            L.px(x, 155, "moss")
            L.px(x + 1, 154, "moss_hi" if rng.random() < 0.5 else "lf_mid")
            L.px(x - 1, 155, "lf")
    return L


# ----------------------------------------------------------------------------- 4 deck slabs
ROW_EDGES = [156]
for _h in (11, 12, 13, 14, 15, 16, 17, 18, 19):
    ROW_EDGES.append(ROW_EDGES[-1] + _h)  # 156 .. 291 with a perspective step


def deck_layer(rng):
    L = Layer()
    for r in range(len(ROW_EDGES) - 1):
        y0, y1 = ROW_EDGES[r], ROW_EDGES[r + 1] - 1
        h = y1 - y0 + 1
        sw = int(round(h * 2.3))
        x = -rng.randint(0, sw) if r % 2 else -sw // 2
        while x < W:
            x1 = x + sw - 1
            weights = ["dk_a", "dk_b", "dk_b", "dk_c", "dk_c"] + (["dk_c"] if r in (0, 1, 8) else ["dk_a"])
            tone = rng.choice(weights)
            if rng.random() < 0.05:
                tone = "dk_hi"
            L.rect(x, y0, x1, y1, tone)
            lit = {"dk_hi": "dk_hi", "dk_a": "dk_hi", "dk_b": "dk_a", "dk_c": "dk_b"}[tone]
            dark = {"dk_hi": "dk_a", "dk_a": "dk_b", "dk_b": "dk_c", "dk_c": "dk_sh"}[tone]
            L.hline(x, x1 - 1, y0, lit)
            L.vline(x, y0, y1 - 1, lit)
            L.hline(x, x1, y1, "dk_seam")
            L.vline(x1, y0, y1, "dk_seam")
            # grain: sparse pixels of the neighbouring tones
            for _ in range(sw * h // 9):
                L.px(rng.randint(x + 1, x1 - 1), rng.randint(y0 + 1, y1 - 1), dark if rng.random() < 0.6 else lit)
            # cracks and stains
            if rng.random() < 0.18:
                cx, cy = rng.randint(x + 3, x1 - 3), rng.randint(y0 + 2, y1 - 2)
                for _ in range(rng.randint(4, 10)):
                    L.px(cx, cy, "dk_seam")
                    cx += rng.choice((-1, 1, 1))
                    cy += rng.choice((-1, 0, 1))
                    cy = min(max(cy, y0 + 1), y1 - 1)
            if rng.random() < 0.12:
                cx, cy, rx = rng.randint(x + 4, x1 - 4), rng.randint(y0 + 3, y1 - 3), rng.randint(3, 6)
                for yy in range(cy - 2, cy + 3):
                    for xx in range(cx - rx, cx + rx + 1):
                        if (xx + yy) % 2 == 0 and ((xx - cx) / rx) ** 2 + ((yy - cy) / 2.5) ** 2 < 1:
                            L.px(xx, yy, "dk_sh")
            x += sw
    return L


# ----------------------------------------------------------------------------- 5 walkway grating + cable trench
WALK_Y0, WALK_Y1 = 244, 281
TRENCH_Y0, TRENCH_Y1 = 236, 242
TRENCH_X0 = 120


def walkway_layer(rng):
    L = Layer()
    x0, x1 = 30, 609
    cell = [["gr_hi", "gr_hi", "gr", "gr"], ["gr", "gr_hole", "gr_hole", "gr_dk"], ["gr", "gr", "gr", "gr_dk"]]
    for y in range(WALK_Y0 + 3, WALK_Y1 - 2):
        for x in range(x0, x1 + 1):
            L.a[y, x] = RGBA[cell[(y - WALK_Y0 - 3) % 3][(x - x0) % 4]]
    # foot polish down the middle of the lane
    for _ in range(420):
        x, y = rng.randint(x0, x1), rng.randint(254, 270)
        if L.name_at(x, y) == "gr_hole":
            L.px(x, y, "gr_dk")
        elif L.name_at(x, y) == "gr":
            L.px(x, y, "gr_hi")
    # a newer replacement panel and two older, rust-stained ones
    for px0, kind in [(126, "new"), (318, "old"), (510, "old")]:
        blobs = [(px0 + rng.randint(6, 40), rng.randint(WALK_Y0 + 6, WALK_Y1 - 6), rng.randint(3, 5)) for _ in range(3)] if kind == "old" else []
        for y in range(WALK_Y0 + 3, WALK_Y1 - 2):
            for x in range(px0 + 2, px0 + 47):
                n = L.name_at(x, y)
                if kind == "new" and n == "gr":
                    L.px(x, y, "gr_hi" if (x + y) % 3 == 0 else "gr")
                elif kind == "old" and any((x - bx) ** 2 + ((y - by) * 1.6) ** 2 <= r * r for bx, by, r in blobs):
                    if n == "gr":
                        L.px(x, y, "br_dk")
                    elif n == "gr_hi":
                        L.px(x, y, "rust")
    for x, y in [(70, WALK_Y1 - 3), (232, WALK_Y0 + 3), (420, WALK_Y1 - 3), (575, WALK_Y0 + 3)]:
        L.px(x, y, "moss")
        L.px(x + 1, y, "lf")
        L.px(x + 1, y - 1 if y > 260 else y + 1, "moss_hi")
    # panel seams and rivets
    for x in range(x0, x1, 48):
        L.vline(x, WALK_Y0 + 3, WALK_Y1 - 3, "gr_dk")
        L.vline(x + 1, WALK_Y0 + 3, WALK_Y1 - 3, "gr")
        for y in (WALK_Y0 + 4, WALK_Y1 - 4):
            L.px(x + 3, y, "gr_hi")
            L.px(x - 3, y, "gr_hi")
    # brass nosing, top and bottom
    L.hline(x0, x1, WALK_Y0, "gr_hi")
    L.hline(x0, x1, WALK_Y0 + 1, "br_hi")
    L.hline(x0, x1, WALK_Y0 + 2, "br_dk")
    L.hline(x0, x1, WALK_Y1 - 2, "gr_dk")
    L.hline(x0, x1, WALK_Y1 - 1, "br")
    L.hline(x0, x1, WALK_Y1, "br_dk")
    for x in range(x0 + 6, x1, 24):
        L.px(x, WALK_Y0 + 1, "br")
        L.px(x, WALK_Y1 - 1, "br_dk")
    # covered cable trench running into the maintenance door (signals go to room 2)
    L.hline(TRENCH_X0, 601, TRENCH_Y0, "dk_seam")
    L.hline(TRENCH_X0, 601, TRENCH_Y0 + 1, "edge")
    L.rect(TRENCH_X0, TRENCH_Y0 + 2, 601, TRENCH_Y1 - 1, "steel")
    L.hline(TRENCH_X0, 601, TRENCH_Y1 - 1, "slate")
    L.hline(TRENCH_X0, 601, TRENCH_Y1, "deep")
    L.vline(TRENCH_X0, TRENCH_Y0, TRENCH_Y1, "deep")
    for x in range(TRENCH_X0 + 20, 601, 22):
        L.vline(x, TRENCH_Y0 + 1, TRENCH_Y1 - 1, "deep")
        L.px(x + 1, TRENCH_Y0 + 2, "edge")
        L.hline(x - 13, x - 9, TRENCH_Y0 + 3, "slate")
        L.px(x - 13, TRENCH_Y0 + 3, "ink")
    return L


# ----------------------------------------------------------------------------- 6 deck detail
def conduit_v(L, x, y0, y1):
    L.vline(x - 1, y0, y1, "edge")
    L.vline(x, y0, y1, "steel")
    L.vline(x + 1, y0, y1, "deep")
    for y in range(y0 + 6, y1, 11):
        L.rect(x - 2, y, x + 2, y + 1, "br")
        L.hline(x - 2, x + 2, y, "br_hi")


def conduit_h(L, x0, x1, y):
    L.hline(x0, x1, y - 1, "edge")
    L.hline(x0, x1, y, "steel")
    L.hline(x0, x1, y + 1, "deep")


def anchor_plate(L, x0, y0):
    L.box(x0, y0, x0 + 12, y0 + 7, "steel", "deep")
    L.hline(x0 + 1, x0 + 11, y0 + 1, "edge")
    for bx in (x0 + 2, x0 + 10):
        L.px(bx, y0 + 5, "ink")
        L.px(bx, y0 + 4, "edge")
    L.rect(x0 + 5, y0 + 1, x0 + 7, y0 + 3, "br")
    L.px(x0 + 6, y0 + 2, "ink")


def detail_layer(rng):
    L = Layer()
    # floor conduits: wall junction box -> antenna plinth
    jx = [x + 8 for x in JUNCTION_X]
    conduit_v(L, jx[0], 157, 199)
    conduit_h(L, 190, jx[0], 199)
    conduit_v(L, jx[1], 157, 199)
    conduit_h(L, 349, jx[1], 199)
    conduit_v(L, jx[2], 157, 199)
    conduit_h(L, jx[2], 458, 199)
    # risers from each plinth down into the trench
    for x in (186, 343, 489):
        conduit_v(L, x, 211, TRENCH_Y0)
    # machine tread prints along the back strip toward antenna A (patrol route)
    for t in range(0, 80, 4):
        x = 40 + t
        y = 191 + int(4 * math.sin(t / 26.0))
        L.hline(x, x + 1, y, "dk_seam")
        L.hline(x, x + 1, y + 6, "dk_seam")
        if t % 8 == 0:
            L.px(x, y + 1, "dk_sh")
            L.px(x, y + 7, "dk_sh")
    # raised cable trough behind the dish: B's feeders run along the wall base to its junction box
    L.rect(290, 160, 361, 167, "st")
    L.hline(290, 361, 160, "st_hi")
    L.vline(290, 160, 185, "st_hi")
    L.rect(290, 168, 361, 185, "st_mid")
    L.hline(290, 361, 168, "st_dk")
    L.hline(290, 361, 185, "st_deep")
    L.vline(361, 160, 185, "st_dk")
    for x in range(292, 360, 12):
        L.rect(x, 161, x + 10, 166, "steel")
        L.hline(x, x + 10, 161, "edge")
        L.vline(x + 10, 161, 166, "deep")
        L.px(x + 5, 163, "ink")
    for x in range(296, 360, 16):
        L.vline(x, 170, 183, "st_dk")
    L.px(300, 184, "moss")
    L.px(352, 184, "moss_hi")
    L.hline(291, 362, 186, "dk_seam")
    # stone planter in the north-west corner, overgrown
    L.rect(44, 166, 98, 172, "st")
    L.hline(44, 98, 166, "st_hi")
    L.rect(44, 173, 98, 184, "st_mid")
    L.hline(44, 98, 173, "st_dk")
    L.hline(44, 98, 184, "st_deep")
    L.vline(98, 166, 184, "st_dk")
    for x in range(52, 98, 12):
        L.vline(x, 174, 183, "st_dk")
    L.hline(45, 99, 185, "dk_seam")
    clump_mass(L, rng, 71, 160, 26, 9, 34, flowers=3)
    tendril(L, rng, 50, 168, 10)
    tendril(L, rng, 90, 168, 8)
    # faded safety-zone paint around each antenna pad (dashed, worn through in places)
    for x0, x1 in [(ANTENNA_X[0] - 42, ANTENNA_X[0] + 31), (ANTENNA_X[1] - 33, ANTENNA_X[1] + 41), (ANTENNA_X[2] - 48, ANTENNA_X[2] + 64)]:
        for x in range(x0, x1 + 1):
            if (x // 3) % 2 == 0 and rng.random() < 0.85:
                L.px(x, 213, "paper_dk")
                if (x // 6) % 3 == 0:
                    L.px(x, 213, "warn_dk")
        for y in range(184, 214):
            if (y // 3) % 2 == 0 and rng.random() < 0.85:
                L.px(x0, y, "paper_dk")
                L.px(x1, y, "paper_dk")
    # guy-wire anchors for antenna C
    anchor_plate(L, 429, 200)
    anchor_plate(L, 525, 200)
    anchor_plate(L, 494, 166)
    # cable drum against the wall (axis vertical)
    L.ellipse(224, 159, 257, 168, "wood_hi")
    L.ellipse(224, 175, 257, 184, "wood")
    L.rect(227, 164, 254, 179, "ink")
    for y in range(165, 179, 2):
        L.hline(228, 253, y, "deep")
        L.px(228 + (y * 5) % 24, y, "steel")
    L.ellipse(224, 159, 257, 168, "wood_hi")
    L.ellipse(229, 161, 252, 166, "wood")
    L.ellipse(236, 162, 245, 165, "ink")
    L.hline(226, 255, 168, "wood")
    L.hline(225, 256, 184, "st_deep")
    # spare-parts crate with a coil on the lid
    L.rect(380, 160, 412, 166, "wood_hi")
    L.hline(380, 412, 160, "paper_dk")
    L.rect(380, 167, 412, 179, "wood")
    for y in (171, 175):
        L.hline(381, 411, y, "br_dk")
    L.vline(380, 160, 179, "br_dk")
    L.vline(412, 160, 179, "br_dk")
    L.rect(380, 167, 382, 169, "br")
    L.rect(410, 167, 412, 169, "br")
    L.ellipse(388, 158, 402, 164, "ink")
    L.ellipse(391, 159, 399, 163, "wood_hi")
    L.hline(390, 400, 158, "deep")
    L.hline(380, 412, 180, "st_deep")
    # moss and weeds in seams, densest at the edges of the deck
    for _ in range(520):
        x = rng.randint(38, 601)
        y = rng.choice([rng.randint(156, 166), rng.randint(282, 291), rng.randint(156, 291)])
        if TRENCH_Y0 - 1 <= y <= WALK_Y1 + 1 and x >= 30:
            continue
        L.px(x, y, rng.choice(("moss", "moss", "moss_hi", "lf")))
        if rng.random() < 0.3:
            L.px(x + 1, y, "moss")
    for x in range(42, 600, 5):
        if rng.random() < 0.5:
            L.px(x, WALK_Y0 - 1, "moss")
        if rng.random() < 0.4:
            L.px(x, WALK_Y1 + 1, rng.choice(("moss", "lf")))
    return L


# ----------------------------------------------------------------------------- 8 doors and side walls
def doors_layer(rng):
    L = Layer()
    # west pier (top coping strip and lit inner face) with the stair down to the surface
    for y0, y1 in [(94, 235), (290, 317)]:
        L.rect(0, y0, 29, y1, "st")
        for y in range(y0 + 7, y1, 11):
            L.hline(0, 29, y, "st_mid")
            L.px(rng.randint(2, 27), y + 2, "st_hi")
        L.vline(0, y0, y1, "st_mid")
        L.vline(28, y0, y1, "st_hi")
        L.rect(30, y0 + 4, 37, y1, "st_mid")
        L.vline(37, y0 + 4, y1, "st_dk")
        for y in range(y0 + 10, y1, 9):
            L.hline(30, 37, y, "st_dk")
    L.hline(0, 29, 94, "st_hi")
    clump_mass(L, rng, 14, 120, 13, 18, 22, flowers=2)
    clump_mass(L, rng, 22, 196, 10, 12, 12)
    # stair treads descending west, darker with depth
    tones = [("st", "st_dk"), ("st_mid", "st_dk"), ("st_mid", "st_deep"), ("st_dk", "st_deep"), ("st_deep", "mortar"), ("mortar", "mortar")]
    x = 37
    for tread, riser in tones:
        L.rect(x - 5, 236, x, 289, tread)
        L.vline(x - 5, 236, 289, riser)
        L.hline(x - 5, x, 236, "st_deep")
        x -= 6
    L.rect(0, 236, x, 289, "mortar")
    L.hline(0, 37, 237, "st_deep")
    L.hline(0, 37, 288, "st_deep")
    # stair handrail
    L.hline(0, 37, 283, "br_hi")
    L.hline(0, 37, 284, "br_dk")
    for xx in (4, 20, 35):
        L.vline(xx, 284, 289, "br_dk")
    # exit plate on the pier
    L.box(6, 170, 24, 182, "teal_dk")
    L.hline(7, 23, 171, "teal")
    L.vline(15, 173, 179, "paper")
    L.line(12, 176, 15, 179, "paper")
    L.line(18, 176, 15, 179, "paper")
    # east: maintenance block wall with the open door to room 2
    for y0, y1 in [(86, 231), (290, 317)]:
        L.rect(610, y0, 639, y1, "st_mid")
        L.rect(602, y0 + 4, 609, y1, "st_dk")
        L.vline(602, y0 + 4, y1, "st_mid")
        for y in range(y0 + 8, y1, 10):
            L.hline(610, 639, y, "st_dk")
            L.hline(602, 609, y, "st_deep")
            L.px(rng.randint(612, 637), y + 2, "st")
        L.vline(610, y0, y1, "st")
    L.hline(610, 639, 86, "st_hi")
    L.rect(610, 87, 639, 89, "st")
    # door: lintel, jambs, dark interior with a teal console glimmer, half-open steel leaf
    L.rect(598, 226, 639, 235, "st")
    L.hline(598, 639, 226, "st_hi")
    L.hline(598, 639, 235, "st_deep")
    L.rect(598, 236, 603, 289, "st")
    L.vline(598, 236, 289, "st_hi")
    L.vline(603, 236, 289, "st_dk")
    L.rect(604, 236, 639, 289, "ink")
    L.rect(604, 236, 639, 240, "deep")
    L.rect(624, 250, 636, 266, "deep")
    for i in range(3):
        L.rect(626 + i * 4, 254, 627 + i * 4, 256, "teal")
    L.hline(626, 635, 260, "teal_dk")
    L.rect(604, 240, 615, 289, "slate")
    L.vline(604, 240, 289, "edge")
    for y in range(246, 288, 8):
        L.hline(605, 615, y, "deep")
    L.vline(615, 240, 289, "ink")
    # threshold plate
    L.rect(596, 282, 639, 289, "steel")
    L.hline(596, 639, 282, "edge")
    for xx in range(598, 639, 6):
        L.px(xx, 285, "deep")
    # door lamp
    L.rect(593, 214, 600, 219, "slate")
    L.rect(594, 220, 599, 223, "teal")
    L.hline(594, 599, 220, "glow")
    L.px(593, 221, "ink")
    L.px(600, 221, "ink")
    clump_mass(L, rng, 626, 98, 14, 8, 14, flowers=1)
    tendril(L, rng, 616, 104, 26)
    tendril(L, rng, 632, 104, 40)
    return L


# ----------------------------------------------------------------------------- 9 front parapet
def front_layer(rng):
    L = Layer()
    L.hline(0, W - 1, 291, "dk_seam")  # deck edge under the railing
    L.rect(0, 292, W - 1, 296, "st")
    L.hline(0, W - 1, 292, "st_hi")
    L.hline(0, W - 1, 296, "st_dk")
    for x in range(17, W, 31):
        L.vline(x, 293, 295, "st_mid")
    masonry(L, rng, 0, W - 1, 297, 317, course=7, tones=("st_mid", "st_mid", "st_dk"))
    L.rect(0, 318, W - 1, H - 1, "st_deep")  # under the footer bar; keeps the plate opaque
    # railing set on the coping (the heroine always stands behind it)
    L.hline(38, 601, 286, "br_hi")
    L.hline(38, 601, 287, "br_dk")
    for x in range(44, 600, 40):
        L.rect(x, 287, x + 1, 291, "br_dk")
        L.px(x, 287, "br")
        L.px(x, 292, "st_deep")
    for x in range(40, 600, 13):
        if rng.random() < 0.45:
            L.px(x, 291, "moss")
            L.px(x + 1, 291, "lf")
    return L


# ----------------------------------------------------------------------------- 10-12 antennas
def plinth(L, x0, x1, top):
    L.rect(x0, top, x1, top + 7, "st")
    L.hline(x0, x1, top, "st_hi")
    L.vline(x0, top, BASE_Y - 1, "st_hi")
    L.rect(x0, top + 8, x1, BASE_Y - 1, "st_mid")
    L.hline(x0, x1, top + 8, "st_dk")
    L.hline(x0, x1, BASE_Y - 1, "st_deep")
    L.vline(x1, top, BASE_Y - 1, "st_dk")
    L.vline(x0, top + 8, BASE_Y - 2, "st")
    for x in range(x0 + 6, x1 - 2, 9):
        L.px(x, top + 11, "st_dk")
    L.px(x0 + 3, top + 13, "moss")
    L.px(x1 - 3, top + 14, "moss")
    L.px(x1 - 4, top + 14, "moss_hi")


def bolt(L, x, y):
    L.px(x, y, "br_hi")
    L.px(x + 1, y, "br_dk")
    L.px(x, y + 1, "br_dk")


def antenna_a():
    """Strongest but jumpy: tall lattice mast with two Yagi arrays, amber beacon, jitter readout."""
    L = Layer()
    cx = ANTENNA_X[0]
    plinth(L, cx - 22, cx + 26, 192)
    for x in (cx - 18, cx + 20):
        bolt(L, x, 195)
    # lattice legs (two visible faces), tapering 28 px -> 10 px
    top, bottom = 70, 194
    def leg_x(side, y):
        t = (bottom - y) / (bottom - top)
        return cx + side * (14 - 9 * t)
    for y in range(top, bottom + 1):
        lx, rx = int(round(leg_x(-1, y))), int(round(leg_x(1, y)))
        L.px(lx - 1, y, "ink")
        L.px(lx, y, "edge")
        L.px(lx + 1, y, "steel")
        L.px(rx - 1, y, "steel")
        L.px(rx, y, "slate")
        L.px(rx + 1, y, "ink")
    rungs = list(range(bottom - 2, top, -14))
    for i, y in enumerate(rungs):
        lx, rx = int(round(leg_x(-1, y))), int(round(leg_x(1, y)))
        L.hline(lx, rx, y, "ink")
        L.hline(lx + 1, rx - 1, y - 1, "steel")
        if i + 1 < len(rungs):
            y2 = rungs[i + 1]
            lx2, rx2 = int(round(leg_x(-1, y2))), int(round(leg_x(1, y2)))
            L.line(lx + 1, y - 1, rx2 - 1, y2 + 1, "slate")
            L.line(rx - 1, y - 1, lx2 + 1, y2 + 1, "deep")
    # feeder cable down the right leg, clamped
    for y in range(76, 192):
        x = int(round(leg_x(1, y))) + 2
        L.px(x, y, "ink" if y % 9 else "br")
    # service platform near the top
    L.rect(cx - 13, 98, cx + 13, 100, "steel")
    L.hline(cx - 13, cx + 13, 98, "edge")
    L.hline(cx - 13, cx + 13, 101, "ink")
    L.hline(cx - 13, cx + 13, 92, "slate")
    for x in (cx - 13, cx - 4, cx + 5, cx + 13):
        L.vline(x, 92, 98, "slate")
    # upper Yagi pointing east (toward the city), lower Yagi pointing west
    L.hline(cx - 6, cx + 46, 74, "ink")
    L.hline(cx - 6, cx + 46, 73, "edge")
    for i, x in enumerate(range(cx + 2, cx + 47, 7)):
        half = 7 - i
        L.vline(x, 74 - half, 74 + half, "ink")
        L.px(x, 74 - half, "edge")
    L.rect(cx - 8, 72, cx - 5, 77, "slate")
    L.hline(cx - 42, cx + 2, 110, "ink")
    L.hline(cx - 42, cx + 2, 109, "edge")
    for i, x in enumerate(range(cx - 6, cx - 43, -7)):
        half = 5 - i // 2
        L.vline(x, 110 - half, 110 + half, "ink")
        L.px(x, 110 - half, "edge")
    # amber obstruction beacon on top
    L.vline(cx, 64, 69, "ink")
    L.rect(cx - 2, 62, cx + 1, 64, "warn")
    L.px(cx - 2, 62, "br_hi")
    # interference sparks off the upper array tip
    for x, y in [(cx + 50, 70), (cx + 52, 72), (cx + 49, 78), (cx + 53, 77), (cx + 55, 74)]:
        L.px(x, y, "warn")
    L.px(cx + 51, 75, "br_hi")
    # sensor-band warning placard on the tower (a patrol machine glyph)
    L.poly([(cx, 140), (cx - 6, 151), (cx + 6, 151)], "ink")
    L.poly([(cx, 142), (cx - 4, 150), (cx + 4, 150)], "warn")
    L.rect(cx - 1, 146, cx + 1, 147, "ink")
    L.px(cx, 145, "ink")
    # jitter readout cabinet bolted to the plinth's west side
    x0, y0 = cx - 37, 166
    L.box(x0, y0, x0 + 16, BASE_Y - 1, "slate")
    L.hline(x0 + 1, x0 + 15, y0 + 1, "edge")
    L.vline(x0 + 1, y0 + 2, BASE_Y - 2, "steel")
    L.rect(x0 + 3, y0 + 4, x0 + 13, y0 + 16, "teal_dk")
    L.hline(x0 + 4, x0 + 12, y0 + 12, "glow")
    for x, yt in [(x0 + 5, y0 + 6), (x0 + 8, y0 + 8), (x0 + 11, y0 + 5)]:
        L.vline(x, yt, y0 + 12, "warn")
        L.px(x + 1, y0 + 11, "warn_dk")
    for i in range(4):
        L.rect(x0 + 3 + i * 3, y0 + 26 - i * 2, x0 + 4 + i * 3, y0 + 27, "glow")
    L.hline(x0 + 3, x0 + 13, y0 + 30, "deep")
    L.hline(x0 + 3, x0 + 13, y0 + 33, "deep")
    L.rect(x0 + 13, y0 + 20, x0 + 14, y0 + 22, "br_hi")
    L.hline(x0 + 17, cx - 16, y0 + 18, "ink")
    return L


def antenna_b():
    """Weaker but steady: a big tilted dish on a pedestal, smooth sine, intact cable to a ground stake."""
    L = Layer()
    cx = ANTENNA_X[1]
    plinth(L, cx - 28, cx + 28, 192)
    for x in (cx - 24, cx + 22):
        bolt(L, x, 195)
    # turntable ring
    L.ellipse(cx - 16, 184, cx + 16, 195, "ink")
    L.ellipse(cx - 15, 185, cx + 15, 193, "steel")
    L.ellipse(cx - 12, 186, cx + 12, 191, "slate")
    L.hline(cx - 13, cx - 2, 185, "edge")
    # pedestal column
    L.rect(cx - 6, 138, cx + 6, 188, "steel")
    L.vline(cx - 6, 138, 188, "ink")
    L.vline(cx + 6, 138, 188, "ink")
    L.vline(cx - 5, 138, 188, "edge")
    L.rect(cx + 3, 138, cx + 5, 188, "slate")
    for y in (150, 172):
        L.rect(cx - 7, y, cx + 7, y + 2, "br")
        L.hline(cx - 7, cx + 7, y, "br_hi")
        L.hline(cx - 7, cx + 7, y + 2, "br_dk")
    # elevation yoke
    L.rect(cx - 10, 128, cx + 10, 138, "slate")
    L.hline(cx - 10, cx + 10, 128, "edge")
    L.rect(cx - 10, 128, cx - 10, 138, "ink")
    L.rect(cx + 10, 128, cx + 10, 138, "ink")
    L.rect(cx - 2, 130, cx + 2, 134, "deep")
    # dish: rotated ellipse facing up-left, concave interior shading, radial ribs
    dcx, dcy, a, b, rot = cx - 6, 108, 37, 25, math.radians(-28)

    def ell(scale, ox=0.0, oy=0.0):
        pts = []
        for k in range(72):
            t = k / 72 * math.tau
            x, y = a * scale * math.cos(t), b * scale * math.sin(t)
            pts.append((dcx + ox + x * math.cos(rot) - y * math.sin(rot), dcy + oy + x * math.sin(rot) + y * math.cos(rot)))
        return pts
    # back of the reflector: a thick dark crescent to the lower right, with a stiffening ring
    L.poly(ell(1.0, 4, 4), "ink")
    L.poly(ell(1.0, 3, 3), "deep")
    L.poly(ell(0.98, 3, 3), "slate")
    L.poly(ell(1.0, 1, 1), "deep")
    # rim and concave face: dark under the sun-side (upper-left) rim, brightening toward the lit lower-right wall
    L.poly(ell(1.0), "ink")
    L.poly(ell(0.95), "deep")
    L.poly(ell(0.9, 2, 1.5), "slate")
    L.poly(ell(0.8, 4, 3), "steel")
    L.poly(ell(0.6, 7, 5), "edge")
    L.poly(ell(0.3, 11, 8), "frost_mid")
    for k in (9, 45):
        t = k / 72 * math.tau
        x, y = a * 0.93 * math.cos(t), b * 0.93 * math.sin(t)
        L.line(dcx + 2, dcy + 2, dcx + x * math.cos(rot) - y * math.sin(rot), dcy + x * math.sin(rot) + y * math.cos(rot), "slate")
    L.poly(ell(0.12, 2, 2), "slate")
    L.px(dcx + 2, dcy + 2, "ink")

    def arc(scale, k0, k1, c):
        pts = ell(scale)
        for k in range(k0, k1):
            p0, p1 = pts[k % 72], pts[(k + 1) % 72]
            L.line(p0[0], p0[1], p1[0], p1[1], c)
    arc(0.985, 26, 58, "frost")
    arc(0.985, 60, 84, "edge")
    # feed struts and horn: the feed hangs in front of the dish toward the upper left (toward the city)
    fx, fy = dcx - 12, dcy - 9
    for k in (4, 30, 56):
        rx, ry = ell(0.93)[k]
        L.line(rx + 1, ry + 1, fx + 1, fy + 1, "ink")
        L.line(rx, ry, fx, fy, "edge")
    L.box(fx - 4, fy - 4, fx + 3, fy + 3, "slate")
    L.hline(fx - 3, fx + 2, fy - 3, "edge")
    L.rect(fx - 2, fy - 1, fx + 1, fy + 1, "br")
    L.px(fx - 2, fy - 1, "br_hi")
    # status box on the pedestal: smooth sine, two of four bars
    x0, y0 = cx + 8, 150
    L.box(x0, y0, x0 + 20, y0 + 20, "slate")
    L.hline(x0 + 1, x0 + 19, y0 + 1, "edge")
    L.rect(x0 + 3, y0 + 3, x0 + 17, y0 + 10, "teal_dk")
    for i in range(15):
        L.px(x0 + 3 + i, y0 + 6 + int(round(2 * math.sin(i / 2.4))), "glow")
    for i in range(4):
        L.rect(x0 + 4 + i * 4, y0 + 17 - i, x0 + 5 + i * 4, y0 + 17, "glow" if i < 2 else "deep")
    # intact cable: box -> pedestal -> plinth side -> brass ground stake, with a service tag
    L.vline(x0 + 10, y0 + 21, 191, "ink")
    L.vline(x0 + 11, y0 + 21, 191, "deep")
    L.px(x0 + 10, 180, "br_hi")
    L.hline(cx + 29, cx + 33, 203, "ink")
    L.hline(cx + 29, cx + 33, 204, "deep")
    sx = cx + 34
    L.rect(sx, 190, sx + 3, BASE_Y - 1, "br_dk")
    L.vline(sx, 190, BASE_Y - 1, "br")
    L.rect(sx - 1, 188, sx + 4, 190, "br")
    L.hline(sx - 1, sx + 4, 188, "br_hi")
    L.rect(sx - 1, 202, sx + 4, 204, "br_hi")
    L.line(x0 + 11, 176, x0 + 15, 179, "ink")
    L.box(x0 + 14, 179, x0 + 19, 185, "paper", "ink")
    L.hline(x0 + 15, x0 + 18, 181, "teal_dk")
    L.px(x0 + 16, 183, "teal_dk")
    return L


def antenna_c():
    """Wind dropouts: weathered guyed mast, bright new radome, wind ribbon, frosted battery, old head."""
    L = Layer()
    cx = ANTENNA_X[2]
    plinth(L, cx - 16, cx + 16, 194)
    bolt(L, cx - 12, 197)
    bolt(L, cx + 11, 197)
    # guy wires (drawn first so the mast sits over their collar)
    collar = (cx, 112)
    for ax, ay in [(435, 202), (531, 202), (500, 168)]:
        L.line(collar[0], collar[1], ax, ay, "ink")
        steps = int(max(abs(ax - collar[0]), abs(ay - collar[1])))
        for s in range(4, steps, 5):
            L.px(collar[0] + (ax - collar[0]) * s / steps + 1, collar[1] + (ay - collar[1]) * s / steps, "edge")
        tx, ty = ax + (collar[0] - ax) * 0.12, ay + (collar[1] - ay) * 0.12
        L.rect(tx - 1, ty - 3, tx + 1, ty + 1, "br")
        L.px(tx - 1, ty - 3, "br_hi")
    # weathered mast: 6 px, faded orange/white obstruction bands, rust flecks
    rng = random.Random(77)
    for y in range(84, 196):
        band = ((y - 84) // 14) % 2 == 0
        lit, mid, dark = ("warn", "warn_dk", "rust") if band else ("paper", "paper_dk", "st_dk")
        L.px(cx - 3, y, "ink")
        L.px(cx - 2, y, lit)
        L.px(cx - 1, y, mid)
        L.px(cx, y, mid)
        L.px(cx + 1, y, dark)
        L.px(cx + 2, y, "ink")
        if rng.random() < 0.22:
            L.px(cx + rng.choice((-1, 0, 1)), y, rng.choice(("rust", "br_dk", "st_mid")))
    for y in (112, 150):
        L.rect(cx - 5, y - 1, cx + 4, y + 2, "br_dk")
        L.hline(cx - 5, cx + 4, y - 1, "br")
        L.px(cx - 5, y, "ink")
        L.px(cx + 4, y, "ink")
    # step bolts up the west side
    for y in range(120, 192, 8):
        L.px(cx - 4, y, "edge")
        L.px(cx - 4, y + 1, "ink")
    # crossarm with two vertical dipole whips
    L.hline(cx - 16, cx + 15, 92, "ink")
    L.hline(cx - 16, cx + 15, 91, "edge")
    for wx in (cx - 14, cx + 13):
        L.vline(wx, 80, 104, "ink")
        L.vline(wx - 1, 81, 103, "edge")
        L.rect(wx - 1, 91, wx + 1, 93, "slate")
    # new radome capsule (clearly brighter than the weathered mast) with its whip
    L.vline(cx, 59, 63, "ink")
    L.box(cx - 6, 63, cx + 5, 84, "paper")
    L.vline(cx - 5, 64, 83, "frost")
    L.vline(cx + 4, 64, 83, "paper_dk")
    L.hline(cx - 5, cx + 4, 64, "frost")
    L.rect(cx - 5, 78, cx + 4, 79, "br")
    L.hline(cx - 5, cx + 4, 78, "br_hi")
    L.px(cx - 4, 66, "frost")
    # wind ribbon streaming east from the upper collar
    L.poly([(cx + 3, 98), (cx + 12, 96), (cx + 20, 100), (cx + 26, 97), (cx + 22, 102), (cx + 13, 103), (cx + 3, 102)], "warn")
    L.line(cx + 5, 102, cx + 14, 103, "warn_dk")
    L.line(cx + 16, 101, cx + 22, 102, "warn_dk")
    L.rect(cx + 2, 97, cx + 3, 103, "ink")
    # clamped readout: trace, gap, dashes (dropouts)
    x0, y0 = cx + 4, 128
    L.box(x0, y0, x0 + 18, y0 + 13, "slate")
    L.hline(x0 + 1, x0 + 17, y0 + 1, "edge")
    L.rect(x0 + 2, y0 + 3, x0 + 16, y0 + 10, "teal_dk")
    for i, dy in enumerate((0, -2, 0, -1)):
        L.px(x0 + 3 + i, y0 + 7 + dy, "glow")
    for x in (x0 + 9, x0 + 12, x0 + 15):
        L.px(x, y0 + 8, "teal")
    L.rect(x0 - 1, y0 + 5, x0, y0 + 8, "br_dk")
    # backup battery on the plinth's east side: frost crust, one amber cell of four
    bx0, by0 = cx + 20, 180
    L.rect(bx0, by0, bx0 + 24, by0 + 6, "steel")
    L.hline(bx0, bx0 + 24, by0, "edge")
    L.box(bx0, by0 + 6, bx0 + 24, BASE_Y - 1, "slate")
    L.vline(bx0, by0, BASE_Y - 1, "ink")
    L.vline(bx0 + 24, by0, BASE_Y - 1, "ink")
    for tx in (bx0 + 4, bx0 + 17):
        L.rect(tx, by0 - 3, tx + 3, by0, "br_dk")
        L.hline(tx, tx + 3, by0 - 3, "frost")
    L.hline(bx0 + 1, bx0 + 23, by0 + 1, "frost")
    for x in range(bx0 + 1, bx0 + 24, 3):
        L.px(x, by0 + 2, "frost_mid")
    for x, d in [(bx0 + 3, 3), (bx0 + 9, 2), (bx0 + 15, 4), (bx0 + 21, 2)]:
        L.vline(x, by0 + 7, by0 + 6 + d, "frost_mid")
        L.px(x, by0 + 7, "frost")
    for i in range(4):
        L.rect(bx0 + 4 + i * 5, by0 + 16, bx0 + 6 + i * 5, by0 + 19, "warn" if i == 0 else "deep")
    L.hline(bx0 + 3, bx0 + 21, by0 + 23, "deep")
    L.hline(cx + 3, bx0 - 1, 192, "ink")
    # the swapped-out head lying on the deck by the west anchor, cracked and dull
    hx, hy = cx - 33, 198
    L.box(hx, hy, hx + 12, hy + 7, "st_mid")
    L.hline(hx + 1, hx + 11, hy + 1, "paper_dk")
    L.line(hx + 5, hy + 2, hx + 8, hy + 6, "ink")
    L.rect(hx + 8, hy + 1, hx + 9, hy + 6, "br_dk")
    L.hline(hx + 13, hx + 15, hy + 4, "ink")
    return L


# ----------------------------------------------------------------------------- 7 cast shadows
SHADE = {}


def shade_of(name):
    if name in SHADE:
        return SHADE[name]
    explicit = {"dk_hi": "dk_b", "dk_a": "dk_sh", "dk_b": "dk_sh", "dk_c": "dk_sh2", "dk_sh": "dk_sh2", "dk_sh2": "dk_seam",
                "dk_seam": "st_deep", "gr_hi": "gr", "gr": "gr_dk", "gr_dk": "gr_hole", "gr_hole": "gr_hole",
                "edge": "steel", "steel": "slate", "slate": "deep", "deep": "ink", "ink": "ink", "br_hi": "br", "br": "br_dk",
                "br_dk": "wood", "moss_hi": "moss", "moss": "lf", "lf": "lf_dk", "lf_mid": "lf", "lf_hi": "lf_mid", "lf_dk": "lf_dk",
                "st_hi": "st", "st": "st_mid", "st_mid": "st_dk", "st_dk": "st_deep", "st_deep": "mortar", "mortar": "mortar",
                "wood_hi": "wood", "wood": "br_dk", "paper_dk": "st_dk"}
    SHADE[name] = explicit.get(name, name)
    return SHADE[name]


def shadow_layer(under, antennas, extra_casters):
    """Darken deck-level pixels under projected antenna silhouettes (sun high in the north-west)."""
    L = Layer()
    mask = np.zeros((H, W), bool)
    for lay in antennas:
        ys, xs = np.nonzero(lay.a[..., 3] == 255)
        for x, y in zip(xs, ys):
            h = BASE_Y - 1 - y
            if h < 0:
                continue
            fx, fy = x + 0.62 * h, BASE_Y + 0.2 * h
            ix, iy = int(round(fx)), int(round(fy))
            for dx in (0, 1):
                if 0 <= ix + dx < W and 0 <= iy < H:
                    mask[iy, ix + dx] = True
    for x0, y0, x1, y1 in extra_casters:
        mask[y0:y1 + 1, x0:x1 + 1] = True
    mask[:157] = False
    mask[WALK_Y1 + 1:] = False
    mask[:, :38] = False
    mask[:, 598:] = False
    ys, xs = np.nonzero(mask)
    for x, y in zip(xs, ys):
        if under[y, x, 3] == 255:
            name = NAME_OF[tuple(int(v) for v in under[y, x, :3])]
            L.a[y, x] = RGBA[shade_of(name)]
    return L


# ----------------------------------------------------------------------------- 13 foreground
def foreground_layer(rng):
    """Corner shrubs at the stair and the maintenance door (the heroine's feet tuck behind them there),
    plus low tufts along the parapet coping. Nothing covers the lane, the markers or the antennas."""
    L = Layer()
    clump_mass(L, rng, 8, 292, 20, 25, 56, flowers=3)
    clump_mass(L, rng, 632, 292, 20, 25, 56, flowers=2)
    for x, n in [(160, 8), (300, 6), (470, 7)]:
        clump_mass(L, rng, x, 299, 10, 4, n)
    L.a[:291, 24:616] = 0
    L.a[:268] = 0
    return L


# ----------------------------------------------------------------------------- build
def build_scene():
    rng = random.Random(20261017)
    sky = sky_layer(rng)
    parapet = parapet_layer(rng)
    kit = wall_kit_layer(rng)
    deck = deck_layer(rng)
    walk = walkway_layer(rng)
    detail = detail_layer(rng)
    antennas = [antenna_a(), antenna_b(), antenna_c()]
    under = composite([sky, parapet, kit, deck, walk, detail])
    contact = [(ANTENNA_X[0] - 37, BASE_Y, ANTENNA_X[0] + 28, BASE_Y + 1), (ANTENNA_X[1] - 28, BASE_Y, ANTENNA_X[1] + 38, BASE_Y + 1),
               (ANTENNA_X[2] - 33, BASE_Y, ANTENNA_X[2] + 45, BASE_Y + 1), (224, 185, 258, 186), (380, 181, 413, 182),
               (38, 157, 597, 160), (38, 157, 45, 243), (590, 157, 597, 243)]
    shadows = shadow_layer(under, antennas, contact)
    doors = doors_layer(rng)
    front = front_layer(rng)
    fg = foreground_layer(random.Random(3141))
    layers = [sky, parapet, kit, deck, walk, detail, shadows, doors, front] + antennas + [fg]
    return layers


def sprite_box(index):
    x = ANTENNA_X[index]
    return x - SPRITE_W // 2, SPRITE_TOP, x + SPRITE_W // 2, BASE_Y  # x0, y0, x1 (excl), y1 (excl)


def to_img(arr):
    return Image.fromarray(arr, "RGBA")


def png_bytes(img):
    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=False)
    return buf.getvalue()


DT = (2026, 10, 17, 18, 48, 16)


def ora_bytes(name, names, imgs, flat):
    w, h = flat.size
    root = ET.Element("image", {"w": str(w), "h": str(h), "name": name, "version": "0.0.3"})
    stack = ET.SubElement(root, "stack")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype", DT), "image/openraster", compress_type=zipfile.ZIP_STORED)
        z.writestr(zipfile.ZipInfo("mergedimage.png", DT), png_bytes(flat), compress_type=zipfile.ZIP_DEFLATED)
        for i, (ln, img) in reversed(list(enumerate(zip(names, imgs)))):  # ORA lists the top layer first
            src = f"data/layer{i:02d}.png"
            z.writestr(zipfile.ZipInfo(src, DT), png_bytes(img), compress_type=zipfile.ZIP_DEFLATED)
            ET.SubElement(stack, "layer", {"name": ln, "src": src, "x": "0", "y": "0", "opacity": "1.0",
                                           "visibility": "visible", "composite-op": "svg:src-over"})
        z.writestr(zipfile.ZipInfo("stack.xml", DT), ET.tostring(root, encoding="utf-8", xml_declaration=True),
                   compress_type=zipfile.ZIP_DEFLATED)
    return buf.getvalue()


def pxo_bytes(export_name, names, imgs, flat):
    w, h = flat.size
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": False, "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": True} for n in names]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0} for _ in names],
                    "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(export_name),
                      "frame_current_tag": "0", "include_tag_in_filename": "false", "interpolation": "0",
                      "lines_count": "1", "new_dir_for_each_frame_tag": "false", "number_of_digits": "4",
                      "number_of_frames": "1", "orientation": "0", "repeat_count": "0", "resize": "100",
                      "save_quality": "0.75", "separator_character": "\"_\"",
                      "sheet_layers_as_separate_files": "false", "split_layers": "false"}
    palette = [{"name": "yonkers-antenna-room1-v02", "colors": [{"color": c, "index": i} for i, c in enumerate(HEX.values())]}]
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": len(names) - 1,
            "export_profile": export_profile, "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json,
            "license": "", "metadata": {"declared_palette": palette}, "next_keyframe_id": 0, "palettes": [],
            "pixelorama_version": PIXELORAMA_VERSION, "project_current_palette_name": "", "pxo_version": 7,
            "reference_images": [], "size_x": w, "size_y": h, "symmetry_points": [w - 1.0, h - 1.0], "tags": [],
            "tile_mode_x_basis_x": w, "tile_mode_x_basis_y": 0, "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": h,
            "tilesets": [], "user_data": "", "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def add(name, payload):
            z.writestr(zipfile.ZipInfo(name, DT), payload, zipfile.ZIP_DEFLATED)
        add("data.json", json.dumps(data, separators=(",", ":")))
        add("mimetype", "application/x-pixelorama")
        add("preview.png", png_bytes(flat))
        add("image_data/frames/1/", b"")
        for i, img in enumerate(imgs, start=1):
            add(f"image_data/frames/1/layer_{i}", img.tobytes())
            add(f"image_data/frames/1/indices_layer_{i}", b"\x00")
    return buf.getvalue()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rel(p):
    return str(p.relative_to(ROOT)).replace("\\", "/")


ANTENNA_SLUGS = ("antenna-a-lattice-yagi", "antenna-b-dish", "antenna-c-guyed-whip")
ANTENNA_READS = [
    "天线 A / Antenna A (scifi.outskirts:0): tallest silhouette, open lattice mast with two Yagi arrays and an amber beacon; "
    "jumpy amber spikes over a full four-bar readout, sparks off the array tip, a sensor-band placard with a machine glyph and "
    "patrol tread prints on the deck behind it = strongest but unreliable",
    "天线 B / Antenna B (scifi.outskirts:1): wide parabolic dish on a turntable pedestal, smooth teal sine with two of four bars, "
    "an unbroken cable from the status box to a brass ground stake with a checked service tag = weaker but steady and intact",
    "天线 C / Antenna C (scifi.outskirts:2): thin weathered (rusted) guyed mast under a bright new radome, amber wind ribbon, "
    "dropout readout, frost-crusted backup battery with one amber cell, the dull cracked old head on the deck = new head did not "
    "fix the wind/cold dropouts",
]


def runtime_names():
    return {
        "plate": RUNTIME_ENV / f"{PREFIX}_corridor-plate_unapproved-v02_{STAMP}.png",
        "foreground": RUNTIME_ENV / f"{PREFIX}_foreground-occluder_unapproved-v02_{STAMP}.png",
        "antennas": [RUNTIME_PROPS / f"{PREFIX}_{slug}_unapproved-v02_{STAMP}.png" for slug in ANTENNA_SLUGS],
    }


def build():
    layers = build_scene()
    arrs = [lay.a for lay in layers]
    for a in arrs:
        assert set(np.unique(a[..., 3]).tolist()) <= {0, 255}, "binary alpha only"
    plate = composite(layers[:9])
    assert (plate[..., 3] == 255).all(), "plate must be opaque"
    for i in range(3):
        x0, y0, x1, y1 = sprite_box(i)
        alpha = layers[9 + i].a[..., 3]
        inside = np.zeros_like(alpha, bool)
        inside[y0:y1, x0:x1] = True
        assert not (alpha[~inside] > 0).any(), f"antenna {i} leaves its sprite box"
    fg = layers[12].a
    flat = composite(layers)
    used = {tuple(int(v) for v in c) for c in flat[..., :3].reshape(-1, 3)} | {tuple(int(v) for v in c) for a in arrs for c in a[a[..., 3] == 255][:, :3]}
    assert used <= set(RGB.values()), "every pixel comes from the declared palette"

    OUT.mkdir(parents=True, exist_ok=True)
    RUNTIME_ENV.mkdir(parents=True, exist_ok=True)
    RUNTIME_PROPS.mkdir(parents=True, exist_ok=True)
    names = runtime_names()
    imgs = [to_img(a) for a in arrs]
    flat_img = to_img(flat)
    stem = f"{PREFIX}_corridor-scene-layers_unapproved-v02_{STAMP}"
    files = {"ora": ora_bytes(stem, SCENE_LAYERS, imgs, flat_img), "pxo": pxo_bytes("yonkers-room1-v02", SCENE_LAYERS, imgs, flat_img),
             "png": png_bytes(flat_img)}
    for ext, data in files.items():
        (OUT / f"{stem}.{ext}").write_bytes(data)
    runtime = {"plate": png_bytes(to_img(plate)), "foreground": png_bytes(to_img(fg))}
    names["plate"].write_bytes(runtime["plate"])
    names["foreground"].write_bytes(runtime["foreground"])
    antenna_items = []
    for i, path in enumerate(names["antennas"]):
        x0, y0, x1, y1 = sprite_box(i)
        crop = png_bytes(to_img(np.ascontiguousarray(layers[9 + i].a[y0:y1, x0:x1])))
        path.write_bytes(crop)
        antenna_items.append({"layer": ANTENNA_LAYERS[i], "clue": f"scifi.outskirts:{i}", "reads_as": ANTENNA_READS[i],
                              "crop_from_layer_xywh": [x0, y0, SPRITE_W, SPRITE_H], "anchor": [ANTENNA_X[i], BASE_Y],
                              "runtime_png": {"file": rel(path), "sha256": sha(crop), "hash_algorithm": "sha256-bytes"}})
    manifest = {
        "project": "Worlds Between (rpg-2-star-ocean-the-second)",
        "scene": "Yonkers outskirts survey annex room 1 (天线走廊 / Antenna Walkway), scifi.outskirts room 1",
        "version": "v02 scene-quality candidate (replaces the v01 m8-concept plate + 64x64 fixtures in this room only)",
        "status": "UNAPPROVED. Codex and the creator have not inspected it. Scene counters unchanged (3/12); no Game Bible, ledger or Git index change.",
        "authorship": "Native pixel art from hand-placed primitives and seeded pixel texture in the source tool, by Claude (Claude Code, "
                      "signed-in Claude Max firstParty, no API key). No generated, traced, resampled or palette-reduced image anywhere; "
                      "every pixel is one of the declared palette colours; binary alpha.",
        "style_reference": "accepted interiors (NYC public facilities rooms 1/2, Yonkers maintenance room 2): warm masonry, ivy, worn "
                           "metal, brass, restrained teal technology; teal/brass/ink/slate kit colours are the accepted room 2 fixture palette",
        "canvas": [W, H], "palette_size": len(HEX), "palette": HEX,
        "layers_bottom_to_top": SCENE_LAYERS,
        "editable_sources": {ext: {"file": rel(OUT / f"{stem}.{ext}"), "sha256": sha(d), "hash_algorithm": "sha256-bytes"} for ext, d in files.items()},
        "runtime_exports": {
            "plate": {"from_layers": PLATE_LAYERS, "rule": "alpha-over composite of layers 1-9, fully opaque, drawn at (0,0) 640x360 with nearest filtering",
                      "file": rel(names["plate"]), "sha256": sha(runtime["plate"]), "hash_algorithm": "sha256-bytes"},
            "antennas": antenna_items,
            "foreground": {"from_layers": ["foreground-occluder"], "rule": "layer 13 as is, drawn at (0,0) above the heroine (z_index 1)",
                           "file": rel(names["foreground"]), "sha256": sha(runtime["foreground"]), "hash_algorithm": "sha256-bytes"},
        },
        "runtime_layout": {
            "antenna_sprite": "Sprite2D, centered=false, position=(clue x, %d), offset=(-64, -%d); host y_sort_enabled so the heroine (feet "
                              "origin) passes behind an antenna when her feet are above y %d" % (BASE_Y, SPRITE_H, BASE_Y),
            "clue_markers": "drawn on the floor in front of each plinth at (163,228) (320,228) (477,228); captions to the right of each marker",
            "interaction": "unchanged CLUE_POSITIONS radius 45 plus 42 px around each floor marker",
            "collision": "13 feet-point Rect2 blockers in survey_annex.gd (back wall to y 166, west pier and east wall with the stair and "
                         "door openings at y 236-281, front parapet from y 281, planter, cable drum, crate, the three plinths, C's three "
                         "guy anchors, and the raised cable trough behind dish B so the heroine is never fully hidden there); axis slide; "
                         "a start inside a blocker can walk out",
            "header": "English only, this room only: Save moves to x 398 and the back button widens to 125 px at x 503 so "
                      "'Return outside' fits (right edge 628)",
        },
        "source_tool": rel(Path(__file__)),
    }
    path = OUT / f"{PREFIX}_corridor-scene-manifest_unapproved-v02_{STAMP}.json"
    path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(path)
    print("palette", len(HEX), "used", len(used))
    return manifest


if __name__ == "__main__":
    build()
