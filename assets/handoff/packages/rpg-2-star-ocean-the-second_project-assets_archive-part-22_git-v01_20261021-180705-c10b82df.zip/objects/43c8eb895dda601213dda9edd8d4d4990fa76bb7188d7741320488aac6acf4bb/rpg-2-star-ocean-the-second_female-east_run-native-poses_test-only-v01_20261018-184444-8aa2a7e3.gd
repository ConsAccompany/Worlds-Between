extends SceneTree
# First-prototype native poses: real advance() steady states (torso cadence included), not an approximation.
const MODEL_PATH := "res://../tools/rpg-2-star-ocean-the-second_female-east_run-stop-source_unapproved-v01_20261018-184444-8aa2a7e3.gd"
const MODEL := preload(MODEL_PATH)
const TAG := "v01_20261018-184444-8aa2a7e3"
func _initialize() -> void:call_deferred("_run")
func _bounds(image: Image) -> Array:
	var r:=image.get_used_rect()
	return [r.position.x,r.position.y,r.end.x,r.end.y]
func _run() -> void:
	var args:=OS.get_cmdline_user_args()
	var folder:=args[0]
	var all_folder:=args[1] if args.size()>1 else ""
	DirAccess.make_dir_recursive_absolute(folder)
	var model: RefCounted=MODEL.new()
	var x:=0.
	var poses:={}
	for i in 400:
		x+=.5
		var state: Dictionary=model.advance(1./280.,x,1.)
		if i>=256:poses[int(state.q)]=state
	var report:={"task":"content.char.protagonist-female.walk-east","stage":"first prototype, before final validation","cell":[80,112],"pivot":[40,104],"scale":.5,"cadence":4.375,"strideSourcePixels":128,"contactSourcePixels":38,"bakeTicks":"400 advance() ticks at 1/280s, +0.5 world px each; states kept after tick256","poses":[],"allPhaseBounds":{},"modelSha256":FileAccess.get_sha256(MODEL_PATH),"artApproved":false,"motionApproved":false}
	var missing:=[]
	for q in 128:
		if not poses.has(q):missing.append(q);continue
		var image: Image=model.render_pose(poses[q]).full
		report.allPhaseBounds[str(q)]=_bounds(image)
		if all_folder!="":
			DirAccess.make_dir_recursive_absolute(all_folder)
			image.save_png(all_folder.path_join("q%03d.png"%q))
	report["missingPhases"]=missing
	for pick in [["contact",0],["passing",19],["flight",51]]:
		var state: Dictionary=poses[pick[1]]
		var image: Image=model.render_pose(state).full
		var name:="rpg-2-star-ocean-the-second_female-east-run_%s-q%03d_native_%s.png"%[pick[0],pick[1],TAG]
		image.save_png(folder.path_join(name))
		var s:=state.duplicate(true)
		s.body=[s.body.x,s.body.y]
		report.poses.append({"pose":pick[0],"q":pick[1],"file":name,"sha256":FileAccess.get_sha256(folder.path_join(name)),"bounds":_bounds(image),"state":s})
	var f:=FileAccess.open(folder.path_join("rpg-2-star-ocean-the-second_female-east-run_native-poses-report_%s.json"%TAG),FileAccess.WRITE)
	f.store_string(JSON.stringify(report,"  ")+"\n")
	f.close()
	print("EAST NATIVE POSES missing=",missing.size()," saved=",report.poses.size())
	quit(1 if missing.size()>0 else 0)
