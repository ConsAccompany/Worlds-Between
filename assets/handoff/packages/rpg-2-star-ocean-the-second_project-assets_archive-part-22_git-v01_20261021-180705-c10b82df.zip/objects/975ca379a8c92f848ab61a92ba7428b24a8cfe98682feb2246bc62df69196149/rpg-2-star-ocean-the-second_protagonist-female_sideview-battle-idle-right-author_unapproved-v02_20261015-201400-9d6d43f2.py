"""UNAPPROVED, test-only candidate v02: female protagonist side-view battle idle, facing right, ONE static frame.

Refines the v01 pilot (tools/...sideview-battle-idle-right-author_unapproved-v01_20261015-194937-03b8a0ab.py, unchanged)
for the owner-approved battle DISPLAY PROPORTION only: Godot node scale 0.65 in the 640x360 canvas (1.3 screen px per
texel at 1280x720). The 112x112 cell, the pin and the 94-texel crown-to-sole height are kept, so the on-screen size
matches the 0.65 screenshot the owner approved. Nothing else is approved.

Hand-authored pixel art. Every texel is typed in the ASCII maps below; the only helpers are run-length shorthand (rl),
the straight 2:1 sword blade (the same texels Pixelorama's line tool would place) and the coat skirt rows, which are
built from per-row edge tables. There is no resampling, filtering, quantizing, dithering, gradient, AI generation or
upscaling anywhere. Every palette key maps to a colour taken verbatim from the owner-approved v8 south static frame,
so the candidate palette is a subset of v8's 32 colours. Alpha is binary.

Read-only inputs (hash-gated, never written): the v8 PNG and its editable .pxo, and the v01 candidate PNG.
No runtime script, scene, Game Bible, tracker, counter or acceptance record is touched.

Modes
  preview <dir>   write separate inspection PNGs (one picture per file, no sheets) into <dir> outside the repo.
  build           write the v02 PNG, .pxo (pxo_version 7), .ora and manifest into
                  game/assets/characters/combat-sideview-pilots/. Never overwrites a different file.
  check [--no-pixelorama]
                  technical gates on the built files; unless --no-pixelorama, also Pixelorama 1.2.3 headless flat and
                  --split-layers exports of temp copies of the .pxo and .ora, run with APPDATA redirected to a fresh temp
                  dir so the real %APPDATA%\\pixelorama is never touched. Prints a JSON report; writes nothing in the repo.

Run with the real Python in isolated mode:  python -I -B <this file> preview|build|check
"""
import argparse, hashlib, io, json, os, shutil, subprocess, sys, tempfile, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
VER = "unapproved-v02"
STAMP = "20261015-201400"
RUN_ID = "9d6d43f2"
W, H = 112, 112
PIN = (52, 104)                 # ground contact, first transparent row under the soles (same as v01)
CROWN_ROW = 10                  # crown-to-sole rows 10..103 = 94 texels, same as v01 (approved 0.65 proportion)
DISPLAY_SCALE = 0.65
OUT_DIR_REL = "game/assets/characters/combat-sideview-pilots"
V8_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
          "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
V8_SHA256 = "ccf9d2a293e7f1b9c706b4d2f1bf9c00b3c7714ec4e9b8bddf023e166f68b6fd"
V8_PXO_SHA256 = "cafa4998b107ae4b884cc877b80bbc695df267f37e09fb6e69701567f08a849e"
V8_PXO_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
              "south-idle-selout-v8-editable_m8-v08_20261015-080907-c8a1c140.pxo")
V01_REL = ("game/assets/characters/combat-sideview-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
           "sideview-battle-idle-right_candidate-frame_unapproved-v01_20261015-194937-8b47fa86.png")
V01_SHA256 = "164e1b0d9bd0d170461466912434f26b22431ca38338209b5dea98e80430bbab"
PIXELORAMA_REL = "work/tooling/pixelorama-1-2-3/Pixelorama-Windows-64bit/Pixelorama.exe"
PIXELORAMA_VERSION = "v1.2.3-stable"
GUIDE_RGB = (255, 0, 255)


def fid(role):
    return hashlib.sha256(f"{RUN_ID}:{role}".encode()).hexdigest()[:8]


SUBJECT = "protagonist-female_sideview-battle-idle-right"
PNG_NAME = f"{SLUG}_{SUBJECT}_candidate-frame-scale0p65_{VER}_{STAMP}-{fid('png')}.png"
PXO_NAME = f"{SLUG}_{SUBJECT}_editable-layers-scale0p65_{VER}_{STAMP}-{fid('pxo')}.pxo"
ORA_NAME = f"{SLUG}_{SUBJECT}_editable-layers-scale0p65_{VER}_{STAMP}-{fid('ora')}.ora"
MANIFEST_NAME = f"{SLUG}_{SUBJECT}_candidate-manifest-scale0p65_{VER}_{STAMP}-{fid('manifest')}.json"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))

# ============================================================================ palette
# key -> v8 colour. Several keys share one colour so each layer keeps its own material vocabulary.
PALETTE = {
    "K": "#0a0a0e", "x": "#201c20",                                                  # line, deepest accent
    "H": "#533b32", "Y": "#41302b", "C": "#634739", "B": "#845436", "Z": "#302526",  # hair
    "i": "#fbc38d", "k": "#e39664", "n": "#bb7c50", "w": "#9a4634", "O": "#faead4",  # skin, catchlight
    "7": "#1a767b", "d": "#11525b", "j": "#0a323b", "u": "#249b98",                  # teal scarf / roll
    "g": "#5e6e8c", "4": "#3a4560", "3": "#222839", "r": "#c07a40", "m": "#a16f4b",  # slate coat, copper trim
    "e": "#d7c0a8", "o": "#faead4", "9": "#b09986", "l": "#cfc8bd",                  # cream shirt, buckle
    "b": "#845436", "a": "#714730", "8": "#41302b", "6": "#302526", "p": "#7e5f4a",  # leather
    "5": "#324542", "f": "#4a625c", "T": "#222839",                                  # spruce trousers
    "s": "#474b54", "t": "#30333a", "v": "#626873", "q": "#23252b",                  # gunmetal
    "L": "#cfc8bd", "P": "#faead4", "U": "#249b98",                                  # blade, gadget light
}


def rl(*parts):
    """Run-length shorthand: rl("K", "3:2", "4:5") == "K3344444"."""
    out = []
    for p in parts:
        if ":" in p:
            ch, n = p.split(":")
            out.append(ch * int(n))
        else:
            out.append(p)
    return "".join(out)


# ============================================================================ layers (bottom -> top)
# Each layer is a list of blocks (x, y, rows); "." is transparent; later blocks in a layer paint over earlier ones.
LAYERS = []


def layer(name, *blocks):
    LAYERS.append((name, list(blocks)))


def rows_at(pairs, y0):
    """[(x, row), ...] starting at y0 -> blocks, one per row."""
    return [(x, y0 + i, [s]) for i, (x, s) in enumerate(pairs)]


# ---------------------------------------------------------------- back (far) leg: thigh under the coat, shin, boot
layer("back-leg", *rows_at([
    (47, "KT55555fK"),           # y64 (under the coat)
    (47, "KT55555fK"),
    (46, "KT55555ffK"),
    (46, "KT55555ffK"),
    (46, "KT55555ffK"),
    (45, "KT55555ffK"),          # y69
    (45, "KT55555ffK"),
    (45, "KT55555ffK"),
    (44, "KT55555ffK"),
    (44, "KT55555ffK"),
    (44, "KT55555ffK"),          # y74
    (43, "KTT5555ffK"),
    (43, "KTT5555ffK"),
    (43, "KT55555ffK"),
    (42, "KT55555ffK"),
    (42, "KTT5555ffK"),          # y79 knee crease
    (41, "KTT5555ffK"),
    (41, "KT55555fK"),
    (40, "KT55555fK"),
    (40, "KT5555ffK"),
    (39, "KTT555ffK"),           # y84
    (39, "KT5555ffK"),
    (39, "KT5555ffK"),
    (38, "KKKKKKKKKK"),          # y87 boot top
    (38, "K8bbbbbbaK"),          # cuff fold
    (38, "K88aaaaa8K"),
    (38, "K8aaaaaa8K"),          # y90
    (38, "K8aaaaaa8K"),
    (38, "K888r8888K"),          # y92 dark strap, copper buckle (no cream: it read as the disc showing through)
    (38, "K8aaaaaa8K"),
    (38, "K8aaaaaa8K"),
    (38, "K8aaaaaabK"),          # y95
    (37, "K68aaaaaabbK"),
    (37, "K68aaaaaaabbK"),
    (37, "K68aaaaaaaabbK"),
    (37, "K668aaaaaaaabbK"),
    (37, "K6688888aaaaabK"),     # y100
    (37, "K666666888888888K"),
    (37, "K666666666666666K"),
    (38, "KKKKKKKKKKKKKKK"),     # y103 sole line
], 64))

# ---------------------------------------------------------------- scarf tail: long teal tail hanging back below the pack
layer("scarf-tail", *rows_at([
    (30, "K7777777K"),           # y56 (mostly under the pack)
    (30, "K7777777K"),
    (29, "Kd777777uK"),
    (29, "Kd77777u7K"),
    (28, "Kd77777u7K"),          # y60
    (27, "Kjd7777u7K"),
    (26, "Kjd7777u7K"),
    (25, "Kjd777u77K"),
    (24, "Kjdd77u77K"),
    (23, "Kjd777u7K"),           # y65
    (22, "Kjd777u7K"),
    (21, "Kjd77u77K"),
    (20, "Kjd77u7K"),
    (19, "Kjd7u77K"),
    (19, "Kjd7u7K"),             # y70
    (19, "KjdKu7K"),             # fringe split
    (19, "KjK.KdK"),
    (19, "KK...K"),
], 56))

# ---------------------------------------------------------------- backpack: teal bedroll end, leather pack, steel canteen
layer("backpack", *rows_at([
    (32, "KKKKKK"),              # y28 bedroll end (concentric roll)
    (30, "KKd777uuKK"),
    (29, "Kd77777777uK"),        # y30
    (28, "Kd777dddd777uK"),
    (28, "Kd77d7777d77uK"),
    (28, "Kd7d77jj77d7uK"),
    (28, "Kd7d77jj77d77K"),
    (28, "Kd77d7777d77dK"),      # y35
    (28, "Kdd77dddd777dK"),
    (29, "Kdd7777777dK"),
    (30, "KKddddddddKK"),
    (29, "K8bbKKKKKKbbbaK"),     # y39 pack flap top under the roll
    (28, "K8bbbbbbbbbbbbbaK"),   # y40
    (28, "K8aaaaaaaaaaaaaaK"),
    (28, "K8aaaaaaaaaaaaaaK"),
    (28, "K88888888rrr8888K"),   # y43 flap edge, buckle
    (28, "K8aaaaaaar8raaaaK"),
    (28, "K8aaaaaaarrraaaaK"),   # y45
    (28, "K8aaaaaaaa8aaaaaK"),
    (28, "K8aaaaaaaaaaaaabK"),
    (28, "K8aaaaaaaaaaaaabK"),
    (28, "K8aaaaaaaaaaaaabK"),
    (28, "K68aaaaaaaaaaaabK"),   # y50
    (28, "K68aaaaaaaaaaaabK"),
    (28, "K68aaaaaaaaaaaabK"),
    (28, "K68aaaaaaaaaaaabK"),
    (28, "K68aaaaaaaaaaaabK"),
    (28, "K68aaaaaaaaaaaabK"),   # y55
    (28, "K668aaaaaaaaaaabK"),
    (28, "K6688888888888aaK"),
    (28, "K66666666666688aK"),
    (29, "KKKKKKKKKKKKKKKK"),    # y59
], 28), *rows_at([
    (25, "KKK"),                 # y47 canteen cap
    (24, "KlLvK"),
    (24, "KlLvK"),
    (24, "KlLvK"),               # y50
    (24, "KuUdK"),               # teal band
    (24, "KlLvK"),
    (24, "KlLvK"),
    (24, "KlLvK"),
    (24, "KvLsK"),               # y55
    (24, "KvvsK"),
    (25, "KKK"),
], 47))

# ---------------------------------------------------------------- near (front) leg: bent knee forward, boot
layer("front-leg", *rows_at([
    (53, "KT55555ffK"),          # y62 (under the coat)
    (54, "KT55555ffK"),
    (54, "KT55555fffK"),
    (55, "KT55555fffK"),
    (55, "KT55555fffK"),
    (56, "KT55555fffK"),         # y67
    (56, "KT55555fffK"),
    (57, "KT55555fffK"),
    (57, "KT55555fffK"),
    (58, "KT55555fffK"),
    (58, "KT55555fffK"),         # y72
    (59, "KT55555fffK"),
    (59, "KT55555fffK"),
    (59, "KT55555ffffK"),
    (59, "KT55555ffffK"),
    (60, "KTT5555fffK"),         # y77
    (60, "KTT5555fffK"),         # knee
    (60, "KT55555ffK"),
    (60, "KT55555ffK"),
    (61, "KT5555ffK"),
    (61, "KT5555ffK"),           # y82
    (61, "KTT555ffK"),
    (61, "KT5555ffK"),
    (61, "KT5555ffK"),
    (61, "KT5555ffK"),
    (60, "KKKKKKKKKKK"),         # y87 boot top
    (60, "KbbbbbbbbaK"),         # cuff fold
    (60, "K8aaaaabbbK"),
    (60, "K8aaaaabbbK"),         # y90
    (60, "K8aaaaabbbK"),
    (60, "K88888r888K"),         # y92 dark strap, copper buckle
    (60, "K8aaaaabbbK"),
    (60, "K8aaaaaabbK"),
    (60, "K8aaaaaabbbK"),        # y95
    (60, "K8aaaaaaabbbK"),
    (60, "K8aaaaaaaabbbK"),
    (60, "K68aaaaaaaabbbK"),
    (60, "K668aaaaaaaaabbK"),
    (60, "K6688888aaaaaabK"),    # y100
    (60, "K66666668888888bK"),
    (60, "K666666666666666K"),
    (61, "KKKKKKKKKKKKKKK"),     # y103 sole line
], 62), (64, 75, [               # dark leather knee pad on the near knee (character sheet)
    ".KKKKKK",
    "K8aabbbK",
    "K8aaabbK",
    "K88aaabK",
    "K888aa8K",
    ".KKKKKK",
]))

# ---------------------------------------------------------------- drop-leg holster on the near thigh
layer("thigh-holster", *rows_at([
    (54, "KaaaaaaaaaaaabK"),     # y71 upper thigh strap
    (54, "KsvvvvsK"),            # holster mouth, lit edge
    (54, "KqttttsK"),
    (54, "KqtUUtsK"),            # y74 teal light
    (54, "KqtUUttK"),
    (54, "KaaaaaaaabK"),         # y76 lower strap
    (54, "KqttttqK"),
    (55, "KqqqqK"),
    (55, "KKKKK"),               # y79
], 71))


# ---------------------------------------------------------------- coat torso, belt and skirt
def skirt_rows():
    """Skirt rows y61..y78 from an edge table (left, right). Back edge shadow, two pleat folds, lit front panel and a
    copper trim along the diagonal hem. The fills are plain per-row runs; nothing is interpolated."""
    edges = [(61, 40, 64), (62, 39, 65), (63, 38, 65), (64, 37, 66), (65, 36, 66), (66, 35, 66), (67, 35, 66),
             (68, 34, 65), (69, 34, 62), (70, 33, 59), (71, 33, 56), (72, 32, 53), (73, 32, 50), (74, 31, 47),
             (75, 31, 44), (76, 30, 41), (77, 30, 38)]
    out = []
    for y, l, r in edges:
        row = []
        for x in range(l, r + 1):
            if x == l or x == r:
                c = "K"
            elif x <= l + 2:
                c = "3"
            elif y >= 68 and x >= r - 2:
                c = "r" if x == r - 1 else "m"           # copper hem trim on the diagonal
            elif y < 68 and x == r - 1:
                c = "r"                                  # copper front edge
            elif y < 68 and x >= r - 3:
                c = "g"                                  # lit front panel
            elif x in (46, 47, 54, 55) and y >= 62:
                c = "3"                                  # fold shadows
            elif x in (48, 56) and y >= 62:
                c = "g"                                  # fold lips
            elif x == 39 and y >= 70:
                c = "g"                                  # back flare fold
            else:
                c = "4"
            row.append(c)
        out.append((l, y, ["".join(row)]))
    out.append((31, 78, ["KKKKK"]))
    return out


layer("body-coat", *rows_at([
    (45, "KK"),                                              # y32 raised coat collar behind the neck
    (44, "KggK"),
    (43, "Kgg4K"),
    (43, "Kg443K"),                                          # y35
    (43, "Kg4433K"),
    (43, "Kg44333K"),
    (43, "Kg44333KKKKKKKKKK"),                               # y38 collar line (under the scarf)
    (42, rl("K", "g", "3", "4:12", "3", "g", "r", "e", "K")),
    (42, rl("K", "3:2", "4:14", "3", "g", "r", "e", "K")),             # y40
    (41, rl("K", "3:2", "4:15", "3", "g", "r", "9", "e", "K")),
    (41, rl("K", "3:2", "4:15", "3", "g", "r", "9", "e", "K")),
    (41, rl("K", "3:2", "4:15", "3", "g", "r", "9", "o", "K")),
    (41, rl("K", "3:2", "4:15", "3", "g", "r", "9", "e", "o", "K")),   # y44 bust
    (41, rl("K", "3:2", "4:15", "3", "g", "r", "9", "o", "e", "K")),
    (41, rl("K", "3:2", "4:15", "3", "a", "a", "a", "l", "a", "K")),   # y46 sternum strap + buckle
    (41, rl("K", "3:2", "4:15", "3", "8", "8", "8", "8", "8", "K")),
    (41, rl("K", "3:2", "4:15", "3", "g", "r", "9", "e", "o", "K")),
    (41, rl("K", "3:2", "4:15", "3", "g", "r", "9", "e", "K")),
    (41, rl("K", "3:3", "4:14", "3", "g", "r", "9", "a", "K")),        # y50 lacing
    (41, rl("K", "3:3", "4:14", "3", "g", "r", "9", "e", "K")),
    (41, rl("K", "3:3", "4:14", "3", "g", "r", "9", "a", "K")),
    (41, rl("K", "3:3", "4:14", "3", "g", "r", "9", "e", "K")),
    (41, rl("K", "3:3", "4:14", "3", "g", "r", "9", "e", "K")),
    (41, rl("K", "3:3", "4:14", "3", "g", "r", "9", "9", "K")),        # y55
    (41, rl("K", "3:3", "4:13", "3:2", "g", "r", "9", "K")),
    (41, rl("K", "3:3", "4:13", "3:2", "g", "r", "9", "K")),
    (41, rl("K", "a", "b:16", "l:3", "b", "K")),                         # y58 belt
    (41, rl("K", "8", "a:16", "l", "8", "l", "a", "K")),
    (41, rl("K", "6", "8:16", "l:3", "8", "K")),                         # y60
], 32), *skirt_rows())

# ---------------------------------------------------------------- pack shoulder strap (harness) down the back of the torso
layer("harness-strap", *rows_at([
    (46, "KbaK"),                # y38
    (46, "KbaK"),
    (45, "KbaK"),                # y40
    (45, "KbaK"),
    (45, "KbaK"),
    (44, "KbaK"),
    (44, "KbaK"),
    (44, "KrrK"),                # y45 copper slide buckle
    (44, "KrlK"),
    (44, "KbaK"),
    (44, "KbaK"),
    (43, "KbaK"),
    (43, "KbaK"),                # y50
    (43, "KbaK"),
    (43, "KbaK"),
    (43, "KbaK"),
    (43, "KbaK"),
    (43, "KbaK"),                # y55
    (43, "KbaK"),
    (43, "KbaK"),
], 38))

# ---------------------------------------------------------------- belt pouch on the back hip (asymmetric kit)
layer("belt-pouch", *rows_at([
    (39, "KKKKKKKKK"),           # y59
    (39, "KbbbbbbaK"),
    (39, "K8bbbbbaK"),
    (39, "K888r888K"),           # flap edge + copper stud
    (39, "K8aaaaa8K"),
    (39, "K8aaaaa8K"),
    (39, "K68aaa88K"),           # y65
    (40, "KKKKKKK"),
], 59))


# ---------------------------------------------------------------- near arm, gloved fist, short sword
def blade_rows():
    """Straight 2:1 rising blade from x76 (centre y52) to the tip; per column: line, edge light, core, shadow, line."""
    out = []
    for x in range(76, 104):
        yc = 52 - (x - 76) // 2
        out.append((x, yc - 2, ["K", "P", "L", "v", "K"]))
    out += [(104, 36, ["K", "P", "K"]), (105, 37, ["K"])]
    return [(x, y, list(col)) for x, y, col in out]


layer("front-arm-sword", *rows_at([
    (50, "KKKKKKKK"),            # y40 shoulder cap
    (49, "K44ggggggK"),
    (48, "K3444gggg4K"),
    (48, "K34444ggg4K"),
    (48, "K344444gg4K"),
    (48, "K3444444g4K"),         # y45
    (48, "K3444444g4K"),
    (49, "K344444g4K"),
    (49, "K344444g4K"),
    (50, "K34444g44K"),
    (50, "K344444g4K"),          # y50
    (51, "K34444g44KKKK"),
    (51, "K3444444gggreK"),      # y52 forearm: sleeve, copper cuff, rolled cream sleeve
    (52, "K3444444ggroK"),
    (52, "K334444444reK"),
    (52, "K333344444m9K"),       # y55
    (53, "K33333333m9K"),
    (54, "KKKKKKKKKKK"),
], 40), *rows_at([
    (61, "KrrK"),                # y58 pommel under the wrist
    (61, "KmmK"),
    (62, "KK"),
], 58), *rows_at([
    (65, "KKKKK"),               # y50 fingerless glove, back of the hand toward the viewer
    (64, "K8abbbK"),
    (64, "K8aabbbK"),
    (64, "K8aaabkiK"),           # y53 thumb over the grip
    (64, "K8aaaakiK"),
    (64, "K88aaakkK"),           # y55
    (64, "K8nkknkK"),            # curled fingers
    (65, "KKKKKKK"),
], 50), *rows_at([
    (72, "KK"),                  # y48 copper crossguard with teal stone
    (71, "KrrK"),
    (71, "KrmK"),                # y50
    (72, "KrmK"),
    (72, "KruK"),
    (72, "KmrK"),
    (73, "KrmK"),
    (73, "KmmK"),                # y55
    (73, "KKK"),
], 48), *blade_rows())

# ---------------------------------------------------------------- scarf: neck wrap, knot and short front tail
layer("scarf-neck", *rows_at([
    (50, "KKKKKKKKKKKKK"),       # y34
    (48, "KK7777777777uuKK"),
    (47, "Kd77777777777uu7K"),
    (46, "Kjd777dddd77777u7K"),
    (46, "Kjdd7777777dd777uK"),
    (46, "Kjjdd77777777dd7u7K"),  # y39
    (47, "KjjddddddddddKd77uK"),
    (48, "KKKKKKKKKKKKKd777uK"),
    (60, "Kjd77uK"),             # y42 front tail over the shirt
    (60, "Kjd77uK"),
    (61, "Kd77uK"),
    (61, "Kd7uuK"),              # y45
    (61, "Kjd7uK"),
    (62, "Kd7K"),
    (62, "KjdK"),
    (63, "KK"),
], 34))

# ---------------------------------------------------------------- high ponytail (behind the head), tied with a copper wrap
layer("ponytail", *rows_at([
    (37, "KKKKKK"),              # y1
    (35, "KKCCBBCKK"),
    (33, "KKHHHCCBBCCK"),
    (32, "KYHHHHHCCBCCK"),
    (31, "KYHHYYHHHHCCCCK"),     # y5
    (30, "KYHHYKKYYHHHHCCK"),
    (30, "KYHYK..KKYHHHHHK"),
    (29, "KZYHHK....KKKK"),
    (29, "KZYHHCK"),
    (28, "KZYHHHCK"),            # y10
    (28, "KZYYHHCK"),
    (28, "KZYHHHCHK"),
    (27, "KZYHYHHCHK"),
    (27, "KZYHYHHCHK"),
    (27, "KZYHYHHHCK"),          # y15
    (27, "KZYYHYHHCK"),
    (27, "KZYHYHHCHK"),
    (27, "KZYHYHHCHK"),
    (27, "KZYHYYHCK"),
    (27, "KZZYHYHCK"),           # y20
    (27, "KZYHYHCHK"),
    (27, "KZYKYHHCK"),           # strands split
    (27, "KZK.KYHCK"),
    (27, "KK..KYHK"),
    (31, "KYK"),                 # y25
    (31, "KK"),
], 1))

# ---------------------------------------------------------------- head: clumped hair, side-swept forelock, side lock, face
# Clumps are split by deep 'x' grooves and lit with C/B strokes from the upper front. Face x59..x73: near eye x61-63 under
# a 4-texel lash, far eye x67, nose tip x72 y28, mouth x66-67.
layer("head", *rows_at([
    (46, "KKKK"),                                          # y7 copper tie
    (45, "KrrmrK"),
    (45, "KmrrmK"),
    (45, "KrmmrKKKKKKKK"),                                 # y10 crown
    (44, "KYYHHCCBBxBBCCHK"),
    (43, "KYYHHHCCBxCBBCxCHK"),
    (42, "KZYYHHHCCxHCBBCxCBHK"),
    (42, "KZYYYHHCxHHHCCBxCBxHK"),
    (41, "KZYYYHHCxHHHHCCxHCBxCHK"),                       # y15
    (41, "KZYYYYHCxHHHHHCxHHCBxCBK"),
    (41, "KZZYYYHxCHHHHHCxHHCBHxCBK"),
    (41, "KZZYHYYxCHHHHHCxHHHCBxCBxK"),
    (41, "KZZYHYxCHHHHHCxHHHCHHxCBxCK"),
    (41, "KZZYYYxCHHHHHCxHHHCHHHxCBxCK"),                  # y20
    (41, "KZZYYxCHHHHHCxHHHYCHHHxCHHxCHK"),
    (41, "KZZYxCHHHHHCxHHYHC" + "HHYiHHHYiHCBK"),           # y22 fringe tips, forelock sweeps forward
    (41, "KZZYxHHHHHHCxHHYHC" + "HYiiiiHYiiYCBK"),
    (40, "KZZZYxHHHHHHCxHHYHC" + "kiYYYiiiYYiYCCK"),        # y24 brows, forelock tip out front
    (41, "KZZYxHHHHHHxHHHYHC" + "kKKKKiiiKKiiYK"),          # y25 lashes
    (41, "KZZxHHHHHHxHHHHYHC" + "kixxOiiixiiiiK"),          # y26 eyes
    (41, "KZZxYHHHHHHxHHHYHC" + "kiHxxiiiHiiiiK"),
    (42, "KZxYHHHHHHxHHHYHC" + "kiiiiiiiiiiiiiK"),          # y28 nose tip
    (42, "KZZYHHHHHxHHHHYHC" + "kikkiiiiiiiikK"),           # y29 cheek
    (43, "KZYHHHHHxHHHHYHC" + "kiiiiiiiiiiiK"),
    (44, "KZYYHHHxHHHHYHC" + "nkiiiiiwwiiK"),               # y31 mouth
    (45, "KZYYHHxHHHYYHC" + "nkiiiiiiikK"),
    (45, "KZYKZYYKYYHKYHC" + "nkiiiikkK"),                  # y33 chin, nape tips
    (44, "KZK.KYK.KYK.KYK" + "KKKKKKKKK"),
    (45, "K...K...K...K"),                                 # y35
], 7))


LAYER_NAMES = [n for n, _ in LAYERS] + ["guides"]


# ============================================================================ raster
def hex_rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def layer_rgba(name, blocks):
    a = np.zeros((H, W, 4), np.uint8)
    for x0, y0, rows in blocks:
        for r, row in enumerate(rows):
            for c, ch in enumerate(row):
                if ch == ".":
                    continue
                if ch not in PALETTE:
                    raise SystemExit(f"{name}: unknown palette key {ch!r} at block ({x0},{y0}) row {r} col {c}")
                x, y = x0 + c, y0 + r
                if not (0 <= x < W and 0 <= y < H):
                    raise SystemExit(f"{name}: texel ({x},{y}) outside the {W}x{H} cell")
                a[y, x, :3] = hex_rgb(PALETTE[ch])
                a[y, x, 3] = 255
    return a


def guides_rgba(comp):
    g = np.zeros((H, W, 4), np.uint8)
    pts = set()
    pts.update((x, 0) for x in range(W)); pts.update((x, H - 1) for x in range(W))
    pts.update((0, y) for y in range(H)); pts.update((W - 1, y) for y in range(H))
    for y in (CROWN_ROW, PIN[1] - 1):
        pts.update((x, y) for x in list(range(1, 7)) + list(range(W - 7, W - 1)))
    pts.add(PIN)
    for x, y in pts:
        g[y, x, :3] = GUIDE_RGB
        g[y, x, 3] = 255
    if (comp[..., 3][g[..., 3] > 0] != 0).any():
        raise SystemExit("a guide texel overlaps an opaque art texel")
    return g


def render():
    """Returns ({layer name: RGBA}, composite RGBA). Alpha is binary, so 'over' is a plain copy."""
    blobs = {}
    comp = np.zeros((H, W, 4), np.uint8)
    for name, blocks in LAYERS:
        a = layer_rgba(name, blocks)
        blobs[name] = a
        m = a[..., 3] == 255
        comp[m] = a[m]
    blobs["guides"] = guides_rgba(comp)
    return blobs, comp


def png_bytes(rgba):
    buf = io.BytesIO()
    Image.fromarray(rgba, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


# ============================================================================ paths / hashes
WIN_MAX_PATH = 259
WIN_LONG_PREFIX = "\\\\?\\"


def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > WIN_MAX_PATH - 12 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def repo_path(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(path):
    with open(_fs(path), "rb") as f:
        return f.read()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def text_sha256_lf(data):
    return hashlib.sha256(data.replace(b"\r\n", b"\n")).hexdigest()


def inputs_checked():
    v8 = read_bytes(repo_path(V8_REL))
    if sha256_bytes(v8) != V8_SHA256:
        raise SystemExit("v8 source hash mismatch; refusing to run")
    v01 = read_bytes(repo_path(V01_REL))
    if sha256_bytes(v01) != V01_SHA256:
        raise SystemExit("v01 candidate hash mismatch; refusing to run")
    return (np.array(Image.open(io.BytesIO(v8)).convert("RGBA")),
            np.array(Image.open(io.BytesIO(v01)).convert("RGBA")))


def v8_palette(v8a):
    m = v8a[..., 3] > 0
    return {"#%02x%02x%02x" % tuple(int(c) for c in px) for px in v8a[m][:, :3]}


# ============================================================================ preview (separate pictures, no sheets)
def on_bg(rgba, bg, zoom):
    im = Image.new("RGBA", (rgba.shape[1], rgba.shape[0]), bg + (255,))
    im.alpha_composite(Image.fromarray(rgba, "RGBA"))
    return im.resize((im.width * zoom, im.height * zoom), Image.NEAREST)


def screen_sim(rgba, bg, disc=True, zoom=4):
    """Approximates the Godot draw at node scale 0.65 (1 texel = 1.3 screen px, nearest, texel centres) on a flat
    background with the 0.65-scaled cream controlled-fighter disc, then enlarges the screen pixels by an integer zoom
    for inspection. Inspection only; the real check is the Godot capture."""
    k = DISPLAY_SCALE * 2.0
    sw, sh = 160, 160
    ox, oy = 80 - PIN[0] * k, 140 - PIN[1] * k
    out = np.zeros((sh, sw, 4), np.uint8)
    out[..., :3] = bg
    out[..., 3] = 255
    if disc:
        r = 13.0 * DISPLAY_SCALE / 0.5 * 2.0
        yy, xx = np.mgrid[0:sh, 0:sw]
        m = (xx + 0.5 - 80) ** 2 + (yy + 0.5 - 140) ** 2 <= r * r
        out[m, :3] = (0xf5, 0xe1, 0xa6)
    for y in range(sh):
        for x in range(sw):
            tx, ty = int(np.floor((x + 0.5 - ox) / k)), int(np.floor((y + 0.5 - oy) / k))
            if 0 <= tx < W and 0 <= ty < H and rgba[ty, tx, 3]:
                out[y, x] = rgba[ty, tx]
    im = Image.fromarray(out, "RGBA")
    return im.resize((sw * zoom, sh * zoom), Image.NEAREST)


def preview(out_dir):
    v8a, _ = inputs_checked()
    blobs, comp = render()
    os.makedirs(out_dir, exist_ok=True)
    Image.fromarray(comp, "RGBA").save(os.path.join(out_dir, "v02_1x.png"))
    on_bg(comp, (74, 78, 86), 6).save(os.path.join(out_dir, "v02_x6_grey.png"))
    on_bg(comp, (226, 220, 206), 6).save(os.path.join(out_dir, "v02_x6_light.png"))
    screen_sim(comp, (20, 24, 32)).save(os.path.join(out_dir, "v02_sim065_dark.png"))
    screen_sim(comp, (214, 208, 196)).save(os.path.join(out_dir, "v02_sim065_light.png"))
    screen_sim(comp, (95, 95, 95)).save(os.path.join(out_dir, "v02_sim065_floor.png"))
    print(json.dumps({**stats(comp, v8a), "isolated_single_texels": isolated_texels(comp)}))


def stats(comp, v8a):
    m = comp[..., 3] > 0
    ys, xs = np.nonzero(m)
    cols = {"#%02x%02x%02x" % tuple(int(c) for c in px) for px in comp[m][:, :3]}
    return {"opaque_texels": int(m.sum()), "colours": len(cols),
            "colours_outside_v8": sorted(cols - v8_palette(v8a)),
            "alpha_values": sorted({int(v) for v in np.unique(comp[..., 3])}),
            "alpha_bounds_inclusive": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
            "body_rows": [int(ys.min()), int(ys.max())], "body_height_texels": int(ys.max() - ys.min() + 1)}


def isolated_texels(comp):
    """Opaque non-line texels whose 4 opaque neighbours all differ from them (single-pixel noise)."""
    rgb = comp[..., :3].astype(np.int32)
    key = (rgb[..., 0] << 16) | (rgb[..., 1] << 8) | rgb[..., 2]
    op = comp[..., 3] > 0
    line = key == int(PALETTE["K"][1:], 16)
    n = 0
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            if not op[y, x] or line[y, x]:
                continue
            same = any(op[y + dy, x + dx] and key[y + dy, x + dx] == key[y, x]
                       for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
            if not same:
                n += 1
    return n


if __name__ == "__main__" and len(sys.argv) > 2 and sys.argv[1] == "preview":
    preview(sys.argv[2])
