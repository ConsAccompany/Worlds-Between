"""UNAPPROVED, test-only candidate v03: female protagonist side-view battle idle, facing right, ONE static frame.

Static-frame refinement only (no motion). The owner approved the battle DISPLAY SCALE 0.65 (the on-screen size of the v01
cell drawn at Godot node scale 0.65), not the art. v01/v02 are 2x-density cells, so at node scale 0.65 every texel lands
on 1.3 screen px and nearest sampling makes texel columns/rows alternate between 1 and 2 screen px. That mixes pixel
densities with the companions, who draw 1 texel = 1 logical px = 2x2 screen px.

v03 is therefore authored NATIVELY at the approved on-screen size: 1 texel = 1 logical px, intended node scale 1.0, so
every texel is an exact 2x2 screen block at 1280x720 like the companions. Crown-to-sole is 61 rows, which matches v01 at
node scale 0.65 (61.0 logical px measured in the 0.65 capture); the ponytail rises 3 rows above the crown (64 total).

Identity follows the original female character sheet and the v02 identity art-direction reference (charcoal-brown split
field coat over a white shirt, teal scarf as the accent, dark-brown high ponytail with a loose side lock, brown pack with a
teal bedroll seen end-on and a small steel canister, utility belt and hip pouch, olive-taupe trousers, strapped brown
boots, ordinary short sword held low). It deliberately does NOT reuse v01/v02's slate-blue coat (v8 south palette).

Hand-authored pixel art: every texel is typed in the ASCII maps below (layers bottom -> top, '.' = transparent). No
resampling, filtering, gradients, dithering, quantizing, AI generation or upscaling. Binary alpha. Palette is a fixed list
of hex colours chosen against the sheet swatches; it is not sampled from any image at runtime.

Modes
  preview <dir>  inspection PNGs in <dir> (outside the repo): x8 zooms and a 2x screen simulation.
  build          writes the single candidate PNG into game/assets/characters/combat-sideview-pilots/ (never overwrites).
  check          technical gates on the built PNG; prints JSON, writes nothing.

Run with the real Python in isolated mode:  python -I -B <this file> preview|build|check
"""
import hashlib, io, json, os, sys
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
W, H = 68, 72
PIN = (32, 68)            # ground contact: first transparent row under the soles, horizontally between the feet
CROWN_ROW = 7             # head crown; soles end on row 67 -> crown-to-sole 61 rows
SOLE_ROW = 67
OUT_REL = ("game/assets/characters/combat-sideview-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
           "sideview-idle-right-static-native0p65_unapproved-v03_20261015-225825-a72adaa9.png")

PALETTE = {
    "K": "#1b1517",                                                  # outline
    "1": "#261b18", "2": "#3e2d27", "3": "#5a4234", "4": "#7d5d46",  # hair, dark -> light
    "S": "#f3c9a3", "s": "#dc9e77", "x": "#ad6d50", "E": "#2a1a17",  # skin light/mid/shadow, iris
    "C": "#2c2422", "c": "#433630", "o": "#5c4a3f", "O": "#7c6655",  # charcoal-brown coat
    "W": "#efe9dd", "w": "#bfb2a1",                                  # white shirt / rolled sleeve
    "T": "#36352f", "t": "#504e46", "y": "#6d6a5e",                  # olive-taupe trousers
    "L": "#3a251c", "l": "#5b3b29", "b": "#7c5236", "B": "#a2724a",  # leather
    "Q": "#113a3d", "q": "#1c6261", "g": "#2c8a84", "G": "#62b9ad",  # teal
    "m": "#5c6570", "M": "#9ba7af", "Z": "#e6edee",                  # steel
}

LAYERS = []


def layer(name, y0, rows):
    """rows: list of (x, string) painted from row y0 downward; '.' leaves texels untouched."""
    LAYERS.append((name, [(x, y0 + r, ch) for r, (x0, row) in enumerate(rows)
                          for x, ch in enumerate(row, x0)]))


def layer_px(name, texels):
    """texels: list of (x, y, key)."""
    LAYERS.append((name, list(texels)))


# ------------------------------------------------------------------------------------------- far (back) leg + boot
# Far side is kept one value step darker than the near side (no light leather on the far boot).
layer("far-leg", 42, [
    (26, "KTTtK"),        # y42 (under the coat)
    (26, "KTTtK"),
    (25, "KTTttK"),
    (25, "KTTttK"),
    (25, "KTTttK"),       # y46
    (24, "KTTttK"),
    (24, "KTTttK"),
    (24, "KTTttK"),
    (24, "KTTttK"),       # y50
    (23, "KTTttK"),
    (23, "KTTttK"),       # y52 knee
    (23, "KTTttK"),
    (23, "KTTttK"),
    (23, "KTTttK"),       # y55
    (23, "KTTttK"),
    (22, "KKKKKKK"),      # y57 boot top
    (22, "KLlllLK"),      # cuff
    (22, "KLLLLLK"),      # y59 strap
    (22, "KLlmllK"),      # buckle (dark steel on the far side)
    (22, "KLllllK"),
    (22, "KLlllllK"),     # y62
    (22, "KLllllllKK"),
    (22, "KLLlllllllK"),
    (22, "KLLLLLlllllK"), # y65
    (22, "KCCCCCCCCCCK"), # y66 sole
    (23, "KKKKKKKKKK"),   # y67
])

# --------------------------------------- scarf tail: hangs behind the pack and shows below it, fringed end trailing back
layer("scarf-tail", 30, [
    (19, "KqgK"),         # y30 (hidden behind the pack)
    (19, "KqgK"),
    (19, "KqgK"),
    (18, "KqqgK"),
    (18, "KqqgK"),
    (18, "KqqgK"),        # y35
    (18, "KqqgK"),
    (17, "KQqgK"),
    (17, "KQqgK"),
    (17, "KQqgK"),
    (16, "KQqggK"),       # y40
    (16, "KQqgK"),        # y41 first visible row under the pack
    (15, "KQqgK"),
    (15, "KQqgK"),
    (14, "KQqgK"),
    (14, "KQqgK"),        # y45
    (13, "KQqgK"),
    (13, "KQqgK"),
    (12, "KQKgK"),        # y48 fringe split
    (12, "KK.KK"),
])

# ---------------------------------------------- pack: teal bedroll end-on on top, leather body, flap, strap, canister
layer("pack", 19, [
    (17, "KKKKK"),        # y19 bedroll (spiral end)
    (15, "KKqqqggKK"),
    (14, "KqqQQQqgGK"),
    (14, "KqQqqqQqgK"),   # y22
    (14, "KqQqQqQqgK"),
    (14, "KqQqqqQqgK"),
    (14, "KqqQQQqqgK"),
    (14, "KQqqqqqqqK"),   # y26
    (15, "KQQqqqqQK"),
    (14, "KKLKKKKKLKK"),  # y28 roll straps meet the flap
    (14, "KLbbbbbbbbbK"),
    (14, "KlbbbbbbbbbK"), # y30 flap
    (14, "KlllllllllbK"),
    (14, "KLLLLlMLLLLK"), # y32 flap edge + steel buckle
    (14, "KLllllMlllbK"),
    (14, "KLllllllllbK"),
    (14, "KLllllllllbK"), # y35
    (14, "KLlllllllllK"),
    (14, "KLLllllllllK"),
    (14, "KLLLlllllllK"),
    (14, "KLLLLLLLLLLK"), # y39
    (15, "KKKKKKKKKK"),   # y40
])
layer("canister", 30, [
    (12, "KK"),           # y30 cap
    (11, "KmMK"),
    (11, "KMZK"),
    (11, "KMZK"),
    (11, "KgGK"),         # teal band
    (11, "KMZK"),         # y35
    (11, "KmMK"),
    (12, "KK"),
])

# ------------------------------------------------------- near (front) leg: thigh shows under the cut-away coat front
layer("near-leg", 41, [
    (32, "KttyK"),        # y41
    (32, "KttyyK"),
    (33, "KTttyK"),
    (33, "KTttyyK"),
    (34, "KTttyK"),       # y45
    (34, "KTttyyK"),
    (35, "KTttyK"),
    (35, "KTttyK"),
    (35, "KLLlbK"),       # y49 dark leather knee pad
    (35, "KLlbBK"),
    (35, "KLLlbK"),
    (36, "KTtyK"),        # y52
    (36, "KTtyyK"),
    (36, "KTtyK"),
    (36, "KTtyK"),        # y55
    (36, "KTtyK"),
    (35, "KKKKKKK"),      # y57 boot top
    (35, "KLbBBbK"),      # cuff
    (35, "KLLLLLK"),      # y59 strap
    (35, "KLlMlbK"),      # buckle
    (35, "KLllbbK"),
    (35, "KLlllbbK"),     # y62
    (35, "KLllllbbKK"),
    (35, "KLLlllllbbK"),
    (35, "KLLLllllllbK"), # y65
    (35, "KCCCCCCCCCCK"), # y66 sole
    (36, "KKKKKKKKKK"),   # y67
])

# ----------------------- coat: torso (darker than the arm), belt, split skirt with long back tail and cut-away front
layer("coat", 22, [
    (27, "KKKKK"),                    # y22 raised back collar
    (25, "KKccoOKK"),
    (24, "KCcccooo"),                 # y24
    (24, "KCccccooo"),
    (24, "KCccccccoo"),
    (24, "KCccccccooo"),
    (24, "KCcccccccooo"),             # y28
    (24, "KCcccccccoooo"),
    (24, "KCccccccccooo"),            # y30
    (24, "KCccccccccooo"),
    (24, "KCccccccccooo"),
    (24, "KCccccccccoooo"),
    (24, "KCccccccccoooo"),           # y34
    (24, "KCccccccccoooo"),
    (24, "KCcccccccccoooo"),
    (24, "KCcccccccccoooo"),          # y37
    (24, "KLLLLLLLLLLLLLLL"),         # y38 belt
    (24, "KLllllllllllllll"),
    (23, "KCcccccccoooooooOK"),       # y40 skirt under the belt
    (22, "KCcccccccoooooooOOK"),
    (22, "KCcccccccKoooooooOK"),      # y42 centre vent starts (x31)
    (21, "KCccccccccKooooOK"),        # y43 front hem cuts back diagonally
    (21, "KCccccccccKooOK"),
    (20, "KCcccccccccKoOK"),          # y45
    (20, "KCcccccccccKOK"),
    (20, "KCccccccccoKK"),
    (19, "KCccccccccbbK"),            # y48 back tail: leather-trimmed hem drops diagonally toward the back
    (19, "KCcccccccbbK"),             # (with the rising front hem this makes the split-tail V at the vent)
    (19, "KCcccccbbK"),               # y50
    (19, "KCccbbK"),
    (19, "KbbK"),                     # y52 longest point at the back
    (20, "KK"),                       # y53
])
# chest: coat front opens over the white shirt; lit lapel edge
layer("shirt-lapel", 23, [
    (32, "OOKWWK"),                   # y23
    (32, "OOOKWWK"),
    (33, "OOKWWWK"),                  # y25
    (33, "OOKwWWK"),
    (34, "OKwWWWK"),
    (34, "OKwWWWK"),                  # y28
    (34, "OKwWWWK"),
    (35, "KwWWWK"),                   # y30
    (35, "KwWWWK"),
    (35, "KwWWWK"),
    (35, "KwWWK"),                    # y33
    (35, "KwWWK"),
    (35, "KwWWK"),
    (35, "KwWWK"),
    (35, "KwWWK"),                    # y37
])
layer("belt-front", 38, [
    (36, "LLMMK"),                    # y38 belt front + steel buckle
    (36, "lLMMK"),
])
layer("hip-pouch", 38, [
    (22, "KKKKKK"),                   # y38
    (22, "KbbbbK"),
    (22, "KLLMLK"),                   # y40 flap edge + stud
    (22, "KlllbK"),
    (22, "KlllbK"),
    (22, "KKKKKK"),                   # y43
])
layer("shirt-tail", 40, [
    (36, "KwWK"),                     # y40 shirt tail peeking under the open coat front
    (36, "KwWK"),
    (37, "KK"),
])

# ------------------------------- near arm: lighter sleeve than the torso, rolled cuff, bare forearm, fingerless glove
layer("near-arm", 25, [
    (27, "KKKKK"),                    # y25 shoulder cap
    (26, "KcooOOK"),
    (26, "KcooOOK"),
    (26, "KcoooOOK"),                 # y28
    (26, "KccooOOK"),
    (27, "KcooOOK"),                  # y30
    (27, "KcooOOK"),
    (27, "KccoOOK"),
    (28, "KwwwWK"),                   # y33 rolled sleeve (shadowed white so it does not merge with the shirt)
    (29, "KwwwWK"),
    (30, "KsSSSK"),                   # y35 forearm
    (31, "KsSSSK"),
    (32, "KLllbbK"),                  # y37 glove around the grip
    (33, "KLbBK"),
    (33, "KsSSK"),                    # y39 fingers
    (34, "KKK"),
])


# ----------------------------------------- short sword held low: small leather-wrapped guard, 2:1 descending blade
def blade_segments(x0=40, x1=51, y0=38):
    """Straight 2:1 descending blade, one column at a time (the texels a pixel line tool places): outline, edge light,
    steel core, outline. The tip column closes the outline."""
    segs = []
    for x in range(x0, x1 + 1):
        yt = y0 + (x - x0) // 2
        for dy, ch in enumerate("KZMK"):
            segs.append((x, yt + dy, ch))
    yt = y0 + (x1 + 1 - x0) // 2
    segs += [(x1 + 1, yt, "K"), (x1 + 1, yt + 1, "K"), (x1 + 1, yt + 2, "K"), (x1 + 2, yt + 1, "K")]
    return segs


layer_px("sword-blade", blade_segments())
layer("sword-guard", 36, [
    (38, "KK"),                       # y36
    (38, "KBK"),
    (38, "KBK"),
    (38, "KbK"),
    (38, "KbK"),                      # y40
    (38, "KK"),
])

# ------------------------------------------------------------------ scarf at the neck, knot and short front tail
layer("scarf-neck", 19, [
    (28, "KKKKKKK"),                  # y19
    (25, "KKKqqqqgggK"),
    (24, "KQqqqqqgggGK"),             # y21
    (23, "KQQqqqqqqggGK"),
    (23, "KQQQqqqqqqgK"),             # y23
    (24, "KKQQQQqqqK"),
    (31, "KqgGK"),                    # y25 front knot / tail over the shirt
    (31, "KqggK"),
    (32, "KqgK"),
    (32, "KQqK"),                     # y28
    (33, "KK"),
])

# --------------------------------------- high ponytail: tied at the top-back, rises, then falls back clear of the head
layer("ponytail", 4, [
    (20, "KKKKK"),                    # y4
    (18, "KK23343K"),
    (17, "K1223334K"),                # y6
    (16, "K122333K"),
    (16, "K12233K"),                  # y8
    (15, "K112233K"),
    (15, "K11223K"),                  # y10
    (15, "K11223K"),
    (15, "K11233K"),
    (15, "K112233K"),                 # y13
    (15, "K11223K"),
    (15, "K1123K"),                   # y15
    (14, "K1223K"),                   # tip flicks back
    (14, "K1K23K"),                   # y17 split tip
    (14, "KK.KK"),
])

# ------------------------------------------------- head: hair mass with lit crown, loose side lock, face looking right
# Face x33..41: brow y12-13, eye y13..15 at x37-38, nose tip x41 y15, mouth x39 y17, chin y19.
layer("head", 6, [
    (24, "KKKK"),                     # y6 tie (wrap) at the top-back
    (23, "KbBbKKKKKK"),               # y7 crown
    (23, "KlbK2334433KK"),            # y8
    (24, "KK23344443332K"),           # y9
    (24, "K2223344433332K"),          # y10
    (24, "K22223334433332K"),         # y11
    (24, "K2122233K3SS33S3K"),        # y12 fringe tips over the brow
    (24, "K2122232KSSSSKKSK"),        # y13 brow / lash line
    (24, "K21222322SSSSEESK"),        # y14 eye (no mid-skin flanking it: read as a blotch at 2x)
    (24, "K2112232KSSSSESSSK"),       # y15 nose tip at x40, outline x41
    (24, "K21122321SSSssSSK"),        # y16 cheek blush under the eye
    (24, "K2112232KsSSSSxSK"),        # y17 mouth
    (25, "K112232KxsSSSSK"),          # y18
    (25, "K11223K2KxssK"),            # y19 chin; loose side lock continues down
    (26, "KK11KK2K.KKK"),             # y20
    (32, "K2K"),                      # y21 lock tip over the scarf
    (33, "K"),
])


# ============================================================================== raster
def hex_rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def render():
    comp = np.zeros((H, W, 4), np.uint8)
    layers = {}
    for name, texels in LAYERS:
        a = np.zeros((H, W, 4), np.uint8)
        for x, y, ch in texels:
            if True:
                if ch == ".":
                    continue
                if ch not in PALETTE:
                    raise SystemExit(f"{name}: unknown key {ch!r} at y{y} x{x}")
                if not (0 <= x < W and 0 <= y < H):
                    raise SystemExit(f"{name}: texel ({x},{y}) outside the {W}x{H} cell")
                a[y, x, :3] = hex_rgb(PALETTE[ch])
                a[y, x, 3] = 255
        layers[name] = a
        m = a[..., 3] == 255
        comp[m] = a[m]
    return layers, comp


def png_bytes(rgba):
    buf = io.BytesIO()
    Image.fromarray(rgba, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def isolated_texels(comp):
    rgb = comp[..., :3].astype(np.int32)
    key = (rgb[..., 0] << 16) | (rgb[..., 1] << 8) | rgb[..., 2]
    op = comp[..., 3] > 0
    line = key == int(PALETTE["K"][1:], 16)
    n = 0
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            if not op[y, x] or line[y, x]:
                continue
            if not any(op[y + dy, x + dx] and key[y + dy, x + dx] == key[y, x]
                       for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                n += 1
    return n


def stats(comp):
    m = comp[..., 3] > 0
    ys, xs = np.nonzero(m)
    cols = {"#%02x%02x%02x" % tuple(int(c) for c in px) for px in comp[m][:, :3]}
    pal = {v.lower() for v in PALETTE.values()}
    crown_cols = [x for x in range(24, 42) if m[CROWN_ROW, x] and not m[:CROWN_ROW, x].any()]  # head only
    return {
        "size": [W, H], "pin": list(PIN), "opaque_texels": int(m.sum()), "colours": len(cols),
        "colours_outside_palette": sorted(cols - pal),
        "alpha_values": sorted({int(v) for v in np.unique(comp[..., 3])}),
        "alpha_bounds_inclusive": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
        "top_row": int(ys.min()), "sole_row": int(ys.max()),
        "crown_row": CROWN_ROW, "crown_columns": crown_cols,
        "crown_to_sole_rows": SOLE_ROW - CROWN_ROW + 1,
        "with_ponytail_rows": int(ys.max() - ys.min() + 1),
        "pin_row_clear": bool(not m[PIN[1]:, :].any()),
        "isolated_single_texels": isolated_texels(comp),
    }


def on_bg(rgba, bg, zoom):
    im = Image.new("RGBA", (rgba.shape[1], rgba.shape[0]), bg + (255,))
    im.alpha_composite(Image.fromarray(rgba, "RGBA"))
    return im.resize((im.width * zoom, im.height * zoom), Image.NEAREST)


def preview(out_dir):
    _, comp = render()
    os.makedirs(out_dir, exist_ok=True)
    Image.fromarray(comp, "RGBA").save(os.path.join(out_dir, "v03_1x.png"))
    on_bg(comp, (88, 90, 96), 8).save(os.path.join(out_dir, "v03_x8_grey.png"))
    on_bg(comp, (226, 220, 206), 8).save(os.path.join(out_dir, "v03_x8_light.png"))
    on_bg(comp, (88, 90, 96), 2).save(os.path.join(out_dir, "v03_x2_screen.png"))
    print(json.dumps(stats(comp)))


def build():
    _, comp = render()
    path = os.path.join(REPO, *OUT_REL.split("/"))
    data = png_bytes(comp)
    if os.path.exists(path):
        with open(path, "rb") as f:
            if f.read() != data:
                raise SystemExit("refusing to overwrite a different existing file: " + OUT_REL)
        print("unchanged " + OUT_REL)
    else:
        with open(path, "wb") as f:
            f.write(data)
        print("wrote " + OUT_REL)
    print(json.dumps({"file": OUT_REL, "sha256": hashlib.sha256(data).hexdigest(), **stats(comp)}))


def check():
    _, comp = render()
    path = os.path.join(REPO, *OUT_REL.split("/"))
    with open(path, "rb") as f:
        data = f.read()
    im = Image.open(io.BytesIO(data))
    disk = np.array(im.convert("RGBA"))
    st = stats(disk)
    gates = {
        "png_mode_rgba": im.mode == "RGBA",
        "size_68x72": list(im.size) == [W, H],
        "matches_ascii_source": bool((disk == comp).all()),
        "binary_alpha": st["alpha_values"] == [0, 255],
        "no_off_palette_colour": st["colours_outside_palette"] == [],
        "colours_le_32": st["colours"] <= 32,
        "sole_on_row_67": st["sole_row"] == SOLE_ROW,
        "crown_to_sole_61": st["crown_to_sole_rows"] == 61,
        "nothing_below_pin_row": st["pin_row_clear"],
        "transparent_border": bool(not disk[0, :, 3].any() and not disk[-1, :, 3].any()
                                   and not disk[:, 0, 3].any() and not disk[:, -1, 3].any()),
    }
    print(json.dumps({"file": OUT_REL, "sha256": hashlib.sha256(data).hexdigest(), "gates": gates,
                      "all_pass": all(gates.values()), **st}, indent=1))
    return all(gates.values())


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    if mode == "preview" and len(sys.argv) > 2:
        preview(sys.argv[2])
    elif mode == "build":
        build()
    elif mode == "check":
        sys.exit(0 if check() else 1)
    else:
        raise SystemExit(__doc__)
