"""Author seven native 1:1 pixel fixtures for the Yonkers outskirts surface scene.

Every pixel is placed by explicit rectangles, lines and polygons without
anti-aliasing; no image is generated, traced or resampled. Each fixture is three
OpenRaster layers (contact-shadow, structure, identity-detail) plus the merged
PNG the runtime draws 1:1 in the 640x360 view. UNAPPROVED v01.

Usage: python -I <this file> [--out DIR] [--runtime DIR]
"""

from __future__ import annotations

from hashlib import sha256
from io import BytesIO
from pathlib import Path
import argparse
import json
import xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
STAMP = "20261017-023534-0228397e"
PREFIX = "rpg-2-star-ocean-the-second_yonkers-outskirts"
OUT = ROOT / "outputs" / "yonkers-outskirts-fixtures-pilot"
RUNTIME = ROOT / "game" / "assets" / "props" / "yonkers-outskirts-fixtures"

# Warm plate palette sampled from the current 640x360 capture (olive-dark
# recesses, sandstone, bronze, teal glass) plus the patrol pilot's steel ramp.
C = {
    "ink": "#1b1a12", "deep": "#2e2b1d", "olive": "#4a4528",
    "stone_dark": "#6b5d3c", "stone": "#9c8a5e", "stone_light": "#c9b57f", "stone_hi": "#e6d3a0",
    "bronze_dark": "#4f3b22", "bronze": "#70542e", "brass": "#a07a3e", "brass_light": "#d0a560", "brass_hi": "#f0cf8a",
    "rust": "#7a4a2a", "rust_light": "#a8673a", "scratch": "#f4ead0",
    "verd_dark": "#33403a", "verd": "#4f6358", "verd_light": "#7d917c",
    "teal_dark": "#1d5a5a", "teal": "#3fa3a0", "glow": "#8fe3d6", "glow_hi": "#d4fff5",
    "moss": "#5d6a27", "moss_light": "#8f9436",
    "red": "#b8503a", "amber": "#d89a3a",
    # Clue lamp: authored in the pending colour of the old markers; the runtime
    # repaints only these lamp pixels teal (#80d0c4) once the clue is recorded.
    "lamp": "#f4ca81",
    # Patrol automaton pilot ramp (manifest palette o,1..6 / a..e / x..w).
    "p_o": "#101217", "p1": "#1b1f26", "p2": "#282e37", "p3": "#384049", "p4": "#4c5562", "p5": "#67717e", "p6": "#8b95a1",
    "p_a": "#36291b", "p_b": "#5a462b", "p_c": "#806439", "p_d": "#a6864f", "p_e": "#cbb077",
    "p_x": "#0c363c", "p_y": "#188a92", "p_z": "#4bd5d2", "p_w": "#c6fff6",
}
SHADOW = (38, 31, 14, 112)


def rgba(name):
    if isinstance(name, tuple):
        return name
    value = C.get(name, name).lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


class Canvas:
    def __init__(self, w, h):
        self.img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)

    def rect(self, x0, y0, x1, y1, fill, outline=None):
        self.d.rectangle((x0, y0, x1, y1), fill=rgba(fill), outline=rgba(outline) if outline else None)

    def line(self, pts, fill, width=1):
        self.d.line(pts, fill=rgba(fill), width=width)

    def poly(self, pts, fill, outline=None):
        self.d.polygon(pts, fill=rgba(fill), outline=rgba(outline) if outline else None)

    def ellipse(self, box, fill, outline=None):
        self.d.ellipse(box, fill=rgba(fill), outline=rgba(outline) if outline else None)

    def px(self, pts, fill):
        for x, y in pts:
            self.img.putpixel((x, y), rgba(fill))


def shadow(w, h, box):
    c = Canvas(w, h)
    c.d.ellipse(box, fill=SHADOW)
    return c


# ---------------------------------------------------------------- fixtures
# Each returns (layers, size, offset-from-clue-point, lamp rect or None).

def discarded_conduit():
    """Trace 1: a cut length of old conduit with fresh sensor scratches."""
    W, H = 48, 28
    sh = shadow(W, H, (3, 14, 45, 25))
    s = Canvas(W, H)
    # Round pipe lying east-west: top-lit cylinder bands in verdigris patina.
    s.rect(8, 6, 38, 18, "ink")
    for y, tone in [(7, "verd"), (8, "verd_light"), (9, "verd_light"), (10, "verd"), (11, "verd"),
                    (12, "verd"), (13, "verd_dark"), (14, "verd_dark"), (15, "verd_dark"), (16, "deep"), (17, "deep")]:
        s.rect(9, y, 37, y, tone)
    # Patina breaks: old bronze showing through, dithered into the bands.
    s.px([(12, 11), (13, 12), (14, 11), (29, 13), (30, 14), (31, 13), (33, 10), (17, 15), (25, 8)], "bronze")
    s.px([(13, 11), (30, 13), (26, 8)], "brass")
    s.px([(11, 14), (19, 13), (27, 15), (35, 14)], "verd")
    # Broken west end: open bore with a jagged, torn lip.
    s.ellipse((4, 5, 13, 19), "ink")
    s.ellipse((5, 6, 12, 18), "verd")
    s.ellipse((6, 8, 11, 16), "ink")
    s.ellipse((7, 9, 10, 15), "deep")
    s.px([(6, 7), (5, 9), (6, 17)], "verd_light")
    s.px([(9, 5), (12, 6), (11, 19), (13, 18)], "ink")
    # East flange (a ring, not a box) with bolt heads.
    s.ellipse((35, 3, 43, 21), "ink")
    s.ellipse((36, 4, 42, 20), "bronze")
    s.ellipse((36, 5, 40, 18), "brass")
    s.line([(37, 7), (37, 15)], "brass_light")
    s.px([(40, 6), (42, 12), (40, 18)], "bronze_dark")
    # Coupling band.
    s.rect(21, 5, 24, 19, "ink")
    s.rect(22, 6, 23, 18, "bronze")
    s.line([(22, 7), (22, 12)], "brass_light")
    d = Canvas(W, H)
    # Fresh probe scratches cut through the patina to bright metal.
    d.line([(13, 8), (18, 11)], "scratch")
    d.line([(15, 8), (19, 10)], "brass_hi")
    d.line([(27, 8), (32, 11)], "scratch")
    d.line([(29, 8), (33, 10)], "brass_hi")
    d.px([(18, 11), (32, 11), (16, 8), (30, 8)], "brass_light")
    # Loose soil and a chip of paving kicked up at the cut end.
    d.px([(1, 18), (2, 20), (4, 21), (12, 21), (14, 22)], "stone_dark")
    d.px([(2, 19), (13, 22)], "stone_light")
    # Clip-on sensor tag left by the earlier survey, with the clue lamp.
    d.rect(41, 18, 46, 23, "ink")
    d.rect(42, 19, 45, 22, "verd")
    d.rect(43, 20, 45, 22, "lamp")
    d.line([(41, 17), (39, 15)], "verd_dark")
    return [sh, s, d], (W, H), (-24, -14), (43, 20, 3, 3)


def maintenance_marker():
    """Trace 2: a survey plate on the wall pier, its arrow leaving the old
    conduit spout and following a newer teal-sheathed live line down."""
    W, H = 28, 40
    sh = shadow(W, H, (5, 34, 18, 39))
    s = Canvas(W, H)
    # Brass plate set into the pier face (left of the waterfall spout).
    s.rect(2, 4, 15, 17, "ink")
    s.rect(3, 5, 14, 16, "bronze")
    s.rect(3, 5, 14, 5, "brass_light")
    s.rect(3, 5, 3, 16, "brass")
    s.rect(4, 6, 13, 15, "deep")
    # Rivets.
    s.px([(4, 6), (13, 6), (4, 15), (13, 15)], "brass_hi")
    # Live line: dark teal sheath with brass clamps, plate down to the ground.
    s.rect(7, 17, 10, 33, "ink")
    s.rect(8, 17, 8, 33, "teal")
    s.rect(9, 17, 9, 33, "teal_dark")
    s.rect(7, 33, 16, 36, "ink")
    s.rect(8, 34, 16, 34, "teal")
    s.rect(8, 35, 16, 35, "teal_dark")
    s.px([(8, 34)], "teal_dark")
    for y in (21, 28):
        s.rect(6, y, 11, y + 1, "ink")
        s.rect(7, y, 9, y, "brass_light")
        s.px([(10, y)], "brass")
    # Ground socket where the live line enters the paving.
    s.rect(16, 32, 21, 37, "ink")
    s.rect(17, 33, 20, 36, "verd")
    s.rect(17, 33, 20, 33, "verd_light")
    d = Canvas(W, H)
    # Painted amber arrow: from the conduit (right) bending down the new line.
    d.line([(12, 9), (8, 9)], "amber")
    d.line([(8, 9), (8, 13)], "amber")
    d.px([(7, 12), (9, 12), (6, 11), (10, 11)], "amber")
    d.px([(12, 8), (12, 10)], "amber")
    # Old conduit stub stamped on the plate (struck through).
    d.px([(11, 13), (12, 13), (13, 13)], "stone")
    d.line([(10, 14), (13, 12)], "red")
    # Clue lamp on the ground socket.
    d.rect(18, 34, 20, 36, "lamp")
    # Moss creeping over the plate's lower edge keeps it in the plate's world.
    d.px([(2, 17), (3, 17), (3, 18), (14, 17), (15, 17)], "moss")
    d.px([(2, 16), (15, 16)], "moss_light")
    # The pier's ivy grows back across the newer cable in two places.
    d.px([(6, 23), (7, 24), (8, 24), (9, 25), (10, 25), (11, 26), (7, 23)], "moss")
    d.px([(8, 23), (10, 24), (12, 26)], "moss_light")
    d.px([(5, 30), (6, 31), (7, 31), (8, 32), (9, 31), (10, 30), (11, 31)], "moss")
    d.px([(7, 30), (9, 30)], "moss_light")
    d.px([(13, 37), (14, 37), (15, 38), (19, 38), (21, 37)], "moss")
    return [sh, s, d], (W, H), (-20, -12), (18, 34, 3, 3)


def relay_cabinet():
    """Relay: an open junction cabinet at the relay mast with a rewritten
    circuit plan on its board, cabled to the mast."""
    W, H = 32, 40
    sh = shadow(W, H, (2, 31, 29, 39))
    s = Canvas(W, H)
    # Stone plinth.
    s.rect(4, 30, 25, 35, "ink")
    s.rect(5, 31, 24, 34, "stone")
    s.rect(5, 31, 24, 31, "stone_hi")
    s.rect(5, 34, 24, 34, "stone_dark")
    # Cabinet: top face, front, right side.
    s.poly([(7, 6), (21, 6), (24, 3), (10, 3)], "verd_light", "ink")
    s.rect(6, 6, 21, 30, "ink")
    s.rect(7, 7, 20, 29, "verd")
    s.poly([(21, 6), (24, 3), (24, 27), (21, 30)], "verd_dark", "ink")
    # Open recess and the board inside.
    s.rect(8, 8, 19, 25, "ink")
    s.rect(9, 9, 18, 24, "teal_dark")
    # Door swung open to the west, its inner face catching the light.
    s.poly([(6, 7), (1, 10), (1, 31), (6, 29)], "verd", "ink")
    s.poly([(5, 9), (2, 11), (2, 29), (5, 28)], "verd_light")
    s.line([(2, 11), (2, 29)], "brass")
    s.px([(4, 13), (4, 25)], "brass_hi")
    # Weathering on the front face.
    s.px([(7, 7), (8, 27), (19, 27), (20, 8)], "verd_light")
    s.px([(7, 20), (20, 16), (7, 12)], "verd_dark")
    # Brass trim and vents.
    s.rect(7, 26, 20, 26, "brass")
    for x in (9, 12, 15, 18):
        s.px([(x, 28)], "deep")
    # Mast cable: from the cabinet's side, over the plinth to the mast.
    s.rect(24, 21, 31, 23, "ink")
    s.rect(25, 22, 31, 22, "teal")
    d = Canvas(W, H)
    # Circuit plan: teal traces overwritten by amber and red corrections.
    d.line([(10, 11), (16, 11), (16, 15)], "glow")
    d.line([(10, 18), (13, 18), (13, 22), (17, 22)], "glow")
    d.line([(11, 13), (11, 16), (15, 16)], "amber")
    d.line([(14, 13), (17, 19)], "red")
    d.line([(12, 20), (16, 17)], "red")
    d.px([(10, 11), (16, 15), (17, 22)], "glow_hi")
    # Taped revision note on the door.
    d.rect(2, 17, 4, 20, "stone_hi")
    d.px([(3, 18)], "red")
    # Clue lamp on the cabinet crown.
    d.rect(16, 3, 18, 5, "lamp")
    return [sh, s, d], (W, H), (-18, -16), (16, 3, 3, 3)


def echo_node():
    """Echo node: a ground-staked acoustic ranging post with a ring head."""
    W, H = 24, 40
    sh = shadow(W, H, (3, 33, 21, 39))
    s = Canvas(W, H)
    # Hex base plate bolted to the paving.
    s.poly([(5, 33), (9, 31), (15, 31), (19, 33), (15, 36), (9, 36)], "bronze", "ink")
    s.line([(9, 32), (15, 32)], "brass_light")
    s.px([(7, 34), (17, 34)], "brass_hi")
    # Post.
    s.rect(10, 13, 13, 33, "ink")
    s.rect(11, 13, 12, 32, "verd")
    s.rect(11, 13, 11, 32, "verd_light")
    s.rect(10, 22, 13, 24, "brass")
    # Ring transducer head, seen from slightly above.
    s.ellipse((3, 3, 20, 15), "ink")
    s.ellipse((4, 4, 19, 14), "brass")
    s.ellipse((6, 6, 17, 12), "ink")
    s.ellipse((7, 7, 16, 11), "teal_dark")
    s.line([(5, 6), (9, 4)], "brass_hi")
    # Ground spike cable.
    s.line([(13, 27), (17, 30), (20, 30)], "ink")
    s.px([(21, 31), (21, 30)], "ink")
    d = Canvas(W, H)
    # Emitter and listening rings.
    d.rect(10, 8, 13, 10, "glow")
    d.px([(11, 9), (12, 9)], "glow_hi")
    d.px([(7, 9), (16, 9)], "teal")
    d.px([(8, 8), (15, 8), (8, 10), (15, 10)], "teal")
    # Clue lamp on the post collar.
    d.rect(11, 25, 13, 27, "lamp")
    return [sh, s, d], (W, H), (-12, -30), (11, 25, 3, 3)


def survey_hatch():
    """Survey entrance: a stone-framed service hatch with its lid raised and
    steps dropping to the survey annex."""
    W, H = 48, 32
    sh = shadow(W, H, (2, 22, 46, 31))
    s = Canvas(W, H)
    # Raised lid (behind the opening), underside visible.
    s.poly([(11, 1), (37, 1), (39, 12), (9, 12)], "verd_dark", "ink")
    s.poly([(13, 3), (35, 3), (36, 10), (12, 10)], "verd")
    s.line([(13, 3), (35, 3)], "verd_light")
    # Stone frame.
    s.poly([(4, 12), (44, 12), (46, 27), (2, 27)], "ink")
    s.poly([(5, 13), (43, 13), (44, 26), (4, 26)], "stone")
    s.line([(5, 13), (43, 13)], "stone_hi")
    s.line([(4, 26), (44, 26)], "stone_dark")
    s.px([(14, 13), (27, 13), (37, 26), (20, 26)], "ink")
    # Opening: steps recede and darken as they drop toward the annex.
    s.rect(9, 15, 39, 24, "ink")
    s.poly([(9, 15), (12, 15), (14, 24), (9, 24)], "deep")
    s.poly([(36, 15), (39, 15), (39, 24), (34, 24)], "olive")
    s.rect(12, 16, 36, 16, "stone_light")
    s.rect(12, 17, 36, 17, "stone_dark")
    s.rect(14, 19, 34, 19, "stone_dark")
    s.rect(14, 20, 34, 20, "olive")
    s.rect(16, 22, 32, 22, "olive")
    s.rect(16, 23, 32, 23, "deep")
    # Worn tread pixels.
    s.px([(18, 16), (25, 16), (31, 16), (20, 19), (28, 19)], "stone_hi")
    # Brass hinges.
    s.rect(14, 11, 17, 13, "ink")
    s.rect(15, 11, 16, 12, "brass_light")
    s.rect(31, 11, 34, 13, "ink")
    s.rect(32, 11, 33, 12, "brass")
    # Stone texture on the frame.
    s.px([(7, 15), (8, 21), (41, 15), (40, 21), (6, 24), (42, 24)], "stone_light")
    s.px([(6, 18), (42, 18), (7, 23), (41, 23)], "stone_dark")
    d = Canvas(W, H)
    # Teal lip lights along the front edge.
    for x in range(12, 37, 4):
        d.px([(x, 25), (x + 1, 25)], "glow")
    # Embossed survey insignia on the lid underside (unlit brass, so the lid
    # reads as a raised steel slab rather than a screen): ring and level line.
    d.ellipse((20, 4, 28, 9), "brass")
    d.ellipse((22, 5, 26, 8), "verd")
    d.line([(16, 7), (32, 7)], "bronze")
    d.px([(20, 6), (21, 5)], "brass_light")
    # Rivets along the lid edge.
    d.px([(14, 4), (34, 4), (13, 9), (35, 9)], "verd_light")
    # Moss in the frame joints.
    d.px([(2, 26), (3, 25), (45, 26), (44, 25), (24, 27)], "moss")
    # Clue lamp on the frame (survey solved turns it teal).
    d.rect(7, 13, 9, 15, "lamp")
    return [sh, s, d], (W, H), (-24, -12), (7, 13, 3, 3)


def bypass_waymark():
    """Bypass lane: a service-path waymark pointing round the patrol."""
    W, H = 20, 32
    sh = shadow(W, H, (3, 27, 16, 31))
    s = Canvas(W, H)
    s.rect(8, 8, 11, 29, "ink")
    s.rect(9, 8, 10, 28, "bronze")
    s.rect(9, 8, 9, 28, "brass")
    s.rect(7, 27, 12, 29, "ink")
    s.rect(8, 27, 11, 28, "stone")
    # Arrow sign pointing north-east, along the bypass.
    s.poly([(2, 6), (14, 6), (18, 10), (14, 14), (2, 14)], "ink")
    s.poly([(3, 7), (14, 7), (17, 10), (14, 13), (3, 13)], "verd")
    s.line([(3, 7), (14, 7)], "verd_light")
    d = Canvas(W, H)
    d.line([(5, 10), (13, 10)], "glow")
    d.px([(12, 9), (12, 11), (11, 8), (11, 12)], "glow")
    # Lamp lit while the patrol is active (runtime dims it afterwards).
    d.rect(8, 2, 11, 5, "ink")
    d.rect(9, 3, 10, 4, "glow")
    d.px([(4, 29), (5, 30), (14, 30), (15, 29)], "moss")
    return [sh, s, d], (W, H), (-10, -22), (9, 3, 2, 2)


def patrol_field_token():
    """Field-scale patrol automaton replacing the old red square. Palette and
    parts follow the unapproved battle pilot (steel plates, brass chest,
    teal visor, shoulder rod); it is a scene prop, not the battle sprite."""
    W, H = 44, 48
    sh = shadow(W, H, (3, 39, 41, 47))
    s = Canvas(W, H)
    # Feet and legs.
    for x0 in (7, 25):
        s.rect(x0, 39, x0 + 11, 45, "p_o")
        s.rect(x0 + 1, 40, x0 + 10, 44, "p3")
        s.rect(x0 + 1, 40, x0 + 10, 40, "p5")
        s.rect(x0 + 1, 43, x0 + 4, 44, "p_c")
        s.rect(x0 + 2, 31, x0 + 8, 39, "p_o")
        s.rect(x0 + 3, 32, x0 + 7, 38, "p4")
        s.rect(x0 + 3, 32, x0 + 4, 38, "p5")
        s.rect(x0 + 3, 34, x0 + 7, 35, "p2")
    # Pelvis.
    s.rect(10, 27, 33, 32, "p_o")
    s.rect(11, 28, 32, 31, "p2")
    s.rect(11, 28, 32, 28, "p4")
    # Torso.
    s.rect(7, 11, 36, 29, "p_o")
    s.rect(8, 12, 35, 28, "p3")
    s.rect(8, 12, 35, 13, "p5")
    s.rect(8, 12, 9, 28, "p4")
    s.rect(33, 14, 35, 28, "p2")
    # Brass chest plate.
    s.rect(14, 14, 29, 25, "p_o")
    s.rect(15, 15, 28, 24, "p_c")
    s.rect(15, 15, 28, 15, "p_e")
    s.rect(15, 15, 15, 24, "p_d")
    s.rect(15, 24, 28, 24, "p_b")
    # Shoulders.
    for x0 in (1, 33):
        s.rect(x0, 10, x0 + 9, 19, "p_o")
        s.rect(x0 + 1, 11, x0 + 8, 18, "p4")
        s.rect(x0 + 1, 11, x0 + 8, 12, "p6")
        s.rect(x0 + 1, 17, x0 + 8, 18, "p2")
    # Arms.
    for x0 in (2, 35):
        s.rect(x0, 19, x0 + 6, 33, "p_o")
        s.rect(x0 + 1, 20, x0 + 5, 32, "p3")
        s.rect(x0 + 1, 20, x0 + 2, 32, "p4")
        s.rect(x0 + 1, 26, x0 + 5, 27, "p_b")
        s.rect(x0, 33, x0 + 6, 36, "p_o")
        s.rect(x0 + 1, 33, x0 + 5, 35, "p2")
    # Head.
    s.rect(15, 3, 28, 12, "p_o")
    s.rect(16, 4, 27, 11, "p4")
    s.rect(16, 4, 27, 5, "p6")
    s.rect(17, 7, 26, 9, "p_x")
    # Shoulder rod (antenna) on the right shoulder.
    s.rect(38, 0, 40, 10, "p_o")
    s.rect(39, 1, 39, 9, "p5")
    d = Canvas(W, H)
    # Teal visor sweep and chest core.
    d.rect(18, 8, 25, 8, "p_z")
    d.px([(21, 8), (22, 8)], "p_w")
    d.rect(20, 18, 23, 21, "p_x")
    d.rect(21, 19, 22, 20, "p_z")
    d.px([(21, 19)], "p_w")
    d.px([(39, 1)], "p_z")
    # Plate seams, bolts and grime.
    d.px([(11, 15), (31, 15), (11, 25), (31, 25)], "p6")
    d.line([(17, 22), (26, 22)], "p_b")
    d.px([(9, 27), (12, 30), (30, 30), (34, 22)], "p1")
    d.px([(4, 14), (36, 14)], "p_e")
    # Lower torso falls into shadow: checker dither p3/p2 under the chest plate.
    for y in (26, 27):
        for x in range(10, 33):
            if (x + y) % 2 == 0:
                d.px([(x, y)], "p2")
    # Knee caps and ankle joints.
    for x0 in (9, 27):
        d.rect(x0, 33, x0 + 4, 34, "p6")
        d.px([(x0 + 1, 33)], "p_e")
        d.px([(x0, 38), (x0 + 4, 38)], "p_o")
    # Head side shading and brow rivets.
    d.rect(26, 6, 27, 11, "p3")
    d.px([(17, 5), (26, 5)], "p_e")
    # Warm ground bounce on boot fronts (sandstone plaza).
    d.px([(9, 44), (10, 44), (27, 44), (28, 44)], "p_d")
    # Boot soles 14 px below the unchanged contact point; head clears the UI label.
    return [sh, s, d], (W, H), (-22, -31), None


FIXTURES = [
    ("discarded-conduit", "trace:0", discarded_conduit),
    ("maintenance-marker", "trace:1", maintenance_marker),
    ("relay-cabinet", "relay", relay_cabinet),
    ("echo-node", "assist", echo_node),
    ("survey-hatch", "survey", survey_hatch),
    ("bypass-waymark", "bypass", bypass_waymark),
    ("patrol-token", "patrol", patrol_field_token),
]
LAYER_NAMES = ["contact-shadow", "structure", "identity-detail"]


def png_bytes(img):
    buf = BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


def merged(layers):
    out = Image.new("RGBA", layers[0].img.size, (0, 0, 0, 0))
    for layer in layers:
        out = Image.alpha_composite(out, layer.img)
    return out


def write_ora(path, layers, size):
    root = ET.Element("image", {"version": "0.0.3", "w": str(size[0]), "h": str(size[1])})
    stack = ET.SubElement(root, "stack")
    with ZipFile(path, "w") as z:
        z.writestr("mimetype", "image/openraster", compress_type=ZIP_STORED)
        # OpenRaster lists the top layer first.
        for index in reversed(range(len(layers))):
            src = f"data/{index:02d}-{LAYER_NAMES[index]}.png"
            z.writestr(src, png_bytes(layers[index].img), compress_type=ZIP_DEFLATED)
            ET.SubElement(stack, "layer", {"name": LAYER_NAMES[index], "src": src, "x": "0", "y": "0",
                                           "opacity": "1.0", "visibility": "visible", "composite-op": "svg:src-over"})
        flat = merged(layers)
        z.writestr("mergedimage.png", png_bytes(flat), compress_type=ZIP_DEFLATED)
        thumb = flat.copy()
        thumb.thumbnail((256, 256), Image.NEAREST)
        z.writestr("Thumbnails/thumbnail.png", png_bytes(thumb), compress_type=ZIP_DEFLATED)
        z.writestr("stack.xml", ET.tostring(root, encoding="utf-8", xml_declaration=True), compress_type=ZIP_DEFLATED)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--runtime", type=Path, default=RUNTIME)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    args.runtime.mkdir(parents=True, exist_ok=True)
    items = []
    for slug, site, build in FIXTURES:
        layers, size, offset, lamp = build()
        stem = f"{PREFIX}_{slug}-pixel-fixture_unapproved-v01_{STAMP}"
        flat = merged(layers)
        data = png_bytes(flat)
        (args.out / f"{stem}.png").write_bytes(data)
        (args.runtime / f"{stem}.png").write_bytes(data)
        write_ora(args.out / f"{stem}.ora", layers, size)
        items.append({
            "purpose": slug, "clueSite": site, "size": list(size), "offsetFromSitePoint": list(offset),
            "lampRect": list(lamp) if lamp else None, "layers": LAYER_NAMES,
            "png": f"{stem}.png", "ora": f"{stem}.ora",
            "pngSha256": sha256(data).hexdigest(), "hashAlgorithm": "sha256-bytes",
        })
    manifest = {
        "project": "rpg-2-star-ocean-the-second", "scene": "scifi.outskirts (Yonkers outskirts surface)",
        "status": "UNAPPROVED v01; runtime candidate drawn by game/scripts/yonkers_outskirts_fixture_layer.gd",
        "method": "Hand-placed rectangles/lines/polygons/pixels with no anti-aliasing; no generated, traced or resampled image.",
        "displayScale": "1 texel = 1 logical px in the 640x360 view (nearest filter)",
        "author": str(Path(__file__).relative_to(ROOT)).replace("\\", "/"),
        "runtimeDir": "game/assets/props/yonkers-outskirts-fixtures",
        "assets": items,
    }
    path = args.out / f"{PREFIX}_seven-clue-fixtures-manifest_unapproved-v01_{STAMP}.json"
    path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
