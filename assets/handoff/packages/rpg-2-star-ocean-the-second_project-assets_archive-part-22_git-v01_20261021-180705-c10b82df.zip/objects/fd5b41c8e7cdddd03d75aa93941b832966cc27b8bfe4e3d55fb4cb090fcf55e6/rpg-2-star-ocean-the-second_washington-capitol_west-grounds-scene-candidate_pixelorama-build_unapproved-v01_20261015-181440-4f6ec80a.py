"""UNAPPROVED Washington (U.S. Capitol west grounds) exploration-scene candidate, layered for Pixelorama.

Deterministic Python tool authored and run by Claude (Claude Code). It paints ONE 1280x720 pixel-art
exploration scene from a fixed 38-colour palette into the 9-layer stack of the production spec
(docs/qa/...washington-capitol_pixelorama-scene-production-spec_technical-unapproved-v01_20261015-174500-5e0d2b71.md)
and writes it as a native Pixelorama .pxo (pxo_version 7) plus an .ora, a flattened PNG and a manifest.
Nothing here is accepted art. Nothing is wired into the game runtime.

Camera: top-down with mild 3/4 front faces. Top of frame = east (Capitol west terrace + stairs), bottom = west
(toward the Mall). Site arrangement follows the CVC "My Capitol" guide page 20 visual audit and the AOC pages:
open West Front Lawn on the axis, curved walks through tree belts on both flanks, benches along the paths.
NOT drawn (deliberately): any moat, basin, pool or water; any compass medallion; the Summerhouse (NW corner of the
grounds, far outside this ~47 m x 26 m crop); the western road loop (outside the scene).
Game fiction layered on top (not site fact): partial collapse of one terrace-wall bay, overgrowth, a survey post,
patrol-route beacons, cordon tape.

Modes
  preview <dir>   render everything into <dir> (outside the repo) for visual iteration; writes nothing in the repo
  build           write candidate files (game/assets/environments/candidates/<RUN>/) and QA previews
                  (outputs/<RUN>/); refuses to overwrite a different existing file
  check           technical gates on the built files (palette, binary alpha, layer stack, occlusion limits,
                  Y-sort, determinism) and, unless --no-pixelorama, Pixelorama 1.2.3 headless flat and
                  --split-layers exports of temp copies, run with APPDATA redirected to a temp dir so the open
                  GUI's %APPDATA%\\pixelorama (config.ini, logs, .running crash marker) is never touched.
                  --write-report writes the JSON report into outputs/<RUN>/ (never overwrites).

Run: python -I -B <this file> preview <tempdir> | build | check [--write-report] [--no-pixelorama]
"""
import argparse, hashlib, io, json, math, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
STAMP = "20261015-181440"
RUN_ID = "4f6ec80a"
RUN = f"wdc-capitol-west-v01_{STAMP}-{RUN_ID}"
BASE = "wdc-capitol-west-v01"
CAND_REL = f"game/assets/environments/candidates/{RUN}"
OUT_REL = f"outputs/{RUN}"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))
SPEC_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_pixelorama-scene-production-spec_"
            "technical-unapproved-v01_20261015-174500-5e0d2b71.md")
AUDIT_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_site-map-visual-audit_"
             "qa-note-unapproved-v01_20261015-175832-86c8c714.md")
HEROINE_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
               "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
PIXELORAMA_DEFAULT = ("C:/Users/hkzha/AppData/Local/Programs/Pixelorama-1.2.3/"
                      "Pixelorama-Windows-64bit/Pixelorama.exe")
PIXELORAMA_VERSION = "v1.2.3-stable"
GODOT_REL = "work/tooling/godot-4-7-2/Godot_v4.7.2-stable_win64_console.exe"      # gitignored local tooling
W, H = 1280, 720
WIN_LONG_PREFIX = "\\\\?\\"

LAYERS = ["ground-base", "paving-walks", "terrace-walls", "ground-detail", "cast-shadows",
          "props-low", "survey-post", "fg-occlusion", "guides"]                     # bottom -> top
ART_LAYERS = LAYERS[:8]                                                            # guides: hidden, locked

# ============================================================================ palette (38 art colours)
PALETTE = [
    ("ink", "1a1c22"),
    ("g0", "1f3324"), ("g1", "2c4a2c"), ("g2", "3d6234"), ("g3", "557a3c"), ("g4", "6f9145"),
    ("g5", "93ad55"), ("g6", "b9c26c"),
    ("d0", "7f7c45"), ("d1", "a99a5e"),
    ("f0", "16262a"), ("f1", "223d3a"), ("f2", "2f5644"),
    ("s0", "3a2c22"), ("s1", "5a4430"), ("s2", "7d6345"), ("s3", "a08458"),
    ("m0", "4a4c58"), ("m1", "6e6f78"), ("m2", "93918f"), ("m3", "b8b3a8"), ("m4", "d6d0c2"), ("m5", "ece6d6"),
    ("p0", "6b5f52"), ("p1", "8d7f6c"), ("p2", "ab9d86"), ("p3", "c6b99e"),
    ("k0", "232a36"), ("k1", "3a4656"), ("k2", "5a6a7c"), ("k3", "8d9cab"),
    ("c0", "1f6f78"), ("c1", "49c6cf"), ("c2", "b4f4f0"),
    ("o0", "a34a1e"), ("o1", "e07a2e"), ("o2", "f4b860"),
    ("fl", "c79ad0"),
]
GUIDE_PALETTE = [("gd-walk", "3cdcff"), ("gd-block", "ff285a"), ("gd-pin", "ffe600"), ("gd-tick", "ffffff"),
                 ("gd-route", "ff78ff")]
ALL_PAL = PALETTE + GUIDE_PALETTE
I = {n: i for i, (n, _) in enumerate(ALL_PAL)}
RGB = np.array([[int(h[j:j + 2], 16) for j in (0, 2, 4)] for _, h in ALL_PAL], np.uint8)
N_ART = len(PALETTE)

GR = [I[n] for n in ("g0", "g1", "g2", "g3", "g4", "g5", "g6")]                 # grass ramp
FOL = [I[n] for n in ("f0", "f1", "f2", "g2", "g3", "g4", "g5")]                # tree canopy ramp
STONE = [I[n] for n in ("ink", "m0", "m1", "m2", "m3", "m4", "m5")]             # marble / granite ramp
PAVE = [I[n] for n in ("m0", "p0", "p1", "p2", "p3", "m4")]                     # walk paving ramp
SOIL = [I[n] for n in ("ink", "s0", "s1", "s2", "s3")]
METAL = [I[n] for n in ("ink", "k0", "k1", "k2", "k3")]

SHADE = {  # opaque cast-shadow colour for each art colour underneath (no semi-alpha anywhere)
    "ink": "ink", "g0": "f0", "g1": "g0", "g2": "g1", "g3": "g1", "g4": "g2", "g5": "g3", "g6": "g4",
    "d0": "g1", "d1": "d0", "f0": "f0", "f1": "f0", "f2": "f1",
    "s0": "ink", "s1": "s0", "s2": "s1", "s3": "s1",
    "m0": "ink", "m1": "m0", "m2": "m1", "m3": "m1", "m4": "m2", "m5": "m3",
    "p0": "m0", "p1": "p0", "p2": "p0", "p3": "p1",
    "k0": "ink", "k1": "k0", "k2": "k1", "k3": "k2", "c0": "k0", "c1": "c0", "c2": "c0",
    "o0": "s0", "o1": "o0", "o2": "o1", "fl": "s1",
}
SHADE_LUT = np.arange(len(ALL_PAL), dtype=np.int16)
for _a, _b in SHADE.items():
    SHADE_LUT[I[_a]] = I[_b]

# ============================================================================ scene geometry (logical px)
FACADE_Y1 = 24            # facade base strip rows 0..23
EDGE_Y = 106              # terrace deck edge = top of the west retaining-wall face
WALL_H = 42               # wall face rows 106..147 (compressed; real height unverified)
FOOT_Y = EDGE_Y + WALL_H  # 148: lawn level at the wall foot
BAL_H = 20                # balustrade rows 86..105
STAIR_X0, STAIR_X1 = 546, 734       # stair flight between the cheek walls (188 px ~ 7 m, unverified)
CHEEK_W = 14
STAIR_BOT = 202           # bottom tread row (stairs project 54 px onto the lawn plane)
FORE = (452, 202, 828, 252)          # paved forecourt at the stair foot (x0, y0, x1, y1), plain paving
AXIS = (600, 680)                    # axial walk x range, runs to the bottom (west) edge
WALK_W = 36
LEFT_WALK = [(500, 230), (322, 242), (244, 352), (206, 740)]       # cubic Bezier control points
RIGHT_WALK = [(779, 230), (950, 248), (1046, 372), (1056, 740)]   # near-mirror, not exact (hand-drawn plan)
BRANCH_W = 26                        # narrower walk branching off toward the NW (Summerhouse side, off-canvas)
LEFT_BRANCH = [(222, 520), (160, 548), (80, 572), (-30, 600)]
COLLAPSE = (880, 1104)               # collapsed terrace-wall bay (game fiction)
POST = (900, 380)                    # survey-post pivot: base centre (x, contact row y)
PIERS = [p for k in range(8) for p in (482 - 64 * k, W - 1 - (482 - 64 * k))]
PATROL = [(640, 214), (800, 262), (856, 300), (900, 396), (1010, 444), (1046, 604), (700, 640), (640, 640)]
SURVEY_GRID = [(x, y) for y in (452, 492, 532) for x in (760, 800, 840, 880)]       # orange pin flags
ENTRY = (640, 700)


# ============================================================================ small helpers
def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > 247 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def rp(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(p):
    with open(_fs(p), "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha_text(b):
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def blank():
    return np.full((H, W), -1, np.int16)


def rng_for(*key):
    return np.random.default_rng(int.from_bytes(hashlib.sha256(repr(key).encode()).digest()[:8], "little"))


def vnoise(seed, cell, h=H, w=W):
    """Smooth value noise in [0,1] (bicubic-upsampled random lattice), deterministic for a seed."""
    r = rng_for("noise", seed, cell, h, w)
    gh, gw = h // cell + 4, w // cell + 4
    g = r.random((gh, gw), dtype=np.float32)
    a = np.asarray(Image.fromarray(g, "F").resize((gw * cell, gh * cell), Image.BICUBIC))[cell:cell + h, cell:cell + w]
    return (a - a.min()) / (a.max() - a.min() + 1e-9)


def despeckle(m, passes=2, valid=None):
    """Replace pixels whose 4 neighbours all differ from them: keeps clusters deliberate, no lone noise."""
    for _ in range(passes):
        p = np.pad(m, 1, mode="edge")
        up, dn, lf, rt = p[:-2, 1:-1], p[2:, 1:-1], p[1:-1, :-2], p[1:-1, 2:]
        iso = (m != up) & (m != dn) & (m != lf) & (m != rt) & (m >= 0)
        if valid is not None:
            iso &= valid
        rep = np.where(lf == rt, lf, np.where(up == dn, up, np.where(lf >= 0, lf, up)))
        m = np.where(iso & (rep >= 0), rep, m)
    return m


def ramp_shift(idx, ramp, d):
    """Move palette index idx by d steps along ramp (clamped); colours not on the ramp map to its middle."""
    pos = {v: k for k, v in enumerate(ramp)}
    k = pos.get(int(idx), len(ramp) // 2)
    return ramp[max(0, min(len(ramp) - 1, k + d))]


def ramp_shift_arr(arr, ramp, d):
    lut = np.arange(len(ALL_PAL), dtype=np.int16)
    for k, v in enumerate(ramp):
        lut[v] = ramp[max(0, min(len(ramp) - 1, k + d))]
    out = arr.copy()
    ok = arr >= 0
    out[ok] = lut[arr[ok]]
    return out


def put(layer, mask, idx):
    layer[mask] = idx


def rect(layer, x0, y0, x1, y1, idx):
    """Fill inclusive rect, clipped."""
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W - 1, x1), min(H - 1, y1)
    if x0 <= x1 and y0 <= y1:
        layer[y0:y1 + 1, x0:x1 + 1] = idx


def setpx(layer, x, y, idx):
    if 0 <= x < W and 0 <= y < H:
        layer[y, x] = idx


def line(layer, x0, y0, x1, y1, idx):
    n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
    for t in np.linspace(0, 1, n):
        setpx(layer, int(round(x0 + (x1 - x0) * t)), int(round(y0 + (y1 - y0) * t)), idx)


def stamp(layer, x, y, rows, cmap, under=None, ramp=None, mask=None):
    """Draw an ASCII sprite. cmap: char -> palette name, or int offset along `ramp` relative to `under`."""
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if ch == ".":
                continue
            px, py = x + i, y + j
            if not (0 <= px < W and 0 <= py < H) or (mask is not None and not mask[py, px]):
                continue
            v = cmap[ch]
            if isinstance(v, int):
                if isinstance(under, np.ndarray):
                    base = under[py, px]
                else:
                    base = under if under is not None else ramp[len(ramp) // 2]
                layer[py, px] = ramp_shift(base, ramp, v)
            else:
                layer[py, px] = I[v]


def composite_idx(layers, names):
    out = layers[names[0]].copy()
    for n in names[1:]:
        m = layers[n] >= 0
        out[m] = layers[n][m]
    return out


def bezier(pts, n=1600):
    t = np.linspace(0, 1, n)[:, None]
    p = [np.array(q, float) for q in pts]
    c = ((1 - t) ** 3) * p[0] + 3 * ((1 - t) ** 2) * t * p[1] + 3 * (1 - t) * t * t * p[2] + (t ** 3) * p[3]
    seg = np.r_[0, np.cumsum(np.hypot(*np.diff(c, axis=0).T))]
    return c, seg


def band_coords(pts, half):
    """Per-pixel (s along curve, signed t across) for pixels within `half`+6 px of a cubic Bezier."""
    c, seg = bezier(pts)
    tang = np.gradient(c, axis=0)
    tang /= np.linalg.norm(tang, axis=1, keepdims=True)
    S = np.full((H, W), np.nan, np.float32)
    T = np.full((H, W), np.nan, np.float32)
    x0 = int(max(0, c[:, 0].min() - half - 8)); x1 = int(min(W, c[:, 0].max() + half + 9))
    y0 = int(max(0, c[:, 1].min() - half - 8)); y1 = int(min(H, c[:, 1].max() + half + 9))
    xs = np.arange(x0, x1)
    for y in range(y0, y1):
        dx = xs[:, None] - c[None, :, 0]
        dy = y - c[None, :, 1]
        d2 = dx * dx + dy * dy
        k = d2.argmin(axis=1)
        d = np.sqrt(d2[np.arange(len(xs)), k])
        sgn = np.sign(tang[k, 0] * (y - c[k, 1]) - tang[k, 1] * (xs - c[k, 0]))
        ok = d <= half + 6
        S[y, xs[ok]] = seg[k[ok]]
        T[y, xs[ok]] = (d * sgn)[ok]
    return S, T, c


# ============================================================================ hand-authored stamps
TUFTS = [  # grass clumps, relative to the tone underneath: a=-2 b=-1 e=0 c=+1 d=+2 (tips lit, base shaded)
    ["..d..", ".c.c.", "cbcbc", ".bbb.", "..a.."],
    [".c...c", "c.c.c.", ".cbcbc", "bbcbb.", ".aaa.."],
    ["c..c..", ".cc.c.", "bccbc.", ".bbbb.", "..aa.."],
    ["..c.", ".dc.", "cbcc", "bbb.", ".a.."],
    [".c.c..", "cdc.c.", "bcbcb.", ".bbab.", "..a..."],
    ["...c...", ".c.cc..", "c.cbc.c", "bcbbcb.", ".abba..", "..aa..."],
    ["c.c", "bcb", ".a."],
    [".b.", "b.b", ".a."],
]
TUFT_MAP = {"a": -2, "b": -1, "e": 0, "c": 1, "d": 2}
TALL_TUFTS = [  # overgrown edges: longer blades
    ["d...d.", "c..c.c", ".c.cb.", "bccb..", "abba..", ".aa..."],
    [".d..d", "c.cc.", "c.c.b", "bcbb.", "abba.", ".aa.."],
    ["..d...", ".dc.d.", "c.cc.c", "bcbcb.", ".abba.", "..aa.."],
]
BENCH = [
    ".K......................K.",
    ".KWWWWWWWWWWWWWWWWWWWWWWK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    ".KwwwwwwwwwwwwwwwwwwwwwwK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    "KkkkkkkkkkkkkkkkkkkkkkkkkK",
    "KWWWWWWWWWWWWWWWWWWWWWWWWK",
    "KwwwwwwwwwwwwwwwwwwwwwwwwK",
    "KWWWWWWWWWWWWWWWWWWWWWWWWK",
    "KvvvvvvvvvvvvvvvvvvvvvvvvK",
    ".KkK..................KkK.",
    ".K.K..................K.K.",
]
BENCH_BROKEN = [
    ".K......................K.",
    ".KWWWWWWWWWWWWWWW.......K.",
    ".KvvvvvvvvvvvvvvvK......K.",
    ".KwwwwwwwwwwwwwwwwwwwwwwK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    "KkkkkkkkkkkkkkkkkkkkkkkkkK",
    "KWWWWWWWWWWWWW..WWWWWWWWWK",
    "KwwwwwwwwwwwwvK.wwwwwwwwwK",
    "K..............vWWWWWWWWWK",
    "K..........WWWvvvvvvvvvvvK",
    ".KkK.........vv.......KkK.",
    ".K.K..................K.K.",
]
BENCH_MAP = {"K": "k0", "k": "k1", "W": "s3", "w": "s2", "v": "s1"}
CRATE = [
    ".kkkkkkkkkkkk.",
    "kHHHHHHHHHHHHk",
    "kHhhhhhhhhhhhk",
    "kHhhhhhhhhhhhk",
    "kKKKKKKKKKKKKk",
    "kMMMMMMMMMMMMk",
    "kMoooooooooMMk",
    "kMOOOOOOOOOMMk",
    "kMMMMcCMMMMMMk",
    "kMMMMccMMMMMMk",
    "kMMMMMMMMMMMMk",
    ".kkkkkkkkkkkk.",
]
CRATE_MAP = {"k": "k0", "H": "k3", "h": "k2", "K": "k1", "M": "k1", "o": "o1", "O": "o0", "c": "c0", "C": "c1"}
BEACON = [  # patrol-route marker (about 16 px: below the 48 px actor's waist)
    ".C.",
    "CXC",
    ".C.",
    ".k.",
    ".kO",
    ".kO",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    "kKk",
    "KKK",
]
BEACON_MAP = {"C": "c1", "X": "c2", "k": "k2", "K": "k0", "O": "o1"}
STAKE = [".o", "oO", "w.", "w.", "w.", "w.", "W.", "W."]
STAKE_MAP = {"o": "o1", "O": "o0", "w": "s3", "W": "s1"}
LAMP_STUB = [  # broken cast-iron lamp post, base only
    "..kk..",
    ".kKk..",
    ".kKk..",
    ".kKK..",
    ".kKK..",
    ".kKK..",
    "kkKKk.",
    "kHKKKk",
    "kHKKKk",
    "kKKKKk",
    "KKKKKK",
]
LAMP_MAP = {"k": "k2", "K": "k1", "H": "k3"}
FLOWERS = ["m5", "m5", "o2", "fl", "m5", "o2"]


# ============================================================================ painters
class Scene:
    def __init__(self):
        self.L = {n: blank() for n in LAYERS}
        self.walk_mask = np.zeros((H, W), bool)          # paved (walks, forecourt, deck, stairs)
        self.block = np.zeros((H, W), bool)              # collision footprints (for guides / walkability)
        self.prop_shadow = []                            # (mask) cast-shadow footprints from props/trees
        self.notes = []

    # ------------------------------------------------------------------ ground-base
    def ground_base(self):
        g = self.L["ground-base"]
        n1, n2, n3 = vnoise("lawn1", 128), vnoise("lawn2", 34), vnoise("lawn3", 6)
        v = 0.55 * n1 + 0.3 * n2 + 0.15 * n3
        t = np.full((H, W), I["g3"], np.int16)
        t[v > 0.52] = I["g4"]
        t[v > 0.80] = I["g5"]
        t[v < 0.22] = I["g2"]
        dry = 0.7 * vnoise("dry1", 60) + 0.3 * vnoise("dry2", 6)
        lawnish = (v > 0.45)
        t[(dry > 0.76) & lawnish] = I["d0"]
        t[(dry > 0.83) & lawnish] = I["d1"]
        # wall-foot planting strip (soil) and tree-belt floor (darker, litter)
        y = np.arange(H)[:, None]
        x = np.arange(W)[None, :]
        strip = (y >= FOOT_Y) & (y < FOOT_Y + 14) & ~((x >= STAIR_X0 - CHEEK_W - 2) & (x <= STAIR_X1 + CHEEK_W + 2))
        sn = vnoise("strip", 5)
        t[strip & (sn < 0.55)] = I["s1"]
        t[strip & (sn >= 0.55)] = I["s2"]
        t[strip & (sn < 0.2)] = I["s0"]
        self.belt = self.belt_mask()
        bn = 0.6 * vnoise("belt1", 22) + 0.4 * vnoise("belt2", 5)
        bt = np.where(bn < 0.35, I["g0"], np.where(bn < 0.55, I["g1"], np.where(bn < 0.8, I["g2"], I["s1"])))
        t[self.belt] = bt[self.belt]
        # deck under the facade (terrace): ground-base holds the marble deck too
        deck = self.deck_slabs()
        t[:EDGE_Y, :] = deck[:EDGE_Y, :]
        # worn patrol trail through grass (desire lines), drawn before despeckle so edges stay clumpy
        trail = self.trail_mask()
        tn = vnoise("trail", 4)
        tt = np.where(tn < 0.35, I["s2"], np.where(tn < 0.7, I["d1"], I["d0"]))
        core = trail & (t != I["s1"])
        t[core] = tt[core]
        t[:EDGE_Y, :] = deck[:EDGE_Y, :]
        t = despeckle(t, 2)
        g[:] = t
        self.trail = trail

    def belt_mask(self):
        """Tree-belt floor: outside the curved walks (plus margin) on both flanks, below the wall-foot strip."""
        if hasattr(self, "_belt"):
            return self._belt
        self.lS, self.lT, self.lc = band_coords(LEFT_WALK, WALK_W / 2)
        self.rS, self.rT, self.rc = band_coords(RIGHT_WALK, WALK_W / 2)
        m = np.zeros((H, W), bool)
        jit = (vnoise("beltedge", 11) - 0.5) * 14
        xs = np.arange(W)
        inner = np.zeros((H, W), bool)       # lawn inside the curved walks (the walkable lawn)
        def smooth(a, b, y, y0, y1):
            s = min(1.0, max(0.0, (y - y0) / (y1 - y0)))
            s = s * s * (3 - 2 * s)
            return a * (1 - s) + b * s

        for y in range(FOOT_Y + 10, H):
            xl = np.interp(y, self.lc[:, 1], self.lc[:, 0])
            xr = np.interp(y, self.rc[:, 1], self.rc[:, 0])
            # belt edges follow the walks lower down and ease out to the far corners near the terrace foot
            bl = smooth(112, xl - WALK_W / 2 - 18, y, 236, 336)
            br = smooth(W - 112, xr + WALK_W / 2 + 18, y, 330, 430)     # rubble spill zone stays open longer
            m[y] = (xs < bl + jit[y]) | (xs > br + jit[y])
            if y < 252:          # lawn margin along the terrace foot
                inner[y] = (xs > 196) & (xs < W - 196)
            else:
                inner[y] = (xs > xl + WALK_W / 2) & (xs < xr - WALK_W / 2)
        self._belt = m
        self.inner_lawn = inner
        return m

    def trail_mask(self):
        """Worn patrol desire lines through the grass: gently curved, ragged, only where the route leaves paving."""
        m = np.zeros((H, W), bool)
        jit = vnoise("trailw", 6)
        curves = [([800, 262], [840, 274], [872, 300], [892, 366], 3.2),
                  ([912, 398], [948, 414], [984, 428], [1020, 446], 3.0),
                  ([1046, 604], [940, 640], [810, 628], [690, 640], 2.2)]
        for ax_, b_, c_, d_, wd in curves:
            c, _ = bezier([ax_, b_, c_, d_], 500)
            x0 = int(max(0, c[:, 0].min() - 12)); x1 = int(min(W, c[:, 0].max() + 13))
            y0 = int(max(0, c[:, 1].min() - 12)); y1 = int(min(H, c[:, 1].max() + 13))
            yy, xx = np.mgrid[y0:y1, x0:x1]
            d = np.full(yy.shape, 1e9)
            for px, py in c[::4]:
                d = np.minimum(d, np.hypot(xx - px, yy - py))
            m[y0:y1, x0:x1] |= d < (wd + 2.6 * jit[y0:y1, x0:x1])
        return m

    def deck_slabs(self):
        """Marble terrace deck: large slabs, lit top/left bevels, grime and moss in joints near the edge."""
        t = np.full((H, W), I["m3"], np.int16)
        sw, sh = 30, 13
        y = np.arange(H)[:, None].repeat(W, 1)
        x = np.arange(W)[None, :].repeat(H, 0)
        row = (y - FACADE_Y1) // sh
        off = (row % 2) * (sw // 2)
        col = (x + off) // sw
        u = (x + off) % sw
        v = (y - FACADE_Y1) % sh
        h = (row * 7919 + col * 104729) % 97
        base = np.where(h < 40, I["m4"], np.where(h < 80, I["m3"], I["m4"]))
        t[:] = base
        t[(v == 1) | (u == 1)] = np.where(base == I["m4"], I["m5"], I["m4"])[(v == 1) | (u == 1)]
        t[(v == sh - 1) | (u == sw - 1)] = I["m2"]
        joint = (u == 0) | (v == 0)
        t[joint] = I["m1"]
        pits = vnoise("deckpit", 3) > 0.86
        t[pits & ~joint] = np.where(base == I["m4"], I["m3"], I["m2"])[pits & ~joint]
        moss = (vnoise("deckmoss", 13) > 0.55) & joint
        t[moss] = I["g2"]
        stain = (vnoise("deckstain", 22) > 0.8) & (vnoise("deckstain2", 3) > 0.45)
        t[stain & ~joint & (t == I["m4"])] = I["m3"]
        return t

    # ------------------------------------------------------------------ paving-walks
    def paving(self):
        p = self.L["paving-walks"]
        self.bS, self.bT, self.bc = band_coords(LEFT_BRANCH, BRANCH_W / 2)
        self.curved_walk(p, self.bS, self.bT, "bw", half=BRANCH_W / 2, below=FORE[1] + 20)
        for S, T, key in ((self.lS, self.lT, "lw"), (self.rS, self.rT, "rw")):
            self.curved_walk(p, S, T, key, below=FORE[1])
        # forecourt and axial walk last, so the curved walks start underneath the forecourt edge
        self.flag_paving(p, FORE[0], FORE[1], FORE[2], FORE[3], 24, 12, "fore")
        self.flag_paving(p, AXIS[0], FORE[3], AXIS[1], H - 1, 20, 10, "axis")
        self.walk_mask |= p >= 0

    def flag_paving(self, p, x0, y0, x1, y1, sw, sh, key):
        ys, xs = np.mgrid[y0:y1 + 1, x0:x1 + 1]
        row = (ys - y0) // sh
        off = (row % 2) * (sw // 2)
        col = (xs - x0 + off) // sw
        u = (xs - x0 + off) % sw
        v = (ys - y0) % sh
        h = (row * 7919 + col * 104729 + len(key) * 31) % 101
        base = np.where(h < 34, I["p2"], np.where(h < 70, I["p3"], np.where(h < 92, I["p2"], I["p1"])))
        t = base.copy()
        lit = (v == 1) | (u == 1)
        t[lit] = ramp_shift_arr(base, PAVE, 1)[lit]
        dark = (v == sh - 1) | (u == sw - 1)
        t[dark] = ramp_shift_arr(base, PAVE, -1)[dark]
        joint = (u == 0) | (v == 0)
        t[joint] = I["p0"]
        pits = vnoise(key + "pit", 3)[y0:y1 + 1, x0:x1 + 1] > 0.85
        t[pits & ~joint] = ramp_shift_arr(base, PAVE, -1)[pits & ~joint]
        wear = vnoise(key + "wear", 26)[y0:y1 + 1, x0:x1 + 1]
        t[joint & (wear > 0.55)] = I["g2"]
        t[joint & (wear > 0.75)] = I["g3"]
        # missing slabs: soil + rubble chips
        miss = (h == 3) | (h == 57) | ((h == 88) & (wear > 0.5))
        sn = vnoise(key + "soil", 3)[y0:y1 + 1, x0:x1 + 1]
        t[miss & ~joint] = np.where(sn < 0.5, I["s1"], I["s2"])[miss & ~joint]
        t[miss & (v == 1)] = I["s0"]
        p[y0:y1 + 1, x0:x1 + 1] = t

    def curved_walk(self, p, S, T, key, half=WALK_W / 2, below=FORE[1] + 20):
        band = np.abs(np.nan_to_num(T, nan=99)) <= half
        band &= np.arange(H)[:, None] >= below
        agg = vnoise(key + "agg", 2)
        tone = vnoise(key + "tone", 40)
        t = np.full((H, W), I["p2"], np.int16)
        t[(agg < 0.2) | ((tone < 0.3) & (agg < 0.42))] = I["p1"]
        t[(agg > 0.8) & (tone > 0.35)] = I["p3"]
        Sn = np.nan_to_num(S)
        Tn = np.nan_to_num(T)
        joint = (np.mod(Sn, 34.0) < 1.0) & (np.abs(Tn) < half - 3)
        t[joint] = I["p0"]
        lip = (np.mod(Sn, 34.0) >= 1.0) & (np.mod(Sn, 34.0) < 2.0) & (np.abs(Tn) < half - 3)
        t[lip] = I["p3"]
        # granite curbs (3 px) both sides; the side facing the light is lit
        curb = np.abs(Tn) >= half - 3
        cj = np.mod(Sn + (Tn > 0) * 9, 22.0) < 1.0
        t[curb] = I["m2"]
        t[curb & (np.abs(Tn) < half - 2)] = I["m3"]
        t[curb & (np.abs(Tn) >= half - 1)] = I["m1"]
        t[curb & cj] = I["m1"]
        # weathering: grass in joints, a few broken-out patches showing soil
        gj = (vnoise(key + "gj", 14) > 0.6) & (joint | (curb & cj))
        t[gj] = I["g2"]
        pot = (vnoise(key + "pot", 9) > 0.86) & (np.abs(Tn) < half - 5)
        t[pot] = I["s1"]
        pr = np.pad(pot, 1)
        rimp = ~pot & (pr[2:, 1:-1] | pr[1:-1, 2:]) & (np.abs(Tn) < half - 3)
        t[rimp] = I["p3"]
        t = despeckle(t, 1)
        p[band] = t[band]

    # ------------------------------------------------------------------ terrace-walls
    def terrace(self):
        tw = self.L["terrace-walls"]
        self.facade(tw)
        self.wall_face(tw)
        self.balustrade(tw)
        self.stairs(tw)
        self.collapse(tw)
        b = np.zeros((H, W), bool)
        b[EDGE_Y - BAL_H:FOOT_Y, :] = True
        b[EDGE_Y - BAL_H:FOOT_Y, STAIR_X0:STAIR_X1 + 1] = False
        b[EDGE_Y - BAL_H:STAIR_BOT + 1, STAIR_X0 - CHEEK_W:STAIR_X0] = True
        b[EDGE_Y - BAL_H:STAIR_BOT + 1, STAIR_X1 + 1:STAIR_X1 + 1 + CHEEK_W] = True
        b[:FACADE_Y1, :] = True
        self.block |= b

    def facade(self, tw):
        """Facade base strip of the Capitol's west front: rusticated courses, dark openings, plinth."""
        y = np.arange(FACADE_Y1)[:, None].repeat(W, 1)
        x = np.arange(W)[None, :].repeat(FACADE_Y1, 0)
        course = y // 5
        v = y % 5
        off = (course % 2) * 17
        u = (x + off) % 34
        h = (course * 31 + (x + off) // 34 * 17) % 13
        t = np.where(h < 6, I["m3"], I["m4"]).astype(np.int16)
        t[v == 1] = I["m5"]
        t[v == 0] = I["m1"]
        t[(u == 0) & (v > 0)] = I["m1"]
        t[(u == 33) & (v > 0)] = I["m2"]
        t[y >= FACADE_Y1 - 6] = I["m2"]
        t[y == FACADE_Y1 - 6] = I["m4"]
        t[y == FACADE_Y1 - 5] = I["m3"]
        t[y == FACADE_Y1 - 1] = I["m1"]
        for cx in range(64, W, 128):            # window/door openings (bottoms only; the facade rises off-frame)
            x0 = cx - 9
            t[0:FACADE_Y1 - 7, x0:x0 + 18] = I["m2"]
            t[0:FACADE_Y1 - 8, x0 + 2:x0 + 16] = I["k0"]
            t[0:FACADE_Y1 - 8, x0 + 2] = I["ink"]
            t[FACADE_Y1 - 9, x0 + 2:x0 + 16] = I["m4"]          # sill
            t[FACADE_Y1 - 8, x0 + 1:x0 + 17] = I["m1"]
            if (cx // 128) % 3 == 1:                            # a few panes catch light (old glass)
                t[3:5, x0 + 5:x0 + 7] = I["k2"]
                t[3, x0 + 5] = I["k3"]
        stain = vnoise("facstain", 9)[:FACADE_Y1] > 0.7
        t[stain & (t == I["m4"])] = I["m3"]
        tw[:FACADE_Y1, :] = t

    def wall_face(self, tw):
        rng = rng_for("wall")
        x = np.arange(W)
        for y in range(EDGE_Y, FOOT_Y):
            r = y - EDGE_Y
            course, v = divmod(r - 2, 8) if r >= 2 else (-1, r)
            row = np.full(W, I["m2"], np.int16)
            if r < 2:
                row[:] = I["m1"] if r == 0 else I["m0"]       # shadow under the plinth overhang
            else:
                widths = rng_for("wallc", course).integers(18, 34, size=80)
                edges = np.cumsum(widths) - (course * 13) % 30
                k = np.searchsorted(edges, x, side="right")
                tone = np.where((k * 37 + course * 11) % 5 < 2, I["m3"], I["m2"])
                row[:] = tone
                if v == 0:
                    row[:] = I["m1"]
                elif v == 1:
                    row[:] = np.where(tone == I["m3"], I["m4"], I["m3"])
                elif v == 7:
                    row[:] = np.where(tone == I["m3"], I["m2"], I["m1"])
                vj = np.isin(x, edges)
                row[vj & (v > 0)] = I["m1"]
            tw[y, :] = row
        # pilasters under the piers
        for px in PIERS:
            tw[EDGE_Y + 2:FOOT_Y, px - 6:px + 6] = I["m3"]
            tw[EDGE_Y + 2:FOOT_Y, px - 6] = I["m4"]
            tw[EDGE_Y + 2:FOOT_Y, px + 5] = I["m1"]
            tw[EDGE_Y + 2:FOOT_Y, px + 6] = I["m0"]
            tw[FOOT_Y - 6, px - 7:px + 7] = I["m4"]                # base moulding
            tw[FOOT_Y - 5:FOOT_Y, px - 7:px + 7] = I["m2"]
        # rain streaks and grime at the foot
        sn = vnoise("streak", 3, H, W)
        for x0 in range(0, W, 3):
            if (x0 * 7919) % 11 < 3:
                ln = 6 + (x0 * 104729) % 22
                seg = tw[EDGE_Y + 2:EDGE_Y + 2 + ln, x0]
                seg[:] = ramp_shift_arr(seg, STONE, -1)
        foot = np.zeros((H, W), bool)
        foot[FOOT_Y - 7:FOOT_Y, :] = True
        gr = foot & (vnoise("wallgrime", 6) > 0.45)
        tw[gr] = ramp_shift_arr(tw, STONE, -1)[gr]
        moss = foot & (vnoise("wallmoss", 4) > 0.7)
        tw[moss & (np.arange(H)[:, None] >= FOOT_Y - 4)] = I["g1"]
        # stepped crack running along joints in the intact bay left of the stairs
        cx, cy = 300, EDGE_Y + 3
        while cy < FOOT_Y - 2:
            tw[cy, cx] = I["ink"]
            tw[cy, cx - 1] = I["m4"] if tw[cy, cx - 1] != I["m1"] else tw[cy, cx - 1]
            cy += 1
            if (cy - EDGE_Y) % 8 == 2:
                for _ in range(int(rng.integers(3, 9))):
                    cx += 1
                    tw[cy, cx] = I["ink"]

    def balustrade(self, tw):
        y0 = EDGE_Y - BAL_H
        cell = ["xLMMDx", "xxLDxx", "xxLDxx", "xLMMDx", "LMMMMD", "LMMMMD", "xLMMDx", "xxLDxx", "xxLDxx",
                "xLMMDx", "LMMMMD"]
        cmap = {"L": I["m4"], "M": I["m3"], "D": I["m2"], "x": I["m1"]}
        for x in range(W):
            if STAIR_X0 - CHEEK_W <= x <= STAIR_X1 + CHEEK_W:
                continue
            tw[y0, x] = I["m5"]
            tw[y0 + 1:y0 + 3, x] = I["m4"]
            tw[y0 + 3, x] = I["m3"]
            tw[y0 + 4, x] = I["m1"]
            for j, row in enumerate(cell):
                ch = row[(x + 1) % 6]
                c = cmap[ch]
                if ch == "x":
                    c = I["m0"] if j >= 8 else I["m1"]
                tw[y0 + 5 + j, x] = c
            tw[y0 + 16, x] = I["m4"]
            tw[y0 + 17, x] = I["m3"]
            tw[y0 + 18, x] = I["m2"]
            tw[y0 + 19, x] = I["m1"]
        for px in PIERS:
            x0 = px - 6
            tw[y0 - 4:EDGE_Y, x0:x0 + 12] = I["m3"]
            tw[y0 - 4:EDGE_Y, x0] = I["m4"]
            tw[y0 - 4:EDGE_Y, x0 + 11] = I["m2"]
            tw[y0 - 4:EDGE_Y, x0 + 12] = I["m1"]
            tw[y0 + 4:y0 + 14, x0 + 3:x0 + 9] = I["m2"]              # recessed panel
            tw[y0 + 4, x0 + 3:x0 + 9] = I["m1"]
            tw[y0 + 4:y0 + 14, x0 + 3] = I["m1"]
            tw[y0 - 7, x0 - 1:x0 + 13] = I["m5"]                     # cap
            tw[y0 - 6:y0 - 4, x0 - 1:x0 + 13] = I["m4"]
            tw[y0 - 4, x0 - 1:x0 + 13] = I["m2"]
            tw[y0 - 7:y0 - 3, x0 + 13] = I["m1"]
        # vines draped over the balustrade/wall are drawn in ground-detail

    def stairs(self, tw):
        top = EDGE_Y - 2
        n = 16
        step = (STAIR_BOT - top) / n
        xs = np.arange(STAIR_X0, STAIR_X1 + 1)
        wear = np.exp(-((xs - 640) / 34.0) ** 2)                      # traffic dished the centre line
        mossn = vnoise("stairmoss", 3)
        self.stair_rows = []
        for k in range(n):
            ya = int(round(top + k * step))
            yb = int(round(top + (k + 1) * step))
            h = yb - ya
            rk = rng_for("tread", k)
            joints = np.cumsum(rk.integers(26, 46, size=12)) + STAIR_X0 - int(rk.integers(0, 20))
            jmask = np.isin(xs, joints)
            blk = np.searchsorted(joints, xs)
            btone = np.where((blk * 5 + k * 3) % 7 < 2, I["m3"], I["m4"])
            for y in range(ya, yb):
                r = y - ya
                if r < h - 2:
                    row = btone.copy()
                    row[(wear > 0.55) & (r == 0)] = I["m3"]
                    row[(wear > 0.8)] = I["m3"]
                    if r == h - 3:                                   # bright nose, chipped in places
                        row[:] = I["m5"]
                        chip = (rk.random(len(xs)) < 0.06)
                        row[chip] = I["m3"]
                    row[jmask] = I["m2"]
                elif r == h - 2:
                    row = np.full(len(xs), I["m1"], np.int16)       # shadow under the nose
                else:
                    row = np.full(len(xs), I["m2"], np.int16)       # riser face
                    row[jmask] = I["m1"]
                # moss creeping in from both cheek walls
                edge = np.minimum(xs - STAIR_X0, STAIR_X1 - xs)
                mm = (edge < 3 + 9 * mossn[y, xs]) & (mossn[y, xs] > 0.45)
                row[mm & (row != I["m5"])] = np.where(mossn[y, xs] > 0.7, I["g3"], I["g2"])[mm & (row != I["m5"])]
                tw[y, STAIR_X0:STAIR_X1 + 1] = row
            self.stair_rows.append((ya, yb))
        # cracked treads and one broken-out tread corner with soil and a weed
        for (cx, cy, w) in ((580, 140, 18), (700, 168, 22), (650, 118, 12)):
            tw[cy, cx:cx + w] = I["ink"]
            tw[cy + 1, cx + 2:cx + w - 2] = I["m2"]
        ya, yb = self.stair_rows[9]
        tw[ya:yb - 1, STAIR_X1 - 26:STAIR_X1 - 6] = I["s1"]
        tw[ya, STAIR_X1 - 26:STAIR_X1 - 6] = I["s0"]
        tw[yb - 2, STAIR_X1 - 26:STAIR_X1 - 6] = I["m2"]
        stamp(tw, STAIR_X1 - 20, ya - 2, [".c.c.", "cbcbc", ".bbb."], {"c": "g4", "b": "g2"})
        # cheek walls: cap strip, inner/outer faces, newel blocks at the foot
        for x0, side in ((STAIR_X0 - CHEEK_W, -1), (STAIR_X1 + 1, 1)):
            tw[EDGE_Y - BAL_H - 6:STAIR_BOT - 14, x0:x0 + CHEEK_W] = I["m4"]
            tw[EDGE_Y - BAL_H - 6:STAIR_BOT - 14, x0] = I["m5"]
            tw[EDGE_Y - BAL_H - 6:STAIR_BOT - 14, x0 + CHEEK_W - 1] = I["m2"]
            tw[EDGE_Y - BAL_H - 7, x0:x0 + CHEEK_W] = I["m5"]
            # newel block: cap + front face
            tw[STAIR_BOT - 22:STAIR_BOT - 14, x0 - 2:x0 + CHEEK_W + 2] = I["m4"]
            tw[STAIR_BOT - 22, x0 - 2:x0 + CHEEK_W + 2] = I["m5"]
            tw[STAIR_BOT - 22:STAIR_BOT - 14, x0 + CHEEK_W + 1] = I["m2"]
            tw[STAIR_BOT - 14:STAIR_BOT + 1, x0 - 2:x0 + CHEEK_W + 2] = I["m2"]
            tw[STAIR_BOT - 14, x0 - 2:x0 + CHEEK_W + 2] = I["m1"]
            tw[STAIR_BOT - 13:STAIR_BOT - 11, x0 - 2:x0 + CHEEK_W + 2] = I["m3"]
            tw[STAIR_BOT - 1:STAIR_BOT + 1, x0 - 2:x0 + CHEEK_W + 2] = I["m1"]
            tw[STAIR_BOT - 14:STAIR_BOT + 1, x0 + CHEEK_W + 1] = I["m1"]
            tw[STAIR_BOT - 14:STAIR_BOT + 1, x0 - 2] = I["m3"]
            # the cheek wall's own face on its outer side, down to the lawn
            if side < 0:
                tw[EDGE_Y:STAIR_BOT - 22, x0 - 1] = I["m3"]
            else:
                tw[EDGE_Y:STAIR_BOT - 22, x0 + CHEEK_W] = I["m1"]

    def collapse(self, tw):
        """Game fiction: one terrace bay has slumped outward. The deck edge is bitten back, the wall face is gone in a
        stepped notch, the fill shows as an overgrown soil slope, and a rubble talus spills onto the lawn."""
        x0, x1 = COLLAPSE
        rng = rng_for("collapse")
        xs = np.arange(x0, x1 + 1)
        cxm = (x0 + x1) / 2 + 6
        half = (x1 - x0) / 2
        u = (xs - cxm) / half
        b = np.clip(1 - np.abs(u) ** 1.6, 0, 1)
        jag = (vnoise("breach", 3, 1, W)[0, x0:x1 + 1] - 0.5) * 7
        lip = np.round(EDGE_Y - BAL_H + 1 - 15 * b ** 0.8 + jag * (b > 0.05)).astype(int)
        # remaining wall: its broken top steps down by whole courses toward the middle of the bay
        frac = np.clip((b - 0.12) / 0.55, 0, 1)
        jw = (vnoise("breachw", 5, 1, W)[0, x0:x1 + 1] - 0.5) * 10
        wall_top = EDGE_Y + 2 + np.round((frac * (WALL_H + 6) + jw * (frac > 0)) / 8).astype(int) * 8
        wall_top = np.where(frac <= 0, EDGE_Y, wall_top)
        self.breach_top = {}
        soil = vnoise("breachsoil", 3)
        soilm = vnoise("breachsoilm", 14)
        g = self.L["ground-base"]
        for i, x in enumerate(xs):
            if b[i] < 0.06:
                continue
            yl, yw = int(lip[i]), int(min(wall_top[i], FOOT_Y + 4))
            self.breach_top[int(x)] = yl
            # remove balustrade / pier pixels above the bitten-back lip (the deck shows through)
            for y in range(EDGE_Y - BAL_H - 8, max(yl, EDGE_Y - BAL_H - 8)):
                tw[y, x] = -1
            for y in range(yl, yw):
                d = y - yl
                if d == 0:
                    c = I["m4"] if (x * 7) % 5 else I["m5"]                      # broken slab edge, lit
                elif d == 1:
                    c = I["m2"]                                                 # slab thickness
                elif d < 4:
                    c = I["s0"]                                                 # undercut shadow
                else:
                    depth = (y - yl) / max(1, (yw - yl))
                    sv = soil[y, x] * 0.6 + soilm[y, x] * 0.4 - depth * 0.25
                    c = I["s3"] if sv > 0.66 else I["s2"] if sv > 0.44 else I["s1"] if sv > 0.22 else I["s0"]
                    if soilm[y, x] > 0.62 and soil[y, x] > 0.35:
                        c = I["g3"] if soil[y, x] > 0.6 else I["g2"]            # turf re-colonising the slope
                tw[y, x] = c
            if wall_top[i] < FOOT_Y:
                tw[int(wall_top[i]), x] = I["m4"]                               # broken top of remaining courses
                tw[int(wall_top[i]) + 1, x] = I["m3"]
            # deck slabs right behind the lip: cracked, sunk one tone
            for y in range(max(FACADE_Y1 + 2, yl - 5), yl):
                if g[y, x] in (I["m4"], I["m5"]):
                    g[y, x] = I["m3"]
        # broken-off ends of the balustrade: a missing rail chunk and a leaning stub at each side
        for xe, sgn in ((x0 + int(np.argmax(b > 0.06)), -1), (x0 + len(b) - 1 - int(np.argmax(b[::-1] > 0.06)), 1)):
            for k in range(1, 9):
                xx = xe + sgn * k
                if k < 5:
                    tw[EDGE_Y - BAL_H:EDGE_Y - BAL_H + 3, xx] = -1
                    tw[EDGE_Y - BAL_H + 3, xx] = I["m2"]
        # roots in the exposed fill
        for _ in range(18):
            rx = int(rng.integers(x0 + 24, x1 - 24))
            if rx not in self.breach_top:
                continue
            ry = self.breach_top[rx] + 4
            for _ in range(int(rng.integers(5, 16))):
                if tw[ry, rx] in (I["s1"], I["s2"], I["s3"]):
                    tw[ry, rx] = I["s0"]
                ry += 1
                rx += int(rng.integers(-1, 2))
        # rubble talus (painter's order: far = smaller y first)
        mound = np.zeros((H, W), bool)
        yy, xx = np.mgrid[0:H, 0:W]
        e = ((xx - cxm) / 132.0) ** 2 + ((yy - (FOOT_Y + 6)) / 66.0) ** 2 + (vnoise("mound", 7) - 0.5) * 0.5
        mound = (e < 1) & (yy >= FOOT_Y - 6) & (tw < 0)
        mn = vnoise("moundtone", 4)
        mt = np.where(mn < 0.3, I["s1"], np.where(mn < 0.55, I["s2"], np.where(mn < 0.8, I["g2"], I["g3"])))
        tw[mound] = mt[mound]
        self.rubble = mound.copy()
        pieces = []
        for k in range(72):
            ty = FOOT_Y - 8 + rng.random() ** 1.4 * 92
            spread = 124 * (1 - (ty - FOOT_Y + 8) / 130)
            tx = cxm + rng.normal(0, 0.45) * spread
            pieces.append((ty, tx, k))
        pieces.sort()
        for ty, tx, k in pieces:
            r = rng.random()
            if r < 0.14:
                self.baluster_piece(tw, int(tx), int(ty), rng)
            elif r < 0.30:
                w = int(rng.integers(4, 8))
                self.block_3q(tw, int(tx) - w // 2, int(ty), w, 2, 3, rng)
            else:
                w = int(rng.integers(12, 28)); d = int(rng.integers(5, 10)); h = int(rng.integers(5, 10))
                self.block_3q(tw, int(tx) - w // 2, int(ty), w, d, h, rng, tilt=int(rng.integers(-2, 3)))
        # toppled pier and a fallen length of top rail, both lying on the lawn below the bay
        self.block_3q(tw, 1012, 210, 44, 10, 11, rng, cap=True)
        self.fallen_rail(tw, 892, 238, 46)
        # a few facade blocks fallen onto the deck behind the bay
        for (bx, by, w) in ((936, 40, 16), (1052, 52, 12), (1150, 34, 20), (842, 58, 10), (1000, 30, 14)):
            self.block_3q(tw, bx, by, w, 5, 5, rng)
            self.block[by + 2:by + 10, bx:bx + w] = True
        self.rubble |= (tw >= 0) & (yy >= FOOT_Y) & (xx >= x0 - 20) & (xx <= x1 + 40)
        self.block |= self.rubble

    def fallen_rail(self, tw, x, y, n):
        """A length of the balustrade's top rail lying on its side, a few balusters still attached."""
        for i in range(n):
            tw[y, x + i] = I["m5"]
            tw[y + 1, x + i] = I["m4"]
            tw[y + 2, x + i] = I["m3"]
            tw[y + 3, x + i] = I["m1"]
        for i in range(2, n - 2, 6):
            if (i // 6) % 3 == 1:
                continue
            stamp(tw, x + i, y + 4, ["LMD", "LMD", ".M.", "LMD", "DDD"], {"L": "m4", "M": "m3", "D": "m1"})
        self.prop_shadow.append(("block", x + n, y + 3, n, 4))

    def block_3q(self, layer, x, y, w, d, h, rng, cap=False, tilt=0):
        """A tumbled ashlar block in 3/4: top face (tone varies per block), front face, chipped corners,
        dark contact edge. `tilt` shears the top face sideways by up to 2 px so blocks do not all sit square."""
        top = [I["m4"], I["m3"], I["m4"], I["m3"], I["m2"]][int(rng.integers(0, 5))]
        lit = I["m5"] if top == I["m4"] else I["m4"] if top == I["m3"] else I["m3"]
        face = I["m2"] if top != I["m2"] else I["m1"]
        for j in range(d + h):
            sh = int(round(tilt * (1 - j / max(1, d)))) if j < d else 0
            for i in range(w):
                px, py = x + i + sh, y + j
                if not (0 <= px < W and 0 <= py < H):
                    continue
                corner = (i == 0 or i == w - 1) and (j == 0 or j == d + h - 1)
                if corner and rng.random() < 0.8:
                    continue
                if j < d:
                    c = lit if (j == 0 or i == 0) else (face if i == w - 1 else top)
                    if cap and j == d - 1:
                        c = face
                else:
                    c = face if j < d + h - 1 else I["ink"]
                    if j == d:
                        c = I["m1"]
                    if i == w - 1 or (i == w - 2 and j > d + 1):
                        c = I["m1"] if face == I["m2"] else I["m0"]
                layer[py, px] = c
        if w > 12 and rng.random() < 0.5:                       # crack across the top face
            cx = x + int(rng.integers(3, w - 3))
            for j in range(1, d):
                setpx(layer, cx + (j // 2), y + j, face)
        self.prop_shadow.append(("block", x + w, y + d, w, h))

    def baluster_piece(self, layer, x, y, rng):
        """A fallen baluster: short lathe-turned cylinder lying on its side."""
        rows = ["..LLLL....", ".LMMMMLLL.", "LMMMMMMMMD", "DMMMMMMMMD", ".DDDMMDDD.", "..ooo.ooo."]
        cm = {"L": "m5", "M": "m4", "D": "m2", "o": "m0"}
        if rng.random() < 0.5:
            rows = [r[::-1] for r in rows]
        stamp(layer, x - 5, y, rows, cm)

    # ------------------------------------------------------------------ ground-detail
    def detail(self):
        d = self.L["ground-detail"]
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls"])
        rng = rng_for("tufts")
        walk = self.walk_mask
        lawn = ~walk & (np.arange(H)[:, None] >= FOOT_Y) & (self.L["terrace-walls"] < 0)
        # 1) tufts across the lawn (sparser in the open centre, denser at edges and in the belts)
        dens = 0.18 + 0.55 * vnoise("tuftd", 36)
        near_walk = np.zeros((H, W), bool)
        wm = walk.copy()
        for k in range(1, 7):
            near_walk[k:, :] |= wm[:-k, :]; near_walk[:-k, :] |= wm[k:, :]
            near_walk[:, k:] |= wm[:, :-k]; near_walk[:, :-k] |= wm[:, k:]
        near_walk &= ~walk
        # unmown drifts: the lawn has been left to go to meadow in patches (game fiction)
        meadow = (vnoise("meadow", 64) > 0.66) & (vnoise("meadow2", 9) > 0.3) & lawn
        self.meadow = meadow
        for gy in range(FOOT_Y, H, 6):
            for gx in range(0, W, 7):
                x = gx + int(rng.integers(0, 6)); y = gy + int(rng.integers(0, 5))
                if not (0 <= x < W and 0 <= y < H) or not lawn[y, x]:
                    continue
                p = dens[y, x] + (0.35 if near_walk[y, x] else 0) + (0.25 if self.belt[y, x] else 0) + \
                    (0.4 if meadow[y, x] else 0)
                if rng.random() > p:
                    continue
                if (near_walk[y, x] or meadow[y, x]) and rng.random() < 0.55:
                    t = TALL_TUFTS[int(rng.integers(len(TALL_TUFTS)))]
                else:
                    t = TUFTS[int(rng.integers(len(TUFTS)))]
                base = comp[y, x]
                if base not in GR:
                    base = I["g3"] if base not in (I["d0"], I["d1"]) else I["g4"]
                stamp(d, x, y, t, TUFT_MAP, under=int(base), ramp=GR)
        # 2) grass encroaching over walk edges (irregular overhang onto the curbs)
        enc = (vnoise("encroach", 5) > 0.5) & walk & ~near_walk
        edge = np.zeros((H, W), bool)
        for k in (1, 2, 3):
            edge[k:, :] |= lawn[:-k, :]; edge[:-k, :] |= lawn[k:, :]
            edge[:, k:] |= lawn[:, :-k]; edge[:, :-k] |= lawn[:, k:]
        edge &= walk
        ov = edge & (vnoise("overhang", 3) > 0.42)
        d[ov] = np.where(vnoise("ovtone", 2)[ov] > 0.5, I["g3"], I["g2"])
        d[:] = despeckle(d, 1, valid=edge)
        # 3) flowers in small deliberate clusters
        for _ in range(420):
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 10, H))
            if not lawn[y, x] or self.belt[y, x] and rng.random() < 0.6:
                continue
            if not meadow[y, x] and rng.random() < 0.6:
                continue
            col = FLOWERS[int(rng.integers(len(FLOWERS)))]
            for _ in range(int(rng.integers(3, 8))):
                fx = x + int(rng.integers(-5, 6)); fy = y + int(rng.integers(-3, 4))
                if 0 <= fx < W - 1 and 0 <= fy < H - 1 and lawn[fy, fx]:
                    d[fy, fx] = I[col]
                    d[fy + 1, fx] = I["g1"]
        # 4) shrubs along the wall-foot strip and in the tree belts
        for x in range(4, W, 22):
            if STAIR_X0 - CHEEK_W - 6 <= x <= STAIR_X1 + CHEEK_W + 6 or COLLAPSE[0] - 8 <= x <= COLLAPSE[1] + 10:
                continue
            if rng.random() < 0.72:
                self.shrub(d, x + int(rng.integers(-4, 5)), FOOT_Y + 6 + int(rng.integers(0, 4)),
                           int(rng.integers(7, 12)), ("wallshrub", x))
        # understorey along the belt margins (the canopies cover the belt interiors)
        bp = np.pad(self.belt, 20)
        margin = self.belt & ~(bp[40:, 20:-20] & bp[:-40, 20:-20] & bp[20:-20, 40:] & bp[20:-20, :-40])
        for k in range(160):
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 20, H))
            if margin[y, x] and not walk[y, x]:
                self.shrub(d, x, y, int(rng.integers(7, 13)), ("beltshrub", k), ramp=FOL)
        # shrubs and saplings rooted in the rubble and the slumped fill
        for k, (x, y, r) in enumerate(((912, 160, 9), (1040, 128, 12), (1080, 206, 8), (948, 232, 7),
                                       (1094, 160, 10), (872, 206, 6), (990, 118, 8))):
            self.shrub(d, x, y, r, ("rubbleshrub", k), ramp=GR)
        # moss on rubble top faces and weeds at the foot of tumbled blocks
        tw = self.L["terrace-walls"]
        rub = self.rubble & (tw >= 0)
        tops = rub & np.isin(tw, [I["m4"], I["m3"]])
        mo = tops & (vnoise("rubmoss", 3) > 0.74)
        d[mo] = np.where(vnoise("rubmoss2", 2)[mo] > 0.5, I["g3"], I["g4"])
        stone = rub & np.isin(tw, [I["m1"], I["m0"], I["ink"]])
        foot = stone & ~np.roll(stone, -1, axis=0)
        fy, fx = np.nonzero(foot)
        for i in range(0, len(fy), 9):
            if rng.random() < 0.6:
                stamp(d, int(fx[i]) - 2, int(fy[i]) - 2, TUFTS[int(rng.integers(len(TUFTS)))], TUFT_MAP,
                      under=I["g3"], ramp=GR)
        # 5) vines hanging from the balustrade over the wall face
        for x in range(2, W, 5):
            if STAIR_X0 - CHEEK_W - 2 <= x <= STAIR_X1 + CHEEK_W + 2 or COLLAPSE[0] <= x <= COLLAPSE[1]:
                continue
            vv = vnoise("vines", 40, 1, W)[0, x]
            if vv < 0.5 or rng.random() > 0.7:
                continue
            ln = int(8 + (vv - 0.5) * 2 * 40 + rng.integers(0, 10))
            self.vine(d, x, EDGE_Y - 6, ln, rng)
        # vines over the collapse lip
        for x in range(COLLAPSE[0] + 10, COLLAPSE[1] - 10, 9):
            yt = self.breach_top.get(x, EDGE_Y)
            self.vine(d, x, yt, int(rng.integers(6, 20)), rng)
        # ivy curtains on the facade base, heaviest toward the damaged south (right) end
        for x in range(6, W, 4):
            fv = vnoise("facvine", 30, 1, W)[0, x] + (0.25 if x > 820 else 0)
            if fv > 0.78 and rng.random() < 0.8:
                self.vine(d, x, 0, int(rng.integers(8, FACADE_Y1 + 4)), rng)
        # 6) cracks on paving and deck; small debris chips; soil scuffs
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls", "ground-detail"])
        for k in range(60):
            if k < 22:
                x = int(rng.integers(20, W - 20)); y = int(rng.integers(FACADE_Y1 + 4, EDGE_Y - BAL_H - 4))
            else:
                x = int(rng.integers(0, W)); y = int(rng.integers(FORE[1], H))
                if not walk[y, x]:
                    continue
            self.crack(d, comp, x, y, int(rng.integers(8, 30)), rng)
        for k in range(140):
            x = int(rng.integers(0, W)); y = int(rng.integers(FACADE_Y1, H))
            near_rubble = abs(x - 990) < 170 and FOOT_Y - 60 < y < 300
            if not (walk[y, x] or near_rubble) or rng.random() < 0.4 and not near_rubble:
                continue
            c = I["m4"] if rng.random() < 0.5 else I["m3"]
            setpx(d, x, y, c); setpx(d, x + 1, y, I["m2"]); setpx(d, x, y + 1, I["m1"])
        # 7) survey paint on paving: orange grid ticks and an arrow toward the post
        for (x, y) in ((760, 220), (790, 236), (708, 214)):
            d[y, x:x + 5] = I["o1"]; d[y - 2:y + 3, x + 2] = I["o1"]
        for (x, y) in ((690, 300), (690, 420), (690, 540)):
            stamp(d, x - 3, y, ["..o..", ".ooo.", "o.o.o", "..o..", "..o.."], {"o": "o1"})
        # cable from the post to the collapse sensors and to the first beacon
        px, py = POST
        for a, b in (((px + 2, py - 30), (968, 232)), ((px + 16, py), (1014, 452))):
            n = int(max(abs(b[0] - a[0]), abs(b[1] - a[1])))
            for t in range(n):
                x = int(a[0] + (b[0] - a[0]) * t / n + 2 * math.sin(t / 9))
                y = int(a[1] + (b[1] - a[1]) * t / n)
                setpx(d, x, y, I["k0"])

    def shrub(self, layer, cx, cy, r, key, ramp=None):
        ramp = ramp or [I[n] for n in ("f0", "f1", "g1", "g2", "g3", "g4", "g5")]
        m, idx, (x0, y0) = self.canopy_raster(cx, cy - r // 2, r, key, ramp=ramp, squash=0.75, tex_cell=2)
        sub = layer[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
        sub[m] = idx[m]
        self.prop_shadow.append(("shrub", cx, cy, r))

    def vine(self, layer, x, y, ln, rng):
        for j in range(ln):
            yy = y + j
            if yy >= FOOT_Y - 1 or yy >= H:
                break
            x += int(rng.integers(-1, 2)) if j % 3 == 0 else 0
            setpx(layer, x, yy, I["g1"])
            if j % 3 == 0:
                side = 1 if (j // 3) % 2 else -1
                setpx(layer, x + side, yy, I["g3"])
                setpx(layer, x + side, yy - 1, I["g4"])
                setpx(layer, x + 2 * side, yy, I["g2"])
                setpx(layer, x + side, yy + 1, I["g1"])

    def crack(self, layer, comp, x, y, n, rng):
        ang = rng.uniform(0, math.pi)
        for _ in range(n):
            if not (0 <= x < W - 1 and 1 <= y < H):
                return
            base = comp[y, x]
            ramp = STONE if base in STONE else PAVE
            layer[y, x] = ramp_shift(base, ramp, -2)
            if layer[y - 1, x] < 0 and rng.random() < 0.35:
                layer[y - 1, x] = ramp_shift(comp[y - 1, x], ramp, 1)
            ang += rng.normal(0, 0.45)
            x += int(round(math.cos(ang))); y += int(round(math.sin(ang)))

    # ------------------------------------------------------------------ canopies
    def canopy_raster(self, cx, cy, r, key, ramp=FOL, squash=0.86, tex_cell=3):
        rng = rng_for("canopy", key)
        blobs = [(0.0, 0.0, r * 0.74)]
        k = int(rng.integers(7, 11))
        for i in range(k):
            a = 2 * math.pi * i / k + rng.uniform(-0.3, 0.3)
            dd = r * rng.uniform(0.42, 0.6)
            blobs.append((math.cos(a) * dd, math.sin(a) * dd * squash, r * rng.uniform(0.32, 0.46)))
        for i in range(3):
            blobs.append((rng.uniform(-0.3, 0.3) * r, -rng.uniform(0.1, 0.38) * r, r * rng.uniform(0.28, 0.4)))
        R = int(r * 1.25) + 4
        yy, xx = np.mgrid[-R:R + 1, -R:R + 1].astype(np.float32)
        zbest = np.full(yy.shape, -1e9, np.float32)
        nx = np.zeros_like(yy); ny = np.zeros_like(yy); nz = np.zeros_like(yy)
        for bi, (bx, by, rb) in enumerate(blobs):
            ph1, ph2 = rng.uniform(0, 6.3), rng.uniform(0, 6.3)
            ang = np.arctan2(yy - by, xx - bx)
            rr = rb * (1 + 0.08 * np.sin(ang * 7 + ph1) + 0.05 * np.sin(ang * 12 + ph2))
            d2 = ((xx - bx) ** 2 + (yy - by) ** 2) / (rr ** 2)
            inside = d2 < 1
            z = np.sqrt(np.clip(1 - d2, 0, 1)) * rb + by * 0.35 + rb * 0.3
            take = inside & (z > zbest)
            zbest[take] = z[take]
            nx[take] = ((xx - bx) / rr)[take]; ny[take] = ((yy - by) / rr)[take]
            nz[take] = np.sqrt(np.clip(1 - d2, 0, 1))[take]
        m = zbest > -1e8
        L = np.array([-0.5, -0.72, 0.9]); L /= np.linalg.norm(L)
        sh = nx * L[0] + ny * L[1] + nz * L[2]
        tex = vnoise(("leaf", key), tex_cell, yy.shape[0], yy.shape[1])
        sh = sh + (tex - 0.5) * 0.42
        q = np.digitize(sh, [-0.1, 0.18, 0.4, 0.6, 0.78, 0.95])          # 0..6 along the ramp
        idx = np.array(ramp, np.int16)[np.clip(q, 0, len(ramp) - 1)]
        # silhouette: dark rim on the lower/right edge, nothing on the lit upper-left edge
        p = np.pad(m, 1)
        rim = m & (~p[2:, 1:-1] | ~p[1:-1, 2:])
        idx[rim] = ramp[0]
        idx = np.where(m, idx, -1).astype(np.int16)
        idx = despeckle(idx, 2, valid=m)
        x0, y0 = int(cx) - R, int(cy) - R
        # clip to canvas
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(W, x0 + 2 * R + 1), min(H, y0 + 2 * R + 1)
        mm = m[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        ii = idx[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        return mm, ii, (cx0, cy0)

    def tree_sites(self):
        """Dense flank belts: jittered grid inside the belt mask, trunks kept clear of every walk so canopies only
        overhang the walk edges (Olmsted: trees frame the lawn; the central axis stays open)."""
        rng = rng_for("treesites")
        curves = [(self.lc, WALK_W / 2), (self.rc, WALK_W / 2), (self.bc, BRANCH_W / 2)]
        sites = []
        for gy in range(FOOT_Y + 64, H + 80, 54):
            for gx in range(-16, W + 30, 58):
                x = gx + int(rng.integers(-16, 17)); y = gy + int(rng.integers(-12, 13))
                if not self.belt[min(H - 1, max(0, y)), min(W - 1, max(0, x))]:
                    continue
                if 820 < x < W - 90 and y < 400:          # keep the collapsed bay and its rubble readable
                    continue
                if 90 < x < W - 90 and y < 330:           # terrace-foot margin stays open lawn
                    continue
                r = int(rng.integers(40, 58))
                cy = y - 10 - 0.9 * r
                clear = True
                for c, hw in curves:
                    d = np.hypot(c[:, 0] - x, c[:, 1] - y).min()
                    dc = np.hypot(c[:, 0] - x, c[:, 1] - cy).min()
                    if d < hw + 16 or dc < hw + 0.92 * r:
                        clear = False
                if clear:
                    sites.append((x, y, r, int(rng.integers(0, 3))))
        sites.sort(key=lambda s: s[1])
        return sites

    def trees(self):
        fg = self.L["fg-occlusion"]
        props = self.L["props-low"]
        sites = self.tree_sites()
        rasters = []
        for k, (tx, ty, r, sp) in enumerate(sites):
            ramp = FOL if sp else [I[n] for n in ("f0", "f1", "g1", "g2", "g3", "g4", "g5")]
            rasters.append(self.canopy_raster(tx, ty - 10 - 0.9 * r, r, ("tree", tx, ty), ramp=ramp))
        # occluder rule (spec section 4): a 48 px actor anywhere walkable keeps >= 1/3 of its height visible.
        # Drop, one at a time, the tree whose canopy hides the most failing actor positions.
        keep = list(range(len(sites)))
        walk = self.walkable_mask()
        spr = heroine_48()[..., 3] == 255
        while True:
            cover = np.zeros((H, W), np.int16) - 1
            for k in keep:
                m, idx, (x0, y0) = rasters[k]
                cover[y0:y0 + m.shape[0], x0:x0 + m.shape[1]][m] = k
            fails = visibility_fails(cover >= 0, walk, spr)
            if not fails:
                break
            votes = {}
            sh, sw = spr.shape
            for (x, y) in fails:
                ids = cover[y - sh + 1:y + 1, x - sw // 2:x - sw // 2 + sw][spr]
                for k in np.unique(ids[ids >= 0]):
                    votes[int(k)] = votes.get(int(k), 0) + 1
            keep.remove(max(votes, key=votes.get))
        self.trees_dropped_for_visibility = len(sites) - len(keep)
        self.tree_list = [sites[k] for k in keep]
        for k in keep:
            tx, ty, r, sp = sites[k]
            m, idx, (x0, y0) = rasters[k]
            sub = fg[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
            sub[m] = idx[m]
            self.trunk(props, tx, ty)
            self.block[ty - 4:ty + 1, tx - 5:tx + 5] = True
            self.prop_shadow.append(("tree", tx, ty, r))

    def trunk(self, layer, tx, ty):
        """Trunk below the canopy with a root flare; lit on the left, bark furrows, dark on the right."""
        for j in range(16):
            y = ty - 15 + j
            hw = 3 if j < 10 else 3 + (j - 9) // 2
            for i in range(-hw, hw + 1):
                x = tx + i
                rel = (i + hw) / (2 * hw)
                c = I["s2"] if rel < 0.3 else I["s1"] if rel < 0.75 else I["s0"]
                if j < 10 and i == 0 and (j * 3 + tx) % 4 == 0:
                    c = I["s0"]
                if j >= 13 and abs(i) == hw and (j + i) % 2:
                    c = I["s0"]
                setpx(layer, x, y, c)
        setpx(layer, tx - hw - 1, ty, I["s1"]); setpx(layer, tx + hw + 1, ty, I["s0"])

    # ------------------------------------------------------------------ props-low and survey post
    def props(self):
        pr = self.L["props-low"]
        rng = rng_for("props")
        # benches on the outer verge of both curved walks (AOC: "Benches along the paths")
        for pts, sgn, ss, broken in ((LEFT_WALK, -1, (0.42, 0.7), (False, True)), (RIGHT_WALK, 1, (0.62,), (False,))):
            c, seg = bezier(pts)
            for s, br in zip(ss, broken):
                k = int(s * (len(c) - 1))
                x, y = c[k]
                bx = int(x + sgn * (WALK_W / 2 + 18)) - 13
                by = int(y) - 8
                stamp(pr, bx, by, BENCH_BROKEN if br else BENCH, BENCH_MAP)
                self.block[by + 5:by + 12, bx:bx + 26] = True
                self.prop_shadow.append(("box", bx + 3, by + 10, 26, 3))
        # broken lamp-post stubs at the forecourt corners
        for x, y in ((FORE[0] + 6, FORE[1] + 8), (FORE[2] - 12, FORE[1] + 8)):
            stamp(pr, x, y - 11, LAMP_STUB, LAMP_MAP)
            self.block[y - 3:y, x:x + 6] = True
            self.prop_shadow.append(("box", x + 2, y - 1, 6, 3))
        # survey crates beside the post
        px, py = POST
        for (x, y) in ((px - 54, py - 4), (px - 40, py + 6), (px + 26, py - 2)):
            stamp(pr, x, y - 11, CRATE, CRATE_MAP)
            self.block[y - 5:y + 1, x:x + 14] = True
            self.prop_shadow.append(("box", x + 2, y, 14, 3))
        # patrol-route beacons
        for (x, y) in (PATROL[1], PATROL[2], PATROL[4], PATROL[5], PATROL[6]):
            bx, by = x + 10, y + 4
            stamp(pr, bx - 1, by - 13, BEACON, BEACON_MAP)
            self.block[by - 1:by + 1, bx - 1:bx + 2] = True
            self.prop_shadow.append(("box", bx, by, 3, 2))
        # cordon stakes + tape around the rubble foot (game fiction: the collapse is under study)
        cord = [(858, 160), (862, 222), (916, 272), (1000, 286), (1088, 268), (1132, 218), (1130, 160)]
        # survey grid: small orange pin flags on the lawn panel nearest the collapse (waist-low)
        for (x, y) in SURVEY_GRID:
            stamp(pr, x, y - 6, ["oo.", "oOo", "k..", "k..", "k..", "K.."], {"o": "o1", "O": "o0", "k": "k2", "K": "k0"})
            self.prop_shadow.append(("box", x + 1, y, 2, 1))
        tops = []
        for (x, y) in cord:
            stamp(pr, x, y - 7, STAKE, STAKE_MAP)
            tops.append((x + 1, y - 7))
            self.prop_shadow.append(("box", x + 1, y, 2, 1))
        for (ax, ay), (bx, by) in zip(tops, tops[1:]):
            n = int(max(abs(bx - ax), abs(by - ay)))
            for t in range(1, n):
                sag = 2.5 * math.sin(math.pi * t / n)
                setpx(pr, int(round(ax + (bx - ax) * t / n)), int(round(ay + (by - ay) * t / n + sag)), I["o1"])
        self.cordon = cord

    def survey_post(self):
        sp = self.L["survey-post"]
        px, py = POST
        # concrete footing pad
        rect(sp, px - 20, py - 9, px + 19, py - 4, I["m3"]); rect(sp, px - 20, py - 9, px + 19, py - 9, I["m4"])
        rect(sp, px - 20, py - 3, px + 19, py, I["m2"]); rect(sp, px - 20, py, px + 19, py, I["m1"])
        rect(sp, px + 19, py - 9, px + 19, py, I["m1"])
        # cabinet
        x0, x1 = px - 14, px + 13
        rect(sp, x0, py - 34, x1, py - 29, I["k2"]); rect(sp, x0, py - 34, x1, py - 34, I["k3"])
        rect(sp, x0, py - 34, x0, py - 29, I["k3"])
        rect(sp, x0, py - 28, x1, py - 7, I["k1"]); rect(sp, x0, py - 28, x0, py - 7, I["k2"])
        rect(sp, x1, py - 28, x1, py - 7, I["k0"]); rect(sp, x0, py - 28, x1, py - 28, I["k0"])
        rect(sp, x0, py - 7, x1, py - 7, I["k0"])
        rect(sp, x0 + 1, py - 13, x1 - 1, py - 11, I["o1"])                           # hazard band
        for i in range(x0 + 1, x1, 4):
            setpx(sp, i, py - 11, I["o0"]); setpx(sp, i + 1, py - 12, I["o0"])
        rect(sp, px - 10, py - 25, px + 2, py - 17, I["k0"])                            # screen
        rect(sp, px - 9, py - 24, px + 1, py - 18, I["c0"])
        rect(sp, px - 8, py - 23, px - 4, py - 23, I["c1"]); rect(sp, px - 8, py - 21, px - 2, py - 21, I["c1"])
        rect(sp, px - 8, py - 19, px - 6, py - 19, I["c1"]); setpx(sp, px, py - 24, I["c2"])
        for yy in range(py - 25, py - 15, 2):                                           # vents
            rect(sp, px + 5, yy, px + 10, yy, I["k0"])
        # mast with bracket rings
        mx = px + 6
        rect(sp, mx, py - 84, mx + 2, py - 35, I["k2"]); rect(sp, mx + 1, py - 84, mx + 1, py - 35, I["k3"])
        rect(sp, mx + 2, py - 84, mx + 2, py - 35, I["k1"])
        for yy in range(py - 80, py - 36, 11):
            rect(sp, mx - 1, yy, mx + 3, yy, I["k0"]); rect(sp, mx - 1, yy - 1, mx + 3, yy - 1, I["k3"])
        # solar panel on an arm
        rect(sp, px - 6, py - 56, mx - 1, py - 56, I["k1"])
        for j in range(10):
            xa = px - 22 + j // 2
            rect(sp, xa, py - 66 + j, xa + 17, py - 66 + j, I["c0"])
            setpx(sp, xa, py - 66 + j, I["k0"]); setpx(sp, xa + 17, py - 66 + j, I["k0"])
            if j in (0, 9):
                rect(sp, xa, py - 66 + j, xa + 17, py - 66 + j, I["k0"])
            if j in (3, 6):
                rect(sp, xa + 1, py - 66 + j, xa + 16, py - 66 + j, I["k1"])
        for xa in (px - 16, px - 10, px - 4):
            for j in range(1, 9):
                setpx(sp, xa + j // 2, py - 66 + j, I["k1"])
        setpx(sp, px - 19, py - 64, I["c2"]); setpx(sp, px - 18, py - 64, I["c1"])
        # small dish
        stamp(sp, mx + 4, py - 76, [".HHH.", "HMMMk", "HMkMk", ".kkk.", "..k.."],
              {"H": "m5", "M": "m4", "k": "k1"})
        # sensor head + lens + accent light (accent: c1/c2 only, no glow alpha)
        stamp(sp, mx - 4, py - 93, ["..XX...", ".CCCC..", "..kk...", ".HHHHk.", "HMMMMMk", "HMcCcMk", "HMMMMMk",
                                    ".kkkkk."],
              {"X": "c2", "C": "c1", "k": "k1", "H": "k3", "M": "k2", "c": "c1"})
        setpx(sp, mx - 1, py - 88, I["c2"])
        # whip antenna with pennant
        rect(sp, x0 + 2, py - 56, x0 + 2, py - 35, I["k2"])
        stamp(sp, x0 + 3, py - 56, ["oo", "oO", "o."], {"o": "o1", "O": "o0"})
        self.block[py - 8:py + 1, px - 20:px + 20] = True
        self.post_mask = sp >= 0

    # ------------------------------------------------------------------ cast shadows
    def shadows(self):
        cs = self.L["cast-shadows"]
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls", "ground-detail"])
        m = np.zeros((H, W), bool)
        yy, xx = np.mgrid[0:H, 0:W]
        # terrace wall: a shadow band on the lawn at the wall foot, ragged by the planting
        band = (yy >= FOOT_Y) & (yy < FOOT_Y + 5 + (vnoise("wsh", 6) * 4).astype(int))
        band &= ~((xx >= STAIR_X0 - CHEEK_W - 2) & (xx <= STAIR_X1 + CHEEK_W + 2))
        m |= band
        # facade plinth shadow on the deck
        m |= (yy >= FACADE_Y1) & (yy < FACADE_Y1 + 3)
        # cheek walls throw a shadow to their right onto the treads/forecourt
        for x0 in (STAIR_X0, STAIR_X1 + CHEEK_W + 3):
            m |= (xx >= x0) & (xx < x0 + 4) & (yy >= EDGE_Y - 2) & (yy <= STAIR_BOT + 4)
        # piers throw short shadows onto the deck behind the balustrade (up-right of the cap)
        noise = vnoise("shedge", 3)
        for kind, *a in self.prop_shadow:
            if kind == "tree":
                tx, ty, r = a
                cx, cy = tx + r * 0.45, ty + 4
                e = ((xx - cx) / (r * 1.05)) ** 2 + ((yy - cy) / (r * 0.42)) ** 2 + (noise - 0.5) * 0.25
                m |= e < 1
            elif kind == "shrub":
                cx, cy, r = a
                e = ((xx - cx - r * 0.4) / (r * 0.95)) ** 2 + ((yy - cy - 1) / (r * 0.45)) ** 2 + (noise - 0.5) * 0.3
                m |= e < 1
            elif kind == "block":
                x, y, w, h = a
                m |= (xx >= x) & (xx < x + max(2, h // 2)) & (yy >= y) & (yy < y + h)
            elif kind == "box":
                x, y, w, h = a
                m |= (xx >= x) & (xx < x + w) & (yy >= y) & (yy < y + h)
        # survey post: pad + cabinet + mast shadow falling down-right
        px, py = POST
        m |= (yy >= py + 1) & (yy <= py + 6) & (xx >= px - 16 + (yy - py)) & (xx <= px + 26 + (yy - py))
        mast = (np.abs((xx - (px + 20)) - (yy - py) * 2.2) < 1.6) & (yy > py) & (yy < py + 18)
        m |= mast
        m &= (yy >= FACADE_Y1)
        # shadows never paint over the walls' vertical faces
        tw = self.L["terrace-walls"]
        m &= ~((tw >= 0) & (yy < FOOT_Y) & (yy >= EDGE_Y - BAL_H - 8))
        cs[m] = SHADE_LUT[comp[m]]

    # ------------------------------------------------------------------ guides (hidden, locked layer)
    def guides(self):
        g = self.L["guides"]
        walkable = self.walkable_mask()
        p = np.pad(walkable, 1)
        edge = walkable & (~p[:-2, 1:-1] | ~p[2:, 1:-1] | ~p[1:-1, :-2] | ~p[1:-1, 2:])
        g[edge] = I["gd-walk"]
        b = self.block
        pb = np.pad(b, 1)
        bedge = b & (~pb[:-2, 1:-1] | ~pb[2:, 1:-1] | ~pb[1:-1, :-2] | ~pb[1:-1, 2:])
        g[bedge] = I["gd-block"]
        for (ax, ay), (bx, by) in zip(PATROL, PATROL[1:] + PATROL[:1]):
            n = int(max(abs(bx - ax), abs(by - ay)))
            for t in range(0, n, 3):
                setpx(g, int(ax + (bx - ax) * t / n), int(ay + (by - ay) * t / n), I["gd-route"])
        for name, (x, y) in self.pins().items():
            for k in range(-4, 5):
                setpx(g, x + k, y, I["gd-pin"]); setpx(g, x, y + k, I["gd-pin"])
        for (x, y) in ((40, 700), (640, 196), (944, 470), (1240, 700), (300, 560)):
            rect(g, x, y - 47, x, y, I["gd-tick"])
            for k in range(0, 48, 8):
                rect(g, x - 2, y - k, x + 2, y - k, I["gd-tick"])
            rect(g, x - 3, y - 47, x + 3, y - 47, I["gd-tick"])

    def pins(self):
        return {"spawn_entry_west": ENTRY, "exit_west_axis": (640, 716), "exit_northwest_walk": (154, 716),
                "exit_southwest_walk": (1126, 716), "exit_east_terrace_stairs": (640, 64),
                "survey_post_interaction": (POST[0], POST[1] + 14), "survey_post_pivot": POST}

    def walkable_mask(self):
        yy = np.arange(H)[:, None]
        wm = self.inner_lawn.copy()                                 # lawn inside the curved walks + foot margin
        wm[:FOOT_Y + 4, :] = False
        wm &= ~self.belt
        wm |= self.walk_mask & (yy >= FORE[1])
        wm[FACADE_Y1 + 4:EDGE_Y - BAL_H - 2, :] = True              # terrace deck
        wm[EDGE_Y - BAL_H - 2:STAIR_BOT + 1, STAIR_X0:STAIR_X1 + 1] = True
        wm &= ~self.block
        if hasattr(self, "breach_top"):
            for x, yt in self.breach_top.items():
                wm[yt - 3:FOOT_Y, x] = False
        return wm

    # ------------------------------------------------------------------ build all
    def build(self):
        self.ground_base()
        self.paving()
        self.terrace()
        self.trees()
        self.props()
        self.survey_post()
        self.detail()
        self.shadows()
        self.guides()
        # ground-base must be opaque; the rest binary alpha by construction
        assert (self.L["ground-base"] >= 0).all()
        return self


def visibility_fails(fg, walk, spr, step=4):
    """Foot positions (sampled every `step` px over walkable texels) where fg hides > 2/3 of the actor's texels."""
    sh, sw = spr.shape
    tot = spr.sum()
    out = []
    for y in range(0, H, step):
        for x in range(0, W, step):
            if not walk[y, x]:
                continue
            x0, y0 = x - sw // 2, y - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            if 1 - (fg[y0:y0 + sh, x0:x0 + sw] & spr).sum() / tot < 1 / 3:
                out.append((x, y))
    return out


# ============================================================================ raster output
def to_rgba(idx):
    a = np.zeros((H, W, 4), np.uint8)
    m = idx >= 0
    a[m, :3] = RGB[idx[m]]
    a[m, 3] = 255
    return a


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


def composite_rgba(rgba_layers, names):
    out = rgba_layers[names[0]].copy()
    for n in names[1:]:
        m = rgba_layers[n][..., 3] == 255
        out[m] = rgba_layers[n][m]
    return out


def heroine_48():
    """Approved v8 static south idle (96 texels = 48 logical px) sampled at 2:1 for scale overlays only."""
    a = np.array(Image.open(rp(HEROINE_REL)).convert("RGBA"))
    ys, xs = np.nonzero(a[..., 3])
    a = a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = a.shape[:2]
    small = np.array(Image.fromarray(a, "RGBA").resize((max(1, w // 2), h // 2), Image.NEAREST))
    small[..., 3] = np.where(small[..., 3] >= 128, 255, 0)
    return small


def paste(dst, spr, x, ybase):
    h, w = spr.shape[:2]
    x0, y0 = x - w // 2, ybase - h + 1
    for j in range(h):
        for i in range(w):
            if spr[j, i, 3] and 0 <= x0 + i < W and 0 <= y0 + j < H:
                dst[y0 + j, x0 + i] = spr[j, i]


def actor_cases():
    """Foot positions for the scale/Y-sort/occlusion stills (behind = north of the post base, front = south)."""
    px, py = POST
    return {"entry": ENTRY, "post_behind": (px - 4, py - 10), "post_front": (px - 2, py + 16),
            "terrace_stairs": (640, 176), "terrace_deck": (420, 70), "left_walk_canopy": (238, 420)}


def runtime_stack_still(rgba, spr, foot):
    """Runtime draw order proposal: base (layers 1-6 merged) -> Y-sorted {post, actor} -> fg-occlusion."""
    base = composite_rgba(rgba, ART_LAYERS[:6])
    px, py = POST
    out = base.copy()
    post = rgba["survey-post"]
    m = post[..., 3] == 255
    if foot[1] < py:                       # actor north of the post base: drawn behind it
        paste(out, spr, foot[0], foot[1]); out[m] = post[m]
    else:
        out[m] = post[m]; paste(out, spr, foot[0], foot[1])
    fg = rgba["fg-occlusion"]
    fm = fg[..., 3] == 255
    out[fm] = fg[fm]
    return out


def zoom(arr, k):
    return np.array(Image.fromarray(arr, "RGBA").resize((arr.shape[1] * k, arr.shape[0] * k), Image.NEAREST))


def guide_overlay(flat, guides):
    out = flat.copy()
    m = guides[..., 3] == 255
    out[m] = guides[m]
    return out


# ============================================================================ containers
DT = (2026, 10, 15, 18, 14, 40)


def zput(z, name, payload, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, DT)
    zi.compress_type = method
    z.writestr(zi, payload)


def make_ora(rgba, comp_png):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.5" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for n in reversed(LAYERS):                                                # ORA lists top first
        vis = "hidden" if n == "guides" else "visible"
        stack.append(f'<layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.000" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>", ""]
    thumb = Image.fromarray(comp_png_arr(comp_png), "RGBA").resize((256, 144), Image.NEAREST)
    tb = io.BytesIO(); thumb.save(tb, "PNG")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "mimetype", b"image/openraster", zipfile.ZIP_STORED)
        zput(z, "stack.xml", "\n".join(stack).encode())
        for n in LAYERS:
            zput(z, f"data/{n}.png", png_bytes(rgba[n]))
        zput(z, "mergedimage.png", comp_png)
        zput(z, "Thumbnails/thumbnail.png", tb.getvalue())
    return buf.getvalue()


def comp_png_arr(b):
    return np.array(Image.open(io.BytesIO(b)).convert("RGBA"))


def make_pxo(rgba, comp_png):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in LAYERS]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYERS], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(BASE), "frame_current_tag": "0",
                      "include_tag_in_filename": "false", "interpolation": "0", "lines_count": "1",
                      "new_dir_for_each_frame_tag": "false", "number_of_digits": "4", "number_of_frames": "1",
                      "orientation": "0", "repeat_count": "0", "resize": "100", "save_quality": "0.75",
                      "separator_character": "\"_\"", "sheet_layers_as_separate_files": "false",
                      "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": 0, "export_profile": export_profile,
            "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json, "license": "", "metadata": {},
            "next_keyframe_id": 0, "palettes": [], "pixelorama_version": PIXELORAMA_VERSION,
            "project_current_palette_name": "", "pxo_version": 7, "reference_images": [], "size_x": W, "size_y": H,
            "symmetry_points": [W - 1.0, H - 1.0], "tags": [], "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0,
            "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "",
            "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "data.json", json.dumps(data, separators=(",", ":")))
        zput(z, "mimetype", "application/x-pixelorama")
        zput(z, "preview.png", comp_png)
        zput(z, "image_data/frames/1/", b"")
        for li, n in enumerate(LAYERS, start=1):
            zput(z, f"image_data/frames/1/layer_{li}", np.ascontiguousarray(rgba[n]).tobytes())
            zput(z, f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_gpl():
    lines = ["GIMP Palette", f"Name: {BASE}", "Columns: 8", "#"]
    for n, h in PALETTE:
        r, g, b = (int(h[j:j + 2], 16) for j in (0, 2, 4))
        lines.append(f"{r:3d} {g:3d} {b:3d}\t{n}")
    return ("\n".join(lines) + "\n").encode()


# ============================================================================ metrics and checks
def metrics(sc, rgba, flat):
    out = {}
    used = set()
    for n in ART_LAYERS:
        a = rgba[n]
        opaque = a[..., 3] == 255
        semi = (a[..., 3] > 0) & (a[..., 3] < 255)
        cols = {tuple(c) for c in a[opaque][:, :3].tolist()} if opaque.any() else set()
        used |= cols
        out[n] = {"opaque_texels": int(opaque.sum()), "semi_alpha_texels": int(semi.sum()),
                  "distinct_colours": len(cols),
                  "colours_outside_art_palette": len(cols - {tuple(RGB[i].tolist()) for i in range(N_ART)})}
    flat_cols = {tuple(c) for c in flat[..., :3].reshape(-1, 3).tolist()}
    idx = np.full((H, W), -1, np.int32)
    lut = {tuple(RGB[i].tolist()): i for i in range(N_ART)}
    fl = flat[..., :3].reshape(-1, 3)
    idx = np.array([lut.get(tuple(c), -1) for c in map(tuple, fl.tolist())], np.int32).reshape(H, W)
    p = np.pad(idx, 1, mode="edge")
    iso = (idx != p[:-2, 1:-1]) & (idx != p[2:, 1:-1]) & (idx != p[1:-1, :-2]) & (idx != p[1:-1, 2:])
    # occlusion limits (proposed in the spec, creator to confirm)
    walk = sc.walkable_mask()
    fg = rgba["fg-occlusion"][..., 3] == 255
    spr = heroine_48()
    sm = spr[..., 3] == 255
    sh, sw = sm.shape
    worst, fails, tested = 1.0, 0, 0
    worst_at = None
    for y in range(0, H, 4):
        for x in range(0, W, 4):
            if not walk[y, x]:
                continue
            x0, y0 = x - sw // 2, y - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            cov = fg[y0:y0 + sh, x0:x0 + sw] & sm
            vis = 1 - cov.sum() / sm.sum()
            tested += 1
            if vis < worst:
                worst, worst_at = vis, (x, y)
            if vis < 1 / 3:
                fails += 1
    out["_summary"] = {
        "art_palette_size": N_ART, "distinct_colours_in_flat": len(flat_cols),
        "distinct_colours_all_art_layers": len(used),
        "isolated_single_texels_in_flat": int(iso.sum()),
        "isolated_single_texel_ratio": round(float(iso.mean()), 5),
        "walkable_texels": int(walk.sum()),
        "fg_occlusion_over_walkable_ratio": round(float((fg & walk).sum() / walk.sum()), 4),
        "fg_limit_ratio": 0.12,
        "actor_visibility_samples": tested, "actor_visibility_worst": round(float(worst), 3),
        "actor_visibility_worst_at_foot": worst_at, "actor_visibility_below_one_third": fails,
        "heroine_overlay_px": [int(sw), int(sh)],
    }
    return out


def ysort_check(rgba):
    """Actor north of the post base must be hidden where the post overlaps; south of it must be on top."""
    spr = heroine_48()
    post = rgba["survey-post"][..., 3] == 255
    res = {}
    for name in ("post_behind", "post_front"):
        foot = actor_cases()[name]
        still = runtime_stack_still(rgba, spr, foot)
        act = np.zeros((H, W, 4), np.uint8)
        paste(act, spr, foot[0], foot[1])
        am = act[..., 3] == 255
        overlap = am & post & ~(rgba["fg-occlusion"][..., 3] == 255)
        if not overlap.any():
            res[name] = {"overlap_texels": 0, "ok": False}
            continue
        shows_actor = (still[overlap] == act[overlap]).all(axis=1)
        shows_post = (still[overlap] == rgba["survey-post"][overlap]).all(axis=1)
        exp_actor = name == "post_front"
        res[name] = {"overlap_texels": int(overlap.sum()),
                     "actor_on_top_texels": int(shows_actor.sum()), "post_on_top_texels": int(shows_post.sum()),
                     "ok": bool(shows_actor.all()) if exp_actor else bool(shows_post.all())}
    return res


# ============================================================================ build artefacts
def artefacts():
    sc = Scene().build()
    rgba = {n: to_rgba(sc.L[n]) for n in LAYERS}
    flat = composite_rgba(rgba, ART_LAYERS)
    flat_png = png_bytes(flat)
    files = {"pxo": make_pxo(rgba, flat_png), "ora": make_ora(rgba, flat_png), "flat": flat_png,
             "gpl": make_gpl()}
    return sc, rgba, flat, files


def names():
    return {"pxo": f"{BASE}.pxo", "ora": f"{BASE}.ora", "flat": f"{BASE}_flat.png", "gpl": f"{BASE}_palette.gpl",
            "manifest": f"{BASE}_manifest.json", "walk": f"{BASE}_walkability.json"}


def walkability_json(sc):
    wm = sc.walkable_mask()
    cell = 8
    rows = []
    for gy in range(0, H, cell):
        r = ""
        for gx in range(0, W, cell):
            blk = wm[gy:gy + cell, gx:gx + cell]
            r += "." if blk.mean() >= 0.5 else "#"
        rows.append(r)
    px, py = POST
    return {"status": "UNAPPROVED candidate data derived from the guides layer; not runtime-integrated",
            "canvas": [W, H], "cell_px": cell, "grid_legend": {".": "walkable (>=50% of cell)", "#": "blocked"},
            "grid": rows, "pins": {k: list(v) for k, v in sc.pins().items()},
            "survey_post": {"pivot_base_centre": [px, py], "footprint_xyxy": [px - 20, py - 8, px + 19, py],
                            "y_sort_rule": "actor foot y < pivot y -> drawn behind the post; else in front"},
            "patrol_route_loop": [list(p) for p in PATROL],
            "cordon_stakes": [list(p) for p in sc.cordon]}


def previews(sc, rgba, flat):
    spr = heroine_48()
    out = {}
    scale = flat.copy()
    for k, foot in actor_cases().items():
        if k in ("post_behind", "post_front"):
            continue
        paste(scale, spr, *foot)
    out["preview_scale-heroine48"] = scale
    out["preview_guides-overlay"] = guide_overlay(flat, rgba["guides"])
    for name in ("post_behind", "post_front", "entry", "terrace_stairs", "left_walk_canopy"):
        st = runtime_stack_still(rgba, spr, actor_cases()[name])
        out[f"still_runtime-stack_{name}"] = st
    crops = {"terrace-stairs": (440, 60, 840, 260), "collapse-post": (840, 120, 1160, 440),
             "left-walk-belt": (0, 200, 400, 520), "lawn-axis": (480, 420, 800, 720)}
    for k, (x0, y0, x1, y1) in crops.items():
        out[f"zoom3x_{k}"] = zoom(scale[y0:y1, x0:x1], 3)
    return out


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def manifest(sc, rgba, flat, files, met):
    nm = names()
    rows = np.nonzero(sc.post_mask.any(axis=1))[0]
    post_h = int(rows.max() - rows.min() + 1)
    return {
        "project": SLUG, "area": "washington-capitol-west-grounds", "run": RUN,
        "status": "UNAPPROVED exploration-scene candidate (test-only). Not accepted art, not runtime-integrated. "
                  "Acceptance is creator review only.",
        "art_approved": False, "runtime_integrated": False, "counters_changed": False,
        "authorship": "Deterministic Python tool authored and run by Claude (Claude Code, claude.ai Max, firstParty). "
                      "No image-generation model; every texel is placed by the tool's rules and hand-authored stamps.",
        "spec": SPEC_REL, "site_audit": AUDIT_REL,
        "canvas": {"w": W, "h": H, "texel": "1 authored texel = 1 logical/screen px; nearest-neighbour only",
                   "camera": "top-down, mild 3/4 front faces; top = east (Capitol west terrace), bottom = west",
                   "scale_reference": {"file": HEROINE_REL, "logical_height_px": 48,
                                       "note": "approved v8 static south idle (96 texels at 2:1) sampled 2:1 for "
                                               "overlays only; not part of any layer"},
                   "px_per_m_estimate": 27},
        "site_fidelity": {
            "observed_or_AOC": ["West terrace edge with balustrade and central stairs at the top (east)",
                                "Open West Front Lawn on the axis; trees only in the flank belts",
                                "Curved walks through tree belts on both flanks; benches along the paths",
                                "Facade base strip only; no dome drawn"],
            "deliberately_absent": ["moat / basins / any water", "compass medallion", "gate-pier avenue",
                                    "Summerhouse (NW corner of the grounds, outside this crop; the NW walk exit "
                                    "pin points toward it)", "western road loop (outside the scene)",
                                    "Reflecting Pool (on the Mall, outside the grounds)"],
            "estimated_not_measured": ["terrace wall drawn 42 px (~1.6 m) high: compressed, real height unverified",
                                       "stair flight 188 px (~7 m) wide, 16 steps: count and layout unverified",
                                       "deck depth 82 px (~3 m) between facade base and edge: compressed",
                                       "walk widths 36 px (~1.3 m), axial walk 80 px (~3 m): unverified",
                                       "lawn panels, walk radii and tree positions: arrangement only"],
            "game_fiction": ["collapsed terrace-wall bay (x 872-1112) with breach, rubble talus and toppled pier",
                             "overgrowth, vines, cracks, missing slabs, dry patches",
                             "science survey post, crates, cables, patrol-route beacons, worn patrol trail, "
                             "orange survey paint, cordon stakes and tape"],
            "concepts_used_as": "mood only (palette temperature, ruin-and-overgrowth feel); no shapes traced"},
        "layers_bottom_to_top": [
            {"index": i + 1, "name": n, "visible": n != "guides", "locked": n == "guides",
             "runtime_export": {"survey-post": "separate Y-sorted sprite, pivot = base centre " + str(list(POST)),
                                "fg-occlusion": "separate overlay above actors",
                                "guides": "never exported"}.get(n, "merged into base"),
             **{k: v for k, v in met.get(n, {}).items()}} for i, n in enumerate(LAYERS)],
        "layer_notes": {
            "terrace-walls": "stair flight (treads + risers) kept whole in this layer so the flight edits as one "
                             "unit; spec lists treads under paving-walks",
            "ground-detail": "tufts, grass overhang on curbs, flowers, shrubs, vines, cracks, chips, survey paint, "
                             "cables",
            "cast-shadows": "opaque palette shadow colours chosen per texel from the colour underneath (SHADE map); "
                            "re-run the tool after editing lower layers",
            "guides": "walk envelope (cyan), collision outlines (red), pins (yellow), 48 px height ticks (white), "
                      "patrol route (magenta); guide colours are outside the art palette and never exported"},
        "palette": [{"name": n, "hex": "#" + h} for n, h in PALETTE],
        "guide_palette": [{"name": n, "hex": "#" + h} for n, h in GUIDE_PALETTE],
        "metrics": met["_summary"],
        "files_sha256_bytes": {nm[k]: sha(v) for k, v in files.items()},
        "survey_post": {"pivot_base_centre": list(POST), "height_px": post_h, "height_vs_actor": round(post_h / 48, 2)},
        "tree_belts": {"trees": len(sc.tree_list), "dropped_by_actor_visibility_rule": sc.trees_dropped_for_visibility},
        "tool": {"file": TOOL_REL, "sha256_text_lf_v1": sha_text(read_bytes(os.path.abspath(__file__))),
                 "python": sys.version.split()[0], "pillow": Image.__version__, "numpy": np.__version__},
    }


def build(preview_dir=None):
    sc, rgba, flat, files = artefacts()
    met = metrics(sc, rgba, flat)
    met["_ysort"] = ysort_check(rgba)
    pv = previews(sc, rgba, flat)
    if preview_dir:
        os.makedirs(preview_dir, exist_ok=True)
        Image.fromarray(flat, "RGBA").save(os.path.join(preview_dir, "flat.png"))
        for k, a in pv.items():
            Image.fromarray(a, "RGBA").save(os.path.join(preview_dir, k + ".png"))
        for n in LAYERS:
            Image.fromarray(rgba[n], "RGBA").save(os.path.join(preview_dir, f"layer-{n}.png"))
        print(json.dumps({"summary": met["_summary"], "ysort": met["_ysort"],
                          "layers": {n: met[n] for n in ART_LAYERS}}, indent=1))
        return 0
    sc2, rgba2, flat2, files2 = artefacts()
    if files2 != files:
        raise SystemExit("build is not deterministic")
    cand, out = rp(CAND_REL), rp(OUT_REL)
    os.makedirs(_fs(cand), exist_ok=True)
    os.makedirs(_fs(out), exist_ok=True)
    nm = names()
    for k in ("pxo", "ora", "flat", "gpl"):
        print(write_new(os.path.join(cand, nm[k]), files[k]), nm[k])
    wj = (json.dumps(walkability_json(sc), indent=1) + "\n").encode()
    files["walk"] = wj
    print(write_new(os.path.join(cand, nm["walk"]), wj), nm["walk"])
    man = manifest(sc, rgba, flat, files, met)
    man["ysort_check"] = met["_ysort"]
    man["qa_previews_dir"] = OUT_REL
    print(write_new(os.path.join(cand, nm["manifest"]), (json.dumps(man, indent=2) + "\n").encode()), nm["manifest"])
    for k, a in pv.items():
        print(write_new(os.path.join(out, f"{BASE}_{k}.png"), png_bytes(a)), k)
    return 0


# ============================================================================ Pixelorama gate (isolated APPDATA)
def snapshot_dir(root):
    snap = {}
    if root and os.path.isdir(root):
        for d, _, fs in os.walk(root):
            for f in fs:
                p = os.path.join(d, f)
                try:
                    st = os.stat(p)
                    snap[os.path.relpath(p, root).replace("\\", "/")] = (st.st_size, st.st_mtime_ns)
                except OSError:
                    snap[os.path.relpath(p, root).replace("\\", "/")] = None
    return snap


def run_isolated(exe, args, fake_appdata, real_root):
    """Run Pixelorama headless with APPDATA pointed at a temp dir. Kill-switch: if anything in the real
    %APPDATA%\\pixelorama other than the GUI's own .running heartbeat changes, or .running disappears, kill at once."""
    env = dict(os.environ)
    env["APPDATA"] = fake_appdata
    before = snapshot_dir(real_root)
    t0 = time.time()
    p = subprocess.Popen([exe, "--headless", "--quit", "--"] + args, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    killed, saw_fake_user_dir, marker_missing = False, False, False
    while p.poll() is None:
        now = snapshot_dir(real_root)
        changed = {k for k in set(before) | set(now) if before.get(k) != now.get(k) and k != ".running"}
        if ".running" in before and ".running" not in now:
            marker_missing = True
        if changed or marker_missing:
            p.kill(); killed = True
            break
        if os.path.isdir(os.path.join(fake_appdata, "pixelorama")):
            saw_fake_user_dir = True
        if time.time() - t0 > 240:
            p.kill(); killed = True
            break
        time.sleep(0.01)
    so, se = p.communicate()
    after = snapshot_dir(real_root)
    noise = ("shader_compiler", "custom_samplers", "Condition \"!actions")
    tail = [l for l in so.splitlines() + se.splitlines() if l.strip() and not any(s in l for s in noise)]
    return {"args": [os.path.basename(a) if os.path.isabs(a) else a for a in args], "exit_code": p.returncode,
            "seconds": round(time.time() - t0, 1), "killed_by_guard": killed,
            "fake_user_dir_created": saw_fake_user_dir or os.path.isdir(os.path.join(fake_appdata, "pixelorama")),
            "real_dir_changed_except_running": sorted(k for k in set(before) | set(after)
                                                      if before.get(k) != after.get(k) and k != ".running"),
            "real_running_marker_present_after": ".running" in after, "output_tail": tail[-5:]}


def list_pngs(d):
    return sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))


def check(exe, write_report, use_pixelorama, godot=None):
    sc, rgba, flat, files = artefacts()
    nm = names()
    cand = rp(CAND_REL)
    for k in ("pxo", "ora", "flat", "gpl"):
        if read_bytes(os.path.join(cand, nm[k])) != files[k]:
            raise SystemExit(f"{nm[k]} on disk differs from a fresh rebuild")
    met = metrics(sc, rgba, flat)
    ys = ysort_check(rgba)
    rep = {"run": RUN, "gates": {}, "metrics": met["_summary"], "ysort": ys}
    s = met["_summary"]
    gates = rep["gates"]
    gates["canvas_1280x720_rgba"] = all(rgba[n].shape == (H, W, 4) for n in LAYERS)
    gates["ground_base_opaque"] = met["ground-base"]["opaque_texels"] == W * H
    gates["binary_alpha_all_layers"] = all(met[n]["semi_alpha_texels"] == 0 for n in ART_LAYERS) and \
        not ((rgba["guides"][..., 3] > 0) & (rgba["guides"][..., 3] < 255)).any()
    gates["art_layers_use_only_palette"] = all(met[n]["colours_outside_art_palette"] == 0 for n in ART_LAYERS)
    gates["palette_32_to_48"] = 32 <= s["distinct_colours_in_flat"] <= 48
    gates["fg_occlusion_le_12pct_walkable"] = s["fg_occlusion_over_walkable_ratio"] <= 0.12
    gates["actor_visible_ge_one_third_everywhere"] = s["actor_visibility_below_one_third"] == 0
    gates["ysort_post"] = all(v["ok"] for v in ys.values())
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        dj = json.loads(z.read("data.json"))
    gates["pxo_layer_stack_matches_spec"] = [l["name"] for l in dj["layers"]] == LAYERS and \
        [l["visible"] for l in dj["layers"]] == [n != "guides" for n in LAYERS]
    gates["build_deterministic"] = artefacts()[3] == files
    evidence = {}
    if use_pixelorama:
        rep["pixelorama"] = pixelorama_gate(exe, files, rgba, flat)
        gates.update(rep["pixelorama"]["verdicts"])
        fp = rep["pixelorama"].pop("_flat_png", None)
        if fp is not None:
            evidence[f"{BASE}_pixelorama-pxo-flat-export.png"] = fp
    if godot:
        rep["godot"], stills = godot_gate(godot, files, rgba)
        gates.update(rep["godot"]["verdicts"])
        for k, b in stills.items():
            evidence[f"{BASE}_godot-still_{k}.png"] = b
    rep["result"] = "PASS" if all(gates.values()) else "FAIL"
    rep["note"] = "Technical gates only. Passing them does not make the art accepted; acceptance is creator review."
    text = json.dumps(rep, indent=2) + "\n"
    print(text)
    if write_report:
        out = rp(OUT_REL)
        print(write_new(os.path.join(out, f"{BASE}_technical-check-report.json"), text.encode()))
        for name, b in evidence.items():
            print(write_new(os.path.join(out, name), b), name)
    return 0 if rep["result"] == "PASS" else 1


GODOT_SCRIPT = r'''extends SceneTree
# Test-only, nonruntime: load the split layer PNGs with Image.load, report size/format/sha256 of the raw RGBA,
# then composite runtime-stack stills (base 1-6 -> Y-sorted {post, actor} -> fg-occlusion) with blend_rect.
func _init():
	var a = OS.get_cmdline_user_args()
	var dir: String = a[0]
	var names = ["ground-base", "paving-walks", "terrace-walls", "ground-detail", "cast-shadows", "props-low", "survey-post", "fg-occlusion"]
	var out = {"layers": {}, "stills": {}}
	var imgs = {}
	for n in names:
		var img = Image.load_from_file(dir + "/" + n + ".png")
		var fmt_in = img.get_format()
		if fmt_in != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		var h = HashingContext.new()
		h.start(HashingContext.HASH_SHA256)
		h.update(img.get_data())
		out["layers"][n] = {"w": img.get_width(), "h": img.get_height(), "format_loaded": fmt_in, "sha256_rgba": h.finish().hex_encode()}
		imgs[n] = img
	var hero = Image.load_from_file(dir + "/heroine48.png")
	hero.convert(Image.FORMAT_RGBA8)
	var cases = JSON.parse_string(FileAccess.get_file_as_string(dir + "/cases.json"))
	var pivot_y: int = int(cases["pivot_y"])
	for key in cases["feet"].keys():
		var foot = cases["feet"][key]
		var st = imgs["ground-base"].duplicate()
		for n in ["paving-walks", "terrace-walls", "ground-detail", "cast-shadows", "props-low"]:
			st.blend_rect(imgs[n], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		var hp = Vector2i(int(foot[0]) - hero.get_width() / 2, int(foot[1]) - hero.get_height() + 1)
		if int(foot[1]) < pivot_y:
			st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
			st.blend_rect(imgs["survey-post"], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		else:
			st.blend_rect(imgs["survey-post"], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
			st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
		st.blend_rect(imgs["fg-occlusion"], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		st.save_png(dir + "/still_" + key + ".png")
		out["stills"][key] = "still_" + key + ".png"
	var f = FileAccess.open(dir + "/godot_report.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("GODOT_GATE_DONE")
	quit()
'''


def godot_gate(godot, files, rgba):
    """Gate 4 (test-only, nonruntime): a throwaway Godot project under %LOCALAPPDATA%\\Temp with APPDATA also
    redirected there, so nothing is written to the repo or to the real Godot user dir."""
    tmp = tempfile.mkdtemp(prefix="wb-wdcgodot-")
    rep = {"godot": godot, "godot_sha256": sha(read_bytes(godot)), "steps": {}}
    stills = {}
    try:
        proj = os.path.join(tmp, "proj"); os.makedirs(proj)
        data = os.path.join(tmp, "data"); os.makedirs(data)
        fake = os.path.join(tmp, "appdata"); os.makedirs(fake)
        with open(os.path.join(proj, "project.godot"), "w", newline="\n") as f:
            f.write('config_version=5\n\n[application]\nconfig/name="wdc-scene-gate"\n')
        with open(os.path.join(proj, "gate.gd"), "w", newline="\n") as f:
            f.write(GODOT_SCRIPT)
        # the layer PNGs exactly as stored in the .ora (the interchange copy of the editable stack)
        with zipfile.ZipFile(io.BytesIO(files["ora"])) as z:
            for n in ART_LAYERS:
                with open(os.path.join(data, f"{n}.png"), "wb") as f:
                    f.write(z.read(f"data/{n}.png"))
        spr = heroine_48()
        Image.fromarray(spr, "RGBA").save(os.path.join(data, "heroine48.png"))
        feet = {k: list(v) for k, v in actor_cases().items() if k in ("entry", "post_behind", "post_front",
                                                                      "terrace_stairs")}
        with open(os.path.join(data, "cases.json"), "w") as f:
            json.dump({"pivot_y": POST[1], "feet": feet}, f)
        env = dict(os.environ); env["APPDATA"] = fake
        p = subprocess.run([godot, "--headless", "--path", proj, "--script", "gate.gd", "--", data],
                           capture_output=True, text=True, timeout=300, env=env, encoding="utf-8", errors="replace")
        rep["exit_code"] = p.returncode
        rep["printed_done"] = "GODOT_GATE_DONE" in p.stdout
        gr = json.load(open(os.path.join(data, "godot_report.json")))
        lay_ok = {}
        for n in ART_LAYERS:
            g = gr["layers"][n]
            lay_ok[n] = g["w"] == W and g["h"] == H and g["sha256_rgba"] == sha(np.ascontiguousarray(rgba[n]).tobytes())
            rep["steps"][n] = {**g, "exact_texels_vs_source": lay_ok[n]}
        st_ok = {}
        for k, foot in feet.items():
            b = read_bytes(os.path.join(data, f"still_{k}.png"))
            got = decode(b)[2]
            exp = runtime_stack_still(rgba, spr, tuple(foot))
            st_ok[k] = bool(got.shape == exp.shape and (got == exp).all())
            rep["steps"]["still_" + k] = {"foot": foot, "equals_python_runtime_stack": st_ok[k],
                                          "differing_texels": int((got != exp).any(axis=2).sum())}
            stills[k] = b
        rep["verdicts"] = {"godot_loads_layers_exact": all(lay_ok.values()) and rep["exit_code"] == 0,
                           "godot_stills_match_ysort_and_occlusion": all(st_ok.values()),
                           "godot_wrote_nothing_outside_temp": not os.path.isdir(
                               os.path.join(os.environ.get("APPDATA", ""), "Godot", "app_userdata", "wdc-scene-gate"))}
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    return rep, stills


def pixelorama_gate(exe, files, rgba, flat):
    real_root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    rep = {"pixelorama": exe, "pixelorama_sha256": sha(read_bytes(exe)),
           "isolation": "APPDATA redirected to a fresh temp dir per run; real %APPDATA%\\pixelorama polled every "
                        "10 ms with a kill-switch", "steps": {}}
    tmp = tempfile.mkdtemp(prefix="wb-wdcscene-")
    try:
        src = {}
        for k in ("pxo", "ora"):
            src[k] = os.path.join(tmp, f"src.{k}")
            with open(src[k], "wb") as f:
                f.write(files[k])
        flats = []
        for label, k, split in (("pxo_flat_1", "pxo", False), ("pxo_flat_2", "pxo", False),
                                ("pxo_split", "pxo", True), ("ora_flat", "ora", False), ("ora_split", "ora", True)):
            d = os.path.join(tmp, label); os.makedirs(d)
            fake = os.path.join(tmp, "appdata_" + label); os.makedirs(fake)
            args = ["--export"] + (["--split-layers"] if split else []) + ["-o", os.path.join(d, "f.png"), src[k]]
            r = run_isolated(exe, args, fake, real_root)
            r["pngs"] = list_pngs(d)
            r["source_copy_unchanged"] = read_bytes(src[k]) == files[k]
            if not split and len(r["pngs"]) == 1:
                b = read_bytes(os.path.join(d, r["pngs"][0]))
                a = decode(b)[2]
                r["png_sha256"] = sha(b)
                r["flat_equals_expected"] = a.shape == flat.shape and bool((a == flat).all())
                r["differing_texels"] = int((a != flat).any(axis=2).sum()) if a.shape == flat.shape else None
                if k == "pxo":
                    flats.append(b)
            if split:
                got = []
                comp = None
                for f in r["pngs"]:
                    a = decode(read_bytes(os.path.join(d, f)))[2]
                    hit = [n for n in LAYERS if a.shape == rgba[n].shape and a.tobytes() == rgba[n].tobytes()]
                    semi = int(((a[..., 3] > 0) & (a[..., 3] < 255)).sum())
                    got.append({"file": f, "exact_layer_match": hit, "semi_alpha": semi})
                r["split"] = got
                matched = [h for g in got for h in g["exact_layer_match"]]
                r["art_layers_all_exact"] = all(n in matched for n in ART_LAYERS)
                r["guides_exported"] = "guides" in matched or any("guides" in g["file"] for g in got)
                # composite of the split art layers (bottom->top) must equal the flattened expectation
                order = {n: i for i, n in enumerate(LAYERS)}
                stack = sorted(((order[g["exact_layer_match"][0]], g["file"]) for g in got
                                if g["exact_layer_match"] and g["exact_layer_match"][0] != "guides"))
                if stack:
                    comp = decode(read_bytes(os.path.join(d, stack[0][1])))[2].copy()
                    for _, f in stack[1:]:
                        a = decode(read_bytes(os.path.join(d, f)))[2]
                        m = a[..., 3] == 255
                        comp[m] = a[m]
                    r["split_composite_equals_flat"] = bool((comp == flat).all())
            rep["steps"][label] = r
        rep["pxo_flat_runs_identical"] = len(flats) == 2 and flats[0] == flats[1]
        if flats:
            rep["_flat_png"] = flats[0]
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    st = rep["steps"]
    guard_ok = all(not v["killed_by_guard"] and not v["real_dir_changed_except_running"]
                   and v["real_running_marker_present_after"] for v in st.values())
    rep["verdicts"] = {
        "pixelorama_isolation_held": guard_ok,
        "pixelorama_pxo_flat_exact": all(st[k].get("flat_equals_expected") for k in ("pxo_flat_1", "pxo_flat_2")),
        "pixelorama_pxo_flat_deterministic": rep["pxo_flat_runs_identical"],
        "pixelorama_pxo_split_layers_exact": st["pxo_split"].get("art_layers_all_exact", False),
        "pixelorama_pxo_split_composite_equals_flat": st["pxo_split"].get("split_composite_equals_flat", False),
        "pixelorama_ora_flat_exact": st["ora_flat"].get("flat_equals_expected", False),
        "pixelorama_ora_split_layers_exact": st["ora_split"].get("art_layers_all_exact", False),
        "pixelorama_sources_unchanged": all(v["source_copy_unchanged"] for v in st.values()),
        "pixelorama_split_does_not_export_hidden_guides": not any(st[k].get("guides_exported")
                                                                  for k in ("pxo_split", "ora_split")),
    }
    return rep


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("dir", nargs="?")
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    ap.add_argument("--write-report", action="store_true")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--godot", default=rp(GODOT_REL))
    ap.add_argument("--no-godot", action="store_true")
    a = ap.parse_args()
    if a.mode == "preview":
        if not a.dir or os.path.abspath(a.dir).startswith(REPO):
            raise SystemExit("preview needs a directory outside the repo")
        return build(a.dir)
    if a.mode == "build":
        return build()
    if not a.no_pixelorama and not os.path.isfile(a.pixelorama):
        raise SystemExit(f"Pixelorama not found: {a.pixelorama}")
    godot = None
    if not a.no_godot:
        if not os.path.isfile(a.godot):
            raise SystemExit(f"Godot not found: {a.godot} (or pass --no-godot)")
        godot = os.path.abspath(a.godot)
    return check(os.path.abspath(a.pixelorama), a.write_report, not a.no_pixelorama, godot)


if __name__ == "__main__":
    sys.exit(main())
