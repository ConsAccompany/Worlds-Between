"""UNAPPROVED v04 candidate of the Washington (U.S. Capitol west grounds) exploration scene.

Deterministic Python tool authored and run by Claude (Claude Code, claude.ai Max, firstParty). It writes ONE 1280x720
pixel-art exploration scene from a fixed 47-colour palette into an 11-layer stack: the v03 10-layer stack plus one
new Y-sorted sprite layer, 'fountain-ysort'. The output is a native Pixelorama .pxo (pxo_version 7), an .ora, a
flattened PNG, a walkability JSON and a manifest. Nothing here is accepted art, and nothing is wired into the game
runtime.

AUTHORING ROUTE. This is NOT a Pixelorama GUI paint pass. The 2026-10-15 Workstream-B dispatch asked for image edits in
the Pixelorama GUI. This session had no desktop or computer-use access to that GUI, so the art is set down by this
tool. The v04 changes are hand-authored placement tables written by Claude, used in place of v03's random scatter:
  * per-bay facade states and per-column damage;
  * tree list: position, family, radius, break and lean per tree;
  * rubble blocks: one entry per block;
  * paving-damage features, lawn patches and scuffs;
  * survey and ruin props.
The material painters (grass blade dither, ashlar, canopy clusters, faceted rocks) are carried over from v03. The
.pxo stays fully editable in Pixelorama; a GUI polish pass on the named layers is the intended next step.

Lineage: a copy of the v03 tool (tools/...pixelorama-build_unapproved-v03_20261015-200031-6c309d6a.py, left
untouched), continued under its own stamp and run id. This tool only reads the v01-v03 candidate files; `check`
re-verifies the v03 hashes.

v04 answers the Codex review of v03 at 640x360 logical gameplay scale, which found:
  * the scene read as a generic neoclassical garden with weak Capitol identity;
  * the facade, trees and lawn repeated;
  * the ruin and survey activity were concentrated in the upper right.
It also follows the v04 art-direction brief (docs/design/...walkable-scene-architecture-art-direction_unapproved-v04_
20261015-215548-aa01fefd.md). The changes:
  * West Front: the facade band grows from 40 to 60 rows. It now shows a rusticated arcade basement under a belt
    course, a main floor with alternating triangular and segmental window pediments, and a projecting central pavilion
    with PAIRED columns. Every bay and column gets a hand-assigned state; there is no rule cycle or random stamp.
  * Terrace: the wall rises from 42 to 74 px, and its face carries terrace-room windows (Olmsted terrace), each in its
    own condition.
  * Stairs: TWIN side stairs (two flights and a landing each) replace the single central stair. They frame a lower
    curved EXEDRA with three blind niches and a DRY octagonal fountain overgrown with shrubs and a self-sown tree. There
    is no water anywhere.
  * Stair damage differs by side:
    - left stair: mostly intact, with grass in the joints, ivy on the outer cheek and one missing baluster;
    - right stair: beside the collapse, with displaced treads, a rubble spill on its outer third and a fallen urn, but
      a clear lane of at least 40 px.
  * Ruin and survey spread across the frame:
    - the survey post moves to the left lawn panel;
    - the collapse is narrower and stays on the right;
    - a second, smaller slump with a fallen urn sits at the left balustrade;
    - an uprooted tree, a toppled walk lamp and a settled section of the axial walk are in the lower half;
    - a survey transect line crosses the centre.
  * Trees, rubble, paving damage and lawn patches are placed from hand-written tables, each item distinct.
Camera: top-down with mild 3/4 front faces. Top of frame = east (Capitol west front + terrace); bottom = west.
NOT drawn (deliberately): any water, moat, pool or reflecting surface; the dome (a separate establishing view is
proposed instead); the Summerhouse; the western road loop. Game fiction drawn on top of the site (not site fact):
  * the collapse and the left slump;
  * a broken column;
  * scorch;
  * bunting;
  * storm damage and overgrowth;
  * the survey post and kit;
  * the patrol beacons;
  * the transect.

Every file this tool writes is named <project slug>_<area>_<purpose>_unapproved-v04_<stamp>-<run id>.<ext>. Each QA
view is a separate image; the tool makes no combined collage or comparison image.

Modes
  preview <dir>   render everything into <dir> (outside the repo) for visual iteration; writes nothing in the repo
  build           write candidate files (game/assets/environments/candidates/<RUN>/) and QA previews
                  (outputs/<RUN>/); refuses to overwrite a different existing file
  check           run the technical gates on the built files. Also, unless switched off:
                    * Pixelorama 1.2.3 headless flat and --split-layers exports of temp copies (skip with
                      --no-pixelorama). APPDATA points at a temp dir, so the open GUI's real %APPDATA%\\pixelorama is
                      never touched.
                    * a throwaway Godot project in temp that renders heroine-scale runtime stills: the full 1280x720
                      scene plus 640x360 logical camera windows (skip with --no-godot).
                  --write-report writes the JSON report and evidence PNGs into outputs/<RUN>/ (never overwrites).

Run: python -I -B <this file> preview <tempdir> | build | check [--write-report] [--no-pixelorama] [--no-godot]
"""
import argparse, hashlib, io, json, math, os, shutil, subprocess, sys, tempfile, time, zipfile
import numpy as np
from PIL import Image, ImageDraw

REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SLUG = "rpg-2-star-ocean-the-second"
AREA = "wdc-capitol-west"
VER = "unapproved-v04"
STAMP = "20261016-004457"
RUN_ID = "a17af0a6"
RUN = f"wdc-capitol-west-v04_{STAMP}-{RUN_ID}"
V03_RUN = "wdc-capitol-west-v03_20261015-200031-6c309d6a"                       # read-only predecessor
V03_TOOL_REL = ("tools/rpg-2-star-ocean-the-second_washington-capitol_west-grounds-scene-candidate_pixelorama-build_"
                "unapproved-v03_20261015-200031-6c309d6a.py")
V03_QA_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_west-grounds-scene-candidate_qa-note-unapproved-"
              "v03_20261015-200031-6c309d6a.md")
V04_PLAN_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_west-grounds-scene-candidate_v04-pixelorama-"
                "layer-and-qa-plan_qa-note-unapproved-v04_20261015-224902-3d9a61c7.md")
BRIEF_REL = ("docs/design/rpg-2-star-ocean-the-second_wdc-capitol-west_walkable-scene-architecture-art-direction_"
             "unapproved-v04_20261015-215548-aa01fefd.md")
CAND_REL = f"game/assets/environments/candidates/{RUN}"
OUT_REL = f"outputs/{RUN}"
TOOL_REL = "tools/" + os.path.basename(os.path.abspath(__file__))
SPEC_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_pixelorama-scene-production-spec_"
            "technical-unapproved-v01_20261015-174500-5e0d2b71.md")
AUDIT_REL = ("docs/qa/rpg-2-star-ocean-the-second_washington-capitol_site-map-visual-audit_"
             "qa-note-unapproved-v01_20261015-175832-86c8c714.md")
HEROINE_REL = ("game/assets/characters/pixelorama-pilots/rpg-2-star-ocean-the-second_protagonist-female_"
               "south-idle-selout-v8-cloth-leather-candidate_m8-v08_20261015-021600-157a5ea0.png")
PIXELORAMA_DEFAULT = ("C:/Users/hkzha/AppData/Local/Programs/Pixelorama-1.2.3/"
                      "Pixelorama-Windows-64bit/Pixelorama.exe")
PIXELORAMA_VERSION = "v1.2.3-stable"
GODOT_REL = "work/tooling/godot-4-7-2/Godot_v4.7.2-stable_win64_console.exe"      # gitignored local tooling
W, H = 1280, 720
CAM_W, CAM_H = 640, 360           # game/project.godot logical viewport (window 1280x720, integer 2x)
WIN_LONG_PREFIX = "\\\\?\\"


def fname(purpose, ext):
    """AGENTS naming: project slug, area, purpose, version, timestamp and run id are all in the file name."""
    return f"{SLUG}_{AREA}_{purpose}_{VER}_{STAMP}-{RUN_ID}.{ext}"


EXPORT_STEM = f"{SLUG}_{AREA}_pixelorama-export_{VER}_{STAMP}-{RUN_ID}"

LAYERS = ["ground-base", "paving-walks", "terrace-walls", "ground-detail", "cast-shadows",
          "props-low", "stair-lamps-ysort", "fountain-ysort", "survey-post", "fg-occlusion",
          "guides"]                                                                # bottom -> top
ART_LAYERS = LAYERS[:10]                                                           # guides: hidden, locked
BASE_LAYERS = LAYERS[:6]                                                           # merged into one base at runtime
YSORT = {"stair-lamps-ysort": None, "fountain-ysort": None, "survey-post": None}   # layer -> pivot y (set below)

# ============================================================================ palette (47 art colours, as v03)
PALETTE = [
    ("ink", "1a1c22"),
    ("g0", "1f3324"), ("g1", "2c4a2c"), ("g2", "3d6234"), ("g3", "557a3c"), ("g4", "6f9145"),
    ("g5", "93ad55"), ("g6", "b9c26c"), ("g7", "d3d98a"),
    ("d0", "7f7c45"), ("d1", "a99a5e"),
    ("f0", "16262a"), ("f1", "223d3a"), ("f2", "2f5644"),
    ("e2", "2a5a52"), ("e3", "40806c"), ("e4", "6aa58a"),
    ("s0", "3a2c22"), ("s1", "5a4430"), ("s2", "7d6345"), ("s3", "a08458"), ("s4", "c6aa76"),
    ("m0", "4a4c58"), ("m1", "6e6f78"), ("m2", "93918f"), ("m3", "b8b3a8"), ("m4", "d6d0c2"), ("m5", "ece6d6"),
    ("p0", "6b5f52"), ("p1", "8d7f6c"), ("p2", "ab9d86"), ("p3", "c6b99e"),
    ("k0", "232a36"), ("k1", "3a4656"), ("k2", "5a6a7c"), ("k3", "8d9cab"),
    ("c0", "1f6f78"), ("c1", "49c6cf"), ("c2", "b4f4f0"),
    ("o0", "a34a1e"), ("o1", "e07a2e"), ("o2", "f4b860"),
    ("fl", "c79ad0"), ("bl", "eda7b6"), ("y0", "e8cf58"),
    ("r0", "9a3b34"), ("n0", "2e3f66"),
]
GUIDE_PALETTE = [("gd-walk", "3cdcff"), ("gd-block", "ff285a"), ("gd-pin", "ffe600"), ("gd-tick", "ffffff"),
                 ("gd-route", "ff78ff")]
ALL_PAL = PALETTE + GUIDE_PALETTE
I = {n: i for i, (n, _) in enumerate(ALL_PAL)}
RGB = np.array([[int(h[j:j + 2], 16) for j in (0, 2, 4)] for _, h in ALL_PAL], np.uint8)
N_ART = len(PALETTE)
WATER = {I["c0"], I["c1"], I["c2"]}            # never allowed inside the fountain basin (dry ruin feature)

GR = [I[n] for n in ("g0", "g1", "g2", "g3", "g4", "g5", "g6", "g7")]           # grass ramp
FOL = [I[n] for n in ("f0", "f1", "f2", "g2", "g3", "g4", "g5")]                # oak canopy ramp
ELM = [I[n] for n in ("f1", "g1", "g2", "g3", "g4", "g5", "g6")]                # elm canopy ramp (yellower)
CON = [I[n] for n in ("f0", "f1", "e2", "e3", "e4")]                            # holly / conifer ramp
MAG = [I[n] for n in ("f0", "f1", "f2", "e2", "e3", "g4")]                      # magnolia ramp (glossy)
BOX = [I[n] for n in ("f0", "f1", "e2", "g2", "g3", "g4")]                      # clipped boxwood / verge shrubs
STONE = [I[n] for n in ("ink", "m0", "m1", "m2", "m3", "m4", "m5")]             # marble / granite ramp
PAVE = [I[n] for n in ("m0", "p0", "p1", "p2", "p3", "m4")]                     # walk paving ramp
SOIL = [I[n] for n in ("ink", "s0", "s1", "s2", "s3", "s4")]
METAL = [I[n] for n in ("ink", "k0", "k1", "k2", "k3")]

SHADE = {  # opaque cast-shadow colour for each art colour underneath (no semi-alpha anywhere)
    "ink": "ink", "g0": "f0", "g1": "g0", "g2": "g1", "g3": "g1", "g4": "g2", "g5": "g3", "g6": "g4", "g7": "g5",
    "d0": "g1", "d1": "d0", "f0": "f0", "f1": "f0", "f2": "f1", "e2": "f1", "e3": "e2", "e4": "e3",
    "s0": "ink", "s1": "s0", "s2": "s1", "s3": "s1", "s4": "s2",
    "m0": "ink", "m1": "m0", "m2": "m1", "m3": "m1", "m4": "m2", "m5": "m3",
    "p0": "m0", "p1": "p0", "p2": "p0", "p3": "p1",
    "k0": "ink", "k1": "k0", "k2": "k1", "k3": "k2", "c0": "k0", "c1": "c0", "c2": "c0",
    "o0": "s0", "o1": "o0", "o2": "o1", "fl": "s1", "bl": "fl", "y0": "d1", "r0": "s0", "n0": "k0",
}
SHADE_LUT = np.arange(len(ALL_PAL), dtype=np.int16)
for _a, _b in SHADE.items():
    SHADE_LUT[I[_a]] = I[_b]

# ============================================================================ scene geometry (logical px)
# v04 vertical layout. The architecture is taller, so the Capitol fills the upper two 640x360 camera windows:
# facade band 0-75 | deck 76-125 | balustrade 126-145 | terrace wall 146-219 | stairs to 300 | forecourt 300-352 | lawn
FACADE_Y1 = 76            # facade rows 0..75: main floor 0..35, belt course 36..39, rusticated basement 40..69, plinth
BELT_Y = 36
BASE_Y0 = 40              # rusticated basement top row
PLINTH_Y = 70
PED_Y, WIN_Y0, WIN_Y1, SILL_Y = 5, 11, 29, 30      # main-floor window: pediment, sash rows, sill (apron to BELT_Y)
PAV = (476, 804)          # central projecting pavilion (symmetric about x 639.5)
PAV_Y1 = 88               # its basement + steps project to row 87
SUBP = ((128, 276), (1003, 1151))    # wing pavilions (slight projection)
SUBP_Y1 = 80
COL_BROKEN = (1, 2)       # (wing pavilion index, column index): game-fiction broken column on the damaged south end
EDGE_Y = 146              # terrace deck edge = top of the west retaining-wall face
WALL_H = 74               # wall face rows 146..219 (compressed; real terrace ~20 ft)
FOOT_Y = EDGE_Y + WALL_H  # 220: lawn level at the wall foot
BAL_H = 20                # balustrade rows 126..145
CHEEK_W = 14
STAIRS = ((404, 499), (780, 875))     # left / right stair flights between their cheek walls (mirror about x 639.5)
STAIR_BOT = 300           # bottom tread row of both stairs
LANDING = (210, 227)      # landing rows of both stairs
EXEDRA = (STAIRS[0][1] + CHEEK_W + 1, STAIRS[1][0] - CHEEK_W - 1)   # 514..765: curved recess between the inner cheeks
EXEDRA_DEPTH = 22         # how far the curved deck edge bows back (north) at the centre
FOUNTAIN = (640, 262)     # dry octagonal basin centre (top face)
FOUNTAIN_HALF = (46, 22)  # half extents of the octagonal coping, top face
FOUNTAIN_FACE = 7         # coping front face height
FORE = (372, 300, 907, 352)          # paved forecourt below both stair feet (x0, y0, x1, y1)
AXIS = (600, 680)                    # axial walk x range, runs to the bottom (west) edge
WALK_W = 36
LEFT_WALK = [(392, 330), (262, 338), (212, 452), (198, 740)]       # cubic Bezier control points
RIGHT_WALK = [(887, 330), (1010, 342), (1068, 470), (1080, 740)]
BRANCH_W = 26
LEFT_BRANCH = [(214, 572), (156, 596), (80, 616), (-30, 640)]
COLLAPSE = (950, 1126)               # collapsed terrace-wall bay (game fiction), right of the right stair
SLUMP = (166, 222)                   # v04: smaller slumped balustrade bay on the left (game fiction)
POST = (452, 486)                    # survey-post pivot: base centre (x, contact row y); v04 left lawn panel
# balustrade piers, listed from each stair's outer cheek outward (uneven bays, mirrored about the axis)
PIERS_L = [334, 278, 222, 166, 110, 54]
PIERS_R = [W - 1 - x for x in PIERS_L]
PIERS = PIERS_L + PIERS_R
# per-bay state of the deck-edge balustrade, from the stair outward (hand-assigned; 'breach'/'slump' = ruin bays)
BAY_STATE_L = ["ivy", "clean", "stained", "slump", "mossy", "replaced", "chipped"]
BAY_STATE_R = ["missing", "breach", "breach", "breach", "chipped", "stained", "ivy"]
PATROL = [(560, 342), (530, 404), (520, 470), (400, 560), (360, 646), (520, 680), (640, 620), (640, 380)]
ENTRY = (640, 700)
YSORT["stair-lamps-ysort"] = STAIR_BOT      # all four newels share their front ground-contact row (300)
YSORT["fountain-ysort"] = FOUNTAIN[1] + 4   # pedestal + self-sown tree, pivot = pedestal base row
YSORT["survey-post"] = POST[1]
CHEEKS = [(STAIRS[0][0] - CHEEK_W, -1, 0), (STAIRS[0][1] + 1, 1, 0),
          (STAIRS[1][0] - CHEEK_W, -1, 1), (STAIRS[1][1] + 1, 1, 1)]   # (cheek x0, side of its stair, stair index)
LAMP_X = tuple(x0 + CHEEK_W // 2 for x0, _, _ in CHEEKS)                # newel / candelabra centre columns
NEWEL_COLLAR = 5                             # documented no-walk margin round each newel footprint (px)
CHEEK_COLLAR = 7                             # no-walk margin along the cheek walls' lawn faces (px)
FOUNTAIN_COLLAR = 5                          # no-walk margin round the basin coping (px)
# ============================================================================ small helpers
def _fs(path):
    path = os.path.abspath(path)
    if os.name == "nt" and len(path) > 247 and not path.startswith(WIN_LONG_PREFIX):
        return WIN_LONG_PREFIX + path
    return path


def rp(rel):
    return os.path.join(REPO, *rel.split("/"))


def read_bytes(p):
    with open(_fs(p), "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def sha_text(b):
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def blank():
    return np.full((H, W), -1, np.int16)


def rng_for(*key):
    return np.random.default_rng(int.from_bytes(hashlib.sha256(repr(key).encode()).digest()[:8], "little"))


def vnoise(seed, cell, h=H, w=W):
    """Smooth value noise in [0,1] (bicubic-upsampled random lattice), deterministic for a seed."""
    r = rng_for("noise", seed, cell, h, w)
    gh, gw = h // cell + 4, w // cell + 4
    g = r.random((gh, gw), dtype=np.float32)
    a = np.asarray(Image.fromarray(g, "F").resize((gw * cell, gh * cell), Image.BICUBIC))[cell:cell + h, cell:cell + w]
    return (a - a.min()) / (a.max() - a.min() + 1e-9)


def blade_noise(seed, h=3):
    """Per-column vertical strokes h px tall (column phase staggered): a grass-blade dither for tone changes."""
    r = rng_for("blade", seed, h)
    offs = r.integers(0, h, W)
    vals = r.random((H // h + 2, W), dtype=np.float32)
    rows = (np.arange(H)[:, None] + offs[None, :]) // h
    return vals[rows, np.arange(W)[None, :]]


def dist_coarse(mask, cs=4, step=2):
    """Approximate Euclidean distance (px) to `mask` (0 inside), from its boundary sampled on a coarse grid."""
    sub = mask[::cs, ::cs]
    p = np.pad(sub, 1, mode="edge")
    edge = sub & ~(p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:])
    gy, gx = np.mgrid[0:sub.shape[0], 0:sub.shape[1]]
    d = np.full(sub.shape, 1e9, np.float32)
    ey, ex = np.nonzero(edge)
    for k in range(0, len(ey), step):
        d = np.minimum(d, np.hypot(gx - ex[k], gy - ey[k]).astype(np.float32))
    d = d * cs
    d[sub] = 0
    return np.repeat(np.repeat(d, cs, 0), cs, 1)[:H, :W]


def cobble_texture(key, y0, y1, x0, x1):
    """Granite rubble masonry (the terrace walls' foundation behind the marble facing): rough courses 4-6 rows high,
    stones 4-11 px long, each with its own grey (neutral or blue-grey granite), a lit top-left arris, a dark lower-right
    arris and dark mortar; stone corners are knocked off so the coursing reads as rubble, not brick."""
    r = rng_for("cobble", key)
    hh, ww = y1 - y0, x1 - x0
    out = np.full((hh, ww), I["s0"], np.int16)
    y = 0
    while y < hh:
        h = int(r.integers(4, 7))
        x = -int(r.integers(0, 8))
        while x < ww:
            w = int(r.integers(4, 12))
            body = [I["m1"], I["k2"], I["m2"], I["m1"], I["k1"]][int(r.integers(0, 5))]
            lit = I["k3"] if body in (I["k2"], I["k1"]) else I["m3"]
            for j in range(h):
                for i in range(w):
                    yy, xx = y + j, x + i
                    if not (0 <= yy < hh and 0 <= xx < ww):
                        continue
                    if j == 0 or i == 0:
                        c = I["s0"] if (j + i) % 3 else I["ink"]            # mortar joint
                    elif (j in (1, h - 1)) and (i in (1, w - 1)):
                        c = I["s0"]                                         # knocked-off corner
                    elif j == 1 or i == 1:
                        c = lit
                    elif j == h - 1 or i == w - 1:
                        c = I["m0"]
                    else:
                        c = body
                    out[yy, xx] = c
            x += w
        y += h
    return out


def despeckle(m, passes=2, valid=None):
    """Replace pixels whose 4 neighbours all differ from them: keeps clusters deliberate, no lone noise."""
    for _ in range(passes):
        p = np.pad(m, 1, mode="edge")
        up, dn, lf, rt = p[:-2, 1:-1], p[2:, 1:-1], p[1:-1, :-2], p[1:-1, 2:]
        iso = (m != up) & (m != dn) & (m != lf) & (m != rt) & (m >= 0)
        if valid is not None:
            iso &= valid
        rep = np.where(lf == rt, lf, np.where(up == dn, up, np.where(lf >= 0, lf, up)))
        m = np.where(iso & (rep >= 0), rep, m)
    return m


def majority(m, r, passes=1):
    """Box majority filter on a boolean mask (window 2r+1): rounds off lace and pinholes into firm shapes."""
    k = 2 * r + 1
    for _ in range(passes):
        p = np.pad(m.astype(np.int32), r + 1)
        c = p.cumsum(0).cumsum(1)
        s_ = c[k:, k:] - c[:-k, k:] - c[k:, :-k] + c[:-k, :-k]
        m = s_[:m.shape[0], :m.shape[1]] * 2 > k * k
    return m


def ramp_shift(idx, ramp, d):
    """Move palette index idx by d steps along ramp (clamped); colours not on the ramp map to its middle."""
    pos = {v: k for k, v in enumerate(ramp)}
    k = pos.get(int(idx), len(ramp) // 2)
    return ramp[max(0, min(len(ramp) - 1, k + d))]


def ramp_shift_arr(arr, ramp, d):
    lut = np.arange(len(ALL_PAL), dtype=np.int16)
    for k, v in enumerate(ramp):
        lut[v] = ramp[max(0, min(len(ramp) - 1, k + d))]
    out = arr.copy()
    ok = arr >= 0
    out[ok] = lut[arr[ok]]
    return out


def put(layer, mask, idx):
    layer[mask] = idx


def rect(layer, x0, y0, x1, y1, idx):
    """Fill inclusive rect, clipped."""
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W - 1, x1), min(H - 1, y1)
    if x0 <= x1 and y0 <= y1:
        layer[y0:y1 + 1, x0:x1 + 1] = idx


def setpx(layer, x, y, idx):
    if 0 <= x < W and 0 <= y < H:
        layer[y, x] = idx


def line(layer, x0, y0, x1, y1, idx):
    n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
    for t in np.linspace(0, 1, n):
        setpx(layer, int(round(x0 + (x1 - x0) * t)), int(round(y0 + (y1 - y0) * t)), idx)


def stamp(layer, x, y, rows, cmap, under=None, ramp=None, mask=None):
    """Draw an ASCII sprite. cmap: char -> palette name, or int offset along `ramp` relative to `under`."""
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if ch == ".":
                continue
            px, py = x + i, y + j
            if not (0 <= px < W and 0 <= py < H) or (mask is not None and not mask[py, px]):
                continue
            v = cmap[ch]
            if isinstance(v, int):
                if isinstance(under, np.ndarray):
                    base = under[py, px]
                else:
                    base = under if under is not None else ramp[len(ramp) // 2]
                layer[py, px] = ramp_shift(base, ramp, v)
            else:
                layer[py, px] = I[v]


def composite_idx(layers, names):
    out = layers[names[0]].copy()
    for n in names[1:]:
        m = layers[n] >= 0
        out[m] = layers[n][m]
    return out


def bezier(pts, n=1600):
    t = np.linspace(0, 1, n)[:, None]
    p = [np.array(q, float) for q in pts]
    c = ((1 - t) ** 3) * p[0] + 3 * ((1 - t) ** 2) * t * p[1] + 3 * (1 - t) * t * t * p[2] + (t ** 3) * p[3]
    seg = np.r_[0, np.cumsum(np.hypot(*np.diff(c, axis=0).T))]
    return c, seg


def band_coords(pts, half):
    """Per-pixel (s along curve, signed t across) for pixels within `half`+6 px of a cubic Bezier."""
    c, seg = bezier(pts)
    tang = np.gradient(c, axis=0)
    tang /= np.linalg.norm(tang, axis=1, keepdims=True)
    S = np.full((H, W), np.nan, np.float32)
    T = np.full((H, W), np.nan, np.float32)
    x0 = int(max(0, c[:, 0].min() - half - 8)); x1 = int(min(W, c[:, 0].max() + half + 9))
    y0 = int(max(0, c[:, 1].min() - half - 8)); y1 = int(min(H, c[:, 1].max() + half + 9))
    xs = np.arange(x0, x1)
    for y in range(y0, y1):
        dx = xs[:, None] - c[None, :, 0]
        dy = y - c[None, :, 1]
        d2 = dx * dx + dy * dy
        k = d2.argmin(axis=1)
        d = np.sqrt(d2[np.arange(len(xs)), k])
        sgn = np.sign(tang[k, 0] * (y - c[k, 1]) - tang[k, 1] * (xs - c[k, 0]))
        ok = d <= half + 6
        S[y, xs[ok]] = seg[k[ok]]
        T[y, xs[ok]] = (d * sgn)[ok]
    return S, T, c


def stamp_mask(x, y, rows):
    """Full-frame mask of an ASCII sprite's non-'.' texels at (x, y)."""
    m = np.zeros((H, W), bool)
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if ch != "." and 0 <= x + i < W and 0 <= y + j < H:
                m[y + j, x + i] = True
    return m


# ============================================================================ v04 hand-authored tables
# Everything below was written by hand for this candidate (positions in logical px, top = east). The painters turn
# each entry into pixels with the v03 material rules; no entry comes from a random scatter.

# --- west front -------------------------------------------------------------------------------------------------
WING_PILASTERS = [42, 85, 124, 281, 320, 364, 408, 452, 471]
WING_PILASTERS = WING_PILASTERS + [W - 1 - x for x in WING_PILASTERS]
# (window centre x, main-floor state, pediment, basement-arch state); the south (right) wing is worse toward the collapse
FACADE_BAYS = [
    (20, "glass", "tri", "grille"), (64, "glass", "seg", "dark"), (106, "vine", "tri", "grille"),
    (298, "dark", "seg", "bricked"), (342, "glass", "tri", "vine"), (386, "boarded", "seg", "grille"),
    (430, "glass", "tri", "dark"),
    (849, "lintel", "tri", "dark"), (893, "scorched", "seg", "collapsed"), (937, "dark", "tri", "bricked"),
    (981, "broken", "seg", "grille"), (1173, "boarded", "tri", "dark"), (1215, "vine", "seg", "vine"),
    (1259, "glass", "tri", "grille"),
]
WING_PAV_WINDOWS = [["glass", "dark", "glass"], ["broken", "scorched", "dark"]]
WING_PAV_ARCHES = [["grille", "door", "dark"], ["collapsed", "bricked", "grille"]]
PAVILION_OPENINGS = ["dark", "glass", "door", "broken", "boarded"]     # loggia bays, left to right
PAVILION_COL_CHIPPED = {3}
PAVILION_COL_SOOT = {6, 7}
PAVILION_ARCHES = ["grille", "dark", "door", "grille", "bricked"]
FACADE_DAMAGE = [(54, 42, 10, "spall"), (198, 14, 8, "spall"), (312, 58, 12, "missing"), (230, 50, 12, "crack"),
                 (560, 66, 10, "spall"), (735, 46, 8, "spall"), (868, 46, 14, "missing"), (912, 16, 10, "spall"),
                 (958, 56, 16, "missing"), (1046, 42, 12, "spall"), (1096, 62, 14, "missing"),
                 (1196, 50, 10, "spall"), (1236, 12, 8, "crack"), (420, 2, 8, "crack")]
SCORCH = [(900, 34, 14), (946, 50, 18), (1000, 40, 12), (1060, 56, 20), (1112, 30, 12)]
FACADE_VINES = [(100, 26, True), (104, 34, True), (108, 40, True), (112, 30, True), (140, 58, True), (24, 20, False),
                (590, 16, False), (866, 26, False), (1210, 44, True), (1216, 52, True), (1222, 36, True),
                (1270, 64, True), (1274, 48, True)]
# --- terrace wall, balustrade, urns -----------------------------------------------------------------------------
WALL_WINDOWS = {("L", 0): "grille", ("L", 1): "dark", ("L", 2): "bricked", ("L", 4): "grille", ("L", 5): "boarded",
                ("L", 6): "bent", ("R", 0): "bent", ("R", 4): "boarded", ("R", 5): "grille", ("R", 6): "dark"}
PIER_CAPS = {334: "chipped", 222: "moss", 54: "chipped", 945: "chipped", 1169: "moss"}
URN_PIERS = {334: "bright", 222: "dark", 110: "streak", 945: "dark", 1169: "streak", 1225: "bright"}
# --- stairs -----------------------------------------------------------------------------------------------------
STAIR_DAMAGE = [
    {"moss_edge": 5, "moss_thr": 0.40, "joint_grass": True, "cracks": [(430, 186, 16), (468, 250, 12)],
     "chipped_noses": [(2, 440), (9, 470)], "displaced": [], "soot": False,
     "missing_balusters": {(0, -1, 172)}, "fallen_urn_pier": None},
    {"moss_edge": 2, "moss_thr": 0.55, "joint_grass": False, "cracks": [(800, 170, 20), (826, 262, 14), (812, 196, 10)],
     "chipped_noses": [(4, 806)], "displaced": [(3, 820, 846, 2), (9, 794, 818, 3)], "soot": True,
     "missing_balusters": set(), "fallen_urn_pier": (1, 1)},
]
NEWEL_STATE = ["intact", "intact", "globe-missing", "snapped"]   # left-outer, left-inner, right-inner, right-outer
# --- ruin: collapse (right) and slump (left) ---------------------------------------------------------------------
RUBBLE = [  # (kind, x, y, ...): rock (size, family) | block (w, d, h, tilt) | pier (w, d, h) | drum (len) | cornice (w)
    # on the slumped fill inside the breach
    ("block", 992, 178, 22, 6, 7, 1), ("rock", 1040, 188, 7, "marble"), ("cornice", 1056, 172, 30),
    ("rock", 1090, 198, 5, "granite"), ("baluster", 1014, 202), ("block", 1030, 205, 16, 5, 6, -1),
    # big pieces at the wall foot
    ("block", 956, 222, 30, 8, 12, 0), ("rock", 1002, 230, 11, "marble"), ("drum", 1020, 240, 22),
    ("rock", 1064, 228, 9, "grey"), ("block", 1082, 234, 26, 7, 11, 2), ("cornice", 1100, 252, 26),
    ("rock", 978, 250, 6, "granite"), ("baluster", 1052, 256), ("rock", 1120, 240, 7, "marble"),
    # mid talus
    ("block", 944, 266, 18, 5, 8, -2), ("rock", 970, 276, 8, "grey"), ("rock", 1006, 268, 5, "marble"),
    ("block", 1030, 278, 14, 5, 7, 1), ("rock", 1074, 272, 6, "granite"), ("drum", 1092, 282, 16),
    ("rock", 1124, 290, 4, "marble"), ("baluster", 992, 294),
    # thrown furthest: the toppled pier, small chips, a rail length
    ("pier", 1034, 300, 44, 12, 13), ("rock", 950, 306, 4, "marble"), ("rock", 1004, 318, 3, "grey"),
    ("rock", 1100, 316, 3, "granite"), ("block", 1086, 326, 10, 4, 5, 0), ("rock", 962, 330, 3, "grey"),
    ("rail", 980, 334, 30),
    # spill toward and onto the right stair's outer third (its inner lane stays clear)
    ("rock", 912, 270, 5, "marble"), ("rock", 904, 286, 3, "grey"),
    ("block", 848, 240, 14, 4, 6, 1), ("rock", 862, 254, 5, "marble"), ("rock", 856, 270, 4, "granite"),
    ("baluster", 864, 282), ("rock", 866, 292, 3, "marble"),
]
DECK_DEBRIS = [(948, 84, 16), (1078, 100, 12), (1172, 80, 18), (886, 106, 10), (1012, 110, 14), (1136, 88, 8)]
DRUM_ON_DECK = (1070, 88)
SLUMP_RUBBLE = [("rock", 182, 230, 6, "marble"), ("block", 194, 224, 16, 5, 7, 1), ("rock", 214, 240, 4, "grey"),
                ("baluster", 172, 244), ("rail", 186, 250, 18), ("rock", 226, 232, 3, "marble"),
                ("rock", 168, 226, 4, "granite")]
SLUMP_URN = (232, 262)
DECK_MOSS = [(180, 100, 7), (420, 112, 6), (880, 118, 8), (1130, 106, 9), (300, 90, 5), (760, 116, 5)]
RUBBLE_SHRUBS = [(980, 196, 9), (1104, 212, 11), (1130, 282, 8), (946, 290, 7), (1070, 300, 9), (1010, 160, 8)]
# --- the overgrown centre ---------------------------------------------------------------------------------------
EXEDRA_SHRUBS = [(524, 222, 10, "box"), (540, 208, 8, "fol"), (566, 204, 11, "elm"), (600, 200, 7, "box"),
                 (700, 202, 9, "box"), (738, 212, 12, "elm"), (756, 226, 8, "box"), (528, 286, 9, "fol"),
                 (752, 292, 7, "box")]
BASIN_PLANTS = [(612, 266, 7, "box"), (660, 262, 8, "box"), (676, 272, 5, "box"), (628, 274, 4, "grass"),
                (650, 252, 3, "grass"), (606, 252, 3, "grass"), (668, 256, 6, "flower")]
# --- trees: (trunk x, trunk base y, radius, family, storm-broken, lean or None) -------------------------------------
TREES = [
    # left belt: oak grove with a magnolia pair, holly accents, the dead snag, a broken elm
    (36, 268, 42, "oak", False, 0.2), (70, 312, 20, "holly", False, None), (52, 366, 50, "elm", True, 0.3),
    (150, 392, 30, "snag", False, 0.0), (10, 452, 40, "oak", False, None), (126, 470, 19, "magnolia", False, None),
    (172, 506, 17, "magnolia", False, None), (60, 540, 50, "oak", False, 0.35), (150, 548, 16, "holly", False, None),
    (-10, 590, 36, "oak", False, None), (112, 652, 18, "holly", False, None), (60, 694, 46, "elm", True, 0.25),
    (156, 704, 24, "magnolia", False, None),
    # right belt: a storm-damaged elm and oak run, magnolia and holly specimens near the walk
    (1240, 262, 46, "elm", False, -0.2), (1228, 334, 18, "holly", False, None), (1252, 384, 40, "oak", True, None),
    (1150, 428, 22, "magnolia", False, None), (1222, 476, 52, "oak", False, -0.3),
    (1124, 526, 17, "holly", False, None), (1262, 566, 36, "elm", True, None), (1180, 604, 44, "oak", False, -0.25),
    (1120, 646, 16, "holly", False, None), (1274, 690, 40, "oak", False, None),
    (1150, 700, 26, "magnolia", False, None),
]
FALLEN_TREE = ((1022, 556), (934, 604))          # uprooted oak: root plate, crown end
# --- lawn ---------------------------------------------------------------------------------------------------------
SWARD_PATCHES = [  # (cx, cy, rx, ry, tone shift, kind)
    (320, 420, 46, 20, -0.14, "damp"), (296, 690, 60, 24, -0.16, "damp"), (980, 600, 50, 20, -0.13, "damp"),
    (520, 640, 50, 18, 0.11, "dry"), (800, 470, 56, 20, 0.1, "dry"), (760, 676, 40, 16, 0.09, "dry"),
    (180, 300, 40, 16, 0.08, "dry")]
SCUFFS_HAND = [(560, 498, 30, 6), (482, 503, 10, 5), (1018, 572, 26, 9), (410, 566, 12, 5)]
TRAIL_CURVES = [([548, 354], [530, 392], [512, 430], [488, 468], 3.0),
                ([430, 500], [404, 532], [392, 566], [384, 606], 2.6),
                ([372, 650], [430, 684], [520, 690], [598, 672], 2.2),
                ([905, 300], [906, 288], [908, 274], [912, 262], 2.4)]
CLOVER_PATCHES = [(420, 324, 6), (300, 430, 6), (536, 410, 5), (760, 560, 7), (880, 450, 5), (330, 580, 8),
                  (560, 700, 5), (940, 520, 6), (250, 300, 6), (1000, 470, 5)]
FLOWER_DRIFTS = [(262, 610, ("y0", "o2"), 30, 10, 5), (276, 452, ("fl", "bl"), 24, 9, 4),
                 (1018, 500, ("m5", "m4"), 26, 9, 5), (1040, 640, ("y0", "y0"), 22, 8, 4),
                 (186, 520, ("bl", "fl"), 20, 8, 4), (1100, 470, ("y0", "o2"), 18, 8, 4),
                 (330, 690, ("fl", "bl"), 24, 12, 5), (860, 690, ("m5", "m4"), 20, 10, 4),
                 (150, 330, ("y0", "o2"), 18, 10, 4), (1170, 360, ("bl", "fl"), 14, 8, 4)]
LAWN_SHRUBS = [(272, 384, 12, "elm", [(12, 5, 4)]), (1006, 420, 13, "box", [(-12, 6, 4), (10, 4, 6)]),
               (420, 380, 10, "fol", [(10, 4, 4)]), (240, 672, 11, "box", [(12, 4, 4)]),
               (1046, 690, 12, "elm", [(-11, 5, 5)])]
BRANCHES = [(160, 452, 0.3, 30), (330, 676, -0.25, 24), (1140, 540, 0.5, 30), (960, 700, -0.15, 22),
            (420, 420, 0.1, 18)]
# --- props and survey --------------------------------------------------------------------------------------------
BENCH_SPECS = [  # (walk, side: +1 = +x side, fraction along the walk, broken, bin beside it)
    (LEFT_WALK, 1, 0.32, False, True), (LEFT_WALK, -1, 0.58, True, False), (LEFT_WALK, 1, 0.80, False, False),
    (RIGHT_WALK, -1, 0.40, False, True), (RIGHT_WALK, 1, 0.70, False, False), (RIGHT_WALK, -1, 0.88, False, True),
    (LEFT_BRANCH, -1, 0.46, True, False)]
TOPPLED_LAMP = (692, 452)
LAMP_HEAD = (892, 316)
SIGNS = [(240, 540), (690, 692)]
QUADRATS = [(300, 650), (520, 590), (764, 560), (968, 664)]
STUMPS = [(418, 612), (816, 570)]
SURVEY_FLAGS = [(744, 396), (784, 396), (824, 396), (744, 432), (784, 432), (824, 432)]
STRAIN_SENSORS = [(944, 236), (1004, 334), (1096, 338), (1150, 262)]
RELAY = (908, 248)
CORDON = [(930, 214), (930, 290), (976, 344), (1046, 356), (1120, 346), (1162, 300), (1160, 214)]
TRANSECT = ((482, 500), (880, 524))
CABLES = [((POST[0] + 2, POST[1] - 12), (506, 450)), ((POST[0] - 24, POST[1] - 4), (406, 514)),
          ((921, 244), (944, 234)), ((921, 246), (1004, 330)), ((921, 242), (1150, 258))]
SURVEY_TICKS = [(560, 316), (600, 330), (700, 316), (740, 330), (470, 340), (812, 340)]
SURVEY_ARROWS = [(560, 360, "left"), (640, 420, "up"), (720, 360, "right"), (640, 540, "up")]
SENSOR = [".C.", "CXC", ".k.", ".k.", ".k.", ".k.", ".k.", ".k.", "kKk"]
RELAY_BOX = ["..xxxxxxxxxx..",
             ".xCCCCCCCCCCx.",
             "xHHHHHHHHHHHHx",
             "xHMMMMMMMMMMDx",
             "xHMoMcMMMMMMDx",
             "xHMMMMMMMMMMDx",
             "xDDDDDDDDDDDDx",
             ".x..........x."]
RELAY_MAP = {"x": "ink", "C": "c0", "H": "k3", "M": "k2", "D": "k1", "o": "o1", "c": "c1"}
LAMP_HEAD_LYING = [".xx......xx.....",
                   "xLMxbBBBBxLMx...",
                   "xLDxbBBBBxLDxxx.",
                   ".xx.....xx.xLMMx",
                   "...........xxxx."]
PINS = {"spawn_entry_west": ENTRY, "exit_west_axis": (640, 716), "exit_northwest_walk": (200, 716),
        "exit_southwest_walk": (1079, 716), "exit_east_portico": (640, 96),
        "left_stair_top": (452, 118), "right_stair_top": (827, 118),
        "left_stair_foot": (452, 306), "right_stair_foot": (810, 306),
        "fountain_west_side": (566, 262), "fountain_east_side": (714, 262), "fountain_behind": (640, 226),
        "survey_post_interaction": (POST[0], POST[1] + 14), "survey_post_pivot": POST}


def bench_positions():
    """(bx, by, broken, binned, side) for every hand-specified bench (shared by ground-base scuffs and props)."""
    out = []
    for pts, sgn, s, broken, binned in BENCH_SPECS:
        c, seg = bezier(pts)
        k = int(s * (len(c) - 1))
        x, y = c[k]
        hw = (BRANCH_W if pts is LEFT_BRANCH else WALK_W) / 2
        out.append((int(x + sgn * (hw + 18)) - 13, int(y) - 8, broken, binned, sgn))
    return out


def scuff_list():
    """Hand scuffs plus a worn patch in front (west) of every bench."""
    return SCUFFS_HAND + [(bx + 13, by + 17, 15, 4) for bx, by, *_ in bench_positions()]



# ============================================================================ hand-authored stamps
TUFTS = [  # grass clumps, relative to the tone underneath: a=-2 b=-1 e=0 c=+1 d=+2 (tips lit, base shaded)
    ["..d..", ".c.c.", "cbcbc", ".bbb.", "..a.."],
    [".c...c", "c.c.c.", ".cbcbc", "bbcbb.", ".aaa.."],
    ["c..c..", ".cc.c.", "bccbc.", ".bbbb.", "..aa.."],
    ["..c.", ".dc.", "cbcc", "bbb.", ".a.."],
    [".c.c..", "cdc.c.", "bcbcb.", ".bbab.", "..a..."],
    ["...c...", ".c.cc..", "c.cbc.c", "bcbbcb.", ".abba..", "..aa..."],
    ["c.c", "bcb", ".a."],
    [".b.", "b.b", ".a."],
]
TUFT_MAP = {"a": -2, "b": -1, "e": 0, "c": 1, "d": 2}
TALL_TUFTS = [  # overgrown edges: longer blades
    ["d...d.", "c..c.c", ".c.cb.", "bccb..", "abba..", ".aa..."],
    [".d..d", "c.cc.", "c.c.b", "bcbb.", "abba.", ".aa.."],
    ["..d...", ".dc.d.", "c.cc.c", "bcbcb.", ".abba.", "..aa.."],
]
BENCH = [
    ".K......................K.",
    ".KWWWWWWWWWWWWWWWWWWWWWWK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    ".KwwwwwwwwwwwwwwwwwwwwwwK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    "KkkkkkkkkkkkkkkkkkkkkkkkkK",
    "KWWWWWWWWWWWWWWWWWWWWWWWWK",
    "KwwwwwwwwwwwwwwwwwwwwwwwwK",
    "KWWWWWWWWWWWWWWWWWWWWWWWWK",
    "KvvvvvvvvvvvvvvvvvvvvvvvvK",
    ".KkK..................KkK.",
    ".K.K..................K.K.",
]
BENCH_BROKEN = [
    ".K......................K.",
    ".KWWWWWWWWWWWWWWW.......K.",
    ".KvvvvvvvvvvvvvvvK......K.",
    ".KwwwwwwwwwwwwwwwwwwwwwwK.",
    ".KvvvvvvvvvvvvvvvvvvvvvvK.",
    "KkkkkkkkkkkkkkkkkkkkkkkkkK",
    "KWWWWWWWWWWWWW..WWWWWWWWWK",
    "KwwwwwwwwwwwwvK.wwwwwwwwwK",
    "K..............vWWWWWWWWWK",
    "K..........WWWvvvvvvvvvvvK",
    ".KkK.........vv.......KkK.",
    ".K.K..................K.K.",
]
BENCH_MAP = {"K": "k0", "k": "k1", "W": "s3", "w": "s2", "v": "s1"}
CRATE = [
    ".kkkkkkkkkkkk.",
    "kHHHHHHHHHHHHk",
    "kHhhhhhhhhhhhk",
    "kHhhhhhhhhhhhk",
    "kKKKKKKKKKKKKk",
    "kMMMMMMMMMMMMk",
    "kMoooooooooMMk",
    "kMOOOOOOOOOMMk",
    "kMMMMcCMMMMMMk",
    "kMMMMccMMMMMMk",
    "kMMMMMMMMMMMMk",
    ".kkkkkkkkkkkk.",
]
CRATE_MAP = {"k": "k0", "H": "k3", "h": "k2", "K": "k1", "M": "k1", "o": "o1", "O": "o0", "c": "c0", "C": "c1"}
BEACON = [  # patrol-route marker (about 16 px: below the 48 px actor's waist)
    ".C.",
    "CXC",
    ".C.",
    ".k.",
    ".kO",
    ".kO",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    ".k.",
    "kKk",
    "KKK",
]
BEACON_MAP = {"C": "c1", "X": "c2", "k": "k2", "K": "k0", "O": "o1"}
STAKE = [".o", "oO", "w.", "w.", "w.", "w.", "W.", "W."]
STAKE_MAP = {"o": "o1", "O": "o0", "w": "s3", "W": "s1"}
LAMP_STUB = [  # broken cast-iron lamp post, base only
    "..kk..",
    ".kKk..",
    ".kKk..",
    ".kKK..",
    ".kKK..",
    ".kKK..",
    "kkKKk.",
    "kHKKKk",
    "kHKKKk",
    "kKKKKk",
    "KKKKKK",
]
LAMP_MAP = {"k": "k2", "K": "k1", "H": "k3"}
FLOWERS = ["m5", "m5", "o2", "fl", "m5", "o2"]
BIN = [  # litter receptacle beside a bench
    ".xxxxxxxx.",
    "xHHHHHHHMx",
    "xKKKKKKKKx",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHbbbbDx.",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHMMMMDx.",
    ".xHMMMDDx.",
    ".xxxxxxxx.",
]
BIN_MAP = {"x": "ink", "H": "k3", "M": "k2", "D": "k1", "K": "k0", "b": "s2"}
SIGN = [  # wayfinding sign; the 'text' is deliberately unreadable dashes
    "xxxxxxxxxxxxxxxxxxxxxx",
    "xHHHHHHHHHHHHHHHHHHHHx",
    "xHPPPPPPPPPPPPPPPPPPDx",
    "xHPTTTTTTT.PPPPPPPPPDx",
    "xHPPPPPPPPPPPPPPPPPPDx",
    "xHPtttt.ttttt.tttPPPDx",
    "xHPtttttt.tttt.ttPPPDx",
    "xHPttt.tttttt.tttPPPDx",
    "xHPPPPPPPPPPPPPPPPPPDx",
    "xHPoooPPPPPPPPPPPPPPDx",
    "xHDDDDDDDDDDDDDDDDDDDx",
    "xxxxxxxxxxxxxxxxxxxxxx",
] + ["...xpqx........xpqx..."] * 13 + ["...xxxx........xxxx..."]
SIGN_MAP = {"x": "ink", "H": "k3", "P": "k1", "D": "k0", "T": "m5", "t": "m3", "o": "o1", "p": "k2", "q": "k0"}
PLAQUE = ["xxxxx", "xHHDx", "xHPDx", "xxxxx", "..q..", "..q.."]
PLAQUE_MAP = {"x": "ink", "H": "s3", "P": "s2", "D": "s1", "q": "k0"}
TRIPOD = [
    "....xxxxxxx.....",
    "...xOOOOOoox....",
    "...xOCXOOoox....",
    "...xOOOOOoox....",
    "....xxxxxxx.....",
    ".......kk.......",
    "......kHKk......",
    "......kHKk......",
    ".....k.kk.k.....",
    ".....k.kk.k.....",
    "....k..kk..k....",
    "....k..kk..k....",
    "...k...kk...k...",
    "...k...kk...k...",
    "..k....kk....k..",
    "..k....kk....k..",
    ".k.....kk.....k.",
    ".k.....kk.....k.",
    "k......kk......k",
    "K......KK......K",
]
TRIPOD_MAP = {"x": "ink", "O": "o1", "o": "o0", "C": "c1", "X": "c2", "k": "k2", "H": "k3", "K": "k0"}
REEL = [
    "..xxxxxxxxxx..",
    ".xWWWWWWWWWWx.",
    "xWKKKKKKKKKKwx",
    "xWKqKqKqKqKKwx",
    "xWKKKKKKKKKKwx",
    "xWKqKqKqKqKKwx",
    "xWKKKKKKKKKKwx",
    ".xwwwwwwwwwwx.",
    "..xxxxxxxxxx..",
    "..s........s..",
]
REEL_MAP = {"x": "ink", "W": "s3", "w": "s1", "K": "k1", "q": "k0", "s": "s0"}
TARP = [
    "....xxxxxxx.....xxxx....",
    "..xxHHHHHHHxxxxxHHHHx...",
    ".xHHHMMMMMHHHHHHMMMMHx..",
    "xHMMMMoMMMMMMMMMMMoMMDx.",
    "xMMMMMoMMMMMMMMMMMoMMMDx",
    "xMMMMMoMMMMMMMMMMMoMMMDx",
    "xMMMMMoMMMMMMMMMMMoMMDDx",
    "xDMMMMoMMMMMMMMMMMoMDDDx",
    "xDDDDDoDDDDDDDDDDDoDDDx.",
    ".xDDDDODDDDDDDDDDDODDx..",
    "..xxxxxxxxxxxxxxxxxxx...",
]
TARP_MAP = {"x": "ink", "H": "k3", "M": "k2", "D": "k1", "o": "o1", "O": "o0"}
SANDBAG = [".xxxxxx.", "xLLLLMMx", "xLMMMMDx", "xMMMMDDx", ".xxxxxx."]
SANDBAG_MAP = {"x": "s0", "L": "s4", "M": "s3", "D": "s2"}
STUMP = [
    "....xxxxxxxxxx......",
    "..xxLLLLMMMMMMxx....",
    ".xLLMRRRRRRRMMMDx...",
    "xLLMRRrrrrrRRMMMDx..",
    "xLMRRrRRRRRrRRMMDx..",
    "xLMRRrRrrrRrRRMMDx..",
    "xLMMRRrrrrrRRMMMDx..",
    ".xLMMRRRRRRRMMMDDxo.",
    "..xxMMMMMMMMMMDDxooo",
    ".xbbbBbbbbBbbbbDDxo.",
    "xbbBbbBbbBbbBbbbDDx.",
    "xbBBbBBbBBbBBbBDDDDx",
    "xBBBBbBBBbBBBBDDDDDx",
    ".xxxxxxxxxxxxxxxxxx.",
]
STUMP_MAP = {"x": "ink", "L": "s4", "M": "s3", "R": "s2", "r": "s1", "D": "s1", "b": "s2", "B": "s1", "o": "o2"}
WARN = [
    ".....x.....",
    "....xox....",
    "...xoOox...",
    "..xooxoox..",
    ".xoooxooox.",
    "xooooxoooox",
    ".xoooooox..",
    "..xooxoox..",
    "...xoOox...",
    "....xox....",
    ".....x.....",
] + [".....k....."] * 8 + [".....K....."]
WARN_MAP = {"x": "ink", "o": "o1", "O": "o2", "k": "k2", "K": "k0"}


# ============================================================================ painters
class Scene:
    def __init__(self):
        self.L = {n: blank() for n in LAYERS}
        self.walk_mask = np.zeros((H, W), bool)          # paved (walks, forecourt, recess floor, deck, stairs)
        self.block = np.zeros((H, W), bool)              # collision footprints (for guides / walkability)
        self.prop_shadow = []                            # cast-shadow footprints from props/trees
        self.tall_items = []                             # (name, x0, y0, x1, y1): base-layer items taller than 2 px
        self.tall_mask = np.zeros((H, W), bool)          # their texels (props-low + terrace-walls), for the depth audit
        self.tall_ground = np.full((H, W), -1, np.int16)  # per texel: its item's ground row in that column
        self.collar = np.zeros((H, W), bool)             # documented no-walk collars derived from the items
        self.notes = []

    def tall(self, name, layer, x0, y0, x1, y1, mask=None):
        """Register a base-layer item that stands up off the ground (crate, trunk, fallen urn, rubble block...).
        In each column the item's lowest texel is its ground-contact row g. The actor is drawn above every base layer,
        so a foot north of g (fy < g) whose 48 px body reaches the item's texels would be drawn over something that
        stands in front of it. The collar blocks exactly those feet: rows [top, g-1] in that column, widened by the
        actor's half width (10 px) each side. The depth audit re-measures every walkable foot afterwards."""
        x0, y0 = max(0, int(x0)), max(0, int(y0))
        x1, y1 = min(W - 1, int(x1)), min(H - 1, int(y1))
        if x1 < x0 or y1 < y0:
            return
        sub = (layer[y0:y1 + 1, x0:x1 + 1] >= 0) if mask is None else mask[y0:y1 + 1, x0:x1 + 1]
        if not sub.any():
            return
        ys, xs = np.nonzero(sub)
        self.tall_items.append((name, x0 + int(xs.min()), y0 + int(ys.min()), x0 + int(xs.max()),
                                y0 + int(ys.max())))
        self.tall_mask[y0:y1 + 1, x0:x1 + 1] |= sub
        for i in np.unique(xs):
            col = np.nonzero(sub[:, i])[0]
            top, g = y0 + int(col.min()), y0 + int(col.max())
            x = x0 + int(i)
            gcol = self.tall_ground[y0:y1 + 1, x]
            gcol[sub[:, i]] = np.maximum(gcol[sub[:, i]], g)
            if g > top:
                self.collar[top:g, max(0, x - 10):min(W, x + 11)] = True
        self.block |= self.collar

    def tall_new(self, name, layer, before):
        """Register the texels painted into `layer` since the snapshot `before` (layer >= 0) as one tall item."""
        new = (layer >= 0) & ~before
        ys, xs = np.nonzero(new)
        if len(ys):
            self.tall(name, layer, xs.min(), ys.min(), xs.max(), ys.max(), mask=new)
        return new

    # ------------------------------------------------------------------ ground-base
    def ground_base(self):
        g = self.L["ground-base"]
        y = np.arange(H)[:, None]
        x = np.arange(W)[None, :]
        yy, xx = np.mgrid[0:H, 0:W]
        self.belt = self.belt_mask()
        # lawn: one continuous light field quantised through vertical 1x3 blade strokes (v03 method), plus v04
        # HAND-PLACED sward patches (damp hollows darker, dry crowns paler) so the panels are not one even tone
        dbelt = dist_coarse(self.belt)
        shade_belt = np.clip(1 - dbelt / 90.0, 0, 1) ** 1.5
        shade_wall = np.clip(1 - (yy - FOOT_Y) / 70.0, 0, 1)
        broad = vnoise("lawn-v04-broad", 260) - 0.5
        f = 0.6 + 0.24 * broad - 0.34 * shade_belt - 0.2 * shade_wall
        edge_n = vnoise("sward-edge-v04", 9) - 0.5
        self.dry = np.zeros((H, W), bool)
        for (cx, cy, rx, ry, dv, kind) in SWARD_PATCHES:
            e = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2 + edge_n * 1.1 + (vnoise(("sward", cx, cy), 5) - 0.5) * 0.5
            fall = np.clip(1.15 - e, 0, 1) ** 0.7
            f = f + dv * fall
            if kind == "dry":
                self.dry |= e < 0.8
        blade = blade_noise("lawn-v04-blade")
        q = f + (blade - 0.5) * 0.2
        t = np.full((H, W), I["g3"], np.int16)
        t[q > 0.5] = I["g4"]
        t[q > 0.83] = I["g5"]
        t[q < 0.22] = I["g2"]
        dryc = self.dry & (q > 0.7)
        t[dryc & (blade > 0.86)] = I["g6"]                                     # sun-bleached blade tips only
        t[self.dry & (q > 0.8) & (blade > 0.95)] = I["d1"]
        self.lawn_field = f
        # survey crew's mown pad round the post: calm lighter sward with an irregular edge and a darker ring
        px, py = POST
        e_pad = ((xx - (px - 6)) / 74.0) ** 2 + ((yy - (py + 4)) / 44.0) ** 2 + \
            (vnoise("padedge-v04", 11) - 0.5) * 0.42 + (vnoise("padedge2-v04", 4) - 0.5) * 0.12
        pad = e_pad < 1
        ring = (e_pad >= 1) & (e_pad < 1.5)
        dl = np.full((H, W), 1e9, np.float32)
        for (ax_, ay_), (bx_2, by_2) in zip(PATROL[1:5], PATROL[2:6]):
            vx, vy = bx_2 - ax_, by_2 - ay_
            tt = np.clip(((xx - ax_) * vx + (yy - ay_) * vy) / float(vx * vx + vy * vy), 0, 1)
            dl = np.minimum(dl, np.hypot(xx - (ax_ + tt * vx), yy - (ay_ + tt * vy)).astype(np.float32))
        lane = dl < 12 + (vnoise("laneedge-v04", 6) - 0.5) * 4
        axis_zone = (xx >= AXIS[0] - 6) & (xx <= AXIS[1] + 6)
        grass = (yy >= FOOT_Y + 14) & ~self.belt & ~axis_zone
        mown = (pad | lane) & grass
        qp = 0.62 + 0.3 * np.clip(1 - e_pad, 0, 1) + (blade - 0.5) * 0.22
        pt = np.where(qp > 0.8, I["g5"], I["g4"])
        t[pad & grass] = pt[pad & grass]
        rq = q - 0.16 * np.clip(1.5 - e_pad, 0, 0.5) * 2
        rt = np.where(rq > 0.5, I["g4"], np.where(rq < 0.22, I["g2"], I["g3"]))
        t[ring & grass] = rt[ring & grass]
        apron = (((xx - px) / 36.0) ** 2 + ((yy - (py - 3)) / 15.0) ** 2 + (blade - 0.5) * 0.5) < 1
        t[apron & grass] = np.where(blade[apron & grass] > 0.55, I["d0"], I["s2"])
        # hand-placed worn scuffs (bench fronts, the crew's drag line, the transect start, the uprooted tree)
        for (cx, cy, rx, ry) in scuff_list():
            e = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2 + (blade - 0.5) * 0.6 + edge_n * 0.4
            sc_ = (e < 1) & grass
            t[sc_] = np.where(blade[sc_] > 0.62, I["s2"], np.where(blade[sc_] > 0.3, I["d0"], I["g3"]))
        self.mown = mown
        self.pad_ring = ring & grass
        # rough meadow only as verges along the curved walks and the belt margins
        cs = 4
        gy_, gx_ = np.mgrid[0:H:cs, 0:W:cs]
        dmin = np.full(gy_.shape, 1e9, np.float32)
        for c in (self.lc, self.rc):
            for qq in c[::6]:
                dmin = np.minimum(dmin, np.hypot(gx_ - qq[0], gy_ - qq[1]).astype(np.float32))
        dwalk = np.repeat(np.repeat(dmin, cs, 0), cs, 1)[:H, :W] - WALK_W / 2
        width = 9 + 26 * vnoise("verge-w-v04", 90) + 8 * np.clip((yy - 420) / 300.0, 0, 1)
        verge = (dwalk > 3) & (dwalk < width)
        beltside = (dbelt > 2) & (dbelt < 6 + 18 * vnoise("beltverge-w-v04", 70))
        mp = np.pad(mown | ring, 6)
        near_mown = mp[12:, 6:-6] | mp[:-12, 6:-6] | mp[6:-6, 12:] | mp[6:-6, :-12] | mown | ring
        ok = (yy > FOOT_Y + 40) & grass & ~near_mown & ~((xx > FORE[0] - 30) & (xx < FORE[2] + 30) & (yy < FORE[3] + 30))
        meadow = majority((verge | beltside) & ok, 2, 2) & ok
        mq = f + 0.1 + (blade - 0.5) * 0.3
        mt = np.where(mq > 0.78, I["g5"], np.where(mq > 0.42, I["g4"], I["g3"]))
        t[meadow] = mt[meadow]
        self.meadow = meadow
        # wall-foot planting strip (soil) beside the stairs; tree-belt floor (darker, litter)
        strip = (yy >= FOOT_Y) & (yy < FOOT_Y + 14)
        for sx0, sx1 in STAIRS:
            strip &= ~((x >= sx0 - CHEEK_W - 2) & (x <= sx1 + CHEEK_W + 2))
        strip &= ~((x >= EXEDRA[0]) & (x <= EXEDRA[1]))
        sn = vnoise("strip-v04", 5)
        t[strip & (sn < 0.55)] = I["s1"]
        t[strip & (sn >= 0.55)] = I["s2"]
        t[strip & (sn < 0.2)] = I["s0"]
        bn = 0.7 * vnoise("belt1-v04", 40) + 0.3 * vnoise("belt2-v04", 9) + (blade - 0.5) * 0.18
        bt = np.where(bn < 0.3, I["g0"], np.where(bn < 0.58, I["g1"], np.where(bn < 0.84, I["g2"], I["s1"])))
        din = dist_coarse(~self.belt)
        soft = self.belt & (din < 12 + 6 * blade)
        bt[soft] = np.where(blade[soft] < 0.5, I["g2"], I["g3"])
        t[self.belt] = bt[self.belt]
        deck = self.deck_slabs()
        trail = self.trail_mask()
        tn = vnoise("trail-v04", 4)
        tt = np.where(tn < 0.35, I["s2"], np.where(tn < 0.7, I["d1"], I["d0"]))
        core = trail & (t != I["s1"])
        t[core] = tt[core]
        t[:EDGE_Y, :] = deck[:EDGE_Y, :]
        t = despeckle(t, 2)
        g[:] = t
        self.trail = trail

    def belt_mask(self):
        """Tree-belt floor: outside the curved walks (plus margin) on both flanks, below the wall-foot strip."""
        if hasattr(self, "_belt"):
            return self._belt
        self.lS, self.lT, self.lc = band_coords(LEFT_WALK, WALK_W / 2)
        self.rS, self.rT, self.rc = band_coords(RIGHT_WALK, WALK_W / 2)
        m = np.zeros((H, W), bool)
        jit = (vnoise("beltedge-v04", 11) - 0.5) * 14
        xs = np.arange(W)
        inner = np.zeros((H, W), bool)       # walkable lawn: inside the curved walks + the terrace-foot margins

        def smooth(a, b, y, y0, y1):
            s = min(1.0, max(0.0, (y - y0) / (y1 - y0)))
            s = s * s * (3 - 2 * s)
            return a * (1 - s) + b * s

        for y in range(FOOT_Y + 10, H):
            xl = np.interp(y, self.lc[:, 1], self.lc[:, 0])
            xr = np.interp(y, self.rc[:, 1], self.rc[:, 0])
            bl = smooth(92, xl - WALK_W / 2 - 18, y, FOOT_Y + 40, 420)
            br = smooth(W - 92, xr + WALK_W / 2 + 18, y, FOOT_Y + 90, 470)   # collapse spill zone stays open longer
            m[y] = (xs < bl + jit[y]) | (xs > br + jit[y])
            if y < FORE[3]:
                inner[y] = (xs > bl + jit[y]) & (xs < br + jit[y])
            else:
                inner[y] = (xs > xl + WALK_W / 2) & (xs < xr - WALK_W / 2)
        self._belt = m
        self.inner_lawn = inner
        return m

    def trail_mask(self):
        """Worn desire lines through the grass (hand-drawn curves): forecourt -> survey post, post -> the lower
        patrol loop, back to the axis, and the right forecourt end -> the collapse sensors."""
        m = np.zeros((H, W), bool)
        jit = vnoise("trailw-v04", 6)
        for ax_, b_, c_, d_, wd in TRAIL_CURVES:
            c, _ = bezier([ax_, b_, c_, d_], 500)
            x0 = int(max(0, c[:, 0].min() - 12)); x1 = int(min(W, c[:, 0].max() + 13))
            y0 = int(max(0, c[:, 1].min() - 12)); y1 = int(min(H, c[:, 1].max() + 13))
            yy, xx = np.mgrid[y0:y1, x0:x1]
            d = np.full(yy.shape, 1e9)
            for px, py in c[::4]:
                d = np.minimum(d, np.hypot(xx - px, yy - py))
            m[y0:y1, x0:x1] |= d < (wd + 2.6 * jit[y0:y1, x0:x1])
        m[:FOOT_Y + 4, :] = False
        return m

    def deck_slabs(self):
        """Marble terrace deck as random-course ashlar: large slabs, lit arrises, settled and heaved slabs."""
        t = np.full((H, W), I["m3"], np.int16)
        self.ashlar_paving(t, 0, FACADE_Y1, W - 1, EDGE_Y - 1, "deck-v04", ch=(9, 15), sl=(22, 64), ramp=STONE,
                           tones=[I["m3"], I["m4"], I["m4"], I["m3"], I["m4"], I["m5"]], joint_c="m1", polish=False,
                           states=(0.01, 0.08, 0.13, 0.22))
        return t

    # ------------------------------------------------------------------ paving-walks
    def paving(self):
        p = self.L["paving-walks"]
        self.bS, self.bT, self.bc = band_coords(LEFT_BRANCH, BRANCH_W / 2)
        self.curved_walk(p, self.bS, self.bT, "bw", half=BRANCH_W / 2, below=FORE[3] + 20)
        for S, T, key in ((self.lS, self.lT, "lw"), (self.rS, self.rT, "rw")):
            self.curved_walk(p, S, T, key, below=FORE[1] + 20)
        # recess floor between the stairs (lawn level, under the exedra; the wall face is painted over its top edge),
        # then the forecourt and the axial walk, so the curved walks start underneath the forecourt edge
        self.ashlar_paving(p, EXEDRA[0], FOOT_Y - EXEDRA_DEPTH - 4, EXEDRA[1], FORE[1] - 1, "recess-v04",
                           ch=(10, 15), sl=(18, 40), states=(0.06, 0.2, 0.28, 0.4))
        self.ashlar_paving(p, FORE[0], FORE[1], FORE[2], FORE[3], "fore-v04", ch=(13, 19), sl=(26, 52))
        self.ashlar_paving(p, AXIS[0], FORE[3], AXIS[1], H - 1, "axis-v04", ch=(8, 13), sl=(13, 31))
        ys = np.arange(FORE[3] + 1, H)
        for xa, cols in ((AXIS[0], ("m1", "m4", "m3")), (AXIS[1] - 2, ("m4", "m3", "m1"))):
            for i, c in enumerate(cols):
                p[ys, xa + i] = I[c]
            p[ys[(ys - FORE[3]) % 22 == 0], xa:xa + 3] = I["m1"]
            p[ys[(ys - FORE[3]) % 22 == 1], xa:xa + 3] = I["m2"]
        self.paving_damage(p)
        self.walk_mask |= p >= 0

    def paving_damage(self, p):
        """v04 hand-authored paving damage (positions and shapes written by hand, not scattered):
          settled band of the axial walk, sinkhole at the right forecourt end, missing slabs on the left forecourt,
          a scorched ring on the axis, crate-drag scrapes toward the survey post, chips fanning from the collapse."""
        r = rng_for("pavedmg-v04")
        # (1) settled section of the axial walk (rows 560-586): slabs dropped a step, lit lip on the upper edge, the
        # lower edge proud and cracked; tufts in the open joints come from ground-detail
        y0, y1 = 560, 586
        band = p[y0:y1, AXIS[0] + 3:AXIS[1] - 2]
        band[:] = ramp_shift_arr(band, PAVE, -1)
        p[y0, AXIS[0] + 3:AXIS[1] - 2] = I["m0"]
        p[y0 - 1, AXIS[0] + 3:AXIS[1] - 2] = I["p3"]
        for xx in range(AXIS[0] + 6, AXIS[1] - 5, 9):
            yy = y1 + (xx * 7) % 3
            p[yy, xx:xx + 6] = I["p0"]
        for (cx, cy, ln, dx) in ((612, 566, 12, 1), (652, 571, 9, -1), (633, 579, 7, 1)):
            for k in range(ln):
                p[cy + k // 2, cx + dx * k] = I["m0"]
        # (2) sinkhole at the right forecourt end: slabs broken and tipped into a soil hole
        hx, hy = 884, 334
        for j in range(-7, 8):
            for i in range(-13, 14):
                e = (i / 13.0) ** 2 + (j / 7.0) ** 2 + 0.18 * math.sin(i * 1.7 + j)
                if e < 1:
                    c = I["s0"] if j < -3 else I["s1"] if e > 0.45 else I["s2"]
                    setpx(p, hx + i, hy + j, c)
                elif e < 1.5:
                    setpx(p, hx + i, hy + j, I["p3"] if j < 0 else I["p0"])          # tipped slab edges
        for (i, j) in ((-5, 1), (-4, 1), (-3, 2), (4, 3), (5, 3), (6, 2)):
            setpx(p, hx + i, hy + j, I["m3"])                                    # fallen fragments in the hole
        self.block[hy - 7:hy + 8, hx - 13:hx + 14] = True
        self.sinkhole = (hx, hy)
        # (3) two missing slabs on the left forecourt: soil, clover cushion (detail paints the clover)
        for (mx, my, mw, mh) in ((410, 318, 22, 12), (434, 331, 16, 10)):
            rect(p, mx, my, mx + mw, my + mh, I["s1"])
            rect(p, mx, my, mx + mw, my + 1, I["s0"])
            rect(p, mx, my, mx + 1, my + mh, I["s0"])
            rect(p, mx, my + mh, mx + mw, my + mh, I["p3"])
        # (4) scorched ring on the axis (game fiction; something burned here): two-step stain, unburnt core
        sx, sy = 640, 468
        for j in range(-9, 10):
            for i in range(-30, 31):
                e = (i / 30.0) ** 2 + (j / 9.0) ** 2 + 0.25 * (r.random() - 0.5)
                if 0.35 < e < 1 and AXIS[0] + 3 <= sx + i <= AXIS[1] - 3:
                    c = p[sy + j, sx + i]
                    if c >= 0:
                        p[sy + j, sx + i] = ramp_shift(c, PAVE, -2 if e < 0.7 else -1)
        # (5) crate-drag scrapes from the axis curb toward the survey post (pale scratch pairs)
        for k in range(3):
            for t in range(0, 34):
                xx_ = AXIS[0] + 2 - t
                yy_ = 494 + k * 4 - t // 5
                if 0 <= yy_ < H and p[yy_, xx_] >= 0:
                    p[yy_, xx_] = ramp_shift(p[yy_, xx_], PAVE, 1)
        # (6) chips and spalls fanning across the right forecourt from the collapse side
        for k in range(26):
            cx = 820 + int(r.integers(0, 86)); cy = FORE[1] + 3 + int(r.integers(0, 40))
            if p[cy, cx] >= 0 and abs(cx - hx) + abs(cy - hy) > 18:
                setpx(p, cx, cy, I["p0"]); setpx(p, cx + 1, cy, I["p3"])

    def ashlar_paving(self, p, x0, y0, x1, y1, key, ch, sl, ramp=PAVE, tones=None, joint_c="p0", polish=True,
                      states=(0.025, 0.11, 0.17, 0.27)):
        """Random-course ashlar: course heights and stone lengths vary, joints never line up course to course. Each
        stone has its own tone, a lit top/left arris and a shaded bottom/right arris. Stones along the centre line are
        polished lighter by traffic; some have settled (darker, with the neighbour's lip lit above them), some have
        heaved (lit upper half, shaded lower), a few are cracked through or missing (soil and a weed). Moss fills the
        joints more toward the curbs and the far (west) end, where fewer feet pass."""
        r = rng_for("ashlar", key)
        J = I[joint_c]
        hh, ww = y1 - y0 + 1, x1 - x0 + 1
        sid = np.full((hh, ww), -1, np.int32)
        stones = []
        y = 0
        while y < hh:
            h = int(r.integers(ch[0], ch[1] + 1))
            x = -int(r.integers(0, sl[1]))
            while x < ww:
                L = int(r.integers(sl[0], sl[1] + 1))
                a, b = max(0, x), min(ww, x + L)
                if b - a >= 3:
                    sid[y:y + h, a:b] = len(stones)
                    stones.append((a, y, b - 1, min(hh, y + h) - 1))
                x += L
            y += h
        cx = (x0 + x1) / 2.0
        tone = np.zeros(len(stones), np.int16)
        state = []
        for k, (a, b_, c, d) in enumerate(stones):
            mid = abs(x0 + (a + c) / 2 - cx) / (ww / 2.0)
            t = r.choice(tones or [I["p1"], I["p2"], I["p2"], I["p3"], I["p3"], I["p2"]])
            if polish and mid < 0.3 and r.random() < 0.55:
                t = ramp_shift(t, ramp, 1)                               # traffic polish down the centre line
            tone[k] = t
            u = r.random()
            state.append("missing" if u < states[0] else "sunk" if u < states[1] else "heave" if u < states[2] else
                         "crack" if u < states[3] else "stain" if u < states[3] + 0.08 else "ok")
        t = np.where(sid >= 0, tone[np.maximum(sid, 0)], J).astype(np.int16)
        stn_ = vnoise(key + "stainshape", 4)
        pv = np.pad(sid, 1, constant_values=-2)
        top = (pv[:-2, 1:-1] != sid); left = (pv[1:-1, :-2] != sid)
        bot = (pv[2:, 1:-1] != sid); right = (pv[1:-1, 2:] != sid)
        joint = top | left                                               # 1 px mortar joint on each stone's top/left
        lit = (np.roll(top, 1, 0) | np.roll(left, 1, 1)) & ~joint
        dark = (bot | right) & ~joint
        t[lit] = ramp_shift_arr(t, ramp, 1)[lit]
        t[dark] = ramp_shift_arr(t, ramp, -1)[dark]
        t[joint] = J
        yy, xx = np.mgrid[0:hh, 0:ww]
        for k, (a, b_, c, d) in enumerate(stones):
            st = state[k]
            sl_ = (slice(b_, d + 1), slice(a, c + 1))
            box = sid[sl_] == k
            sub = t[sl_]
            if st == "sunk":
                sub[box] = ramp_shift_arr(sub, ramp, -1)[box]
                if b_ > 0:
                    t[b_ - 1, a:c + 1] = np.where(t[b_ - 1, a:c + 1] == J, J, I["m4"])  # neighbour's lip
                t[b_, a:c + 1] = I["m0"]
            elif st == "heave":
                mh = b_ + (d - b_) // 2
                up = box & (yy[sl_] <= mh)
                sub[up] = ramp_shift_arr(sub, ramp, 1)[up]
                lo = box & (yy[sl_] > mh + 1)
                sub[lo] = ramp_shift_arr(sub, ramp, -1)[lo]
            elif st == "crack" and c - a > 8:
                px_ = int(r.integers(a + 3, c - 3))
                for yv in range(b_ + 1, d + 1):
                    px_ += int(r.integers(-1, 2))
                    px_ = min(c - 1, max(a + 1, px_))
                    t[yv, px_] = J
                    if t[yv, px_ - 1] != J:
                        t[yv, px_ - 1] = ramp_shift(t[yv, px_ - 1], ramp, 1)
            elif st == "missing":
                sn = vnoise((key, "hole", k), 3, d - b_ + 1, c - a + 1)
                sub[box] = np.where(sn < 0.6, I["s1"], I["s2"])[box]
                t[b_:b_ + 2, a:c + 1] = I["s0"]
                t[b_:d + 1, a:a + 2] = I["s0"]
                t[b_, a:c + 1] = I["ink"]
                t[d, a:c + 1] = I["s3"]
                gx = (a + c) // 2
                for (i, j, cc) in ((0, 1, "g4"), (-1, 2, "g3"), (1, 2, "g3"), (0, 2, "g2"), (-2, 3, "g2"),
                                   (2, 3, "g2"), (0, 3, "g1")):
                    if b_ + j <= d and a <= gx + i <= c:
                        t[b_ + j, gx + i] = I[cc]
        far = np.clip((y0 + yy - 300) / 420.0, 0, 1)
        edge = np.abs(x0 + xx - cx) / (ww / 2.0)
        mossy = joint & (vnoise(key + "moss", 5)[y0:y1 + 1, x0:x1 + 1] < 0.12 + 0.55 * edge ** 2 + 0.25 * far)
        t[mossy] = np.where(vnoise(key + "moss2", 2)[y0:y1 + 1, x0:x1 + 1][mossy] > 0.6, I["g3"], I["g2"])
        stained = np.array([st_ == "stain" for st_ in state] + [False])
        stain = stained[np.where(sid >= 0, sid, len(state))] & ~joint & ~lit & \
            (stn_[y0:y1 + 1, x0:x1 + 1] > 0.45)
        t[stain] = ramp_shift_arr(t, ramp, -1)[stain]
        p[y0:y1 + 1, x0:x1 + 1] = t

    def flag_paving(self, p, x0, y0, x1, y1, sw, sh, key):
        ys, xs = np.mgrid[y0:y1 + 1, x0:x1 + 1]
        row = (ys - y0) // sh
        off = (row % 2) * (sw // 2)
        col = (xs - x0 + off) // sw
        u = (xs - x0 + off) % sw
        v = (ys - y0) % sh
        h = (row * 7919 + col * 104729 + len(key) * 31) % 101
        base = np.where(h < 34, I["p2"], np.where(h < 70, I["p3"], np.where(h < 92, I["p2"], I["p1"])))
        t = base.copy()
        lit = (v == 1) | (u == 1)
        t[lit] = ramp_shift_arr(base, PAVE, 1)[lit]
        dark = (v == sh - 1) | (u == sw - 1)
        t[dark] = ramp_shift_arr(base, PAVE, -1)[dark]
        joint = (u == 0) | (v == 0)
        t[joint] = I["p0"]
        pits = vnoise(key + "pit", 3)[y0:y1 + 1, x0:x1 + 1] > 0.85
        t[pits & ~joint] = ramp_shift_arr(base, PAVE, -1)[pits & ~joint]
        wear = vnoise(key + "wear", 26)[y0:y1 + 1, x0:x1 + 1]
        t[joint & (wear > 0.55)] = I["g2"]
        t[joint & (wear > 0.75)] = I["g3"]
        # missing slabs: soil + rubble chips
        miss = (h == 3) | (h == 57) | ((h == 88) & (wear > 0.5))
        sn = vnoise(key + "soil", 3)[y0:y1 + 1, x0:x1 + 1]
        t[miss & ~joint] = np.where(sn < 0.5, I["s1"], I["s2"])[miss & ~joint]
        t[miss & (v == 1)] = I["s0"]
        p[y0:y1 + 1, x0:x1 + 1] = t

    def curved_walk(self, p, S, T, key, half=WALK_W / 2, below=FORE[1] + 20):
        band = np.abs(np.nan_to_num(T, nan=99)) <= half
        band &= np.arange(H)[:, None] >= below
        agg = vnoise(key + "agg", 2)
        tone = vnoise(key + "tone", 40)
        t = np.full((H, W), I["p2"], np.int16)
        t[(agg < 0.2) | ((tone < 0.3) & (agg < 0.42))] = I["p1"]
        t[(agg > 0.8) & (tone > 0.35)] = I["p3"]
        Sn = np.nan_to_num(S)
        Tn = np.nan_to_num(T)
        joint = (np.mod(Sn, 34.0) < 1.0) & (np.abs(Tn) < half - 3)
        t[joint] = I["p0"]
        lip = (np.mod(Sn, 34.0) >= 1.0) & (np.mod(Sn, 34.0) < 2.0) & (np.abs(Tn) < half - 3)
        t[lip] = I["p3"]
        # granite curbs (3 px) both sides; the side facing the light is lit
        curb = np.abs(Tn) >= half - 3
        cj = np.mod(Sn + (Tn > 0) * 9, 22.0) < 1.0
        t[curb] = I["m2"]
        t[curb & (np.abs(Tn) < half - 2)] = I["m3"]
        t[curb & (np.abs(Tn) >= half - 1)] = I["m1"]
        t[curb & cj] = I["m1"]
        # weathering: grass in joints, a few broken-out patches showing soil
        gj = (vnoise(key + "gj", 14) > 0.6) & (joint | (curb & cj))
        t[gj] = I["g2"]
        pot = (vnoise(key + "pot", 9) > 0.86) & (np.abs(Tn) < half - 5)
        t[pot] = I["s1"]
        pr = np.pad(pot, 1)
        rimp = ~pot & (pr[2:, 1:-1] | pr[1:-1, 2:]) & (np.abs(Tn) < half - 3)
        t[rimp] = I["p3"]
        t = despeckle(t, 1)
        p[band] = t[band]

    # ------------------------------------------------------------------ terrace-walls
    def terrace(self):
        tw = self.L["terrace-walls"]
        self.col_shadows = []                      # (x_right_of_base, base_row, front_row)
        self.fixture_mask = np.zeros((H, W), bool)  # urns, lamps, coping: never shaded by the cast-shadow layer
        self.piece_mask = np.zeros((H, W), bool)
        self.facade(tw)
        self.wall_face(tw)
        self.exedra(tw)
        self.balustrade(tw)
        self.stairs(tw)
        self.newels()
        self.fountain(tw)
        self.collapse(tw)
        self.slump(tw)
        b = np.zeros((H, W), bool)
        b[EDGE_Y - BAL_H:FOOT_Y, :] = True
        for sx0, sx1 in STAIRS:
            b[EDGE_Y - BAL_H:FOOT_Y, sx0:sx1 + 1] = False
            b[EDGE_Y - BAL_H:STAIR_BOT + 1, sx0 - CHEEK_W:sx0] = True
            b[EDGE_Y - BAL_H:STAIR_BOT + 1, sx1 + 1:sx1 + 1 + CHEEK_W] = True
        for x in range(EXEDRA[0], EXEDRA[1] + 1):              # curved balustrade + curved wall; floor stays open
            b[EDGE_Y - BAL_H:FOOT_Y, x] = False
            b[self.rim[x] - BAL_H:self.floor_y[x] + 1, x] = True
        b[:FACADE_Y1 + 2, :] = True
        b[:PAV_Y1 + 2, PAV[0] - 3:PAV[1] + 4] = True
        for s0, s1 in SUBP:
            b[:SUBP_Y1 + 2, s0 - 1:s1 + 2] = True
        # documented no-walk collision round the four Y-sorted newels: footprint + collar on its open side and in
        # front, and a strip along each cheek wall's open face (lawn for the outer cheeks, recess floor for the inner)
        nc = np.zeros((H, W), bool)
        for (bx0, by0, bx1, by1), (cx0, side, si) in zip(self.newel_boxes, CHEEKS):
            nc[by0:by1 + 1 + NEWEL_COLLAR, bx0:bx1 + 1] = True
            if side < 0:
                nc[FOOT_Y:by1 + 1 + NEWEL_COLLAR, bx0 - NEWEL_COLLAR:bx0] = True
                nc[FOOT_Y:by1 + 1, bx0 - CHEEK_COLLAR:bx0] = True
            else:
                nc[FOOT_Y:by1 + 1 + NEWEL_COLLAR, bx1 + 1:bx1 + 1 + NEWEL_COLLAR] = True
                nc[FOOT_Y:by1 + 1, bx1 + 1:bx1 + 1 + CHEEK_COLLAR] = True
        # deck feet level with or behind a base-layer urn are blocked (urn top row down to the urn's base row)
        for (ux0, uy0, ux1, uy1) in self.urn_boxes:
            if uy1 < EDGE_Y:
                nc[uy0:uy1 + 1, ux0 - 12:ux1 + 13] = True
        # landing piers (with urns) on the cheek walls: a stair-side strip beside each pier
        la, lb = LANDING
        for sx0, sx1 in STAIRS:
            nc[la - 18:lb + 1, sx0:sx0 + 12] = True
            nc[la - 18:lb + 1, sx1 - 11:sx1 + 1] = True
        # the dry fountain: coping + front face + collar (the pedestal and tree are Y-sorted above it)
        fc = self.fountain_mask.copy()
        for _ in range(FOUNTAIN_COLLAR):
            pf = np.pad(fc, 1)
            fc = fc | pf[:-2, 1:-1] | pf[2:, 1:-1] | pf[1:-1, :-2] | pf[1:-1, 2:]
        nc |= fc
        self.newel_collar = nc
        b |= nc
        self.block |= b

    # ------------------------------------------------------------------ west front (facade band, rows 0..59)
    def rusticated_rows(self, y0, y1, key, dark=0):
        """Banded rustication: 6-row courses, lit upper arris, shaded lower bevel and a deep channel per course."""
        out = np.zeros((y1 - y0, W), np.int16)
        xs = np.arange(W)
        for y in range(y0, y1):
            c, v = divmod(y - y0, 6)
            r = rng_for("rust", key, c)
            edges = np.cumsum(r.integers(38, 66, size=40)) - int(r.integers(0, 40))
            k = np.searchsorted(edges, xs, side="right")
            tone = np.where((k * 37 + c * 11) % 5 < 2, I["m3"], I["m4"])
            if v == 0:
                row = np.where(tone == I["m4"], I["m5"], I["m4"])
            elif v == 4:
                row = np.full(W, I["m2"], np.int16)
            elif v == 5:
                row = np.full(W, I["m0"], np.int16)
            else:
                row = tone.copy()
            row[np.isin(xs, edges) & (v < 4)] = I["m2"]
            out[y - y0] = row
        if dark:
            out = ramp_shift_arr(out, STONE, -dark)
        return out

    def ashlar_rows(self, y0, y1, key, ch=5):
        """Smooth main-floor ashlar: shallow courses, thin joints, light stone (no rustication channels)."""
        out = np.zeros((y1 - y0, W), np.int16)
        xs = np.arange(W)
        for y in range(y0, y1):
            c, v = divmod(y - y0, ch)
            r = rng_for("ashlar-main", key, c)
            edges = np.cumsum(r.integers(26, 48, size=60)) - int(r.integers(0, 30))
            k = np.searchsorted(edges, xs, side="right")
            row = np.where((k * 29 + c * 7) % 7 < 2, I["m4"], I["m5"]).astype(np.int16)
            if v == ch - 1:
                row[:] = I["m3"]
            row[np.isin(xs, edges) & (v < ch - 1)] = I["m3"]
            out[y - y0] = row
        return out

    def facade(self, tw):
        """The Capitol West Front cropped to its two lower storeys. Main floor (rows 0-35): smooth ashlar, pilasters,
        tall windows with ALTERNATING triangular / segmental pediments. Belt course (rows 36-39). Rusticated arcade
        basement (rows 40-69) with a round-arched opening under every window. Plinth (rows 70-75). The central
        pavilion projects to row 87 and carries a loggia of PAIRED columns behind a balustrade; the wing pavilions
        carry engaged columns. Bay, arch and column conditions are hand-assigned (FACADE_BAYS / PAVILION_* /
        WING_PAV_*); no cycling rule, no random stamp. Arrangement is a readability cue, not a measured elevation."""
        t = np.zeros((FACADE_Y1, W), np.int16)
        t[:BELT_Y] = self.ashlar_rows(0, BELT_Y, "wing", ch=6)
        for y, c in zip(range(BELT_Y, BASE_Y0), ("m5", "m4", "m3", "m1")):
            t[y, :] = I[c]
        t[BASE_Y0:PLINTH_Y] = self.rusticated_rows(BASE_Y0, PLINTH_Y, "wing")
        for y, c in zip(range(PLINTH_Y, FACADE_Y1), ("m5", "m4", "m3", "m3", "m2", "m1")):
            t[y, :] = I[c]
        tw[:FACADE_Y1, :] = t
        for x in WING_PILASTERS:
            self.pilaster(tw, x, 0, BELT_Y, ("wing", x))
        for (cx, main, ped, base) in FACADE_BAYS:
            self.main_window(tw, cx, main, ped, ("w", cx))
            self.basement_arch(tw, cx, BASE_Y0 + 7, PLINTH_Y - 1, 14, base, ("wb", cx))
        for pi, (s0, s1) in enumerate(SUBP):
            self.wing_pavilion(tw, pi, s0, s1)
        self.central_pavilion(tw)
        for (x, y, w, kind) in FACADE_DAMAGE:
            seg = tw[y:y + 4, x:x + w]
            ok = ~np.isin(seg, [I["k0"], I["k1"], I["ink"], I["k2"]])
            if kind == "missing":
                seg[ok] = I["m1"]
                tw[y, x:x + w] = I["m0"]
                tw[y + 1:y + 4, x] = I["m0"]
                tw[y + 3, x + 1:x + w] = I["m4"]
                tw[y + 1:y + 3, x + 2:x + w - 1] = np.where((np.arange(2)[:, None] + np.arange(w - 3)[None, :]) % 3,
                                                            I["s1"], I["m0"])
            elif kind == "spall":
                seg[ok] = ramp_shift_arr(seg, STONE, -1)[ok]
                tw[y, x + 1:x + w - 1] = I["m1"]
                tw[y + 1, x + 2:x + w - 2] = I["m0"]
                tw[y + 2, x + 2:x + w - 2] = I["m4"]
            else:
                cx = x
                for yy in range(y, min(FACADE_Y1 - 6, y + 18)):
                    tw[yy, cx] = I["ink"]
                    if yy % 3 == 0:
                        cx += 1
        # rain and soot streaks down the stone (material weathering, as on the v03 terrace wall): breaks the identical
        # horizontal bands of the rustication and the smooth ashlar so no two stretches of facade read as one stamp
        rs = rng_for("facade-streaks-v04")
        for x in range(W):
            if rs.random() < 0.2:
                y0 = int(rs.integers(0, PLINTH_Y - 6)); ln = int(rs.integers(3, 18))
                for yy in range(y0, min(PLINTH_Y, y0 + ln)):
                    c = tw[yy, x]
                    if c in (I["m5"], I["m4"], I["m3"]):
                        tw[yy, x] = ramp_shift(c, STONE, -1)
        for (sx, hgt, hw) in SCORCH:
            for x in range(sx - hw, sx + hw + 1):
                if not 0 <= x < W or PAV[0] - 2 <= x <= PAV[1] + 2:
                    continue
                u = abs(x - sx) / float(hw + 1)
                ln = int(hgt * (1 - u ** 1.6) * (0.85 + 0.15 * math.sin(x * 0.9)))
                for yv in range(max(0, FACADE_Y1 - 1 - ln), FACADE_Y1 - 1):
                    c = tw[yv, x]
                    if c in (I["m5"], I["m4"], I["m3"], I["m2"]):
                        tw[yv, x] = ramp_shift(c, STONE, -2 if yv > FACADE_Y1 - 1 - ln // 2 else -1)

    def pilaster(self, tw, cx, y0, y1, key):
        prof = ("m5", "m4", "m4", "m4", "m3", "m3", "m2")
        x0 = cx - 3
        for i, c in enumerate(prof):
            tw[y0:y1, x0 + i] = I[c]
        tw[y1 - 3, x0 - 1:x0 + 8] = I["m5"]
        tw[y1 - 2:y1, x0 - 1:x0 + 8] = I["m3"]
        tw[y1 - 3:y1, x0 + 7] = I["m1"]
        r = rng_for("pil-v04", key)
        gx = x0 + int(r.integers(1, 6)); gl = int(r.integers(6, y1 - y0 - 4))
        gy = int(r.integers(y0, max(y0 + 1, y1 - 3 - gl)))
        seg = tw[gy:gy + gl, gx]
        seg[:] = ramp_shift_arr(seg, STONE, -1)
        if r.random() < 0.4:
            cx_ = x0 + (0 if r.random() < 0.5 else 5)
            tw[y1 - 3:y1 - 1, cx_:cx_ + 2] = I["m1"]

    def main_window(self, tw, cx, state, ped, key):
        """Main-floor window (rows PED_Y..BELT_Y-1): pediment (triangular or segmental) with its cornice, architrave and
        sash with transoms, sill, balustered apron. States: glass, dark, broken, boarded, vine, scorched, lintel."""
        x0, x1 = cx - 7, cx + 6
        p = PED_Y
        if ped == "tri":
            for j, hw in enumerate((2, 4, 6, 8)):
                tw[p + j, cx - hw:cx + hw] = I["m5"]
                tw[p + j, cx:cx + hw] = I["m3"]
                tw[p + j, cx - hw] = I["m4"]; tw[p + j, cx + hw - 1] = I["m1"]
                if j >= 2:
                    tw[p + j, cx - hw + 2:cx + hw - 2] = I["m4"]          # tympanum
        else:
            tw[p + 1, cx - 4:cx + 4] = I["m4"]
            tw[p + 2, cx - 7:cx + 7] = I["m5"]; tw[p + 2, cx + 1:cx + 7] = I["m3"]
            tw[p + 3, cx - 9:cx + 9] = I["m4"]; tw[p + 3, cx + 3:cx + 9] = I["m3"]
        tw[p + 4, cx - 10:cx + 10] = I["m5"]                                 # cornice
        tw[p + 5, cx - 10:cx + 10] = I["m2"]
        rect(tw, x0 - 2, WIN_Y0, x1 + 2, WIN_Y1, I["m3"])
        rect(tw, x0 - 2, WIN_Y0, x0 - 2, WIN_Y1, I["m5"]); rect(tw, x1 + 2, WIN_Y0, x1 + 2, WIN_Y1, I["m1"])
        rect(tw, x0, WIN_Y0, x1, WIN_Y1, I["k1"])
        rect(tw, x0, WIN_Y0, x0, WIN_Y1, I["ink"]); rect(tw, x1, WIN_Y0, x1, WIN_Y1, I["m4"])
        rect(tw, cx, WIN_Y0 + 1, cx, WIN_Y1, I["k2"])
        for ty in (WIN_Y0 + 6, WIN_Y0 + 12):
            rect(tw, x0 + 1, ty, x1 - 1, ty, I["k2"])
        rect(tw, x0 - 3, SILL_Y, x1 + 3, SILL_Y, I["m5"])
        for xx in range(x0 - 1, x1 + 2, 3):
            tw[SILL_Y + 1:BELT_Y - 1, xx] = I["m4"]; tw[SILL_Y + 1:BELT_Y - 1, xx + 1] = I["m2"]
        tw[BELT_Y - 1, x0 - 2:x1 + 3] = I["m2"]
        if state == "glass":
            for j in range(5):
                setpx(tw, x0 + 2 + j, WIN_Y1 - 2 - j, I["k3"]); setpx(tw, x0 + 3 + j, WIN_Y1 - 2 - j, I["k2"])
                setpx(tw, x0 + 3 + j, WIN_Y0 + 9 - j // 2, I["k3"])
        elif state in ("dark", "vine", "scorched", "lintel"):
            rect(tw, x0 + 1, WIN_Y0 + 1, x1 - 1, WIN_Y1, I["k0"])
        elif state == "broken":
            rect(tw, x0 + 1, WIN_Y0 + 1, x1 - 1, WIN_Y1, I["k0"])
            for (a, b_) in ((x0 + 1, WIN_Y0 + 1), (x0 + 2, WIN_Y0 + 2), (x1 - 1, WIN_Y0 + 4), (x0 + 1, WIN_Y0 + 11),
                            (x1 - 2, WIN_Y1 - 1), (x1 - 1, WIN_Y1 - 2), (x0 + 4, WIN_Y0 + 6)):
                setpx(tw, a, b_, I["k3"])
            rect(tw, x0 + 1, WIN_Y0 + 12, x0 + 5, WIN_Y0 + 12, I["k2"])
        elif state == "boarded":
            for j, y in enumerate(range(WIN_Y0 + 1, WIN_Y1, 3)):
                rect(tw, x0 + 1, y, x1 - 1, y + 1, I["s3"] if j % 2 else I["s2"])
                rect(tw, x0 + 1, y + 2, x1 - 1, y + 2, I["s1"])
            for yy in range(WIN_Y0 + 2, WIN_Y1 - 1):                         # one diagonal brace
                setpx(tw, x0 + 1 + (yy - WIN_Y0) * (x1 - x0 - 2) // (WIN_Y1 - WIN_Y0), yy, I["s1"])
        r = rng_for("mainwin-v04", key)
        if r.random() < 0.75:
            sx = x0 + int(r.integers(-2, 10)); ln = int(r.integers(2, 6))
            for yy in range(SILL_Y + 1, min(BELT_Y, SILL_Y + 1 + ln)):
                for xx in (sx, sx + 1):
                    if tw[yy, xx] in STONE:
                        tw[yy, xx] = ramp_shift(tw[yy, xx], STONE, -1)
        if r.random() < 0.5:
            cxc = x0 - 2 if r.random() < 0.5 else x1 + 1
            cyc = int(r.integers(WIN_Y0, WIN_Y1 - 2))
            tw[cyc:cyc + 2, cxc:cxc + 2] = I["m1"]
        if r.random() < 0.45:
            for xx in range(x0 - 3 + int(r.integers(0, 6)), x1 + 3, int(r.integers(3, 7))):
                setpx(tw, xx, SILL_Y, I["g3"]); setpx(tw, xx + 1, SILL_Y, I["g2"])
        if r.random() < 0.3:
            xx = x0 - 1 + 3 * int(r.integers(0, 5))
            tw[SILL_Y + 1:BELT_Y - 1, xx:xx + 2] = I["m1"]
        if state == "scorched":
            for xx in range(x0 - 4, x1 + 5):
                for yy in range(0, WIN_Y0 + 1):
                    c = tw[yy, xx]
                    if c in (I["m5"], I["m4"], I["m3"]):
                        tw[yy, xx] = ramp_shift(c, STONE, -2 if abs(xx - cx) < 5 else -1)
        if state == "lintel":
            rect(tw, cx, p, cx + 10, p + 5, I["s1"])
            tw[p:p + 6, cx] = I["m1"]
            tw[p + 5, cx:cx + 11] = I["m0"]
            for yy in range(WIN_Y1, BELT_Y):
                setpx(tw, x1 + 3 + ((yy - WIN_Y1) // 3), yy, I["ink"])
            for yy in range(0, p):
                setpx(tw, cx + 4 - yy // 2, yy, I["ink"])

    def basement_arch(self, tw, cx, y_top, y_bot, w, state, key, ring=True):
        """Round-arched basement opening cut through the rustication: voussoir ring with keystone, reveal in shade.
        States: grille, dark, bricked (later infill), door (bronze), collapsed (keystone dropped), vine."""
        x0, x1 = cx - w // 2, cx + w // 2 - 1
        r = w / 2.0
        cyf = y_top + r
        for y in range(int(y_top - 3), y_bot + 1):
            for x in range(x0 - 3, x1 + 4):
                if not (0 <= x < W and 0 <= y < H):
                    continue
                dx = x - (x0 + x1) / 2.0
                if y >= cyf:
                    inside = x0 <= x <= x1
                    d = abs(dx) - r + 0.5
                else:
                    d = math.hypot(dx, y - cyf) - r
                    inside = d <= 0
                if inside:
                    tw[y, x] = I["k0"]
                elif ring and y < cyf and d <= 2.6:
                    tw[y, x] = I["m4"] if dx < -1 else I["m3"] if dx <= 2 else I["m2"]
                    if abs(abs(dx) - abs(y - cyf)) < 0.6:
                        tw[y, x] = I["m1"]
        stamp(tw, cx - 2, int(y_top - 3), ["LMMD", "LMMD", ".MD."], {"L": "m5", "M": "m4", "D": "m2"})
        tw[int(cyf):y_bot + 1, x0] = I["ink"]
        tw[int(cyf):y_bot + 1, x1] = I["m2"]
        r = rng_for("arch-v04", key)
        side = int(r.integers(0, 2))
        vx = x0 - 2 if side == 0 else x1 + 1
        vy = int(cyf) - int(r.integers(1, 5))                               # chipped voussoir beside the head
        tw[vy:vy + 2, vx:vx + 2] = I["m1"]
        for k in range(int(r.integers(0, 4))):
            mx = x0 - 3 + int(r.integers(0, w + 6))
            if 0 <= mx < W and tw[y_bot, mx] != I["k0"]:
                tw[y_bot - 1:y_bot + 1, mx] = I["g2"]
        if r.random() < 0.5:
            sx = (x0 - 3) if r.random() < 0.5 else (x1 + 2)
            for yy in range(int(cyf) + 2, min(y_bot, int(cyf) + 4 + int(r.integers(4, 12)))):
                if tw[yy, sx] in STONE:
                    tw[yy, sx] = ramp_shift(tw[yy, sx], STONE, -1)
        if state == "grille":
            for xx in range(x0 + 2, x1, 3):
                tw[int(y_top) + 2:y_bot, xx] = I["k2"]
            tw[int(cyf) + 3, x0 + 1:x1] = I["k2"]; tw[y_bot - 6, x0 + 1:x1] = I["k2"]
        elif state == "bricked":
            for yy in range(int(y_top) + 1, y_bot + 1):
                for xx in range(x0 + 1, x1):
                    if tw[yy, xx] != I["k0"]:
                        continue
                    row = (yy - int(y_top)) // 3
                    col = (xx - x0 + (row % 2) * 3) // 6
                    joint = (yy - int(y_top)) % 3 == 0 or (xx - x0 + (row % 2) * 3) % 6 == 0
                    tw[yy, xx] = I["p0"] if joint else (I["p1"] if (row + col) % 3 else I["p2"])
        elif state == "door":
            rect(tw, x0 + 1, int(cyf), x1 - 1, y_bot, I["k1"])
            tw[int(cyf):y_bot + 1, cx] = I["k0"]
            for yy in (int(cyf) + 3, y_bot - 8):
                rect(tw, x0 + 2, yy, cx - 2, yy + 4, I["k2"]); rect(tw, cx + 2, yy, x1 - 2, yy + 4, I["k2"])
                rect(tw, x0 + 2, yy, cx - 2, yy, I["k3"])
        elif state == "collapsed":
            rect(tw, cx - 3, int(y_top - 3), cx + 2, int(y_top) + 1, I["k0"])
            for (i, j, c) in ((-3, 4, "m3"), (-2, 4, "m4"), (-1, 5, "m2"), (1, 5, "m3"), (2, 4, "m4"), (0, 6, "m1"),
                              (-4, 6, "s1"), (3, 6, "s1")):
                setpx(tw, cx + i, int(y_top) + j, I[c])
            for yy in range(int(y_top - 8), int(y_top - 3)):
                setpx(tw, cx + (yy % 2), yy, I["ink"])

    def wing_pavilion(self, tw, pi, s0, s1):
        """Wing pavilion: slight projection (front face to SUBP_Y1), four engaged columns on the main floor with
        three windows between them, three basement arches, lit left edge and shaded right edge."""
        rect(tw, s0, PLINTH_Y, s1, SUBP_Y1 - 1, I["m3"])
        back = self.rusticated_rows(BASE_Y0, SUBP_Y1 - 6, ("subp", pi))
        tw[BASE_Y0:SUBP_Y1 - 6, s0:s1 + 1] = back[:, s0:s1 + 1]
        for y, c in zip(range(SUBP_Y1 - 6, SUBP_Y1), ("m5", "m4", "m3", "m3", "m2", "m1")):
            tw[y, s0:s1 + 1] = I[c]
        tw[0:SUBP_Y1, s0] = I["m5"]; tw[0:SUBP_Y1, s0 + 1] = I["m4"]
        tw[0:SUBP_Y1, s1] = I["m0"]; tw[0:SUBP_Y1, s1 - 1] = I["m1"]
        n = 4
        cxs = [int(round(s0 + 16 + i * (s1 - s0 - 32) / (n - 1))) for i in range(n)]
        for i in range(n - 1):
            wcx = (cxs[i] + cxs[i + 1]) // 2
            self.main_window(tw, wcx, WING_PAV_WINDOWS[pi][i], "seg" if i == 1 else "tri", ("wp", pi, i))
            self.basement_arch(tw, wcx, BASE_Y0 + 9, SUBP_Y1 - 7, 14, WING_PAV_ARCHES[pi][i], ("wpa", pi, i))
        for i, cx in enumerate(cxs):
            broken = 12 if (pi, i) == COL_BROKEN else None
            self.column(tw, cx, BELT_Y - 1, BELT_Y + 3, broken_at=broken, key=("wpc", pi, i), sw=8)

    def central_pavilion(self, tw):
        """Central pavilion: main floor = recessed loggia with FOUR PAIRS of columns (the West Front's paired
        colonnade) standing on a balustraded podium, hand-assigned openings behind; rusticated basement projecting
        to row PAV_Y1 with five arches (the centre one an entrance), two steps."""
        x0, x1 = PAV
        rect(tw, x0, 0, x1, BELT_Y - 1, I["k1"])
        rect(tw, x0, 0, x1, 2, I["k0"])
        pair_c = [510, 596, 683, 769]
        bays = [(x0 + 4, pair_c[0] - 12)] + [(pair_c[i] + 12, pair_c[i + 1] - 12) for i in range(3)] + \
               [(pair_c[3] + 12, x1 - 4)]
        for (a, b), st in zip(bays, PAVILION_OPENINGS):
            cx = (a + b) // 2
            if st == "door":
                rect(tw, cx - 10, 5, cx + 10, BELT_Y - 1, I["m2"]); rect(tw, cx - 9, 6, cx + 9, BELT_Y - 1, I["k2"])
                for yy in range(5, 9):
                    d = abs(yy - 5)
                    rect(tw, cx - 10 + d, yy, cx + 10 - d, yy, I["m3"])
                tw[9:BELT_Y, cx] = I["k1"]
                for yy in (11, 20):
                    rect(tw, cx - 7, yy, cx - 2, yy + 6, I["k3"]); rect(tw, cx + 2, yy, cx + 7, yy + 6, I["k3"])
                    rect(tw, cx - 7, yy + 6, cx - 2, yy + 6, I["k1"]); rect(tw, cx + 2, yy + 6, cx + 7, yy + 6, I["k1"])
            else:
                rect(tw, cx - 7, 6, cx + 7, BELT_Y - 3, I["m2"])
                rect(tw, cx - 6, 7, cx + 6, BELT_Y - 3, I["k0"] if st != "glass" else I["k1"])
                rect(tw, cx - 7, BELT_Y - 3, cx + 7, BELT_Y - 3, I["m4"])
                for ty in (14, 22):
                    rect(tw, cx - 5, ty, cx + 5, ty, I["k2"])
                if st == "glass":
                    for j in range(5):
                        setpx(tw, cx - 4 + j, 28 - j, I["k3"])
                elif st == "broken":
                    for (i, j) in ((-6, 7), (-5, 8), (5, 10), (6, 19), (-6, 27), (0, 15)):
                        setpx(tw, cx + i, j, I["k3"])
                elif st == "boarded":
                    for j, y in enumerate(range(8, BELT_Y - 3, 3)):
                        rect(tw, cx - 6, y, cx + 6, y + 1, I["s3"] if j % 2 else I["s2"])
        # balustraded podium across the loggia front (between and behind the column bases)
        yb0 = BELT_Y - 7
        tw[yb0, x0 + 2:x1 - 1] = I["m5"]; tw[yb0 + 1, x0 + 2:x1 - 1] = I["m3"]
        for xx in range(x0 + 4, x1 - 2, 4):
            tw[yb0 + 2:BELT_Y - 1, xx] = I["m4"]; tw[yb0 + 2:BELT_Y - 1, xx + 1] = I["m2"]
        tw[BELT_Y - 1, x0 + 2:x1 - 1] = I["m2"]
        for k, pc in enumerate(pair_c):
            for j, sx in enumerate((pc - 6, pc + 5)):
                n = 2 * k + j
                self.column(tw, sx, BELT_Y - 1, BELT_Y + 3, key=("pav", n), sw=8,
                            chip=(n in PAVILION_COL_CHIPPED), soot=(n in PAVILION_COL_SOOT))
        base = self.rusticated_rows(BASE_Y0, PAV_Y1 - 6, "pav-base")
        tw[BASE_Y0:PAV_Y1 - 6, x0:x1 + 1] = base[:, x0:x1 + 1]
        for (cx, st) in zip((530, 585, 640, 694, 749), PAVILION_ARCHES):
            w = 18 if cx == 640 else 14
            self.basement_arch(tw, cx, BASE_Y0 + 10, PAV_Y1 - 7, w, st, ("pa", cx))
        for y, c in zip(range(PAV_Y1 - 6, PAV_Y1), ("m5", "m4", "m2", "m5", "m3", "m1")):
            tw[y, x0 - 4:x1 + 5] = I[c]
        for x in range(x0 + 9, x1, 31):
            tw[PAV_Y1 - 5:PAV_Y1 - 3, x] = I["m3"]
        tw[BELT_Y:PAV_Y1 - 6, x0] = I["m5"]; tw[BELT_Y:PAV_Y1 - 6, x0 + 1] = I["m4"]
        tw[BELT_Y:PAV_Y1 - 6, x1] = I["m0"]; tw[BELT_Y:PAV_Y1 - 6, x1 - 1] = I["m1"]

    def column(self, tw, cx, yb, sty_front, broken_at=None, key=None, sw=10, chip=False, soot=False):
        """A fluted column shaft lit from the left on an Attic base whose bottom row is yb; the shaft runs off the top
        of the frame unless broken_at is set. chip: a chunk knocked out of the shaft; soot: darkened flutes."""
        x0 = cx - sw // 2
        tones = ("m3", "m5", "m4", "m5", "m4", "m3", "m4", "m3", "m2", "m1")[10 - sw:] if sw < 10 else \
            ("m3", "m5", "m4", "m5", "m4", "m3", "m4", "m3", "m2", "m1")
        top = 0 if broken_at is None else broken_at
        backup = tw[:, x0:x0 + sw].copy()
        for i, c in enumerate(tones):
            tw[top:yb - 4, x0 + i] = I[c]
        tw[top:yb - 4, x0 - 1] = I["m1"]
        r = rng_for("col-v04", key)
        fx = x0 + int(r.integers(1, sw - 2))
        fy0 = int(r.integers(top, max(top + 1, yb - 12)))
        tw[fy0:yb - 4 - int(r.integers(0, 6)), fx] = I["m2"]
        if r.random() < 0.5:
            py_ = int(r.integers(top + 2, max(top + 3, yb - 8)))
            tw[py_:py_ + 2, x0 + sw - 3:x0 + sw - 1] = I["m2"]
        if soot:
            seg = tw[top:yb - 4, x0:x0 + sw]
            seg[:] = ramp_shift_arr(seg, STONE, -1)
        if chip:
            tw[8:12, x0 + sw - 4:x0 + sw] = I["m1"]; tw[12, x0 + sw - 4:x0 + sw] = I["m4"]
            tw[8, x0 + sw - 4:x0 + sw] = I["m0"]
        if broken_at is not None:
            jag = (0, 1, 3, 2, 4, 3, 1, 2, 0, 1)
            for i in range(sw):
                y = broken_at + jag[i]
                tw[broken_at:y, x0 + i] = backup[broken_at:y, i]
                tw[y, x0 + i] = I["m5"] if i < sw * 0.6 else I["m4"]
                tw[y + 1, x0 + i] = I["m3"]
        rows = ((yb - 4, sw + 2, ("m5", "m4", "m2")), (yb - 3, sw, ("m1", "m1", "m0")),
                (yb - 2, sw + 4, ("m5", "m4", "m2")), (yb - 1, sw + 4, ("m4", "m3", "m1")),
                (yb, sw + 4, ("m2", "m1", "m0")))
        for y, w, (lit, mid, dark) in rows:
            a = cx - w // 2
            tw[y, a:a + w] = I[mid]
            tw[y, a:a + max(2, w // 3)] = I[lit]
            tw[y, a + w - 2:a + w] = I[dark]

    # ------------------------------------------------------------------ terrace wall face (rows 146..219)
    def wall_face(self, tw):
        x = np.arange(W)
        for y in range(EDGE_Y, FOOT_Y):
            r = y - EDGE_Y
            course, v = divmod(r - 2, 8) if r >= 2 else (-1, r)
            row = np.full(W, I["m2"], np.int16)
            if r < 2:
                row[:] = I["m1"] if r == 0 else I["m0"]
            else:
                widths = rng_for("wallc-v04", course).integers(18, 34, size=80)
                edges = np.cumsum(widths) - (course * 13) % 30
                k = np.searchsorted(edges, x, side="right")
                tone = np.where((k * 37 + course * 11) % 5 < 2, I["m3"], I["m2"])
                row[:] = tone
                if v == 0:
                    row[:] = I["m1"]
                elif v == 1:
                    row[:] = np.where(tone == I["m3"], I["m4"], I["m3"])
                elif v == 7:
                    row[:] = np.where(tone == I["m3"], I["m2"], I["m1"])
                row[np.isin(x, edges) & (v > 0)] = I["m1"]
            tw[y, :] = row
        for k, px in enumerate(PIERS):
            tw[EDGE_Y + 2:FOOT_Y, px - 6:px + 6] = I["m3"]
            tw[EDGE_Y + 2:FOOT_Y, px - 6] = I["m4"]
            tw[EDGE_Y + 2:FOOT_Y, px + 5] = I["m1"]
            tw[EDGE_Y + 2:FOOT_Y, px + 6] = I["m0"]
            tw[FOOT_Y - 6, px - 7:px + 7] = I["m4"]
            tw[FOOT_Y - 5:FOOT_Y, px - 7:px + 7] = I["m2"]
        sn = vnoise("damp-v04", 4)
        for (a, b, state, key) in self.bay_list():
            if state == "breach":
                continue
            a, b = max(0, a), min(W - 1, b)
            r = rng_for("bayface-v04", key)
            face = np.zeros((H, W), bool)
            face[EDGE_Y + 2:FOOT_Y - 6, a + 7:b - 6] = True
            if state in ("stained", "missing", "ivy", "slump"):
                damp = face & (sn > 0.36 + 0.25 * r.random())
                tw[damp] = ramp_shift_arr(tw, STONE, -1)[damp]
            # terrace-room window (the Olmsted terrace holds rooms behind this wall), its own condition per bay
            wst = WALL_WINDOWS.get(key, "none")
            if wst != "none":
                self.terrace_window(tw, (a + b) // 2, wst, key)
            if state in ("stained", "chipped") or (a > 900 and r.random() < 0.6):
                for _ in range(int(r.integers(2, 6))):
                    ex = int(r.integers(a + 10, max(a + 11, b - 8)))
                    ey = EDGE_Y + 2 + int(r.integers(0, 8) * 8 % 56)
                    for j in range(int(r.integers(4, 12))):
                        if ey + j < FOOT_Y - 6 and tw[ey + j, ex] not in (I["m1"], I["k0"], I["k1"], I["k2"]):
                            tw[ey + j, ex] = I["m4"] if j % 3 else I["m5"]
            if state in ("chipped", "missing", "mossy", "slump") and r.random() < 0.85:
                cx, cy = int(r.integers(a + 14, max(a + 15, b - 14))), EDGE_Y + 3
                while cy < FOOT_Y - 2:
                    if tw[cy, cx] not in (I["k0"], I["k1"]):
                        tw[cy, cx] = I["ink"]
                    cy += 1
                    if (cy - EDGE_Y) % 8 == 2:
                        for _ in range(int(r.integers(2, 7))):
                            cx = min(W - 2, max(1, cx + (1 if r.random() < 0.6 else -1)))
                            tw[cy, cx] = I["ink"]
        for x0 in range(0, W, 3):
            if (x0 * 7919) % 11 < 3:
                ln = 6 + (x0 * 104729) % 30
                seg = tw[EDGE_Y + 2:EDGE_Y + 2 + ln, x0]
                ok = ~np.isin(seg, [I["k0"], I["k1"], I["k2"], I["ink"]])
                seg[ok] = ramp_shift_arr(seg, STONE, -1)[ok]
        foot = np.zeros((H, W), bool)
        foot[FOOT_Y - 8:FOOT_Y, :] = True
        gr = foot & (vnoise("wallgrime-v04", 6) > 0.45)
        tw[gr] = ramp_shift_arr(tw, STONE, -1)[gr]
        moss = foot & (vnoise("wallmoss-v04", 4) > 0.62)
        tw[moss & (np.arange(H)[:, None] >= FOOT_Y - 5)] = I["g1"]
        tw[moss & (np.arange(H)[:, None] >= FOOT_Y - 2) & (vnoise("wallmoss2-v04", 2) > 0.5)] = I["g2"]

    def terrace_window(self, tw, cx, state, key):
        """Window of a terrace room: segmental head, deep reveal, iron grille. States: grille, dark, bricked,
        boarded, bent (grille torn open), vine (dark; ivy from ground-detail covers it)."""
        x0, x1, y0, y1 = cx - 7, cx + 6, 168, 197
        rect(tw, x0 - 3, y0 - 5, x1 + 3, y1 + 2, I["m4"])                  # surround
        rect(tw, x1 + 3, y0 - 5, x1 + 3, y1 + 2, I["m2"])
        for i in range(x0 - 2, x1 + 3):                                      # segmental head voussoirs
            d = abs(i - (x0 + x1) / 2.0)
            hgt = int(round(3 - d * d / 22.0))
            tw[y0 - 2 - hgt:y0, i] = I["m3"] if i < cx else I["m2"]
            if i % 3 == 0:
                tw[y0 - 2 - hgt:y0, i] = I["m1"]
        rect(tw, x0, y0, x1, y1, I["k0"])
        rect(tw, x0, y0, x0 + 1, y1, I["ink"])
        rect(tw, x0 - 3, y1 + 1, x1 + 3, y1 + 1, I["m5"]); rect(tw, x0 - 2, y1 + 2, x1 + 2, y1 + 2, I["m1"])
        if state in ("grille", "bent"):
            for xx in range(x0 + 3, x1, 3):
                tw[y0 + 1:y1, xx] = I["k2"]
            tw[y0 + 8, x0 + 1:x1] = I["k2"]; tw[y1 - 6, x0 + 1:x1] = I["k2"]
            if state == "bent":                                              # bars wrenched open at the bottom
                for xx in (x0 + 6, x0 + 9):
                    tw[y1 - 10:y1, xx] = I["k0"]
                    for j in range(6):
                        setpx(tw, xx - 1 - j // 2 if xx < cx else xx + 1 + j // 2, y1 - 6 + j, I["k2"])
        elif state == "bricked":
            for yy in range(y0, y1 + 1):
                for xx in range(x0 + 1, x1 + 1):
                    row = (yy - y0) // 3
                    joint = (yy - y0) % 3 == 0 or (xx - x0 + (row % 2) * 3) % 6 == 0
                    tw[yy, xx] = I["p0"] if joint else (I["p1"] if (row + xx // 6) % 3 else I["p2"])
        elif state == "boarded":
            for j, yy in enumerate(range(y0 + 1, y1, 4)):
                rect(tw, x0 + 1, yy, x1, yy + 2, I["s2"] if j % 2 else I["s3"])
                rect(tw, x0 + 1, yy + 3, x1, yy + 3, I["s1"])

    def bay_list(self):
        """Balustrade bays between piers, from each stair's outer cheek wall to the frame edge."""
        if hasattr(self, "_bays"):
            return self._bays
        left = [STAIRS[0][0] - CHEEK_W] + PIERS_L + [-30]
        right = [STAIRS[1][1] + CHEEK_W] + PIERS_R + [W + 30]
        bays = []
        for k, (a, b) in enumerate(zip(left, left[1:])):
            bays.append((b, a, BAY_STATE_L[k], ("L", k)))
        for k, (a, b) in enumerate(zip(right, right[1:])):
            st = BAY_STATE_R[k]
            if st != "breach" and COLLAPSE[0] - 6 < (a + b) / 2 < COLLAPSE[1] + 6:
                st = "breach"
            bays.append((a, b, st, ("R", k)))
        self._bays = bays
        return bays

    def balustrade(self, tw):
        y0 = EDGE_Y - BAL_H
        prof = ["xLMMDx", "xxLDxx", "xxLDxx", "xLMMDx", "LMMMMD", "LMMMMD", "xLMMDx", "xxLDxx", "xxLDxx",
                "xLMMDx", "LMMMMD"]
        pitch = 7
        for (a, b, state, key) in self.bay_list():
            if state == "breach":
                continue
            a0 = a + 7 if a in PIERS else max(0, a + 1)
            b0 = b - 7 if b in PIERS else min(W - 1, b - 1)
            if b0 <= a0:
                continue
            r = rng_for("bay-v04", key)
            rail = {"y0": "m5", "y1": "m4", "y2": "m4", "y3": "m3", "y4": "m1"}
            if state in ("stained", "missing", "slump"):
                rail = {"y0": "m4", "y1": "m3", "y2": "m3", "y3": "m2", "y4": "m1"}
            n = (b0 - a0 + 1) // pitch
            off = a0 + ((b0 - a0 + 1) - n * pitch) // 2
            sag = np.zeros(b0 - a0 + 1, int)
            gap = (-1, -1)
            if state == "slump":                                         # rail snapped in the middle and sagging
                mid = (a0 + b0) // 2
                gap = (mid - 3, mid + 4)
                xs_ = np.arange(a0, b0 + 1)
                sag = np.round(5 * np.clip(1 - np.abs(xs_ - mid) / ((b0 - a0) / 2.0), 0, 1) ** 0.7).astype(int)
            for i_, xx in enumerate(range(a0, b0 + 1)):
                if gap[0] <= xx <= gap[1]:
                    continue
                for j, kk in enumerate(("y0", "y1", "y2", "y3", "y4")):
                    tw[y0 + j + sag[i_], xx] = I[rail[kk]]
            tw[y0 + 5:y0 + 16, a0:b0 + 1] = I["m1"]
            tw[y0 + 13:y0 + 16, a0:b0 + 1] = I["m0"]
            missing = set()
            if state == "missing":
                missing = {2, 3, 4}
            elif state == "slump":
                missing = {n // 2 - 1, n // 2, n // 2 + 1, n // 2 + 2}
            replaced = {n // 3} if state == "replaced" and n else set()
            cracked = {int(r.integers(0, n))} if state in ("chipped", "stained") and n else set()
            for i in range(n):
                bx = off + i * pitch
                if i in missing:
                    for j in range(8, 11):
                        for q, ch in enumerate(prof[j]):
                            if ch != "x":
                                tw[y0 + 5 + j, bx + q] = I["m3"] if ch in "LM" else I["m2"]
                    tw[y0 + 13, bx + 1:bx + 5] = I["m4"]
                    continue
                cm = {"L": "m4", "M": "m3", "D": "m2"}
                if i in replaced:
                    cm = {"L": "m5", "M": "m4", "D": "m3"}
                elif state in ("stained", "missing", "slump"):
                    cm = {"L": "m3", "M": "m2", "D": "m1"}
                for j, row in enumerate(prof):
                    for q, ch in enumerate(row):
                        if ch == "x":
                            continue
                        c = cm[ch]
                        if state == "mossy" and j >= 9 and (q + i + j) % 3:
                            c = "g2" if ch == "D" else "g3"
                        tw[y0 + 5 + j, bx + q] = I[c]
                if i in cracked:
                    for j in range(3, 9):
                        setpx(tw, bx + 1 + (j - 3) // 2, y0 + 5 + j, I["ink"])
            for j, c in ((16, "m4"), (17, "m3"), (18, "m2"), (19, "m1")):
                tw[y0 + j, a0:b0 + 1] = I[c]
            if state == "chipped":
                for nx in (a0 + (b0 - a0) // 4, a0 + 2 * (b0 - a0) // 3):
                    tw[y0:y0 + 2, nx:nx + 5] = I["m2"]
                    tw[y0 + 2, nx:nx + 3] = I["m1"]
            if state == "mossy":
                mo = vnoise(("railmoss-v04", key), 3, 1, W)[0]
                for xx in range(a0, b0 + 1):
                    if mo[xx] > 0.45:
                        tw[y0, xx] = I["g3"] if mo[xx] > 0.7 else I["g2"]
                        if mo[xx] > 0.62:
                            tw[y0 + 1, xx] = I["g2"]
            if state == "stained":
                for xx in range(a0, b0 + 1, 3):
                    if r.random() < 0.4:
                        ln = int(r.integers(3, 9))
                        seg = tw[y0 + 4:y0 + 4 + ln, xx]
                        ok = seg != I["m1"]
                        seg[ok] = ramp_shift_arr(seg, STONE, -1)[ok]
        self.urn_boxes = getattr(self, "urn_boxes", [])
        for k, px in enumerate(PIERS):
            if COLLAPSE[0] - 4 < px < COLLAPSE[1] + 4:
                continue
            x0 = px - 6
            tw[y0 - 4:EDGE_Y, x0:x0 + 12] = I["m3"]
            tw[y0 - 4:EDGE_Y, x0] = I["m4"]
            tw[y0 - 4:EDGE_Y, x0 + 11] = I["m2"]
            tw[y0 - 4:EDGE_Y, x0 + 12] = I["m1"]
            tw[y0 + 4:y0 + 14, x0 + 3:x0 + 9] = I["m2"]
            tw[y0 + 4, x0 + 3:x0 + 9] = I["m1"]
            tw[y0 + 4:y0 + 14, x0 + 3] = I["m1"]
            tw[y0 - 7, x0 - 1:x0 + 13] = I["m5"]
            tw[y0 - 6:y0 - 4, x0 - 1:x0 + 13] = I["m4"]
            tw[y0 - 4, x0 - 1:x0 + 13] = I["m2"]
            tw[y0 - 7:y0 - 3, x0 + 13] = I["m1"]
            if PIER_CAPS.get(px) == "chipped":
                tw[y0 - 7:y0 - 5, x0 + 9:x0 + 13] = I["m2"]
                tw[y0 - 5, x0 + 9:x0 + 13] = I["m1"]
            elif PIER_CAPS.get(px) == "moss":
                tw[y0 - 7, x0 + 2:x0 + 8] = I["g3"]
                tw[y0 - 6, x0 + 3:x0 + 6] = I["g2"]
            if px in URN_PIERS:
                self.urn(tw, px + 1, y0 - 8, ("pier", px), patina=URN_PIERS[px])
        self.bunting(tw)

    def bunting(self, tw):
        """Game fiction grounded in West Front practice (the inaugural platform is built over this terrace): faded
        red-white-blue pleated bunting fans left hanging on the balustrade beside the stairs and on the exedra rail.
        Sun-faded, one torn, one fallen on the deck."""
        fw = 19
        star = "".join("s" if i % 4 == 2 else "N" for i in range(fw))
        bands = [(1, "R"), (1, "W"), (2, "R"), (2, "W"), (3, "R"), (4, "W"), (5, "R"), (7, "R")]
        fan = ["N" * fw, star, "N" * fw] + ["." * k + ch * (fw - 2 * k) + "." * k for k, ch in bands]
        cm = {"N": "n0", "s": "m5", "R": "r0", "W": "m4"}
        dk = {"N": "k0", "s": "m3", "R": "o0", "W": "m2"}
        y_straight = EDGE_Y - BAL_H
        spots = []
        for (a, b, state, key) in self.bay_list():
            if key in (("L", 0), ("L", 2), ("R", 0)):
                spots.append(((max(0, a) + min(W - 1, b)) // 2, y_straight, key, False))
        cxm = (EXEDRA[0] + EXEDRA[1]) // 2
        for k, dx in enumerate((-62, 0, 62)):
            x = cxm + dx
            spots.append((x, self.rim[x] - BAL_H, ("X", k), k == 1))
        self.bunting_spots = spots
        for (cx, y0, key, torn) in spots:
            r = rng_for("bunting-v04", key)
            for j, row in enumerate(fan):
                for i, ch in enumerate(row):
                    if ch == ".":
                        continue
                    if torn and j >= 4 and i > 10:
                        continue
                    if j >= 3 and r.random() < 0.04:
                        continue
                    c = (dk if i % 3 == 2 and j >= 3 else cm)[ch]
                    if ch == "R" and (i + j) % 5 == 0:
                        c = "o0"
                    xx = cx - fw // 2 + i
                    yo = y0 + 3 + j + ((self.rim[xx] - self.rim[cx]) if key[0] == "X" and xx in self.rim else 0)
                    setpx(tw, xx, yo, I[c])
            for j in range(3):
                setpx(tw, cx - fw // 2, y0 + j, I["m2"]); setpx(tw, cx + fw // 2, y0 + j, I["m2"])
        fx, fy = 300, 104                                               # one fan blown down onto the deck
        for j, row in enumerate(fan[:6]):
            for i, ch in enumerate(row):
                if ch != "." and (i + 2 * j) % 7:
                    setpx(tw, fx + i + j // 2, fy + j, I[(dk if i % 3 == 2 else cm)[ch]])
        self.fallen_bunting = (fx, fy, 18, 6)

    # ------------------------------------------------------------------ exedra (curved recess between the stairs)
    def exedra(self, tw):
        """The lower west terrace's curved recess between the twin stairs: the deck edge bows back to the east,
        a curved retaining wall (left half turned away from the light, right half lit) with three blind arched
        niches; the centre niche keeps a dry lion-mask spout with a dark algae stain (no water). The recess floor
        is at lawn level (paving layer). A curved balustrade with two urn piers follows the rim."""
        e0, e1 = EXEDRA
        cx = (e0 + e1) / 2.0
        hw = (e1 - e0 + 1) / 2.0
        self.rim, self.floor_y = {}, {}
        niches = [(cx + hw * math.sin(th), th) for th in (-0.66, 0.0, 0.66)]
        for x in range(e0, e1 + 1):
            u = max(-1.0, min(1.0, (x - cx) / hw))
            bow = EXEDRA_DEPTH * math.sqrt(max(0.0, 1 - u * u))
            rim = int(round(EDGE_Y - bow))
            fl = rim + WALL_H
            self.rim[x], self.floor_y[x] = rim, fl
            tw[EDGE_Y - BAL_H - 8:FOOT_Y + 1, x] = -1
            th = math.asin(u)
            base = I["m2"] if u < -0.45 else I["m3"] if u < 0.4 else I["m4"]
            lit = ramp_shift(base, STONE, 1)
            dk = ramp_shift(base, STONE, -1)
            for y in range(rim, fl):
                d = y - rim
                if d < 2:
                    c = I["m1"] if d == 0 else I["m0"]
                else:
                    course, v = divmod(d - 2, 8)
                    stone = int(math.floor((th + 1.6) / 0.14 + course * 0.5))
                    c = base if (stone * 5 + course) % 4 else dk
                    if v == 0:
                        c = I["m1"]
                    elif v == 1:
                        c = lit
                    elif v == 7:
                        c = dk
                    s_prev = int(math.floor((math.asin(max(-1.0, min(1.0, (x - 1 - cx) / hw))) + 1.6) / 0.14
                                            + course * 0.5))
                    if s_prev != stone and v > 0:
                        c = I["m1"]
                tw[y, x] = c
            tw[fl - 1, x] = I["m1"]
        for (nx, th) in niches:
            self.niche(tw, nx, th, centre=(abs(th) < 0.01))
        # curved balustrade on the rim: rail, balusters spaced along the arc (foreshortened), plinth
        s_of = {x: hw * math.asin(max(-1.0, min(1.0, (x - cx) / hw))) for x in range(e0, e1 + 1)}
        for x in range(e0, e1 + 1):
            rim = self.rim[x]
            y0 = rim - BAL_H
            for j, c in enumerate(("m5", "m4", "m4", "m3", "m1")):
                tw[y0 + j, x] = I[c]
            tw[y0 + 5:y0 + 16, x] = I["m1"]
            tw[y0 + 13:y0 + 16, x] = I["m0"]
            for j, c in ((16, "m4"), (17, "m3"), (18, "m2"), (19, "m1")):
                tw[y0 + j, x] = I[c]
        prof = ["LMMD", ".LD.", ".LD.", "LMMD", "LMMD", "LMMD", "LMMD", ".LD.", ".LD.", "LMMD", "LMMD"]
        s0, s1 = s_of[e0], s_of[e1]
        k = 0
        s = s0 + 5
        while s < s1 - 5:
            x = int(round(cx + hw * math.sin(s / hw)))
            th = s / hw
            narrow = math.cos(th) < 0.55
            y0 = self.rim[x] - BAL_H
            for j, row in enumerate(prof):
                for q, ch in enumerate(row[1:3] if narrow else row):
                    if ch == ".":
                        continue
                    tw[y0 + 5 + j, x - 1 + q] = I[{"L": "m4", "M": "m3", "D": "m2"}[ch]]
            s += 7
            k += 1
        # two urn piers on the curve
        for u_ in (-0.52, 0.52):
            px = int(round(cx + hw * u_))
            y0 = self.rim[px] - BAL_H
            tw[y0 - 4:self.rim[px], px - 6:px + 6] = I["m3"]
            tw[y0 - 4:self.rim[px], px - 6] = I["m4"]
            tw[y0 - 4:self.rim[px], px + 5] = I["m1"]
            tw[y0 - 7, px - 7:px + 7] = I["m5"]
            tw[y0 - 6:y0 - 4, px - 7:px + 7] = I["m4"]
            tw[y0 - 4, px - 7:px + 7] = I["m2"]
            self.urn(tw, px, y0 - 8, ("exedra", u_), patina="dark" if u_ > 0 else "bright")
        self.exedra_piers = [int(round(cx + hw * u_)) for u_ in (-0.52, 0.52)]

    def niche(self, tw, nx, th, centre=False):
        """Blind arched niche in the curved wall, foreshortened by cos(theta); left reveal in shade, shell hood."""
        hwn = max(3.0, 8.0 * math.cos(th))
        x0, x1 = int(round(nx - hwn)), int(round(nx + hwn))
        fl = self.floor_y[int(round(nx))]
        y_top, y_bot = fl - 54, fl - 12
        cyf = y_top + hwn
        for x in range(x0 - 2, x1 + 3):
            for y in range(int(y_top) - 2, y_bot + 2):
                dx = x - nx
                if y >= cyf:
                    d = abs(dx) - hwn
                else:
                    d = math.hypot(dx / max(0.6, math.cos(th)) * math.cos(th), y - cyf) - hwn
                if d <= 0:
                    rel = (x - x0) / max(1.0, x1 - x0)
                    c = I["m0"] if rel < 0.35 else I["m1"]
                    if y < cyf + 3:                                    # shell hood ribs
                        c = I["m2"] if (x + y) % 3 else I["m1"]
                    tw[y, x] = c
                elif d <= 1.6:
                    tw[y, x] = I["m4"] if dx < 0 else I["m2"]
        tw[y_bot, x0:x1 + 1] = I["m4"]
        tw[y_bot + 1, x0:x1 + 1] = I["m2"]
        if centre:                                                     # dry lion-mask spout + algae stain
            my = fl - 34
            stamp(tw, int(nx) - 4, my, [".xMMMx.", "xMLMLMx", "xMxMxMx", "xMMDMMx", ".xMkMx.", "..xkx.."],
                  {"x": "m1", "M": "m3", "L": "m4", "D": "m2", "k": "ink"})
            for j in range(6, 22):
                for i in (-1, 0, 1):
                    if (j + i) % 4 != 3:
                        setpx(tw, int(nx) + i, my + j, I["g0"] if i == 0 else I["g1"])

    # ------------------------------------------------------------------ twin stairs
    def stairs(self, tw):
        """Two stairs, each with two flights and a landing, framing the exedra. Treads are lit tops; risers face
        west (away from the light); the riser above shades the back row of each tread; the centre line is dished
        and polished. Damage differs by side (STAIR_DAMAGE):
          left stair: mostly intact; grass in the tread joints, two chipped nosings, one missing cheek baluster;
          right stair: beside the collapse; two displaced treads, soot, and a rubble spill on its outer third
            (painted by collapse()); a fallen urn on the outer landing pier. Its inner lane stays clear."""
        top = EDGE_Y - 2
        self.stair_rows = {0: [], 1: []}
        la, lb = LANDING
        for si, (sx0, sx1) in enumerate(STAIRS):
            dmg = STAIR_DAMAGE[si]
            xs = np.arange(sx0, sx1 + 1)
            cxs = (sx0 + sx1) / 2.0
            wear = np.exp(-((xs - cxs) / 18.0) ** 2)
            mossn = vnoise(("stairmoss-v04", si), 3)
            flights = ((top, la, 7), (lb + 1, STAIR_BOT, 7))
            for f, (ya0, yb0, n) in enumerate(flights):
                step = (yb0 - ya0) / n
                for k in range(n):
                    ya = int(round(ya0 + k * step)); yb = int(round(ya0 + (k + 1) * step))
                    h = yb - ya
                    rk = rng_for("tread-v04", si, f, k)
                    joints = np.cumsum(rk.integers(20, 40, size=10)) + sx0 - int(rk.integers(0, 18))
                    jmask = np.isin(xs, joints)
                    blk = np.searchsorted(joints, xs)
                    btone = np.where((blk * 5 + k * 3 + f + si) % 7 < 2, I["m3"], I["m4"])
                    for y in range(ya, yb):
                        r = y - ya
                        if r == 0:
                            row = np.full(len(xs), I["m2"], np.int16)
                            row[wear > 0.6] = I["m3"]
                        elif r < h - 3:
                            row = btone.copy()
                            row[(wear > 0.75) & (r == 1)] = I["m5"]
                            row[jmask] = I["m2"]
                        elif r == h - 3:
                            row = np.full(len(xs), I["m5"], np.int16)
                            row[wear > 0.7] = I["m4"]
                        elif r == h - 2:
                            row = np.full(len(xs), I["m1"], np.int16)
                        else:
                            row = np.full(len(xs), I["m2"], np.int16)
                            row[jmask] = I["m1"]
                        edge = np.minimum(xs - sx0, sx1 - xs)
                        mm = (edge < dmg["moss_edge"] + 9 * mossn[y, xs]) & (mossn[y, xs] > dmg["moss_thr"])
                        keep = row != I["m5"]
                        row[mm & keep] = np.where(mossn[y, xs] > 0.7, I["g3"], I["g2"])[mm & keep]
                        if dmg["joint_grass"] and r == h - 1:              # grass in the riser joints
                            gj = (rk.random(len(xs)) < 0.22) & (edge > 6)
                            row[gj] = I["g3"]
                        tw[y, sx0:sx1 + 1] = row
                    self.stair_rows[si].append((ya, yb))
            for y in range(la, lb + 1):
                r = y - la
                u = (xs - sx0 + (r // 9) * 23) % 46
                row = np.where(((xs // 46) + r // 9) % 3 == 0, I["m3"], I["m4"]).astype(np.int16)
                row[u == 0] = I["m2"]
                if r % 9 == 0:
                    row[:] = I["m2"]
                if r == lb - la - 2:
                    row[:] = I["m5"]
                elif r == lb - la - 1:
                    row[:] = I["m1"]
                elif r == lb - la:
                    row[:] = I["m2"]
                tw[y, sx0:sx1 + 1] = row
            gx0 = int(cxs) - 6
            tw[la + 4:la + 10, gx0:gx0 + 13] = I["k1"]
            for gx in range(gx0 + 1, gx0 + 13, 2):
                tw[la + 5:la + 9, gx] = I["k0"]
            tw[la + 4, gx0:gx0 + 13] = I["k2"]
            for (cx, cy, w) in dmg["cracks"]:
                tw[cy, cx:cx + w] = I["ink"]
                tw[cy + 1, cx + 2:cx + w - 2] = I["m2"]
            for (k_, x_) in dmg["chipped_noses"]:
                ya, yb = self.stair_rows[si][k_]
                tw[yb - 3, x_:x_ + 5] = I["m3"]
                tw[yb - 2, x_:x_ + 5] = I["m0"]
            for (k_, xa, xb, drop) in dmg["displaced"]:                 # a tread block dropped and tipped
                ya, yb = self.stair_rows[si][k_]
                seg = tw[ya:yb, xa:xb].copy()
                tw[ya:ya + drop, xa:xb] = I["ink"]
                tw[ya + drop:yb, xa:xb] = seg[:yb - ya - drop]
                tw[yb - 1, xa:xb] = I["m4"]
                tw[ya:yb, xb - 1] = I["m1"]
                tw[ya + drop:yb, xa] = I["m4"]
            if dmg["soot"]:
                sn = vnoise(("stairsoot", si), 5)
                for y in range(top, la):
                    for x in range(sx1 - 34, sx1 + 1):
                        if sn[y, x] > 0.58 and tw[y, x] in (I["m3"], I["m4"], I["m5"]):
                            tw[y, x] = ramp_shift(tw[y, x], STONE, -1)
            # cheek walls with a stair balustrade seen from above, landing pier a step wider with an urn
            for x0, side in ((sx0 - CHEEK_W, -1), (sx1 + 1, 1)):
                y_a, y_b = EDGE_Y - BAL_H - 6, STAIR_BOT - 14
                tw[y_a:y_b, x0:x0 + CHEEK_W] = I["m3"]
                tw[y_a:y_b, x0] = I["m5"]; tw[y_a:y_b, x0 + 1] = I["m4"]
                tw[y_a:y_b, x0 + CHEEK_W - 2] = I["m2"]; tw[y_a:y_b, x0 + CHEEK_W - 1] = I["m1"]
                for y in range(y_a + 2, y_b - 1, 5):
                    if (si, side, y) in dmg["missing_balusters"]:
                        tw[y + 1, x0 + 4:x0 + 9] = I["m1"]
                        continue
                    tw[y, x0 + 4:x0 + 9] = I["m4"]; tw[y + 1, x0 + 4:x0 + 9] = I["m2"]
                    tw[y + 2, x0 + 5:x0 + 8] = I["m1"]
                tw[y_a:y_b, x0 + 3] = I["m5"]
                tw[y_a - 1, x0:x0 + CHEEK_W] = I["m5"]
                rc = rng_for("cheek-v04", si, side)
                for _ in range(int(rc.integers(4, 9))):
                    my = int(rc.integers(y_a + 2, y_b - 3)); mxo = int(rc.integers(1, CHEEK_W - 3))
                    tw[my:my + 2, x0 + mxo:x0 + mxo + 2] = I["g2"] if si == 0 else I["m2"]
                    if si == 0:
                        setpx(tw, x0 + mxo + 1, my - 1, I["g3"])
                for _ in range(int(rc.integers(1, 4))):
                    cy_ = int(rc.integers(y_a + 4, y_b - 4))
                    tw[cy_:cy_ + 3, x0 + (0 if side < 0 else CHEEK_W - 2):x0 + (2 if side < 0 else CHEEK_W)] = I["m1"]
                px0 = x0 - 2
                tw[la - 6:lb + 1, px0:px0 + CHEEK_W + 4] = I["m3"]
                tw[la - 6, px0:px0 + CHEEK_W + 4] = I["m5"]
                tw[la - 5:la, px0:px0 + CHEEK_W + 4] = I["m4"]
                tw[la, px0:px0 + CHEEK_W + 4] = I["m2"]
                tw[la + 1:lb + 1, px0] = I["m4"]; tw[la + 1:lb + 1, px0 + CHEEK_W + 3] = I["m1"]
                tw[la + 4:lb - 2, px0 + 4:px0 + CHEEK_W] = I["m2"]
                tw[la + 4, px0 + 4:px0 + CHEEK_W] = I["m1"]
                if (si, side) == dmg["fallen_urn_pier"]:
                    tw[la - 6:la - 3, px0 + 3:px0 + 9] = I["m2"]          # empty socket on the cap
                    tw[la - 6, px0 + 4:px0 + 8] = I["m0"]
                    self.fallen_urn(tw, sx1 - 22, lb - 2, ("stairurn", si))
                else:
                    self.urn(tw, px0 + (CHEEK_W + 4) // 2, la - 5, ("landing", si, side),
                             patina="dark" if (si + (side > 0)) % 2 else "bright")
                if side < 0:
                    tw[EDGE_Y:STAIR_BOT - 22, x0 - 1] = I["m3"]
                else:
                    tw[EDGE_Y:STAIR_BOT - 22, x0 + CHEEK_W] = I["m1"]

    def urn(self, layer, cx, base_y, key, patina="bright"):
        """Bronze urn on a pier cap (the west terrace balustrade piers carry bronze urns, cast 1890): verdigris body,
        lit lip and shoulder, dark foot. 9 px wide, 11 px tall. Patina is hand-assigned per urn."""
        spr = ["..xxxxx..",
               ".xLMMMDx.",
               "..xBBbx..",
               ".xLBBBbx.",
               "xLBBBBbbx",
               "xLBBBBbbx",
               ".xBBBbbx.",
               "..xbbbx..",
               "...xbx...",
               "..xLBbx..",
               ".xxxxxxx."]
        cm = {"x": "ink", "L": "e4", "M": "e3", "D": "e2", "B": "e3", "b": "e2"}
        if patina == "dark":
            cm = {"x": "ink", "L": "e3", "M": "e3", "D": "f1", "B": "e2", "b": "f1"}
        elif patina == "streak":
            cm = {"x": "ink", "L": "e4", "M": "e3", "D": "e2", "B": "e3", "b": "f1"}
        y0 = base_y - len(spr) + 1
        stamp(layer, cx - 4, y0, spr, cm)
        if patina == "streak":
            for j in range(3, 9):
                setpx(layer, cx - 1, y0 + j, I["e4"])
        if not hasattr(self, "urn_boxes"):
            self.urn_boxes = []
        self.urn_boxes.append((cx - 4, y0, cx + 4, base_y))
        for j, row in enumerate(spr):
            for i, ch in enumerate(row):
                if ch != "." and 0 <= y0 + j < H and 0 <= cx - 4 + i < W:
                    self.fixture_mask[y0 + j, cx - 4 + i] = True
        self.prop_shadow.append(("box", cx + 1, base_y + 1, 6, 2))

    def fallen_urn(self, layer, x, ybase, key):
        """A bronze urn knocked off its pier, lying on its side (mouth to the left), a dent in the body."""
        spr = ["...xxxxxx..",
               ".xxLBBBBbx.",
               "xLxBBBBBbbx",
               "xMxBBBBbbbx",
               "xDxBBbbbbbx",
               ".xxbbbbbbx.",
               "...xxxxxx.."]
        stamp(layer, x, ybase - len(spr) + 1, spr, {"x": "ink", "L": "e4", "M": "e3", "D": "e2", "B": "e3",
                                                     "b": "e2"})
        setpx(layer, x + 6, ybase - 4, I["f1"]); setpx(layer, x + 7, ybase - 4, I["f1"])
        self.tall(("fallen-urn",) + tuple(key), layer, x, ybase - len(spr) + 1, x + 10, ybase,
                  mask=stamp_mask(x, ybase - len(spr) + 1, spr))
        self.prop_shadow.append(("box", x + 2, ybase + 1, 10, 2))

    def newels(self):
        """The four stair-foot newel blocks and their bronze candelabra, painted into the Y-sorted layer
        'stair-lamps-ysort' with one shared pivot (their front ground-contact row, STAIR_BOT). Conditions are
        hand-assigned (NEWEL_STATE): intact, globe missing, or snapped (the lamp head lies on the forecourt)."""
        sl = self.L["stair-lamps-ysort"]
        self.newel_boxes = []
        for (x0, side, si), st in zip(CHEEKS, NEWEL_STATE):
            sl[STAIR_BOT - 22:STAIR_BOT - 14, x0 - 2:x0 + CHEEK_W + 2] = I["m4"]
            sl[STAIR_BOT - 22, x0 - 2:x0 + CHEEK_W + 2] = I["m5"]
            sl[STAIR_BOT - 22:STAIR_BOT - 14, x0 - 2] = I["m5"]
            sl[STAIR_BOT - 22:STAIR_BOT - 14, x0 + CHEEK_W + 1] = I["m2"]
            sl[STAIR_BOT - 14:STAIR_BOT + 1, x0 - 2:x0 + CHEEK_W + 2] = I["m2"]
            sl[STAIR_BOT - 14, x0 - 2:x0 + CHEEK_W + 2] = I["m1"]
            sl[STAIR_BOT - 13:STAIR_BOT - 11, x0 - 2:x0 + CHEEK_W + 2] = I["m3"]
            sl[STAIR_BOT - 8:STAIR_BOT - 3, x0 + 1:x0 + CHEEK_W - 1] = I["m1"]
            sl[STAIR_BOT - 8, x0 + 1:x0 + CHEEK_W - 1] = I["m0"]
            sl[STAIR_BOT - 3, x0 + 1:x0 + CHEEK_W - 1] = I["m3"]
            sl[STAIR_BOT - 1:STAIR_BOT + 1, x0 - 2:x0 + CHEEK_W + 2] = I["m1"]
            sl[STAIR_BOT - 14:STAIR_BOT + 1, x0 + CHEEK_W + 1] = I["m1"]
            sl[STAIR_BOT - 14:STAIR_BOT + 1, x0 - 2] = I["m3"]
            sl[STAIR_BOT, x0 - 2:x0 + CHEEK_W + 2] = I["ink"]
            if si == 1:                                                         # moss creeping up the south newels
                for i in range(0, CHEEK_W + 4, 2 + (side > 0)):
                    sl[STAIR_BOT - 2 - (i * 7) % 4:STAIR_BOT, x0 - 2 + i] = I["g2"]
            self.candelabra(sl, x0 + CHEEK_W // 2, STAIR_BOT - 19, state=st)
            self.newel_boxes.append((x0 - 2, STAIR_BOT - 22, x0 + CHEEK_W + 1, STAIR_BOT))

    def candelabra(self, tw, cx, base_y, state="intact"):
        spr = [".....x.....",
               "....xLx....",
               "...xLMMx...",
               "...xLMDx...",
               "....xxx....",
               ".....B.....",
               ".xx..B..xx.",
               "xLMx.B.xLMx",
               "xLDx.B.xLDx",
               ".xx..B..xx.",
               "..b..B..k..",
               "..bBBBBBk..",
               ".....B.....",
               ".....B.....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "....bBk....",
               "...bbBkk...",
               "...bBBBk...",
               "..bbBBBkk..",
               "..bBBBBBk..",
               ".bbBBBBBkk.",
               "xxxxxxxxxxx"]
        if state == "globe-missing":
            spr = ["...........", "...........", "...........", "....xkx....", "....xbx...."] + spr[5:]
        elif state == "snapped":                                         # shaft snapped; head lies on the forecourt
            spr = ["..........."] * 15 + ["....xBx....", "...xbBk....", "....bBk....", "....bBk....",
                                          "....bBk...."] + spr[20:]
        stamp(tw, cx - 5, base_y - len(spr) + 1, spr,
              {"x": "ink", "M": "m4", "L": "m5", "D": "m2", "B": "e2", "b": "e3", "k": "f1"})
        y0 = base_y - len(spr) + 1
        for j, row in enumerate(spr):
            for i, ch in enumerate(row):
                if ch != ".":
                    self.fixture_mask[y0 + j, cx - 5 + i] = True
        self.prop_shadow.append(("box", cx + 2, base_y + 1, 6, 2))

    # ------------------------------------------------------------------ dry octagonal fountain
    def fountain(self, tw):
        """Dry granite-rimmed octagonal fountain in the recess (the real lower west terrace has one between the grand
        stairs). Coping top face and front faces in terrace-walls; soil and broken basin floor inside (no water: no
        c0/c1/c2 anywhere in the basin); plants come from ground-detail. Pedestal (dry jet column, bronze nozzle
        broken off) and a self-sown tree go to the Y-sorted layer 'fountain-ysort'. Cracked coping, one coping stone
        missing on the front-right."""
        fx, fy = FOUNTAIN
        ax, ay = FOUNTAIN_HALF
        bx, by = int(ax * 0.42), int(ay * 0.42)
        outer = [(-bx, -ay), (bx, -ay), (ax, -by), (ax, by), (bx, ay), (-bx, ay), (-ax, by), (-ax, -by)]
        yy, xx = np.mgrid[0:H, 0:W]

        def poly_mask(pts, sx=1.0, sy=1.0):
            m = np.ones((H, W), bool)
            P = [(fx + px * sx, fy + py * sy) for px, py in pts]
            for k in range(len(P)):
                (x0, y0), (x1, y1) = P[k], P[(k + 1) % len(P)]
                m &= ((x1 - x0) * (yy + 0.5 - y0) - (y1 - y0) * (xx + 0.5 - x0)) >= 0
            return m
        top = poly_mask(outer)
        inner = poly_mask(outer, 0.8, 0.7)
        face = np.zeros((H, W), bool)
        for k in range(1, FOUNTAIN_FACE + 1):
            sh = np.zeros((H, W), bool)
            sh[k:, :] = top[:-k, :]
            face |= sh
        face &= ~top
        coping = top & ~inner
        basin = inner
        self.fountain_basin = basin
        rel_x = xx - fx
        # coping: granite, lit back-left, joints every ~14 px of perimeter angle
        ang = np.arctan2((yy - fy) / float(ay), (xx - fx) / float(ax))
        joint = (np.mod(ang + 3.3, 0.42) < 0.06)
        cop = np.where(rel_x < -ax * 0.2, I["m4"], np.where(rel_x < ax * 0.4, I["m3"], I["k3"])).astype(np.int16)
        inner_edge = coping & ~poly_mask(outer, 0.86, 0.8)
        cop = np.where(inner_edge, I["m2"], cop)
        cop = np.where(joint & coping, I["m1"], cop)
        outer_rim = top & ~poly_mask(outer, 0.95, 0.9)
        cop = np.where(outer_rim & (yy < fy), I["m5"], cop)
        tw[coping] = cop[coping]
        # front faces: SW faces toward the light (lighter), S face mid, SE face dark; ink contact at the foot
        fc = np.where(rel_x < -bx, I["m3"], np.where(rel_x <= bx, I["k2"], I["k1"])).astype(np.int16)
        frow = np.zeros((H, W), bool)
        frow[1:, :] = face[1:, :] & ~face[:-1, :] & ~top[:-1, :]
        fc = np.where(face & ~np.roll(face, -1, 0), I["ink"], fc)
        fc = np.where(frow, I["m4"], fc)
        tw[face] = fc[face]
        # basin: soil and broken basin floor slabs (dry), darker toward the back wall of the basin
        sn = vnoise("basin-soil-v04", 3)
        bs = np.where(sn < 0.45, I["s1"], np.where(sn < 0.8, I["s2"], I["s0"])).astype(np.int16)
        bs = np.where((yy < fy - ay * 0.4) & basin, I["s0"], bs)
        slab = basin & (vnoise("basin-slab-v04", 6) > 0.7)
        bs = np.where(slab, I["m2"], bs)
        bs = np.where(slab & (vnoise("basin-slab2-v04", 2) > 0.6), I["m1"], bs)
        tw[basin] = bs[basin]
        # missing coping stone (front-right) and two cracks
        for j in range(0, 6):
            for i in range(0, 12):
                x_, y_ = fx + bx + 4 + i - j, fy + ay - 6 + j
                if 0 <= y_ < H and (coping[y_, x_] or face[y_, x_]):
                    tw[y_, x_] = I["s1"] if j < 3 else I["s0"]
        for (cx_, cy_, ln, d) in ((fx - ax + 8, fy - 6, 6, 1), (fx - 4, fy - ay + 1, 5, -1)):
            for t in range(ln):
                setpx(tw, cx_ + t * d, cy_ + t // 2, I["ink"])
        self.fountain_mask = top | face
        self.fixture_mask |= top | face
        # Y-sorted: pedestal (granite plinth, bronze jet column, nozzle broken off) and the self-sown tree
        fl = self.L["fountain-ysort"]
        pv = YSORT["fountain-ysort"]
        ped = ["...xxxxxxxxxx...",
               ".xxMMMMMMMMMMxx.",
               "xLMMMMMMMMMMMMDx",
               "xLLMMMMMMMMMMDDx",
               ".xxDDDDDDDDDDxx.",
               ".xFFFFFFFFFFFFx.",
               ".xFFFFFFFFFFGGx.",
               ".xFFFFFFFFFFGGx.",
               ".xFFFFFFFFFGGGx.",
               "..xxxxxxxxxxxx.."]
        stamp(fl, fx - 8, pv - len(ped) + 1, ped, {"x": "ink", "L": "m4", "M": "k3", "D": "k2", "F": "k2",
                                                    "G": "k1"})
        col = ["..x..", ".xBx.", "xBBbx", "xLBbx", "xLBbx", "xLBbx", "xxbxx", "xLBbx", "xLBbx", "xLBbx",
               "xLBbx", "xBBbx", "xxxxx"]
        col[0] = ".x.x."                                                 # nozzle snapped: two jagged prongs
        stamp(fl, fx - 2, pv - len(ped) - len(col) + 3, col, {"x": "ink", "L": "e4", "B": "e3", "b": "e2"})
        tx, ty = fx - 22, fy - 8                                         # self-sown tree, back-left of the basin
        before_tree = fl >= 0
        for j in range(26):
            x_ = tx + (j // 9)
            setpx(fl, x_, ty - j, I["s2"]); setpx(fl, x_ + 1, ty - j, I["s0"])
        for (bxo, byo, d) in ((0, -14, -1), (2, -20, 1)):
            for q in range(1, 6):
                setpx(fl, tx + bxo + d * q, ty + byo - q // 2, I["s1"])
        m, idx, (cx0, cy0) = self.canopy_raster(tx + 3, ty - 34, 14, ("fountain-tree",), ramp=ELM, squash=0.78,
                                                tex_cell=2)
        sub = fl[cy0:cy0 + m.shape[0], cx0:cx0 + m.shape[1]]
        sub[m] = idx[m]
        self.fountain_tree = (tx, ty)
        self.fountain_tree_mask = (fl >= 0) & ~before_tree
        self.prop_shadow.append(("shrub", tx + 4, ty + 2, 12))
        self.prop_shadow.append(("box", fx + 4, pv + 1, 12, 3))

    # ------------------------------------------------------------------ collapse (right) and slump (left)
    def collapse(self, tw):
        """Game fiction: one terrace bay right of the right stair has slumped outward. The deck edge is bitten back;
        the wall face is gone in a stepped notch showing the rubble core; the exposed fill is a cut bank of soil
        strata over the terrace's own granite rubble foundation; a lit talus spills onto the lawn. Every block,
        drum, cornice piece, baluster and rail on it is placed from the hand-written RUBBLE table."""
        x0, x1 = COLLAPSE
        rng = rng_for("collapse-v04")
        xs = np.arange(x0, x1 + 1)
        cxm = (x0 + x1) / 2 + 6
        half = (x1 - x0) / 2
        u = (xs - cxm) / half
        b = np.clip(1 - np.abs(u) ** 1.6, 0, 1)
        jag = (vnoise("breach-v04", 3, 1, W)[0, x0:x1 + 1] - 0.5) * 7
        lip = np.round(EDGE_Y - BAL_H + 1 - 20 * b ** 0.8 + jag * (b > 0.05)).astype(int)
        frac = np.clip((b - 0.12) / 0.55, 0, 1)
        jw = (vnoise("breachw-v04", 28, 1, W)[0, x0:x1 + 1] - 0.5) * 12
        lip_smooth = EDGE_Y - BAL_H + 1 - 20 * b ** 0.8
        wall_top = EDGE_Y + 2 + np.round((frac * (WALL_H + 6) + jw * (frac > 0)) / 8).astype(int) * 8
        wall_top = np.where(frac <= 0, EDGE_Y, wall_top)
        self.breach_top = {}
        wob = vnoise("strata-wob-v04", 16)
        grit = vnoise("strata-grit-v04", 2)
        stn = vnoise("strata-stones-v04", 4)
        turf = vnoise("strata-turf-v04", 7)
        g = self.L["ground-base"]
        strata = ((0.10, 2), (0.19, 4), (0.24, -1), (0.42, 3), (0.47, 4), (0.60, 3), (0.80, 2), (9.0, 1))
        breach = np.zeros((H, W), bool)
        cob_y0 = EDGE_Y - BAL_H - 12
        cob = cobble_texture("collapse-v04", cob_y0, FOOT_Y + 8, x0, x1 + 1)
        for i, x in enumerate(xs):
            if b[i] < 0.06:
                continue
            yl, yw = int(lip[i]), int(min(wall_top[i], FOOT_Y + 4))
            self.breach_top[int(x)] = yl
            for y in range(EDGE_Y - BAL_H - 8, max(yl, EDGE_Y - BAL_H - 8)):
                tw[y, x] = -1
            under = 3 + int(round(3 * b[i]))
            lat = u[i]
            for y in range(yl, yw):
                d = y - yl
                if d == 0:
                    c = I["m5"] if (x * 7) % 5 else I["m4"]
                elif d == 1:
                    c = I["m3"]
                elif d == 2:
                    c = I["m1"]
                elif d < under + 2:
                    c = I["ink"] if d < 5 else I["s0"]
                else:
                    zn = (y - (lip_smooth[i] + under + 2)) / 96.0 + (wob[y, x] - 0.5) * 0.08
                    k = next(s for lim, s in strata if zn < lim)
                    if k < 0:
                        c = I["m2"] if grit[y, x] > 0.55 else I["m1"] if grit[y, x] > 0.3 else I["s1"]
                    else:
                        ld = lat + (grit[y, x] - 0.5) * 0.22
                        if ld < -0.38:
                            k -= 1 if ld > -0.7 else 2
                        elif ld > 0.35:
                            k += 1
                        if zn < 0.1 and grit[y, x] > 0.72:
                            k -= 1
                        c = SOIL[max(1, min(5, k))]
                        if zn > 0.7 and turf[y, x] > 0.56:
                            c = I["g3"] if (lat > 0 and turf[y, x] > 0.66) else I["g2"]
                    if stn[y, x] > 0.8 and zn > 0.16:
                        c = I["m3"] if stn[y, x] > 0.87 else I["m2"]
                    if zn > 0.56 + (grit[y, x] - 0.5) * 0.06 + 0.04 * math.sin(x / 7.0):
                        c = int(cob[y - cob_y0, x - x0])
                        if lat < -0.62:
                            c = ramp_shift(c, STONE, -1)
                tw[y, x] = c
                breach[y, x] = True
            if wall_top[i] < FOOT_Y:
                wt = int(wall_top[i])
                for y in range(max(yl + under + 2, wt - 3), wt):
                    tw[y, x] = I["m1"] if grit[y, x] > 0.5 else I["s1"] if grit[y, x] > 0.25 else I["m2"]
                tw[wt, x] = I["m4"]
                tw[wt + 1, x] = I["m3"]
            for y in range(max(FACADE_Y1 + 2, yl - 5), yl):
                if g[y, x] in (I["m4"], I["m5"]):
                    g[y, x] = I["m3"]
        st = breach & np.isin(tw, [I["m2"], I["m3"]])
        pst = np.pad(st, 1)
        tw[st & ~pst[:-2, 1:-1]] = I["m4"]
        tw[st & ~pst[2:, 1:-1]] = I["m1"]
        for i in range(1, len(xs)):
            if b[i] < 0.06 or b[i - 1] < 0.06:
                continue
            ta, tb = int(min(wall_top[i - 1], FOOT_Y)), int(min(wall_top[i], FOOT_Y))
            if tb > ta:
                tw[ta:tb, xs[i - 1]] = I["m1"]; tw[ta:tb, xs[i - 1] - 1] = I["m2"]
            elif ta > tb:
                tw[tb:ta, xs[i]] = I["m5"]; tw[tb:ta, xs[i] + 1] = I["m4"]
        for _ in range(22):
            rx = int(rng.integers(x0 + 20, x1 - 20))
            if rx not in self.breach_top:
                continue
            ry = self.breach_top[rx] + 7
            for _ in range(int(rng.integers(5, 15))):
                if breach[ry, rx] and tw[ry, rx] in SOIL:
                    tw[ry, rx] = I["s0"]
                ry += 1
                rx += int(rng.integers(-1, 2))
        y0 = EDGE_Y - BAL_H
        il = int(np.argmax(b > 0.06)); ir = len(b) - 1 - int(np.argmax(b[::-1] > 0.06))
        xl, xr = x0 + il, x0 + ir
        tw[y0:y0 + 2, xl - 4:xl] = -1
        tw[y0 + 2, xl - 5:xl - 1] = I["m4"]
        tw[y0 + 2:y0 + 5, xl - 1] = I["m1"]
        tw[y0 + 5:y0 + 16, xl - 6:xl] = I["m1"]
        for t in range(14):
            px, py = int(round(xl - 3 + t * 0.6)), y0 + 4 + t
            belly = t in (4, 5, 6, 10, 11)
            for q, c in enumerate(("m4", "m3", "m3", "m1") if belly else ("m4", "m3", "m1")):
                setpx(tw, px + q - 1, py, I[c])
                self.piece_mask[py, px + q - 1] = True
        tw[y0:y0 + 5, xr + 1] = I["m5"]
        tw[y0, xr + 1:xr + 4] = I["m3"]
        tw[y0 + 5:y0 + 16, xr + 2:xr + 9] = I["m1"]
        tw[y0 + 13:y0 + 16, xr + 2:xr + 9] = I["m0"]
        tw[y0 + 13:y0 + 16, xr + 4:xr + 7] = I["m3"]
        for t in range(10):
            setpx(tw, xr + 9 + t // 4, y0 + 5 + t, I["m4"]); setpx(tw, xr + 10 + t // 4, y0 + 5 + t, I["m2"])
        # talus heightfield
        yy, xx = np.mgrid[0:H, 0:W]
        cy = FOOT_Y + 8
        e = ((xx - cxm) / 104.0) ** 2 + ((yy - cy) / 84.0) ** 2 + (vnoise("mound2-v04", 9) - 0.5) * 0.5
        hgt = (np.clip(1 - e, 0, None) ** 0.75 * 46 + vnoise("moundbump-v04", 6) * 4 + vnoise("moundbump2-v04", 15) * 8)
        mound = (e < 1) & (yy >= FOOT_Y - 6) & (tw < 0) & (xx > STAIRS[1][1] + CHEEK_W + 10)
        gy_, gx_ = np.gradient(hgt.astype(np.float32))
        Lv = np.array([-0.55, -0.62, 0.56]); Lv /= np.linalg.norm(Lv)
        nn = np.sqrt(gx_ ** 2 + gy_ ** 2 + 1)
        shv = (-gx_ * Lv[0] - gy_ * Lv[1] + Lv[2]) / nn + (vnoise("moundtex-v04", 2) - 0.5) * 0.06
        qs = np.quantile(shv[mound], [0.12, 0.36, 0.66, 0.9])
        bl_ = blade_noise("talus-v04")
        q = np.digitize(shv + (bl_ - 0.5) * 0.1, qs)
        soil_c = np.array([I["s0"], I["s1"], I["s2"], I["s3"], I["s4"]], np.int16)[q]
        turf_c = np.array([I["g1"], I["g2"], I["g3"], I["g4"], I["g5"]], np.int16)[q]
        is_turf = mound & ((e + (bl_ - 0.5) * 0.3 + (vnoise("moundturf-v04", 13) - 0.5) * 0.2) > 0.68)
        mt = np.where(is_turf, turf_c, soil_c)
        mt[mound & ~is_turf & (vnoise("moundgrit-v04", 2) > 0.8)] = I["m2"]
        tw[mound] = mt[mound]
        self.mound_mask = mound.copy()
        self.rubble = mound.copy()
        self.rubble_pieces(tw, RUBBLE + [("rail", xl + 6, 168, 20)])
        for (bx, by, w) in DECK_DEBRIS:
            self.block_3q(tw, bx, by, w, 5, 5, rng_for("deckdebris", bx), name="deck-debris")
            self.block[by + 2:by + 10, bx:bx + w] = True
        drum = ["....LLLLLLLLLLLLLLLLLLL...",
                "..LLMMMMMMMMMMMMMMMMMMMEE.",
                ".LMMMMMMMMMMMMMMMMMMMMEeeE",
                "LMMMNMMMNMMMNMMMNMMMNMEeeE",
                "MMMMMMMMMMMMMMMMMMMMMMEecE",
                "DMMDNMMDNMMDNMMDNMMDNDEeeE",
                "DDDDDDDDDDDDDDDDDDDDDDEeeE",
                ".DDDDDDDDDDDDDDDDDDDDDEeE.",
                "..kkkkkkkkkkkkkkkkkkkkkk.."]
        dx0, dy0 = DRUM_ON_DECK
        stamp(tw, dx0, dy0, drum, {"L": "m5", "M": "m4", "N": "m3", "D": "m2", "E": "m3", "e": "m4", "c": "m1",
                                   "k": "ink"})
        self.block[dy0 + 3:dy0 + 9, dx0:dx0 + 26] = True
        self.tall("deck-drum", tw, dx0, dy0, dx0 + 25, dy0 + 8, mask=stamp_mask(dx0, dy0, drum))
        self.prop_shadow.append(("block", dx0, dy0, 26, 5, 4))
        self.rubble |= (tw >= 0) & (yy >= FOOT_Y) & (xx >= x0 - 20) & (xx <= x1 + 40)
        self.block |= self.rubble

    def rubble_pieces(self, tw, table):
        """Place hand-listed pieces in painter's order (far rows first). Each piece gets its own seeded variation, a
        registered ground row (depth audit) and collision over its footprint."""
        order = sorted(range(len(table)), key=lambda k: table[k][2])
        for k in order:
            e = table[k]
            kind, x, y = e[0], int(e[1]), int(e[2])
            r = rng_for("rubble-v04", k, kind, x, y)
            keep_pm = self.piece_mask
            self.piece_mask = np.zeros((H, W), bool)
            if kind == "rock":
                self.rock_poly(tw, x, y, float(e[3]), r, fam=e[4])
            elif kind == "block":
                self.block_3q(tw, x, y, int(e[3]), int(e[4]), int(e[5]), r, tilt=int(e[6]), name=None)
            elif kind == "pier":
                self.block_3q(tw, x, y, int(e[3]), int(e[4]), int(e[5]), r, cap=True, top_c=I["m4"], name=None)
            elif kind == "drum":
                self.drum_piece(tw, x, y, int(e[3]), r)
            elif kind == "cornice":
                self.cornice_piece(tw, x, y, int(e[3]), r)
            elif kind == "baluster":
                self.baluster_piece(tw, x, y, r)
            elif kind == "rail":
                self.fallen_rail(tw, x, y, int(e[3]))
            new = self.piece_mask & (tw >= 0)
            self.piece_mask = keep_pm | new
            ys, xs_ = np.nonzero(new)
            if len(ys):
                x0_, x1_, y0_, y1_ = xs_.min(), xs_.max(), ys.min(), ys.max()
                self.tall(("rubble", k, kind), tw, x0_, y0_, x1_, y1_, mask=new)
                self.block[y0_:y1_ + 1, x0_:x1_ + 1] = True

    def slump(self, tw):
        """Game fiction, left side: a smaller slump of one balustrade bay (SLUMP). The rail sags and has snapped
        (drawn by balustrade()), the wall face below has bulged: a stepped crack, three facing stones fallen out
        exposing the rubble core, and a small talus with a fallen urn rolled onto the lawn."""
        a, b = SLUMP
        cob = cobble_texture("slump-v04", EDGE_Y, FOOT_Y, a, b + 1)
        for (sx, sy, sw, sh) in ((a + 14, EDGE_Y + 18, 14, 9), (a + 30, EDGE_Y + 34, 12, 10), (a + 22, EDGE_Y + 50, 16, 9)):
            for yv in range(sy, sy + sh):
                for xv in range(sx, sx + sw):
                    tw[yv, xv] = cob[yv - EDGE_Y, xv - a]
            tw[sy, sx:sx + sw] = I["ink"]
            tw[sy:sy + sh, sx] = I["m0"]
            tw[sy + sh, sx:sx + sw] = I["m4"]
        cx, cy = a + 44, EDGE_Y + 3
        while cy < FOOT_Y - 2:
            tw[cy, cx] = I["ink"]
            if tw[cy, cx + 1] not in (I["ink"],):
                tw[cy, cx + 1] = ramp_shift(tw[cy, cx + 1], STONE, 1)
            cy += 1
            if (cy - EDGE_Y) % 8 == 2:
                cx += -3 if (cy // 8) % 2 else 2
        bulge = np.zeros((H, W), bool)
        bulge[EDGE_Y + 10:FOOT_Y - 8, a + 8:b - 8] = True
        dn = vnoise("slump-damp", 4) > 0.42
        tw[bulge & dn & (tw >= 0)] = ramp_shift_arr(tw, STONE, -1)[bulge & dn & (tw >= 0)]
        self.rubble_pieces(tw, SLUMP_RUBBLE)

    def fallen_rail(self, tw, x, y, n):
        """A length of the balustrade's top rail lying on its side, a few balusters still attached."""
        for i in range(n):
            tw[y, x + i] = I["m5"]
            tw[y + 1, x + i] = I["m4"]
            tw[y + 2, x + i] = I["m3"]
            tw[y + 3, x + i] = I["m1"]
        tw[y:y + 4, x + n - 1] = I["m1"]
        tw[y:y + 3, x] = I["m4"]
        self.piece_mask[y:y + 4, x:x + n] = True
        for i in range(2, n - 2, 7):
            if (i // 7) % 3 == 1:
                continue
            stamp(tw, x + i, y + 4, ["LMD", "LMD", ".M.", "LMD", "DDD"], {"L": "m4", "M": "m3", "D": "m1"})
            self.piece_mask[y + 4:y + 9, x + i:x + i + 3] = True
        self.prop_shadow.append(("block", x, y, n, 4, 5))

    def block_3q(self, layer, x, y, w, d, h, rng, cap=False, tilt=0, top_c=None, name=None):
        """A tumbled ashlar block in 3/4: lit top face with a bright leading arris, darker front face shading down to
        an ink contact row, a shaded right edge and chipped corners. `tilt` shears the top face by up to 2 px."""
        fam = {I["m4"]: ("m5", "m3", "m2"), I["m3"]: ("m4", "m2", "m1"), I["m2"]: ("m3", "m1", "m0"),
               I["p3"]: ("m4", "p1", "p0"), I["p2"]: ("p3", "p1", "p0")}
        top = top_c if top_c is not None else [I["m4"], I["m3"], I["m4"], I["m3"], I["m2"], I["p3"], I["p2"],
                                               I["m4"]][int(rng.integers(0, 8))]
        lit, face, face_lo = (I[n] for n in fam[top])
        before = layer >= 0 if name else None
        for j in range(d + h):
            sh = int(round(tilt * (1 - j / max(1, d)))) if j < d else 0
            for i in range(w):
                px, py = x + i + sh, y + j
                if not (0 <= px < W and 0 <= py < H):
                    continue
                corner = (i == 0 or i == w - 1) and (j == 0 or j == d + h - 1)
                if corner and rng.random() < 0.8:
                    continue
                if j < d:
                    c = lit if (j == 0 or i == 0) else top
                    if i >= w - 2:
                        c = face
                    if cap and j == d - 1:
                        c = face
                else:
                    c = face if j < d + h // 2 else face_lo
                    if j == d + h - 1:
                        c = I["ink"]
                    if i >= w - 2 and j < d + h - 1:
                        c = ramp_shift(face_lo, STONE, -1)
                layer[py, px] = c
                self.piece_mask[py, px] = True
        if w > 12 and rng.random() < 0.5:
            cx = x + int(rng.integers(3, w - 3))
            for j in range(1, d):
                setpx(layer, cx + (j // 2), y + j, face)
        if w > 10 and rng.random() < 0.4:
            cx = x + int(rng.integers(2, w - 4))
            for i in range(int(rng.integers(2, 4))):
                setpx(layer, cx + i, y + d, face_lo); setpx(layer, cx + i, y + d - 1, face)
        if w > 14 and d > 4 and rng.random() < 0.45:
            sx, sy = x + int(rng.integers(2, w - 5)), y + int(rng.integers(1, d - 2))
            c = I["g2"] if rng.random() < 0.5 else face
            for (i, j) in ((0, 0), (1, 0), (2, 0), (1, 1), (2, 1)):
                setpx(layer, sx + i, sy + j, c)
        if name:
            self.tall_new((name, x, y), layer, before)
        self.prop_shadow.append(("block", x, y, w, d, h))

    def rock_poly(self, layer, cx, cy, size, rng, fam=None):
        """A broken, faceted chunk seen in 3/4: an irregular convex top facet extruded into side facets; marble
        (white / grey) or granite (blue-grey). fam is hand-assigned in the rubble tables."""
        n = int(rng.integers(5, 8))
        ang = np.sort(rng.uniform(0, 2 * math.pi, n))
        rx, ry = size * float(rng.uniform(0.85, 1.25)), size * float(rng.uniform(0.45, 0.65))
        rot = float(rng.uniform(-0.5, 0.5))
        rad = rng.uniform(0.72, 1.08, n)
        px_ = cx + rad * rx * np.cos(ang) * math.cos(rot) - rad * ry * np.sin(ang) * math.sin(rot)
        py_ = cy + rad * rx * np.cos(ang) * math.sin(rot) + rad * ry * np.sin(ang) * math.cos(rot)
        hgt = max(2, int(round(size * float(rng.uniform(0.45, 0.8)))))
        fam = fam or rng.choice(["marble", "marble", "grey", "granite"])
        top_c, lit_c, face_c, low_c = {"marble": ("m4", "m5", "m3", "m2"), "grey": ("m3", "m4", "m2", "m1"),
                                       "granite": ("k2", "k3", "m1", "m0")}[fam]
        x0, x1 = int(px_.min()) - 1, int(px_.max()) + 2
        y0, y1 = int(py_.min()) - 1, int(py_.max()) + hgt + 2
        if x1 <= 0 or y1 <= 0 or x0 >= W or y0 >= H:
            return
        Y, X = np.mgrid[y0:y1, x0:x1]
        inside = np.ones(X.shape, bool)
        cxp, cyp = px_.mean(), py_.mean()
        for k in range(n):
            ax, ay, bx, by = px_[k], py_[k], px_[(k + 1) % n], py_[(k + 1) % n]
            sgn = np.sign((bx - ax) * (cyp - ay) - (by - ay) * (cxp - ax))
            inside &= np.sign((bx - ax) * (Y + 0.5 - ay) - (by - ay) * (X + 0.5 - ax)) * sgn >= 0
        ext = inside.copy()
        for k in range(1, hgt + 1):
            ext[k:] |= inside[:-k]
        side = ext & ~inside
        out = np.full(X.shape, -1, np.int16)
        out[inside] = I[top_c]
        lo = inside & ((X - cxp) * 0.6 + (Y - cyp) > size * 0.18)
        out[lo] = I[face_c] if fam != "granite" else I["k1"]
        pi_ = np.pad(inside, 1)
        arris = inside & (~pi_[:-2, 1:-1] | ~pi_[1:-1, :-2])
        out[arris & (X - cxp < size * 0.4)] = I[lit_c]
        out[side] = np.where(X[side] < cxp - size * 0.15, I[face_c], I[low_c])
        for k in range(n):
            vx, vy = int(round(px_[k])), int(round(py_[k]))
            if vy > cyp:
                for j in range(1, hgt):
                    yy_, xx_ = vy + j - y0, vx - x0
                    if 0 <= yy_ < out.shape[0] and 0 <= xx_ < out.shape[1] and side[yy_, xx_]:
                        out[yy_, xx_] = I["m0"] if fam != "granite" else I["ink"]
        pe = np.pad(ext, 1)
        contact = ext & ~pe[2:, 1:-1]
        out[contact] = I["ink"]
        if size > 5 and rng.random() < 0.5:
            sy_, sx_ = int(cyp) - y0, int(cxp) - x0 - 2
            for (i, j) in ((0, 0), (1, 0), (2, 0), (1, 1), (2, 1), (3, 1)):
                if 0 <= sy_ + j < out.shape[0] and 0 <= sx_ + i < out.shape[1] and inside[sy_ + j, sx_ + i]:
                    out[sy_ + j, sx_ + i] = I["g3"] if fam != "granite" else I["g2"]
        ok = out >= 0
        ys_, xs_ = np.nonzero(ok)
        for yy_, xx_ in zip(ys_, xs_):
            gy, gx = yy_ + y0, xx_ + x0
            if 0 <= gy < H and 0 <= gx < W:
                layer[gy, gx] = out[yy_, xx_]
                self.piece_mask[gy, gx] = True
        self.prop_shadow.append(("block", int(px_.min()), int(py_.min()), int(px_.max() - px_.min()) + 1,
                                 int(py_.max() - py_.min()) + 1, hgt))

    def drum_piece(self, layer, x, y, ln, rng):
        """A fallen fluted column drum lying across the slope: flutes read as long bands lit from the top, the
        sawn end faces the light on the left with its bedding circle, ink contact line underneath."""
        bands = ("m4", "m5", "m4", "m5", "m3", "m4", "m3", "m2", "m1")
        if rng.random() < 0.4:
            bands = ("m3", "m4", "m3", "m4", "m2", "m3", "m2", "m1", "m0")
        for j, c in enumerate(bands):
            for i in range(ln):
                if j in (0, 8) and (i < 2 or i >= ln - 2):
                    continue
                if j in (1, 7) and (i < 1 or i >= ln - 1):
                    continue
                setpx(layer, x + i, y + j, I[c])
                self.piece_mask[min(H - 1, y + j), min(W - 1, max(0, x + i))] = True
        end = ("..L.", ".LLM", "LLMM", "LMNM", "LMNM", "LMNM", "LLMM", ".LMD", "..D.")  # sawn end, left
        stamp(layer, x - 2, y, end, {"L": "m5", "M": "m4", "N": "m3", "D": "m2"})
        for i in range(2, ln - 1):
            setpx(layer, x + i, y + 9, I["ink"])
        if rng.random() < 0.5:                                  # broken right end: jagged dark fracture
            for j in range(1, 8):
                setpx(layer, x + ln - 1 - (j % 3), y + j, I["m1"])
        self.prop_shadow.append(("block", x, y, ln, 5, 4))

    def cornice_piece(self, layer, x, y, w, rng):
        """A fallen cornice fragment: lit top bed, then the classical profile on its front face (fillet, shadow,
        a dentil course, ovolo, fascia) ending in an ink contact row. Ends are broken, not square."""
        prof = ("m5", "m4", "m4", "m3", "m5", "m1", "dent", "m0", "m4", "m3", "m2", "ink")
        for j, c in enumerate(prof):
            for i in range(w):
                lo = 2 if j < 4 else 0
                if i < lo + (j * 3 + int(x)) % 2 or i > w - 1 - (j * 5 + int(y)) % 3:
                    continue
                if c == "dent":
                    cc = I["m4"] if (i // 2) % 2 == 0 else I["ink"]
                else:
                    cc = I[c]
                if i >= w - 3 and j < 4:
                    cc = I["m3"]
                setpx(layer, x + i, y + j, cc)
                self.piece_mask[min(H - 1, y + j), min(W - 1, max(0, x + i))] = True
        if w > 22:                                              # moss in the dentil recesses
            for i in range(3, w - 4, 7):
                setpx(layer, x + i, y + 7, I["g2"])
        self.prop_shadow.append(("block", x, y, w, 4, 8))

    def baluster_piece(self, layer, x, y, rng):
        """A fallen baluster: short lathe-turned cylinder lying on its side."""
        rows = ["..LLLL....", ".LMMMMLLL.", "LMMMMMMMMD", "DMMMMMMMMD", ".DDDMMDDD.", "..kkk.kkk."]
        cm = {"L": "m5", "M": "m4", "D": "m2", "k": "ink"}
        if rng.random() < 0.5:
            rows = [r[::-1] for r in rows]
        stamp(layer, x - 5, y, rows, cm)
        self.piece_mask[y:y + 6, max(0, x - 5):x + 5] = True
        self.prop_shadow.append(("block", x - 5, y, 10, 2, 4))

    # ------------------------------------------------------------------ ground-detail
    def detail(self):
        d = self.L["ground-detail"]
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls"])
        rng = rng_for("tufts-v04")
        walk = self.walk_mask
        tw = self.L["terrace-walls"]
        yy = np.arange(H)[:, None]
        lawn = ~walk & (yy >= FOOT_Y) & (tw < 0)
        self.lawn = lawn
        # 1) tufts massed into patches (sward between them stays calm)
        clump = vnoise("tuftclump-v04", 24) * 0.8 + vnoise("tuftclump2-v04", 7) * 0.2
        dens = 0.02 + 0.7 * np.clip((clump - 0.42) / 0.4, 0, 1) ** 1.4 + 0.06 * np.clip((yy - 400) / 300.0, 0, 1)
        near_walk = np.zeros((H, W), bool)
        wm = walk.copy()
        for k in range(1, 9):
            near_walk[k:, :] |= wm[:-k, :]; near_walk[:-k, :] |= wm[k:, :]
            near_walk[:, k:] |= wm[:, :-k]; near_walk[:, :-k] |= wm[:, k:]
        near_walk &= ~walk
        self.near_walk = near_walk
        meadow = self.meadow & lawn
        for gy in range(FOOT_Y, H, 5):
            for gx in range(0, W, 6):
                x = gx + int(rng.integers(0, 5)); y = gy + int(rng.integers(0, 4))
                if not (0 <= x < W and 0 <= y < H) or not lawn[y, x]:
                    continue
                p = dens[y, x] + (0.35 if near_walk[y, x] else 0) + (0.2 if self.belt[y, x] else 0) + \
                    (0.4 if meadow[y, x] else 0)
                if self.mown[y, x]:
                    p *= 0.12
                if rng.random() > p:
                    continue
                tall = (near_walk[y, x] or meadow[y, x]) and rng.random() < 0.6
                t = TALL_TUFTS[int(rng.integers(len(TALL_TUFTS)))] if tall else TUFTS[int(rng.integers(len(TUFTS)))]
                base = comp[y, x]
                if base not in GR:
                    base = I["g3"] if base not in (I["d0"], I["d1"]) else I["g4"]
                stamp(d, x, y, t, TUFT_MAP, under=int(base), ramp=GR)
                if tall and meadow[y, x] and rng.random() < 0.35:
                    setpx(d, x + 1, y - 1, I["d1"]); setpx(d, x + 1, y, I["g6"])
        # deck: weeds along the balustrade's inner foot and the facade plinth, moss in hand-placed joint patches
        deck_lo = EDGE_Y - BAL_H - 3
        for x in range(2, W - 6, 6):
            if rng.random() < 0.38 and tw[deck_lo, x] < 0 and walk[deck_lo, x] is not None:
                stamp(d, x, deck_lo - int(rng.integers(0, 3)), TUFTS[int(rng.integers(len(TUFTS)))], TUFT_MAP,
                      under=I["g3"], ramp=GR)
        for x in range(2, W - 6, 9):
            yb = (PAV_Y1 if PAV[0] - 4 <= x <= PAV[1] + 4 else SUBP_Y1 if any(a_ - 1 <= x <= b_ + 1 for a_, b_ in SUBP)
                  else FACADE_Y1) + 1
            if rng.random() < 0.3 and tw[yb, x] < 0:
                stamp(d, x, yb, TUFTS[int(rng.integers(len(TUFTS)))], TUFT_MAP, under=I["g3"], ramp=GR)
        gb = self.L["ground-base"]
        for (mx, my, mr) in DECK_MOSS:
            for j in range(-mr, mr + 1):
                for i in range(-mr * 2, mr * 2 + 1):
                    y_, x_ = my + j, mx + i
                    if (i / (2.0 * mr)) ** 2 + (j / float(mr)) ** 2 < 1 and gb[y_, x_] == I["m1"] and tw[y_, x_] < 0:
                        d[y_, x_] = I["g2"] if (i + j) % 3 else I["g3"]
        # 2) grass encroaching over walk edges
        edge = np.zeros((H, W), bool)
        for k in (1, 2, 3):
            edge[k:, :] |= lawn[:-k, :]; edge[:-k, :] |= lawn[k:, :]
            edge[:, k:] |= lawn[:, :-k]; edge[:, :-k] |= lawn[:, k:]
        edge &= walk
        ov = edge & (vnoise("overhang-v04", 3) > 0.42)
        d[ov] = np.where(vnoise("ovtone-v04", 2)[ov] > 0.5, I["g3"], I["g2"])
        d[:] = despeckle(d, 1, valid=edge)
        self.meadow_edges(d, lawn)
        self.verge(d, rng, lawn)
        self.lawn_features(d, rng, lawn)
        # 3) the overgrown centre: recess floor reclaimed by grass from the walls inward, shrubs at the exedra foot,
        # ivy curtains down the curved wall, a planted-out dry basin
        self.recess_overgrowth(d, comp)
        # 4) shrubs along the wall-foot strips and in the tree belts
        skip = [(sx0 - CHEEK_W - 6, sx1 + CHEEK_W + 6) for sx0, sx1 in STAIRS] + \
               [(EXEDRA[0], EXEDRA[1]), (COLLAPSE[0] - 8, COLLAPSE[1] + 10), (SLUMP[0] - 6, SLUMP[1] + 30)]
        for x in range(4, W, 22):
            if any(a <= x <= b for a, b in skip):
                continue
            if rng.random() < 0.72:
                self.shrub(d, x + int(rng.integers(-4, 5)), FOOT_Y + 6 + int(rng.integers(0, 4)),
                           int(rng.integers(7, 12)), ("wallshrub-v04", x), ramp=BOX if x % 3 else None)
        bp = np.pad(self.belt, 20)
        margin = self.belt & ~(bp[40:, 20:-20] & bp[:-40, 20:-20] & bp[20:-20, 40:] & bp[20:-20, :-40])
        for k in range(200):
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 30, H))
            if margin[y, x] and not walk[y, x]:
                self.shrub(d, x, y, int(rng.integers(6, 13)), ("beltshrub-v04", k), ramp=(FOL, BOX, CON)[k % 3])
        for k, (x, y, r) in enumerate(RUBBLE_SHRUBS):
            self.shrub(d, x, y, r, ("rubbleshrub-v04", k), ramp=GR[:7])
        # 5) leaf litter and fallen branches
        self.litter(d, rng, lawn)
        # 6) moss on rubble top faces and weeds at the foot of tumbled blocks
        rub = self.piece_mask & (tw >= 0)
        tops = rub & np.isin(tw, [I["m4"], I["m3"]])
        mo = tops & (vnoise("rubmoss-v04", 3) > 0.74)
        d[mo] = np.where(vnoise("rubmoss2-v04", 2)[mo] > 0.5, I["g3"], I["g4"])
        stone = rub & np.isin(tw, [I["m1"], I["m0"], I["ink"]])
        foot = stone & ~np.roll(stone, -1, axis=0)
        fy, fx = np.nonzero(foot)
        for i in range(0, len(fy), 9):
            if rng.random() < 0.6 and fy[i] >= FOOT_Y:
                stamp(d, int(fx[i]) - 2, int(fy[i]) - 2, TUFTS[int(rng.integers(len(TUFTS)))], TUFT_MAP,
                      under=I["g3"], ramp=GR)
        # 7) vines and ivy per balustrade bay condition; collapse and slump edges; hand-placed facade vines
        y0 = EDGE_Y - BAL_H
        for (a, b, state, key) in self.bay_list():
            if state == "breach":
                continue
            pr = {"ivy": 0.95, "mossy": 0.55, "clean": 0.08, "replaced": 0.18, "missing": 0.45,
                  "slump": 0.7}.get(state, 0.3)
            for x in range(max(2, a + 8), min(W - 2, b - 7), 4 if state == "ivy" else 5):
                if rng.random() > pr:
                    continue
                if state == "ivy":
                    self.vine(d, x, y0 + int(rng.integers(-2, 6)), int(30 + rng.integers(0, 44)), rng, dense=True)
                else:
                    self.vine(d, x, EDGE_Y - 6, int(8 + rng.integers(0, 40)), rng)
            if state == "ivy":
                ivn = vnoise(("ivymass-v04", key), 3, 1, W)[0]
                for x in range(max(0, a + 10), min(W, b - 9)):
                    for y in range(y0 - 3, y0 + 9):
                        v = ivn[x] * 10 - (y - y0 + 3) * 0.6
                        if v > 4.2 and (x + 2 * y) % 3:
                            d[y, x] = I["g4"] if (x + y) % 4 == 0 else I["g3"] if (x * 3 + y) % 5 else I["g2"]
        for x in range(COLLAPSE[0] + 10, COLLAPSE[1] - 10, 9):
            yt = self.breach_top.get(x, EDGE_Y)
            self.vine(d, x, yt, int(rng.integers(6, 24)), rng)
        for (x, ln, dense) in FACADE_VINES:
            self.vine(d, x, 0, ln, rng, dense=dense, stop=FACADE_Y1 - 4)
        # left stair: ivy over the outer cheek wall and grass along the landing edge (the intact, greener stair)
        sx0 = STAIRS[0][0]
        for x in range(sx0 - CHEEK_W, sx0, 3):
            self.vine(d, x, EDGE_Y - BAL_H - 4, int(rng.integers(30, 90)), rng, dense=True, stop=STAIR_BOT - 24)
        for x in range(sx0 + 4, STAIRS[0][1] - 4, 7):
            if rng.random() < 0.6:
                stamp(d, x, LANDING[1] - 3, TUFTS[int(rng.integers(len(TUFTS)))], TUFT_MAP, under=I["g3"], ramp=GR)
        # 8) cracks on the deck and walks; chips near the rubble
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls", "ground-detail"])
        for k in range(46):
            if k < 18:
                x = int(rng.integers(20, W - 20)); y = int(rng.integers(PAV_Y1 + 4, EDGE_Y - BAL_H - 4))
                if tw[y, x] >= 0:
                    continue
            else:
                x = int(rng.integers(0, W)); y = int(rng.integers(FORE[1], H))
                if not walk[y, x]:
                    continue
            self.crack(d, comp, x, y, int(rng.integers(8, 26)), rng)
        for k in range(120):
            x = int(rng.integers(0, W)); y = int(rng.integers(FACADE_Y1, H))
            near_rubble = abs(x - 1040) < 150 and FOOT_Y - 90 < y < 360
            if not (walk[y, x] or near_rubble) or rng.random() < 0.4 and not near_rubble:
                continue
            if tw[y, x] >= 0 and not near_rubble:
                continue
            c = I["m4"] if rng.random() < 0.5 else I["m3"]
            setpx(d, x, y, c); setpx(d, x + 1, y, I["m2"]); setpx(d, x, y + 1, I["m1"])
        # 9) survey paint (hand-placed): grid ticks on the forecourt, arrows toward the post and the collapse
        for (x, y) in SURVEY_TICKS:
            d[y, x:x + 5] = I["o1"]; d[y - 2:y + 3, x + 2] = I["o1"]
        for (x, y, dirn) in SURVEY_ARROWS:
            spr = ["..o..", ".ooo.", "o.o.o", "..o..", "..o.."] if dirn == "up" else \
                  ["..o..", ".o...", "ooooo", ".o...", "..o.."] if dirn == "left" else \
                  ["..o..", "...o.", "ooooo", "...o.", "..o.."]
            stamp(d, x - 2, y, spr, {"o": "o1"})
        # survey transect: an orange string line pegged every 36 px from the post across the axis to the fountain
        # side of the right panel (ground-level decal, never blocks walking), small orange peg tags
        (ax_, ay_), (bx_, by_) = TRANSECT
        n = int(max(abs(bx_ - ax_), abs(by_ - ay_)))
        for t in range(n + 1):
            x = int(round(ax_ + (bx_ - ax_) * t / n)); y = int(round(ay_ + (by_ - ay_) * t / n))
            setpx(d, x, y, I["o1"] if t % 6 else I["o2"])
            if t % 36 == 0:
                for (i, j, c) in ((0, -1, "o2"), (1, -1, "o1"), (0, -2, "o1"), (0, 1, "s0")):
                    setpx(d, x + i, y + j, I[c])
        # cables: post -> its instruments; relay box -> the collapse strain sensors
        for (a, b) in CABLES:
            n = int(max(abs(b[0] - a[0]), abs(b[1] - a[1])))
            for t in range(n):
                x = int(a[0] + (b[0] - a[0]) * t / n + 2 * math.sin(t / 9))
                y = int(a[1] + (b[1] - a[1]) * t / n)
                setpx(d, x, y, I["k0"])
                if t % 5 == 0:
                    setpx(d, x, y - 1, I["k1"])

    def recess_overgrowth(self, d, comp):
        """The overgrown centre between the stairs. Grass and moss take the recess paving joints from the curved
        wall and the stair cheeks inward (density falls off toward the forecourt), shrubs crowd the exedra foot,
        ivy curtains hang down the wall's shaded left half, and the dry basin is planted out with box, grasses and
        a flowering weed. All placements in EXEDRA_SHRUBS / BASIN_PLANTS are hand-written."""
        e0, e1 = EXEDRA
        rng = rng_for("recess-v04")
        yy, xx = np.mgrid[0:H, 0:W]
        floor = np.zeros((H, W), bool)
        for x in range(e0, e1 + 1):
            floor[self.floor_y[x]:FORE[1], x] = True
        floor &= ~self.fountain_mask
        wall_d = np.full((H, W), 999.0, np.float32)
        for x in range(e0, e1 + 1):
            wall_d[:, x] = yy[:, x] - self.floor_y[x]
        cheek_d = np.minimum(np.abs(xx - e0), np.abs(xx - e1)).astype(np.float32)
        dist = np.minimum(wall_d, cheek_d)
        fd = np.hypot((xx - FOUNTAIN[0]) / 1.6, (yy - FOUNTAIN[1]) * 1.2)
        dens = np.clip(1 - dist / 46.0, 0, 1) * 0.85 + np.clip(1 - (fd - 50) / 26.0, 0, 1) * 0.5
        joints = floor & np.isin(comp, [I["p0"], I["s1"], I["s2"]])
        gn = vnoise("recess-grass-v04", 3)
        g = joints & (gn < dens)
        d[g] = np.where(gn[g] < dens[g] * 0.5, I["g2"], I["g3"])
        ys, xs = np.nonzero(floor)
        for k in rng.permutation(len(ys))[: len(ys) // 190]:
            y, x = int(ys[k]), int(xs[k])
            if rng.random() < dens[y, x]:
                stamp(d, x - 2, y - 3, TALL_TUFTS[int(rng.integers(len(TALL_TUFTS)))] if dens[y, x] > 0.6
                      else TUFTS[int(rng.integers(len(TUFTS)))], TUFT_MAP, under=I["g3"], ramp=GR)
        for k, (x, y, r, ramp) in enumerate(EXEDRA_SHRUBS):
            self.shrub(d, x, y, r, ("exedrashrub-v04", k), ramp={"box": BOX, "elm": ELM, "fol": FOL}[ramp])
        cxm = (e0 + e1) / 2.0
        for x in range(e0 + 6, int(cxm) - 18, 3):                       # shaded left half: heavy ivy
            if rng.random() < 0.8:
                self.vine(d, x, self.rim[x] - BAL_H + int(rng.integers(0, 8)), int(rng.integers(26, 70)), rng,
                          dense=True, stop=self.floor_y[x])
        for x in range(int(cxm) + 30, e1 - 6, 7):                       # lit right half: a few strands
            if rng.random() < 0.45:
                self.vine(d, x, self.rim[x] - 4, int(rng.integers(10, 34)), rng, stop=self.floor_y[x])
        for k, (x, y, r, kind) in enumerate(BASIN_PLANTS):
            if kind == "box":
                self.shrub(d, x, y, r, ("basin-v04", k), ramp=BOX)
            elif kind == "grass":
                for q in range(r):
                    stamp(d, x + int(rng.integers(-6, 7)), y + int(rng.integers(-3, 3)),
                          TALL_TUFTS[int(rng.integers(len(TALL_TUFTS)))], TUFT_MAP, under=I["g3"], ramp=GR)
            elif kind == "flower":
                for q in range(r):
                    fx, fy = x + int(rng.integers(-7, 8)), y + int(rng.integers(-3, 4))
                    setpx(d, fx, fy, I["y0"]); setpx(d, fx + 1, fy, I["o2"]); setpx(d, fx, fy + 1, I["g2"])
        cop = self.fountain_mask & (self.L["terrace-walls"] >= 0) & (vnoise("copmoss-v04", 3) > 0.7) & \
            (yy < FOUNTAIN[1])
        d[cop] = I["g2"]
        # radial cracks across the recess floor from the basin (settlement round the heavy coping)
        for ang in (2.6, 3.3, 0.2, 0.8, 1.9):
            x, y = FOUNTAIN[0] + math.cos(ang) * 52, FOUNTAIN[1] + math.sin(ang) * 28
            for t in range(int(rng.integers(12, 26))):
                xi, yi = int(round(x)), int(round(y))
                if 0 <= yi < H and 0 <= xi < W and floor[yi, xi]:
                    d[yi, xi] = ramp_shift(comp[yi, xi], PAVE, -2) if comp[yi, xi] in PAVE else I["p0"]
                ang += float(rng.normal(0, 0.3))
                x += math.cos(ang); y += math.sin(ang) * 0.6

    def meadow_edges(self, d, lawn):
        """Give the rough drifts height. Along a drift's lower (south) edge the blade fronts face away from the
        upper-left light and drop a short shadow onto the short grass; along its upper edge lit tips stand up.
        Seed heads sit on top in small clusters, not single texels."""
        m = self.meadow & lawn
        pm = np.pad(m, 1)
        south = m & ~pm[2:, 1:-1]
        north = m & ~pm[:-2, 1:-1]
        ys, xs = np.nonzero(south)
        for y, x in zip(ys.tolist(), xs.tolist()):
            if (x + y // 3) % 4 == 3:                                   # gaps between blade clumps
                continue
            h = 2 + ((x * 7 + y * 3) % 5 > 2) + ((x * 13) % 7 == 0)     # 2..4 rows
            d[y, x] = I["g3"]
            for j in range(h):
                yj = y + 1 + j
                if yj >= H or not lawn[yj, x] or self.walk_mask[yj, x]:
                    break
                d[yj, x] = I["g2"] if j < h - 1 else I["g1"]
        ys, xs = np.nonzero(north)
        for y, x in zip(ys.tolist(), xs.tolist()):
            if (x * 5 + y) % 4 == 0:
                continue
            d[y, x] = I["g5"]
            if (x * 3) % 4 == 1 and y > 0 and lawn[y - 1, x]:
                d[y - 1, x] = I["g6"]
        r = rng_for("seeds")
        ys, xs = np.nonzero(m)
        for k in r.choice(len(ys), size=len(ys) // 90, replace=False):
            y, x = int(ys[k]), int(xs[k])
            setpx(d, x, y, I["d1"]); setpx(d, x + 1, y, I["g7"]); setpx(d, x, y + 1, I["g3"])

    def verge(self, d, rng, lawn):
        """Purposeful planting where people walk: clipped box and ferns on the belt side of the curved walks,
        perennials and small beds on the lawn side, low drifts along both edges of the axial walk (kept clear)."""
        curves = [(self.lc, WALK_W / 2, "L"), (self.rc, WALK_W / 2, "R"), (self.bc, BRANCH_W / 2, "B")]
        self.verge_items = []
        for c, hw, key in curves:
            tang = np.gradient(c, axis=0)
            tang /= np.linalg.norm(tang, axis=1, keepdims=True)
            nrm = np.stack([-tang[:, 1], tang[:, 0]], 1)
            seg = np.r_[0, np.cumsum(np.hypot(*np.diff(c, axis=0).T))]
            s = float(rng.uniform(4, 16))
            while s < seg[-1]:
                k = int(np.searchsorted(seg, s))
                s += float(rng.uniform(13, 30))
                if k >= len(c):
                    break
                p = c[k]
                if p[1] < FORE[3] + 6 or p[1] > H + 6:
                    continue
                for side in (-1, 1):
                    q = p + nrm[k] * side * (hw + 12)
                    qx, qy = int(q[0]), int(q[1])
                    if not (2 <= qx < W - 2 and FOOT_Y + 8 <= qy < H - 2):
                        continue
                    outer = bool(self.belt[qy, qx])
                    if rng.random() > (0.82 if outer else 0.4):
                        continue
                    if outer:
                        kind = ("box", "box", "fern", "bed", "shrub")[int(rng.integers(0, 5))]
                    else:
                        kind = ("perennial", "perennial", "boxsmall", "bed")[int(rng.integers(0, 4))]
                    r = {"box": 8, "shrub": 10, "fern": 6, "bed": 7, "perennial": 5, "boxsmall": 5}[kind]
                    r += int(rng.integers(-1, 3))
                    off = hw + r * 0.75 + 4
                    q = p + nrm[k] * side * off
                    qx, qy = int(q[0]), int(q[1])
                    if not (0 <= qx < W and 0 <= qy < H) or self.walk_mask[qy, qx]:
                        continue
                    self.verge_item(d, kind, qx, qy, r, rng, (key, int(s), side))
        # axial walk: low drifts 8+ px off each curb, never on the walk
        y = FORE[3] + 14
        while y < H - 6:
            y += int(rng.integers(16, 34))
            for side in (-1, 1):
                if rng.random() > 0.5:
                    continue
                x = AXIS[0] - 9 - int(rng.integers(0, 10)) if side < 0 else AXIS[1] + 9 + int(rng.integers(0, 10))
                if 0 <= y < H and lawn[y, x]:
                    kind = ("perennial", "bed", "perennial", "clover")[int(rng.integers(0, 4))]
                    self.verge_item(d, kind, x, y, 4, rng, ("axis", y, side))

    def verge_item(self, d, kind, x, y, r, rng, key):
        self.verge_items.append((kind, x, y))
        if kind in ("box", "boxsmall", "shrub"):
            self.shrub(d, x, y, r, ("verge",) + key, ramp=BOX if kind != "shrub" else FOL)
            if kind == "box" and rng.random() < 0.3:                     # a few box balls hold white blossom
                for _ in range(3):
                    fx, fy = x + int(rng.integers(-r // 2, r // 2 + 1)), y - r // 2 - int(rng.integers(0, r // 2 + 1))
                    setpx(d, fx, fy, I["m5"]); setpx(d, fx + 1, fy, I["m4"])
        elif kind == "fern":
            n = int(rng.integers(6, 9))
            for i in range(n):
                a = math.pi * (0.1 + 0.8 * i / (n - 1)) + rng.uniform(-0.15, 0.15)
                ln = r + int(rng.integers(0, 3))
                for t in range(ln):
                    fx = int(round(x + math.cos(a) * t * 1.2)); fy = int(round(y - math.sin(a) * t * 0.8))
                    setpx(d, fx, fy, I["g4"] if t > ln // 2 else I["g3"])
                    if t % 2 == 1 and t < ln - 1:
                        setpx(d, fx, fy + 1, I["g2"])
                setpx(d, int(round(x + math.cos(a) * ln * 1.2)), int(round(y - math.sin(a) * ln * 0.8)), I["g5"])
            setpx(d, x, y, I["g1"]); setpx(d, x + 1, y, I["g1"])
            self.prop_shadow.append(("shrub", x, y, r))
        elif kind in ("bed", "perennial", "clover"):
            col = ("y0", "fl", "bl", "m5", "o2", "y0")[int(rng.integers(0, 6))]
            if kind == "clover":
                col = "m5"
            leaves = 10 if kind == "perennial" else 16
            for _ in range(leaves):
                fx = x + int(rng.integers(-r, r + 1)); fy = y + int(rng.integers(-r // 2, r // 2 + 1))
                if self.walk_mask[min(H - 1, fy), min(W - 1, max(0, fx))]:
                    continue
                setpx(d, fx, fy, I["g4"]); setpx(d, fx + 1, fy, I["g3"]); setpx(d, fx, fy + 1, I["g2"])
            heads = int(rng.integers(5, 9)) if kind != "bed" else int(rng.integers(9, 15))
            for _ in range(heads):
                fx = x + int(rng.integers(-r, r + 1)); fy = y - int(rng.integers(0, r // 2 + 3))
                if self.walk_mask[min(H - 1, fy + 1), min(W - 1, max(0, fx))]:
                    continue
                setpx(d, fx, fy, I[col]); setpx(d, fx + 1, fy, I[col] if col != "m5" else I["m4"])
                setpx(d, fx, fy + 1, I["g1"])

    def lawn_features(self, d, rng, lawn):
        """Open-lawn interest without props, from hand-written tables: clover cushions, wildflower drifts in the
        meadow verges, self-sown shrub clumps with flowering skirts."""
        for n, (x, y, r) in enumerate(CLOVER_PATCHES):
            base = self.L["ground-base"][y, x]
            hi = ramp_shift(base if base in GR else I["g3"], GR, 1)
            lo = ramp_shift(base if base in GR else I["g3"], GR, -1)
            bn = vnoise(("clover-v04", n), 2, 2 * r + 3, 2 * r + 3)
            for j in range(-r, r + 1):
                for i in range(-r - 2, r + 3):
                    e = (i / (r + 1.5)) ** 2 + (j / (r * 0.7 + 0.5)) ** 2 + (bn[j + r, i + r] - 0.5) * 0.6
                    yy_, xx_ = min(H - 1, y + j), min(W - 1, max(0, x + i))
                    if e < 1 and (lawn[yy_, xx_] or self.walk_mask[yy_, xx_] and
                                  self.L["paving-walks"][yy_, xx_] in (I["s1"], I["s0"])):
                        leaf = (i * 3 + j * 5 + n) % 7 == 0 or (i * 3 + j * 5 + n) % 7 == 1 and e < 0.5
                        setpx(d, x + i, y + j, hi if leaf else (ramp_shift(lo, GR, -1) if j > 0 and e > 0.75 else lo))
            for q in range(2 + n % 4):
                fx, fy = x + ((q * 5 + n) % (2 * r - 1)) - r + 1, y + ((q * 3) % (r + 1)) - r // 2
                setpx(d, fx, fy, I["m5"]); setpx(d, fx, fy + 1, I["g2"])
        for k, (x, y, cols, cnt, sx, sy) in enumerate(FLOWER_DRIFTS):
            col, col2 = cols
            rr = rng_for("drift-v04", k)
            for _ in range(cnt):
                fx = x + int(rr.normal(0, sx)); fy = y + int(rr.normal(0, sy))
                if 0 <= fx < W - 1 and 0 <= fy < H - 1 and lawn[fy, fx] and not (AXIS[0] - 2 <= fx <= AXIS[1] + 2):
                    setpx(d, fx, fy, I[col]); setpx(d, fx + 1, fy, I[col2]); setpx(d, fx, fy + 1, I["g2"])
        self.lawn_shrubs = []
        for k, (x, y, r, ramp, comps) in enumerate(LAWN_SHRUBS):
            ramp_ = {"elm": ELM, "box": BOX, "fol": FOL}[ramp]
            for j, (ox, oy, dr) in enumerate(comps):
                self.shrub(d, x + ox, y + oy, r - dr, ("lawnshrub-v04", k, j), ramp=ramp_)
            self.shrub(d, x, y, r, ("lawnshrub-v04", k), ramp=ramp_)
            for q in range(10):
                fx, fy = x - r - 3 + (q * 7 + k * 3) % (2 * r + 7), y + (q * 5) % 4
                if 0 <= fx < W - 1 and fy < H and lawn[fy, fx]:
                    setpx(d, fx, fy, I["fl"] if (fx + fy) % 2 else I["m5"]); setpx(d, fx + 1, fy, I["g3"])
            self.lawn_shrubs.append((x, y))

    def litter(self, d, rng, lawn):
        """Leaf litter at belt margins and under canopies near the walks; hand-placed fallen branches."""
        bp = np.pad(self.belt, 14)
        near_belt = (bp[28:, 14:-14] | bp[:-28, 14:-14] | bp[14:-14, 28:] | bp[14:-14, :-28]) & ~self.belt
        cols = (("s2", "s3"), ("o0", "o2"), ("d1", "s3"), ("s1", "s2"), ("d0", "d1"))
        k = 0
        for _ in range(9000):
            if k >= 480:
                break
            x = int(rng.integers(0, W)); y = int(rng.integers(FOOT_Y + 10, H - 2))
            ok = (near_belt[y, x] and lawn[y, x]) or (self.walk_mask[y, x] and self.belt_near_walk[y, x])
            if not ok or AXIS[0] - 2 <= x <= AXIS[1] + 2:
                continue
            k += 1
            a, b = cols[int(rng.integers(0, len(cols)))]
            for _ in range(int(rng.integers(2, 6))):
                fx, fy = x + int(rng.integers(-4, 5)), y + int(rng.integers(-2, 3))
                if 0 <= fx < W - 1 and 0 <= fy < H and not (AXIS[0] - 2 <= fx <= AXIS[1] + 2):
                    setpx(d, fx, fy, I[a]); setpx(d, fx + 1, fy, I[b])
        for bx, by, ang, ln in BRANCHES:
            if not lawn[by, bx]:
                continue
            for t in range(ln):
                x = int(round(bx + math.cos(ang) * t)); y = int(round(by + math.sin(ang) * t))
                setpx(d, x, y, I["s2"]); setpx(d, x, y + 1, I["s1"]); setpx(d, x, y + 2, I["s0"])
                if t in (ln // 3, 2 * ln // 3):
                    for q in range(1, 6):
                        setpx(d, x + q, y - q, I["s1"])
                        if q == 5:
                            stamp(d, x + q - 2, y - q - 2, [".c.", "cbc", ".b."], {"c": "g4", "b": "g2"})
            self.prop_shadow.append(("box", bx + 2, by + 3, ln, 2))

    def shrub(self, layer, cx, cy, r, key, ramp=None):
        ramp = ramp or [I[n] for n in ("f0", "f1", "g1", "g2", "g3", "g4", "g5")]
        m, idx, (x0, y0) = self.canopy_raster(cx, cy - r // 2, r, key, ramp=ramp, squash=0.75, tex_cell=2)
        sub = layer[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
        sub[m] = idx[m]
        self.prop_shadow.append(("shrub", cx, cy, r))

    def vine(self, layer, x, y, ln, rng, dense=False, stop=None):
        stop = FOOT_Y - 1 if stop is None else stop
        for j in range(ln):
            yy = y + j
            if yy >= stop or yy >= H:
                break
            x += int(rng.integers(-1, 2)) if j % 3 == 0 else 0
            setpx(layer, x, yy, I["g1"])
            if j % 3 == 0 or (dense and j % 3 == 1):
                side = 1 if (j // 3) % 2 else -1
                setpx(layer, x + side, yy, I["g3"])
                setpx(layer, x + side, yy - 1, I["g4"])
                setpx(layer, x + 2 * side, yy, I["g2"])
                setpx(layer, x + side, yy + 1, I["g1"])
                if dense:
                    setpx(layer, x - side, yy + 1, I["g3"]); setpx(layer, x - side, yy, I["g2"])

    def crack(self, layer, comp, x, y, n, rng):
        ang = rng.uniform(0, math.pi)
        for _ in range(n):
            if not (0 <= x < W - 1 and 1 <= y < H):
                return
            base = comp[y, x]
            ramp = STONE if base in STONE else PAVE
            layer[y, x] = ramp_shift(base, ramp, -2)
            if layer[y - 1, x] < 0 and rng.random() < 0.35:
                layer[y - 1, x] = ramp_shift(comp[y - 1, x], ramp, 1)
            ang += rng.normal(0, 0.45)
            x += int(round(math.cos(ang))); y += int(round(math.sin(ang)))

    # ------------------------------------------------------------------ canopies (4 tree families)
    @staticmethod
    def quant(ramp):
        n = len(ramp)
        return {5: [-0.05, 0.3, 0.6, 0.85], 6: [-0.08, 0.22, 0.48, 0.7, 0.9],
                7: [-0.1, 0.18, 0.4, 0.6, 0.78, 0.95]}.get(n, list(np.linspace(-0.1, 0.95, n - 1)))

    def canopy_raster(self, cx, cy, r, key, ramp=FOL, squash=0.86, tex_cell=3, shape="round"):
        rng = rng_for("canopy", key)
        if shape == "spread":                                           # elm: three sub-crowns, flatter, ragged
            blobs = []
            for sx, sy, sr in ((-0.52, 0.06, 0.55), (0.0, -0.14, 0.6), (0.52, 0.08, 0.53)):
                bx0 = (sx + rng.uniform(-0.08, 0.08)) * r
                by0 = (sy + rng.uniform(-0.06, 0.06)) * r * squash
                rb0 = sr * r * rng.uniform(0.9, 1.1)
                blobs.append((bx0, by0, rb0 * 0.78))
                k = int(rng.integers(5, 8))
                for i in range(k):
                    a = 2 * math.pi * i / k + rng.uniform(-0.4, 0.4)
                    dd = rb0 * rng.uniform(0.45, 0.72)
                    blobs.append((bx0 + math.cos(a) * dd, by0 + math.sin(a) * dd * squash,
                                  rb0 * rng.uniform(0.3, 0.46)))
            R = int(r * 1.5) + 4
        elif shape == "small":                                          # magnolia: compact, glossy, few big lobes
            blobs = [(0.0, 0.0, r * 0.72)]
            k = int(rng.integers(5, 8))
            for i in range(k):
                a = 2 * math.pi * i / k + rng.uniform(-0.3, 0.3)
                dd = r * rng.uniform(0.38, 0.52)
                blobs.append((math.cos(a) * dd, math.sin(a) * dd * squash, r * rng.uniform(0.38, 0.5)))
            R = int(r * 1.25) + 4
        else:                                                           # oak / shrubs: round, many lobes
            blobs = [(0.0, 0.0, r * 0.74)]
            k = int(rng.integers(7, 11))
            for i in range(k):
                a = 2 * math.pi * i / k + rng.uniform(-0.3, 0.3)
                dd = r * rng.uniform(0.42, 0.6)
                blobs.append((math.cos(a) * dd, math.sin(a) * dd * squash, r * rng.uniform(0.32, 0.46)))
            for i in range(3):
                blobs.append((rng.uniform(-0.3, 0.3) * r, -rng.uniform(0.1, 0.38) * r, r * rng.uniform(0.28, 0.4)))
            R = int(r * 1.25) + 4
        yy, xx = np.mgrid[-R:R + 1, -R:R + 1].astype(np.float32)
        zbest = np.full(yy.shape, -1e9, np.float32)
        nx = np.zeros_like(yy); ny = np.zeros_like(yy); nz = np.zeros_like(yy)
        for bi, (bx, by, rb) in enumerate(blobs):
            ph1, ph2 = rng.uniform(0, 6.3), rng.uniform(0, 6.3)
            ang = np.arctan2(yy - by, xx - bx)
            rough = 0.12 if shape == "spread" else 0.08
            rr = rb * (1 + rough * np.sin(ang * 7 + ph1) + 0.05 * np.sin(ang * 12 + ph2))
            d2 = ((xx - bx) ** 2 + (yy - by) ** 2) / (rr ** 2)
            inside = d2 < 1
            z = np.sqrt(np.clip(1 - d2, 0, 1)) * rb + by * 0.35 + rb * 0.3
            take = inside & (z > zbest)
            zbest[take] = z[take]
            nx[take] = ((xx - bx) / rr)[take]; ny[take] = ((yy - by) / rr)[take]
            nz[take] = np.sqrt(np.clip(1 - d2, 0, 1))[take]
        env = zbest > -1e8
        L = np.array([-0.55, -0.75, 0.85]); L /= np.linalg.norm(L)
        sh_env = nx * L[0] + ny * L[1] + nz * L[2]                    # whole-crown light (big form first)
        # v03 leaf clusters. v02 shaded each crown as smooth lobes plus value noise, so every tree read as the same
        # speckled ball. Now the crown is built from leaf clusters on a jittered hex grid: each cluster is lit as its
        # own little dome, overlaps the one behind it, and drops a dark notch onto it. The silhouette is the
        # cluster union, so edges scallop instead of following a noisy circle.
        rc = max(2.4, {"spread": 0.16, "small": 0.27}.get(shape, 0.2) * r)
        sp = rc * 1.25
        cents = []
        jit = rng.uniform(0, 1)
        for j, gy in enumerate(np.arange(-R, R + 1, sp * 0.86)):
            for gx in np.arange(-R + (j % 2) * sp / 2 + jit * sp, R + 1, sp):
                ccx = gx + rng.uniform(-0.32, 0.32) * sp
                ccy = gy + rng.uniform(-0.32, 0.32) * sp
                ix, iy = int(round(ccx)) + R, int(round(ccy)) + R
                if not (0 <= ix < 2 * R + 1 and 0 <= iy < 2 * R + 1) or not env[iy, ix]:
                    continue
                if shape == "spread" and rng.random() < 0.13 and nz[iy, ix] > 0.35:
                    continue                                            # elm: gaps between twig masses
                cents.append((ccx, ccy, rc * rng.uniform(0.8, 1.28), float(zbest[iy, ix]), rng.uniform(0, 6.3)))
        cz = np.full(yy.shape, -1e9, np.float32)
        cid = np.full(yy.shape, -1, np.int32)
        lnx = np.zeros_like(yy); lny = np.zeros_like(yy); lnz = np.zeros_like(yy)
        for k, (ccx, ccy, rk, zc, ph) in enumerate(cents):
            x0b, x1b = int(max(0, ccx + R - rk - 3)), int(min(2 * R + 1, ccx + R + rk + 4))
            y0b, y1b = int(max(0, ccy + R - rk - 3)), int(min(2 * R + 1, ccy + R + rk + 4))
            X = xx[y0b:y1b, x0b:x1b] - ccx
            Y = (yy[y0b:y1b, x0b:x1b] - ccy) / 0.86
            ang = np.arctan2(Y, X)
            rr = rk * (1 + 0.13 * np.sin(ang * 5 + ph) + 0.06 * np.sin(ang * 9 + 2 * ph))
            d2 = (X * X + Y * Y) / (rr * rr)
            inside = d2 < 1
            z = zc + np.sqrt(np.clip(1 - d2, 0, 1)) * rk * 0.7
            sub = cz[y0b:y1b, x0b:x1b]
            take = inside & (z > sub)
            sub[take] = z[take]
            cid[y0b:y1b, x0b:x1b][take] = k
            lnx[y0b:y1b, x0b:x1b][take] = (X / rr)[take]
            lny[y0b:y1b, x0b:x1b][take] = (Y / rr)[take]
            lnz[y0b:y1b, x0b:x1b][take] = np.sqrt(np.clip(1 - d2, 0, 1))[take]
        clus = cid >= 0
        er = env.copy()                                                 # interior of the envelope never shows sky
        for _ in range(max(1, int(rc * 0.6))):
            pe = np.pad(er, 1)
            er &= pe[:-2, 1:-1] & pe[2:, 1:-1] & pe[1:-1, :-2] & pe[1:-1, 2:]
        m = clus | er
        local = lnx * L[0] + lny * L[1] + lnz * L[2]
        tex = vnoise(("leaf", key), max(2, tex_cell - 1), yy.shape[0], yy.shape[1])
        sh = 0.5 * sh_env + 0.62 * np.where(clus, local, -0.2) + (tex - 0.5) * 0.14 - 0.08
        q = np.digitize(sh, self.quant(ramp))
        q = np.clip(q, 0, len(ramp) - 1)
        # cluster-over-cluster contact: a texel whose up-left neighbour belongs to a HIGHER cluster is in its shadow
        pc = np.pad(cid, 2, constant_values=-1)
        pz = np.pad(cz, 2, constant_values=-1e9)
        notch = np.zeros(yy.shape, bool)
        for dy, dx in ((-1, 0), (-1, -1), (0, -1), (-2, -1)):
            nid = pc[2 + dy:2 + dy + yy.shape[0], 2 + dx:2 + dx + yy.shape[1]]
            nzv = pz[2 + dy:2 + dy + yy.shape[0], 2 + dx:2 + dx + yy.shape[1]]
            notch |= clus & (nid >= 0) & (nid != cid) & (nzv > cz + 0.5)
        q[notch] = np.maximum(0, np.minimum(q[notch], 2) - 1)
        q[er & ~clus] = 1                                               # pockets: deep interior shade
        idx = np.array(ramp, np.int16)[q]
        if shape == "spread":                                           # dark pockets between the sub-crowns
            pock = m & (vnoise(("pocket", key), 4, yy.shape[0], yy.shape[1]) > 0.82) & (q <= 3)
            idx[pock] = ramp[1]
        p = np.pad(m, 1)
        rim = m & (~p[2:, 1:-1] | ~p[1:-1, 2:])
        idx[rim] = ramp[0]
        idx = np.where(m, idx, -1).astype(np.int16)
        idx = despeckle(idx, 1, valid=m)
        self._last_q = (q, m)
        x0, y0 = int(cx) - R, int(cy) - R
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(W, x0 + 2 * R + 1), min(H, y0 + 2 * R + 1)
        mm = m[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        ii = idx[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        return mm, ii, (cx0, cy0)

    def cone_raster(self, cx, base_y, r, key, ramp=CON):
        """Holly / conifer: a tiered cone seen from above-front, tip at the top, lit from the left; each tier's
        underside falls into shadow."""
        rng = rng_for("cone", key)
        h = int(r * 2.3)
        tiers = int(rng.integers(4, 6))
        R = r + 4
        yy, xx = np.mgrid[0:h + 1, -R:R + 1].astype(np.float32)
        t = yy / h
        tp = (t * tiers + rng.uniform(0, 0.3)) % 1.0
        edge = vnoise(("coneedge", key), 2, h + 1, 2 * R + 1)
        hw = r * (0.1 + 0.9 * t ** 0.85) * (0.68 + 0.32 * tp) + (edge - 0.5) * 3.2
        m = np.abs(xx) <= hw
        nxn = np.clip(xx / np.maximum(hw, 1), -1, 1)
        tex = vnoise(("conetex", key), 2, h + 1, 2 * R + 1)
        sh = -0.6 * nxn + 0.42 * (1 - tp) + (tex - 0.5) * 0.4 - 0.12 * t
        q = np.digitize(sh, [-0.3, 0.05, 0.35, 0.62])
        idx = np.array(ramp, np.int16)[np.clip(q, 0, len(ramp) - 1)]
        under = m & (tp > 0.84)
        idx[under] = np.where(nxn[under] > 0.1, ramp[0], ramp[1])
        p = np.pad(m, 1)
        rim = m & (~p[2:, 1:-1] | ~p[1:-1, 2:])
        idx[rim] = ramp[0]
        idx = np.where(m, idx, -1).astype(np.int16)
        idx = despeckle(idx, 2, valid=m)
        x0, y0 = int(cx) - R, int(base_y) - h
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(W, x0 + 2 * R + 1), min(H, y0 + h + 1)
        mm = m[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        ii = idx[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
        return mm, ii, (cx0, cy0)

    @staticmethod
    def canopy_centre(fam, x, y, r):
        """(centre x, centre y, reach) of a family's canopy for a trunk base at (x, y)."""
        if fam == "holly":
            return x, y - 6 - 1.15 * r, 1.15 * r
        if fam == "magnolia":
            return x, y - 8 - 0.85 * r, 0.95 * r
        if fam == "elm":
            return x, y - 12 - 0.8 * r, 1.2 * r
        return x, y - 10 - 0.9 * r, 0.92 * r

    def tree_sites(self):
        """v04: every tree is hand-placed from the TREES table (position, family, radius, storm break, lean): varied
        groupings per belt (an oak grove with a magnolia pair and a holly accent on the left; a storm-damaged elm and
        oak run on the right), sizes deliberately uneven. v03 filled a jittered grid at random."""
        self.tree_opts = {}
        sites = []
        for (x, y, r, fam, brk, lean) in TREES:
            sites.append((x, y, r, fam))
            self.tree_opts[(x, y)] = (brk, lean)
        sites.sort(key=lambda s: s[1])
        return sites

    def tree_raster(self, tx, ty, r, fam):
        key = ("tree-v04", tx, ty)
        ccx, ccy, _ = self.canopy_centre(fam, tx, ty, r)
        brk = self.tree_opts.get((tx, ty), (False, None))[0]
        if fam == "holly":
            return self.cone_raster(tx, ty - 6, r, key)
        if fam == "snag":
            return self.snag_raster(tx, ty, r, key)
        tr = rng_for("treevar-v04", key)
        lean = self.tree_lean(tx, ty)
        ccx += lean * 0.6 * r
        if fam == "elm":
            out = self.canopy_raster(ccx, ccy, r, key, ramp=ELM, squash=float(tr.uniform(0.64, 0.8)), shape="spread")
            return self.storm_break(out, ccx, ccy, r, key, tr) if brk else out
        if fam == "oak":
            out = self.canopy_raster(ccx, ccy, r, key, ramp=FOL, squash=float(tr.uniform(0.76, 0.98)))
            return self.storm_break(out, ccx, ccy, r, key, tr) if brk else out
        if fam == "magnolia":
            m, idx, o = self.canopy_raster(ccx, ccy, r, key, ramp=MAG, squash=0.8, tex_cell=2, shape="small")
            rng = rng_for("blossom", key)
            ys, xs = np.nonzero(m & (idx >= 0) & np.isin(idx, [I["e2"], I["e3"], I["g4"]]))
            for k in rng.permutation(len(ys))[: max(4, len(ys) // 14)]:
                y, x = int(ys[k]), int(xs[k])
                c = I["bl"] if rng.random() < 0.7 else I["m5"]
                idx[y, x] = c
                if x + 1 < idx.shape[1] and m[y, x + 1]:
                    idx[y, x + 1] = c if c == I["m5"] else I["fl"]
            return m, idx, o
        return self.canopy_raster(ccx, ccy, r, key, ramp=FOL)

    def tree_lean(self, tx, ty):
        """-1..1: hand value from TREES when given, else margin trees lean out toward the open lawn light."""
        o = getattr(self, "tree_opts", {}).get((tx, ty))
        if o is not None and o[1] is not None:
            return o[1]
        r = rng_for("lean-v04", tx, ty)
        v = float(r.uniform(-0.2, 0.2))
        if tx < 640 and tx > 100:
            v += 0.3 * float(r.random())
        elif tx >= 640 and tx < W - 100:
            v -= 0.3 * float(r.random())
        return max(-0.6, min(0.6, v))

    def storm_break(self, out, ccx, ccy, r, key, tr):
        """A storm has torn a limb out of the crown: a wedge of the canopy is gone, and the stripped limb and its
        snapped stubs show through it (lit upper edge, dark underside)."""
        m, idx, (x0, y0) = out
        m = m.copy(); idx = idx.copy()
        hh, ww = m.shape
        yy, xx = np.mgrid[0:hh, 0:ww]
        X, Y = xx + x0 - ccx, yy + y0 - ccy
        a0 = float(tr.choice([-2.6, -2.1, -0.6, -0.2, 0.3, 2.9]))       # never straight down (trunk side)
        span = float(tr.uniform(0.45, 0.75))
        ang = np.arctan2(Y, X)
        da = np.angle(np.exp(1j * (ang - a0)))
        rad = np.hypot(X, Y / 0.86)
        cut = (np.abs(da) < span / 2) & (rad > r * float(tr.uniform(0.45, 0.62))) & m
        m[cut] = False
        idx[cut] = -1
        p = np.pad(m, 1)                                                 # fresh outline round the wound
        rim = m & ~(p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:])
        idx[rim] = np.where(np.isin(idx[rim], [I["g5"], I["g6"], I["g4"]]), I["g3"], idx[rim])
        # the stripped limb: from inside the crown out through the gap, forking once
        ln = r * float(tr.uniform(0.95, 1.2))
        bx, by = ccx - x0 + math.cos(a0) * r * 0.3, ccy - y0 + math.sin(a0) * r * 0.26
        def limb(xa, ya, ang_, n, wdt):
            for t in range(int(n)):
                px_ = int(round(xa + math.cos(ang_) * t)); py_ = int(round(ya + math.sin(ang_) * t * 0.86))
                for w_ in range(wdt):
                    for (qx, qy, c) in ((px_, py_ - w_, "s2" if w_ == 0 else "s1"), (px_, py_ + 1, "s0")):
                        if 0 <= qx < ww and 0 <= qy < hh and (cut[qy, qx] or not m[qy, qx]):
                            if not m[qy, qx] or cut[qy, qx]:
                                m[qy, qx] = True
                                idx[qy, qx] = I[c]
            return xa + math.cos(ang_) * n, ya + math.sin(ang_) * n * 0.86
        ex, ey = limb(bx, by, a0, ln * 0.7, 2)
        limb(ex, ey, a0 + 0.5, ln * 0.35, 1)
        limb(ex, ey, a0 - 0.45, ln * 0.28, 1)
        limb(bx + math.cos(a0) * ln * 0.35, by + math.sin(a0) * ln * 0.3, a0 + 1.1, ln * 0.18, 1)
        return m, idx, (x0, y0)

    def snag_raster(self, tx, ty, r, key):
        """A dead, ivy-hung snag: bare forked limbs (lit left edges), one snapped leader, small ivy clusters."""
        rng = rng_for("snag", key)
        R = int(r * 1.3) + 6
        hh, ww = 2 * R, 2 * R + 1
        m = np.zeros((hh, ww), bool)
        idx = np.full((hh, ww), -1, np.int16)
        ox, oy = R, hh - 1                                              # trunk base in raster coords
        def put_(x, y, c):
            x, y = int(round(x)), int(round(y))
            if 0 <= x < ww and 0 <= y < hh:
                m[y, x] = True; idx[y, x] = I[c]
        def grow(x, y, ang_, n, wdt, depth):
            for t in range(int(n)):
                x += math.cos(ang_); y += math.sin(ang_)
                ang_ += float(rng.normal(0, 0.06))
                for w_ in range(wdt):
                    put_(x + w_, y, "s2" if w_ == 0 else ("s1" if w_ < wdt - 1 else "s0"))
                put_(x + wdt, y, "ink" if wdt > 1 else "s0")
            if depth > 0:
                for da in (-0.55 + float(rng.uniform(-0.15, 0.15)), 0.5 + float(rng.uniform(-0.15, 0.15))):
                    if rng.random() < 0.85:
                        grow(x, y, ang_ + da, n * float(rng.uniform(0.5, 0.7)), max(1, wdt - 1), depth - 1)
        tall = int(r * 0.9)
        x, y = ox, oy - 20                                              # top of the props-layer trunk
        for t in range(tall):
            for w_ in range(4):
                put_(x - 2 + w_, y - t, ("s2", "s1", "s1", "s0")[w_])
            put_(x + 2, y - t, "ink")
        put_(x - 1, y - tall, "m3"); put_(x, y - tall, "m4"); put_(x + 1, y - tall, "m2")   # snapped leader, raw wood
        for a_, f_ in ((-2.35, 0.55), (-0.8, 0.5), (-1.9, 0.75), (-1.1, 0.8)):
            grow(x, y - tall * f_, a_ + float(rng.uniform(-0.12, 0.12)), r * float(rng.uniform(0.42, 0.6)), 2, 2)
        ys, xs = np.nonzero(m)                                          # ivy clusters hanging on the limbs
        for k in rng.permutation(len(ys))[:7]:
            cy_, cx_ = int(ys[k]), int(xs[k])
            for (i, j, c) in ((0, 0, "g3"), (1, 0, "g2"), (-1, 1, "g2"), (0, 1, "g1"), (1, 1, "g1"), (0, -1, "g4"),
                              (-1, 0, "g3"), (2, 1, "g1")):
                put_(cx_ + i, cy_ + j, c)
        x0, y0 = int(tx) - ox, int(ty) - oy
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(W, x0 + ww), min(H, y0 + hh)
        return m[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0], idx[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0], (cx0, cy0)

    def trees(self):
        fg = self.L["fg-occlusion"]
        props = self.L["props-low"]
        sites = self.tree_sites()
        rasters = [self.tree_raster(*s) for s in sites]
        # occluder rule (spec section 4): a 48 px actor anywhere walkable keeps >= 1/3 of its height visible.
        # The hand placements are checked against it; any tree that breaks it would be dropped and reported.
        keep = list(range(len(sites)))
        walk = self.walkable_mask()
        spr = heroine_48()[..., 3] == 255
        while True:
            cover = np.zeros((H, W), np.int16) - 1
            for k in keep:
                m, idx, (x0, y0) = rasters[k]
                cover[y0:y0 + m.shape[0], x0:x0 + m.shape[1]][m] = k
            fails = visibility_fails(cover >= 0, walk, spr)
            if not fails:
                break
            votes = {}
            sh, sw = spr.shape
            for (x, y) in fails:
                ids = cover[y - sh + 1:y + 1, x - sw // 2:x - sw // 2 + sw][spr]
                for k in np.unique(ids[ids >= 0]):
                    votes[int(k)] = votes.get(int(k), 0) + 1
            keep.remove(max(votes, key=votes.get))
        self.trees_dropped_for_visibility = len(sites) - len(keep)
        self.trees_dropped = [sites[k] for k in range(len(sites)) if k not in keep]
        self.tree_list = [sites[k] for k in keep]
        for k in keep:
            tx, ty, r, fam = sites[k]
            m, idx, (x0, y0) = rasters[k]
            sub = fg[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
            sub[m] = idx[m]
            before = props >= 0
            self.trunk(props, tx, ty, fam)
            new = (props >= 0) & ~before
            ys, xs = np.nonzero(new)
            if len(ys):
                self.tall(("trunk", tx, ty), props, xs.min(), ys.min(), xs.max(), ys.max(), mask=new)
            self.block[ty - 4:ty + 1, tx - 5:tx + 5] = True
            self.prop_shadow.append(("tree", tx, ty, r, fam))
        bnw = np.zeros((H, W), bool)
        bnw[fg >= 0] = True
        self.belt_near_walk = bnw

    def trunk(self, layer, tx, ty, fam):
        """Trunk below the canopy with a root flare; lit on the left, bark furrows, dark on the right."""
        if fam == "magnolia":                                           # multi-stemmed, smooth grey bark
            for sx, lean in ((-3, -1), (0, 0), (3, 1)):
                for j in range(8):
                    x = tx + sx + (lean * j) // 4; y = ty - j
                    setpx(layer, x, y, I["m1"]); setpx(layer, x + 1, y, I["m0"])
                    if j < 3:
                        setpx(layer, x - 1, y, I["m2"])
            return
        if fam == "holly":                                              # short dark stem under the skirt
            for j in range(6):
                for i in (-2, -1, 0, 1, 2):
                    setpx(layer, tx + i, ty - j, I["s1"] if i < 0 else I["s0"])
            setpx(layer, tx - 3, ty, I["s1"]); setpx(layer, tx + 3, ty, I["s0"])
            return
        tall = 16 if fam == "oak" else 20
        lean = self.tree_lean(tx, ty)
        for j in range(tall):
            y = ty - tall + 1 + j
            hw = 3 if j < tall - 6 else 3 + (j - tall + 7) // 2
            sx = int(round(lean * 0.6 * (tall - 1 - j) * 0.5))           # leaning bole, flare stays planted
            for i in range(-hw, hw + 1):
                x = tx + i + sx
                rel = (i + hw) / (2 * hw)
                c = I["s2"] if rel < 0.3 else I["s1"] if rel < 0.75 else I["s0"]
                if j < tall - 6 and i == 0 and (j * 3 + tx) % 4 == 0:
                    c = I["s0"]
                if j >= tall - 3 and abs(i) == hw and (j + i) % 2:
                    c = I["s0"]
                setpx(layer, x, y, c)
        if fam == "snag":
            return
        if fam == "elm":                                                # vase fork visible under the crown
            for q in range(1, 6):
                setpx(layer, tx - 2 - q, ty - tall - q + 1, I["s1"]); setpx(layer, tx - 1 - q, ty - tall - q + 1, I["s2"])
                setpx(layer, tx + 2 + q, ty - tall - q + 1, I["s0"]); setpx(layer, tx + 1 + q, ty - tall - q + 1, I["s1"])
        setpx(layer, tx - hw - 1, ty, I["s1"]); setpx(layer, tx + hw + 1, ty, I["s0"])

    # ------------------------------------------------------------------ props-low and survey post
    def put_prop(self, layer, name, x, y, spr, cmap, block_rows=None, shadow=None):
        """Stamp a hand-placed prop whose bottom row is its ground row; register it for the depth audit (with a
        no-walk collar) and optionally a box shadow (dx, dw, dh)."""
        stamp(layer, x, y - len(spr) + 1, spr, cmap)
        self.tall(name, layer, x, y - len(spr) + 1, x + len(spr[0]) - 1, y, mask=stamp_mask(x, y - len(spr) + 1, spr))
        if shadow:
            dx, dw, dh = shadow
            self.prop_shadow.append(("box", x + dx, y + 1, dw, dh))

    def props(self):
        pr = self.L["props-low"]
        # benches (AOC: "Benches along the paths"), hand-placed along the walks; bins beside three
        self.bench_list = []
        for (bx, by, broken, binned, side) in bench_positions():
            self.put_prop(pr, ("bench", bx), bx, by + 12, BENCH_BROKEN if broken else BENCH, BENCH_MAP,
                          shadow=(4, 26, 3))
            self.bench_list.append((bx, by))
            if binned:
                lx = bx + (30 if side > 0 else -14)
                self.put_prop(pr, ("bin", lx), lx, by + 12, BIN, BIN_MAP, shadow=(4, 9, 3))
        # toppled walk lamp beside the axis: broken base stub, the post and lantern lying on the lawn
        sx_, sy_ = TOPPLED_LAMP
        before = pr >= 0
        self.put_prop(pr, ("lamp-stub",), sx_, sy_, LAMP_STUB, LAMP_MAP, shadow=(3, 7, 3))
        for t in range(36):
            x = sx_ + 8 + t; y = sy_ - 2 + t // 3
            setpx(pr, x, y, I["k2"]); setpx(pr, x, y + 1, I["k1"]); setpx(pr, x, y + 2, I["ink"])
        stamp(pr, sx_ + 43, sy_ + 6, [".xxxx.", "xkHHkx", "xHkkHx", "xkHHkx", ".xxxx."],
              {"x": "ink", "k": "k1", "H": "k3"})
        self.tall_new(("lamp-lying",), pr, before)
        self.prop_shadow.append(("box", sx_ + 10, sy_ + 3, 36, 2))
        # wayfinding signs (text unreadable at this scale by design)
        for sx, sy in SIGNS:
            self.put_prop(pr, ("sign", sx), sx, sy, SIGN, SIGN_MAP, shadow=(6, 20, 3))
        # commemorative-tree plaques at the three trees nearest a walk
        curves = [(self.lc, WALK_W / 2), (self.rc, WALK_W / 2), (self.bc, BRANCH_W / 2)]
        near = sorted(self.tree_list, key=lambda s: min(np.hypot(c[:, 0] - s[0], c[:, 1] - s[1]).min() - hw
                                                       for c, hw in curves))
        self.plaques = []
        for tx, ty, r, fam in near[:3]:
            stamp(pr, tx + 7, ty - 3, PLAQUE, PLAQUE_MAP)
            self.tall(("plaque", tx), pr, tx + 7, ty - 3, tx + 11, ty + 2, mask=stamp_mask(tx + 7, ty - 3, PLAQUE))
            self.plaques.append((tx + 9, ty + 3))
        # vegetation-survey quadrats (flat frames on the lawn) and old stumps
        self.quadrats = list(QUADRATS)
        for k, (qx, qy) in enumerate(self.quadrats):
            self.quadrat(pr, qx, qy, k)
        for (sx, sy) in STUMPS:
            self.put_prop(pr, ("stump", sx), sx, sy, STUMP, STUMP_MAP, shadow=(7, 17, 4))
        self.stumps = list(STUMPS)
        # survey kit around the post (offsets from POST, hand-placed)
        px, py = POST
        for (dx, dy) in ((-56, -4), (-42, 7), (30, -2)):
            self.put_prop(pr, ("crate", dx), px + dx, py + dy, CRATE, CRATE_MAP, shadow=(3, 14, 3))
        for spr_, cmap_, dx, dy in ((TRIPOD, TRIPOD_MAP, 50, -34), (REEL, REEL_MAP, -50, 30),
                                    (TARP, TARP_MAP, -100, -14)):
            self.put_prop(pr, ("kit", dx), px + dx, py + dy, spr_, cmap_, shadow=(4, len(spr_[0]) - 2, 3))
        for (dx, dy) in ((-32, 1), (20, 3), (-8, 4)):
            stamp(pr, px + dx, py + dy - len(SANDBAG) + 1, SANDBAG, SANDBAG_MAP)
        for (dx, dy) in ((-48, 4), (52, -6)):
            stamp(pr, px + dx - 1, py + dy - 4, [".k.", "kKk", ".k.", ".K."], {"k": "k2", "K": "k0"})
        # patrol-route beacons on the lawn legs of the loop
        for k in (1, 3, 4, 5):
            x, y = PATROL[k]
            bx, by = x + 10, y + 4
            self.put_prop(pr, ("beacon", k), bx - 1, by, BEACON, BEACON_MAP, shadow=(2, 4, 2))
        # survey pin flags on the right panel by the fountain side (waist-low)
        for (x, y) in SURVEY_FLAGS:
            self.put_prop(pr, ("flag", x, y), x, y, ["oo.", "oOo", "k..", "k..", "k..", "K.."],
                          {"o": "o1", "O": "o0", "k": "k2", "K": "k0"}, shadow=(1, 3, 1))
        # strain sensors on stakes at the collapse, the relay box, the cordon and its warning sign
        for (x, y) in STRAIN_SENSORS:
            stamp(pr, x - 1, y - 9, SENSOR, {"C": "c1", "X": "c2", "k": "k2", "K": "k0"})
            self.tall(("sensor", x), pr, x - 1, y - 9, x + 1, y - 1, mask=stamp_mask(x - 1, y - 9, SENSOR))
            self.prop_shadow.append(("box", x + 1, y, 4, 2))
        rx, ry = RELAY
        self.put_prop(pr, ("relay",), rx, ry, RELAY_BOX, RELAY_MAP, shadow=(3, 14, 3))
        tops = []
        for (x, y) in CORDON:
            stamp(pr, x, y - 7, STAKE, STAKE_MAP)
            self.tall(("stake", x, y), pr, x, y - 7, x + 1, y, mask=stamp_mask(x, y - 7, STAKE))
            tops.append((x + 1, y - 7))
            self.prop_shadow.append(("box", x + 1, y, 3, 1))
        for (ax, ay), (bx, by) in zip(tops, tops[1:]):
            n = int(max(abs(bx - ax), abs(by - ay)))
            for t in range(1, n):
                sag = 2.5 * math.sin(math.pi * t / n)
                setpx(pr, int(round(ax + (bx - ax) * t / n)), int(round(ay + (by - ay) * t / n + sag)), I["o1"])
        wx, wy = CORDON[3]
        stamp(pr, wx - 4, wy - len(WARN) - 2, WARN, WARN_MAP)
        self.cordon = list(CORDON)
        # the slump's fallen urn rolled onto the lawn; the snapped candelabra head lying by the right stair foot
        ux, uy = SLUMP_URN
        self.fallen_urn(pr, ux, uy, ("slumpurn",))
        hx, hy = LAMP_HEAD
        self.put_prop(pr, ("lamp-head",), hx, hy, LAMP_HEAD_LYING, {"x": "ink", "M": "m4", "L": "m5", "D": "m2",
                                                                   "B": "e2", "b": "e3", "k": "f1"},
                      shadow=(2, 18, 2))
        self.uprooted_tree(pr)

    def uprooted_tree(self, pr):
        """A storm-thrown oak lying on the right lawn panel (FALLEN_TREE, hand-placed): the upturned root plate stands
        up at the lawn edge with its crater behind it; the trunk (lit along its top) lies toward the lower left; the
        dead crown at its end is a flattened mass of brown and olive leaf clusters with a few bare limbs."""
        (rx, ry), (ex, ey) = FALLEN_TREE
        before = pr >= 0
        L = math.hypot(ex - rx, ey - ry)
        ux, uy = (ex - rx) / L, (ey - ry) / L
        # crater behind the plate (soil torn out of the lawn)
        for j in range(-7, 8):
            for i in range(-19, 20):
                e = (i / 19.0) ** 2 + (j / 7.0) ** 2 + 0.12 * math.sin(i * 0.9 + j)
                if e < 1:
                    setpx(pr, rx + 12 + i, ry + 3 + j, I["s0"] if e < 0.55 else I["s1"])
                    if j > 4 and e > 0.6:
                        setpx(pr, rx + 12 + i, ry + 3 + j, I["s3"])
        # trunk: cylinder shading across its width, bark furrows, ink contact underneath
        n = int(L * 0.86)
        for t in range(n):
            x, y = rx + ux * t, ry + uy * t
            hw = 7 - int(3.0 * t / n)
            for j in range(-hw, hw + 2):
                c = I["s4"] if j == -hw else I["s3"] if j < -hw + 3 else I["s2"] if j < hw - 1 else I["s1"]
                if j == hw:
                    c = I["s0"]
                if j == hw + 1:
                    c = I["ink"]
                if (t + 3 * j) % 9 == 0 and -hw < j < hw - 1:
                    c = I["s1"]
                setpx(pr, int(round(x)), int(round(y)) + j, c)
            if t in (int(n * 0.35), int(n * 0.6)):
                for q in range(1, 7):
                    setpx(pr, int(x) + q // 2, int(y) - hw - q, I["s2"]); setpx(pr, int(x) + q // 2 + 1, int(y) - hw - q, I["s0"])
        # root plate: a standing disc of matted soil and roots, lit on its upper-left rim, rocks caught in it
        for j in range(-28, 5):
            for i in range(-18, 19):
                e = (i / 18.0) ** 2 + ((j + 11) / 16.0) ** 2 + 0.13 * math.sin(i * 1.3 + j * 0.7)
                if e < 1:
                    c = I["s1"] if (i * 3 + j * 5) % 7 else I["s0"]
                    if (i + 2 * j) % 11 == 0:
                        c = I["s2"]
                    if e > 0.8:
                        c = I["s3"] if (i < 0 and j < -11) else I["s0"]
                    setpx(pr, rx + i, ry + j, c)
        for (a, ln) in ((-2.6, 8), (-2.1, 7), (-1.4, 9), (-0.7, 6), (0.2, 7), (2.8, 6), (-3.0, 5)):
            for q in range(ln):
                setpx(pr, int(round(rx + math.cos(a) * (18 + q))), int(round(ry - 11 + math.sin(a) * (16 + q) * 0.9)),
                      I["s1"] if q < ln - 2 else I["s2"])
        for (i, j, c) in ((-5, -14, "m3"), (-4, -14, "m2"), (6, -6, "m3"), (2, -18, "m2"), (-8, -4, "m4")):
            setpx(pr, rx + i, ry + j, I[c])
        # dead crown at the far end
        dead = [I[c] for c in ("s0", "s1", "o0", "s2", "d1", "s3")]
        m, idx, (x0, y0) = self.canopy_raster(ex - 14, ey - 8, 34, ("fallen-crown",), ramp=dead, squash=0.5,
                                                tex_cell=2, shape="spread")
        sub = pr[y0:y0 + m.shape[0], x0:x0 + m.shape[1]]
        keep_green = vnoise("fallen-green", 3, m.shape[0], m.shape[1]) > 0.78
        idx2 = np.where(keep_green & (idx >= I["s2"]), I["g3"], idx)
        sub[m] = idx2[m]
        for (a, ln) in ((-2.4, 26), (-2.9, 22), (-1.9, 18), (2.7, 16)):
            bx, by = rx + ux * n, ry + uy * n
            for q in range(ln):
                setpx(pr, int(round(bx + math.cos(a) * q)), int(round(by + math.sin(a) * q * 0.6)), I["s2"])
        self.fallen_tree_mask = self.tall_new(("uprooted-tree",), pr, before)
        self.prop_shadow.append(("block", ex - 24, ey - 8, int(L * 0.6), 8, 7))
        self.prop_shadow.append(("shrub", rx + 4, ry + 2, 14))

    def quadrat(self, layer, x, y, k):
        """A 27 x 17 px PVC quadrat seen in 3/4 (white tube, lit top edge, shaded near edge), orange corner tags
        and a small numbered stake tag; grass shows through. Ground-level: never blocks walking."""
        w, h = 27, 17
        for i in range(w):
            setpx(layer, x + i, y, I["m5"]); setpx(layer, x + i, y + h - 1, I["m4"])
            setpx(layer, x + i, y + h, I["m2"])
        for j in range(h):
            setpx(layer, x, y + j, I["m5"]); setpx(layer, x + w - 1, y + j, I["m4"])
            setpx(layer, x + w, y + j, I["m2"])
        for (cx, cy) in ((x, y), (x + w - 2, y), (x, y + h - 2), (x + w - 2, y + h - 2)):
            for (i, j) in ((0, 0), (1, 0), (0, 1), (1, 1)):
                setpx(layer, cx + i, cy + j, I["o1"])
        stamp(layer, x + w + 2, y - 4, ["xxxx", "xooO", "xoOO", "xxxx", ".k..", ".k..", ".K.."],
              {"x": "ink", "o": "o2", "O": "o1", "k": "k2", "K": "k0"})
        if k % 2 == 0:                                                  # a clipped sample square inside
            for j in range(5, 10):
                for i in range(6, 13):
                    setpx(layer, x + i, y + j, I["g5"] if (i + j) % 2 else I["g4"])
            for i in range(6, 13):
                setpx(layer, x + i, y + 10, I["s1"])
        self.prop_shadow.append(("box", x + 2, y + h + 1, w, 1))

    def survey_post(self):
        """Science survey post, about 2.8x the actor: ink-outlined so it holds against the lawn, lit left edges,
        hazard band, screen, mast with rungs, angled solar panel, dish, sensor head with a cyan beacon, pennant
        and two guy wires. All accents are opaque palette colours (no glow alpha)."""
        sp = self.L["survey-post"]
        px, py = POST
        # concrete pad
        rect(sp, px - 25, py - 11, px + 24, py, I["ink"])
        rect(sp, px - 24, py - 10, px + 23, py - 5, I["m3"]); rect(sp, px - 24, py - 10, px + 23, py - 10, I["m5"])
        rect(sp, px - 24, py - 10, px - 24, py - 5, I["m4"])
        rect(sp, px - 24, py - 4, px + 23, py - 1, I["m2"]); rect(sp, px - 24, py - 4, px + 23, py - 4, I["m1"])
        rect(sp, px + 22, py - 10, px + 23, py - 1, I["m1"])
        # cabinet
        x0, x1 = px - 16, px + 15
        rect(sp, x0 - 1, py - 47, x1 + 1, py - 10, I["ink"])
        rect(sp, x0, py - 46, x1, py - 42, I["k3"]); rect(sp, x0, py - 46, x1, py - 46, I["m4"])
        rect(sp, x0, py - 41, x1, py - 41, I["k0"])
        rect(sp, x0, py - 40, x1, py - 11, I["k1"])
        rect(sp, x0, py - 40, x0, py - 11, I["k3"]); rect(sp, x0 + 1, py - 40, x0 + 1, py - 11, I["k2"])
        rect(sp, x1 - 1, py - 40, x1, py - 11, I["k0"])
        rect(sp, x0 + 1, py - 19, x1 - 1, py - 15, I["o1"])                              # hazard band
        for i in range(x0 + 1, x1, 5):
            for j in range(5):
                setpx(sp, i + j // 2 + 1, py - 19 + j, I["ink"]); setpx(sp, i + j // 2 + 2, py - 19 + j, I["ink"])
        rect(sp, x0 + 1, py - 14, x1 - 1, py - 14, I["o0"])
        rect(sp, px - 13, py - 37, px + 4, py - 24, I["k0"])                             # screen
        rect(sp, px - 12, py - 36, px + 3, py - 25, I["c0"])
        for i, h_ in enumerate((3, 5, 4, 7, 6, 8, 5, 9, 7, 6, 8, 10, 9, 8)):
            setpx(sp, px - 11 + i, py - 26 - h_, I["c1"])
            setpx(sp, px - 11 + i, py - 25 - h_, I["c0"] if h_ < 9 else I["c1"])
        setpx(sp, px + 1, py - 35, I["c2"]); setpx(sp, px + 2, py - 35, I["c2"])
        for j, c in enumerate(("c2", "c1", "o1", "k3")):                                   # status LEDs
            rect(sp, px + 8, py - 37 + 3 * j, px + 9, py - 37 + 3 * j, I[c])
        for yy in range(py - 24, py - 20, 2):                                              # vents
            rect(sp, px + 6, yy, px + 13, yy, I["k0"]); rect(sp, px + 6, yy + 1, px + 13, yy + 1, I["k2"])
        rect(sp, px + 12, py - 31, px + 12, py - 28, I["m4"])
        # mast with rungs and bracket rings
        mx = px + 6
        top = py - 120
        rect(sp, mx - 1, top, mx + 4, py - 47, I["ink"])
        rect(sp, mx, top, mx, py - 48, I["k3"]); rect(sp, mx + 1, top, mx + 2, py - 48, I["k2"])
        rect(sp, mx + 3, top, mx + 3, py - 48, I["k1"])
        for yy in range(top + 4, py - 50, 6):
            rect(sp, mx, yy, mx + 3, yy, I["k0"])
        for yy in range(top + 14, py - 50, 20):
            rect(sp, mx - 2, yy, mx + 5, yy, I["k3"]); rect(sp, mx - 2, yy + 1, mx + 5, yy + 1, I["k0"])
        # solar panel on an arm, angled toward the light
        rect(sp, px - 12, py - 79, mx - 2, py - 78, I["k1"]); rect(sp, px - 12, py - 77, mx - 2, py - 77, I["ink"])
        for j in range(16):
            xa = px - 42 + j // 2
            y = py - 96 + j
            rect(sp, xa, y, xa + 29, y, I["c0"])
            setpx(sp, xa, y, I["ink"]); setpx(sp, xa + 29, y, I["ink"])
            if j in (0, 15):
                rect(sp, xa, y, xa + 29, y, I["ink"])
            elif j in (5, 10):
                rect(sp, xa + 1, y, xa + 28, y, I["k1"])
            if 0 < j < 15:
                for cx_ in (7, 14, 21):
                    setpx(sp, xa + cx_, y, I["k1"])
        for j in range(1, 5):
            rect(sp, px - 41 + j // 2, py - 96 + j, px - 36 + j // 2 - j, py - 96 + j, I["c1"])
        setpx(sp, px - 40, py - 94, I["c2"]); setpx(sp, px - 39, py - 94, I["c2"])
        rect(sp, px - 25, py - 80, px - 24, py - 78, I["k1"])
        # dish on the right
        stamp(sp, mx + 6, py - 108, [".kkkkk...", "kHHHHMk..", "kHMMMMMk.", "kHMMMMMkK", ".kMMMMk.K", "..kkkk..K",
                                     "...kk....", "...kk...."], {"H": "m5", "M": "m4", "k": "ink", "K": "k2"})
        rect(sp, mx + 4, py - 102, mx + 8, py - 101, I["k1"])
        # sensor head + beacon
        hx = mx - 5
        hy = top - 14
        stamp(sp, hx, hy, ["....CC.......", "...CXXC......", "....CC.......", ".kkkkkkkkkk..",
                           "kHHHHHHHHMMk.", "kHMMMMMMMMMk.", "kHMcCCCcMMMk.", "kHMCXXXCMMMk.", "kHMcCCCcMMMk.",
                           "kHMMMMMMMMMk.", ".kkkkkkkkkk..", "....kkkk.....", "....kKKk....."],
              {"C": "c1", "X": "c2", "k": "ink", "H": "k3", "M": "k2", "c": "c0", "K": "k1"})
        # whip antenna with pennant
        rect(sp, x0 + 3, py - 86, x0 + 3, py - 48, I["k2"])
        stamp(sp, x0 + 4, py - 86, ["kkkkkk", "kooooOk", "kooOOk", "kOOk", "kk"], {"o": "o1", "O": "o0", "k": "ink"})
        # v03 focal contrast: a 1 px ink silhouette round the whole post (mast, panel, dish, head) so it holds against
        # the light pad at 1x; the guy wires are drawn after it and stay 1 px
        mk = sp >= 0
        pk = np.pad(mk, 1)
        ol = ~mk & (pk[:-2, 1:-1] | pk[2:, 1:-1] | pk[1:-1, :-2] | pk[1:-1, 2:])
        sp[ol] = I["ink"]
        rect(sp, mx, top, mx, py - 48, I["m4"])                                         # mast rim light
        # guy wires to the anchors
        for (ax, ay) in ((px - 48, py + 1), (px + 52, py - 9)):
            line(sp, mx + 1, py - 110, ax, ay, I["k0"])
        self.block[py - 10:py + 1, px - 25:px + 25] = True
        self.post_mask = sp >= 0

    # ------------------------------------------------------------------ cast shadows (light from upper left)
    def shadows(self):
        cs = self.L["cast-shadows"]
        comp = composite_idx(self.L, ["ground-base", "paving-walks", "terrace-walls", "ground-detail"])
        m1 = np.zeros((H, W), bool)
        m2 = np.zeros((H, W), bool)
        yy, xx = np.mgrid[0:H, 0:W]
        noise = vnoise("shedge-v04", 3)

        def ell(mask, cx, cy, rx, ry, jit=0.25, rot=None):
            x0, x1 = int(max(0, cx - rx * 1.6 - 2)), int(min(W, cx + rx * 1.6 + 3))
            y0, y1 = int(max(0, cy - rx * 1.6 - 2)), int(min(H, cy + rx * 1.6 + 3))
            if x0 >= x1 or y0 >= y1:
                return
            X, Y = xx[y0:y1, x0:x1] - cx, yy[y0:y1, x0:x1] - cy
            if rot is not None:
                c, s = math.cos(rot), math.sin(rot)
                X, Y = X * c + Y * s, -X * s + Y * c
            e = (X / rx) ** 2 + (Y / ry) ** 2 + (noise[y0:y1, x0:x1] - 0.5) * jit
            mask[y0:y1, x0:x1] |= e < 1

        wing = (yy >= FACADE_Y1) & (yy < FACADE_Y1 + 5 + (noise * 2).astype(int))
        m1 |= wing; m2 |= (yy >= FACADE_Y1) & (yy < FACADE_Y1 + 2)
        for a, b, ybot in [(PAV[0] - 4, PAV[1] + 4, PAV_Y1)] + [(s0, s1, SUBP_Y1) for s0, s1 in SUBP]:
            sh = (yy >= ybot) & (yy < ybot + 7) & (xx >= a + 3 + (yy - ybot)) & (xx <= b + 4 + (yy - ybot) * 1.2)
            m1 |= sh; m2 |= sh & (yy < ybot + 3)
            m1 |= (xx > b) & (xx <= b + 7) & (yy >= FACADE_Y1) & (yy < ybot + 3)
        band = (yy >= FOOT_Y) & (yy < FOOT_Y + 9 + (vnoise("wsh-v04", 6) * 6).astype(int))
        for sx0, sx1 in STAIRS:
            band &= ~((xx >= sx0 - CHEEK_W - 2) & (xx <= sx1 + CHEEK_W + 2))
        band &= ~((xx >= EXEDRA[0]) & (xx <= EXEDRA[1]))
        m1 |= band; m2 |= band & (yy < FOOT_Y + 3)
        cxm = (EXEDRA[0] + EXEDRA[1]) / 2.0
        hw = (EXEDRA[1] - EXEDRA[0]) / 2.0
        for x in range(EXEDRA[0], EXEDRA[1] + 1):                       # the curved wall shades its floor
            fl = self.floor_y[x]
            dep = int(6 + 12 * max(0.0, (cxm - x) / hw) + 3 * noise[fl, x])
            m1[fl:fl + dep, x] = True
            m2[fl:fl + 3 + dep // 4, x] = True
        for sx0, sx1 in STAIRS:
            for x0 in (sx0, sx1 + CHEEK_W + 3):
                cw = (xx >= x0) & (xx < x0 + 6) & (yy >= EDGE_Y - 2) & (yy <= STAIR_BOT + 6)
                m1 |= cw; m2 |= cw & (xx < x0 + 2)
        fm = self.fountain_mask
        fsh = np.zeros((H, W), bool)
        fsh[4:, 6:] = fm[:-4, :-6]
        m1 |= fsh & ~fm
        m2 |= np.roll(np.roll(fm, 2, 0), 3, 1) & ~fm
        for kind, *a in self.prop_shadow:
            if kind == "tree":
                tx, ty, r, fam = a
                if fam == "snag":
                    ell(m1, tx + 0.7 * r, ty + 0.3 * r, 0.9 * r, 0.12 * r, jit=0.9, rot=0.45)
                    ell(m2, tx + 3, ty + 1, 0.2 * r, 0.1 * r, jit=0.1)
                elif fam == "holly":
                    ell(m1, tx + 0.85 * r, ty + 0.5 * r, 1.25 * r, 0.42 * r, rot=0.55)
                    ell(m2, tx + 3, ty + 1, 0.4 * r, 0.16 * r, jit=0.1)
                else:
                    k = {"elm": (0.75, 0.16, 1.3, 0.44), "magnolia": (0.55, 0.14, 1.0, 0.46)}.get(
                        fam, (0.62, 0.14, 1.12, 0.5))
                    ell(m1, tx + k[0] * r, ty + k[1] * r + 3, k[2] * r, k[3] * r, jit=0.3)
                    ell(m2, tx + 0.3 * r, ty + 2, 0.5 * r, 0.2 * r, jit=0.15)
            elif kind == "shrub":
                cx, cy, r = a
                ell(m1, cx + 0.5 * r, cy + 1, 0.95 * r, 0.45 * r, jit=0.3)
                ell(m2, cx + 0.3 * r, cy, 0.5 * r, 0.22 * r, jit=0.1)
            elif kind == "block":
                x, y, w, d, h = a
                dx, dy = max(2, int(round(h * 0.8))), max(1, int(round(h * 0.45)))
                sh = (xx >= x + dx) & (xx < x + w + dx) & (yy >= y + dy) & (yy < y + d + h + dy)
                m1 |= sh
                m2 |= sh & (xx < x + w + 2) & (yy < y + d + h + 2)
            elif kind == "box":
                x, y, w, h = a
                bx_ = (xx >= x) & (xx < x + w) & (yy >= y) & (yy < y + h)
                m1 |= bx_; m2 |= bx_ & (yy == y)
        mm = self.mound_mask
        m1 |= np.roll(np.roll(mm, 6, 0), 9, 1) & ~mm
        m2 |= np.roll(np.roll(mm, 2, 0), 3, 1) & ~mm
        px, py = POST
        cab = (yy >= py + 1) & (yy <= py + 16) & (xx >= px - 22 + (yy - py) * 1.6) & (xx <= px + 28 + (yy - py) * 1.6)
        mast = (np.abs((xx - (px + 26)) - (yy - py) * 1.6) < 2.2) & (yy > py) & (yy < py + 44)
        m1 |= cab | mast
        m2 |= cab & (yy <= py + 5)
        ell(m1, px + 44, py + 30, 18, 6, jit=0.1)
        ell(m1, px + 98, py + 44, 6, 3, jit=0.1)
        m1 &= (yy >= FACADE_Y1)
        tw = self.L["terrace-walls"]
        stairs = np.zeros((H, W), bool)
        for sx0, sx1 in STAIRS:
            stairs[:, sx0:sx1 + 1] = True
        walls = (tw >= 0) & (yy < FOOT_Y) & (yy >= PAV_Y1) & ~self.mound_mask & ~(stairs & (yy >= EDGE_Y - 2))
        front = (tw >= 0) & (yy < PAV_Y1)
        bad = walls | front | self.piece_mask | self.fixture_mask
        m1 &= ~bad; m2 &= ~bad
        colsh = np.zeros((H, W), bool)
        for (sx, sy, fr) in self.col_shadows:
            colsh |= (yy >= sy) & (yy < fr) & (xx >= sx + (yy - sy) * 0.8 - 1) & (xx < sx + (yy - sy) * 0.8 + 5)
        colsh &= (tw >= 0) & ~np.isin(tw, [I["m0"], I["ink"]])
        m1 |= colsh
        m2 &= m1
        cs[m1] = SHADE_LUT[comp[m1]]
        cs[m2] = SHADE_LUT[SHADE_LUT[comp[m2]]]

    # ------------------------------------------------------------------ guides (hidden, locked layer)
    def guides(self):
        g = self.L["guides"]
        walkable = self.walkable_mask()
        p = np.pad(walkable, 1)
        edge = walkable & (~p[:-2, 1:-1] | ~p[2:, 1:-1] | ~p[1:-1, :-2] | ~p[1:-1, 2:])
        g[edge] = I["gd-walk"]
        b = self.block
        pb = np.pad(b, 1)
        bedge = b & (~pb[:-2, 1:-1] | ~pb[2:, 1:-1] | ~pb[1:-1, :-2] | ~pb[1:-1, 2:])
        g[bedge] = I["gd-block"]
        for (ax, ay), (bx, by) in zip(PATROL, PATROL[1:] + PATROL[:1]):
            n = int(max(abs(bx - ax), abs(by - ay)))
            for t in range(0, n, 3):
                setpx(g, int(ax + (bx - ax) * t / n), int(ay + (by - ay) * t / n), I["gd-route"])
        for name, (x, y) in self.pins().items():
            for k in range(-4, 5):
                setpx(g, x + k, y, I["gd-pin"]); setpx(g, x, y + k, I["gd-pin"])
        for (x, y) in ((40, 700), (452, 296), (827, 296), (640, 300), (1240, 700), (300, 600)):
            rect(g, x, y - 47, x, y, I["gd-tick"])
            for k in range(0, 48, 8):
                rect(g, x - 2, y - k, x + 2, y - k, I["gd-tick"])
            rect(g, x - 3, y - 47, x + 3, y - 47, I["gd-tick"])

    def pins(self):
        return dict(PINS)

    def walkable_mask(self):
        yy = np.arange(H)[:, None]
        wm = self.inner_lawn.copy()
        wm[:FOOT_Y + 4, :] = False
        wm &= ~self.belt
        wm |= self.walk_mask & (yy >= FOOT_Y - EXEDRA_DEPTH - 4)
        wm[FACADE_Y1 + 4:EDGE_Y - BAL_H - 2, :] = True
        for sx0, sx1 in STAIRS:
            wm[EDGE_Y - BAL_H - 2:STAIR_BOT + 1, sx0:sx1 + 1] = True
        wm &= ~self.block
        if hasattr(self, "breach_top"):
            for x, yt in self.breach_top.items():
                wm[yt - 3:FOOT_Y, x] = False
        return wm

    # ------------------------------------------------------------------ build all
    def build(self):
        self.ground_base()
        self.paving()
        self.terrace()
        self.trees()
        self.props()
        self.survey_post()
        self.detail()
        self.shadows()
        self.guides()
        assert (self.L["ground-base"] >= 0).all()
        return self


def visibility_fails(fg, walk, spr, step=4):
    """Foot positions (sampled every `step` px over walkable texels) where fg hides > 2/3 of the actor's texels."""
    sh, sw = spr.shape
    tot = spr.sum()
    out = []
    for y in range(0, H, step):
        for x in range(0, W, step):
            if not walk[y, x]:
                continue
            x0, y0 = x - sw // 2, y - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            if 1 - (fg[y0:y0 + sh, x0:x0 + sw] & spr).sum() / tot < 1 / 3:
                out.append((x, y))
    return out


# ============================================================================ raster output
def to_rgba(idx):
    a = np.zeros((H, W, 4), np.uint8)
    m = idx >= 0
    a[m, :3] = RGB[idx[m]]
    a[m, 3] = 255
    return a


def png_bytes(arr):
    buf = io.BytesIO()
    Image.fromarray(arr, "RGBA").save(buf, "PNG", optimize=False, compress_level=9)
    return buf.getvalue()


def decode(png):
    im = Image.open(io.BytesIO(png))
    return im.mode, im.size, np.array(im.convert("RGBA"))


def composite_rgba(rgba_layers, names):
    out = rgba_layers[names[0]].copy()
    for n in names[1:]:
        m = rgba_layers[n][..., 3] == 255
        out[m] = rgba_layers[n][m]
    return out


def heroine_48():
    """Approved v8 static south idle (96 texels = 48 logical px) sampled at 2:1 for scale overlays only."""
    a = np.array(Image.open(rp(HEROINE_REL)).convert("RGBA"))
    ys, xs = np.nonzero(a[..., 3])
    a = a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = a.shape[:2]
    small = np.array(Image.fromarray(a, "RGBA").resize((max(1, w // 2), h // 2), Image.NEAREST))
    small[..., 3] = np.where(small[..., 3] >= 128, 255, 0)
    return small


def paste(dst, spr, x, ybase):
    h, w = spr.shape[:2]
    x0, y0 = x - w // 2, ybase - h + 1
    for j in range(h):
        for i in range(w):
            if spr[j, i, 3] and 0 <= x0 + i < W and 0 <= y0 + j < H:
                dst[y0 + j, x0 + i] = spr[j, i]


def actor_cases():
    """Foot positions for the heroine-scale stills (behind = north of a sprite's pivot row, front = south)."""
    px, py = POST
    return {"entry": ENTRY, "axis_mid": (640, 520),
            "left_stair_foot": (452, 306), "left_stair_mid": (452, 236), "left_stair_top": (452, 150),
            "right_stair_foot": (812, 306), "right_stair_rubble": (806, 262), "right_stair_top": (827, 150),
            "recess_front": (640, 304), "recess_side": (566, 262), "fountain_behind": (624, 232),
            "fountain_front": (628, 300),
            "newel_behind": (LAMP_X[0] + 9, STAIR_BOT - 8), "newel_front": (LAMP_X[0] + 2, STAIR_BOT + 12),
            "post_behind": (px - 6, py - 24), "post_front": (px - 2, py + 16),
            "portico": (640, 98), "deck_south_wing": (1000, 104), "fallen_tree": (930, 652),
            "lower_left_panel": (330, 610)}


SCALE_CASES = ("entry", "left_stair_mid", "right_stair_rubble", "recess_side", "portico", "post_front",
               "fallen_tree", "axis_mid")
YSORT_CASES = (("post_behind", "survey-post"), ("post_front", "survey-post"),
               ("newel_behind", "stair-lamps-ysort"), ("newel_front", "stair-lamps-ysort"),
               ("fountain_behind", "fountain-ysort"), ("fountain_front", "fountain-ysort"))


def ysort_order(foot_y):
    """Runtime draw order of the Y-sorted sprite layers and the actor: a sprite is drawn before (under) the actor
    when its pivot row <= the actor's foot row, after (over) it otherwise."""
    order = []
    placed = False
    for name, pivot in sorted(YSORT.items(), key=lambda kv: kv[1]):
        if not placed and foot_y < pivot:
            order.append("actor"); placed = True
        order.append(name)
    if not placed:
        order.append("actor")
    return order


def runtime_stack_still(rgba, spr, foot):
    """Runtime draw order proposal: base (layers 1-6 merged) -> Y-sorted {stair lamps, fountain, survey post, actor}
    by pivot row -> fg-occlusion."""
    out = composite_rgba(rgba, BASE_LAYERS)
    for name in ysort_order(foot[1]):
        if name == "actor":
            paste(out, spr, foot[0], foot[1])
        else:
            m = rgba[name][..., 3] == 255
            out[m] = rgba[name][m]
    fg = rgba["fg-occlusion"]
    fm = fg[..., 3] == 255
    out[fm] = fg[fm]
    return out


def camera_rect(foot):
    """640x360 logical camera window centred on the actor's body (foot - 24 rows), clamped to the 1280x720 scene."""
    cx = min(max(int(foot[0]), CAM_W // 2), W - CAM_W // 2)
    cy = min(max(int(foot[1]) - 24, CAM_H // 2), H - CAM_H // 2)
    return cx - CAM_W // 2, cy - CAM_H // 2


def camera_view(still, foot):
    """What the game window shows: the 640x360 logical crop at integer 2x (1280x720), nearest neighbour."""
    x0, y0 = camera_rect(foot)
    return zoom(still[y0:y0 + CAM_H, x0:x0 + CAM_W], 2)


def zoom(arr, k):
    return np.array(Image.fromarray(arr, "RGBA").resize((arr.shape[1] * k, arr.shape[0] * k), Image.NEAREST))


def guide_overlay(flat, guides):
    out = flat.copy()
    m = guides[..., 3] == 255
    out[m] = guides[m]
    return out


# ============================================================================ containers
DT = (2026, 10, 16, 0, 44, 57)


def zput(z, name, payload, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, DT)
    zi.compress_type = method
    z.writestr(zi, payload)


def make_ora(rgba, comp_png):
    stack = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<image version="0.0.5" w="{W}" h="{H}" xres="72" yres="72">', "<stack>"]
    for n in reversed(LAYERS):                                                # ORA lists top first
        vis = "hidden" if n == "guides" else "visible"
        stack.append(f'<layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.000" '
                     f'visibility="{vis}" composite-op="svg:src-over"/>')
    stack += ["</stack>", "</image>", ""]
    thumb = Image.fromarray(comp_png_arr(comp_png), "RGBA").resize((256, 144), Image.NEAREST)
    tb = io.BytesIO(); thumb.save(tb, "PNG")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "mimetype", b"image/openraster", zipfile.ZIP_STORED)
        zput(z, "stack.xml", "\n".join(stack).encode())
        for n in LAYERS:
            zput(z, f"data/{n}.png", png_bytes(rgba[n]))
        zput(z, "mergedimage.png", comp_png)
        zput(z, "Thumbnails/thumbnail.png", tb.getvalue())
    return buf.getvalue()


def comp_png_arr(b):
    return np.array(Image.open(io.BytesIO(b)).convert("RGBA"))


def make_pxo(rgba, comp_png):
    layer_json = [{"animated_params": "Dictionary[String, Dictionary]({\n\"opacity\": {}\n})", "blend_mode": 0,
                   "clipping_mask": False, "effects": [], "locked": n == "guides", "metadata": {}, "name": n,
                   "new_cels_linked": False, "opacity": 1.0, "parent": -1, "type": 0,
                   "ui_color": "(0.0, 0.0, 0.0, 0.0)", "visible": n != "guides"} for n in LAYERS]
    frames_json = [{"cels": [{"metadata": {}, "opacity": 1.0, "ui_color": "(0.0, 0.0, 0.0, 0.0)", "z_index": 0}
                             for _ in LAYERS], "duration": 1.0, "metadata": {}}]
    export_profile = {"crop_mode": "0", "current_tab": "0", "direction": "0", "directory_path": "\"\"",
                      "erase_unselected_area": "false", "export_json": "false", "export_layers": "0",
                      "file_format": "0", "file_name": json.dumps(EXPORT_STEM), "frame_current_tag": "0",
                      "include_tag_in_filename": "false", "interpolation": "0", "lines_count": "1",
                      "new_dir_for_each_frame_tag": "false", "number_of_digits": "4", "number_of_frames": "1",
                      "orientation": "0", "repeat_count": "0", "resize": "100", "save_quality": "0.75",
                      "separator_character": "\"_\"", "sheet_layers_as_separate_files": "false",
                      "split_layers": "false"}
    data = {"author_company": "", "author_contact": "", "author_display_name": "", "author_real_name": "",
            "brushes": [], "color_mode": 5, "current_frame": 0, "current_layer": 0, "export_profile": export_profile,
            "fps": 6.0, "frames": frames_json, "guides": [], "layers": layer_json, "license": "", "metadata": {},
            "next_keyframe_id": 0, "palettes": [], "pixelorama_version": PIXELORAMA_VERSION,
            "project_current_palette_name": "", "pxo_version": 7, "reference_images": [], "size_x": W, "size_y": H,
            "symmetry_points": [W - 1.0, H - 1.0], "tags": [], "tile_mode_x_basis_x": W, "tile_mode_x_basis_y": 0,
            "tile_mode_y_basis_x": 0, "tile_mode_y_basis_y": H, "tilesets": [], "user_data": "",
            "vanishing_points": []}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        zput(z, "data.json", json.dumps(data, separators=(",", ":")))
        zput(z, "mimetype", "application/x-pixelorama")
        zput(z, "preview.png", comp_png)
        zput(z, "image_data/frames/1/", b"")
        for li, n in enumerate(LAYERS, start=1):
            zput(z, f"image_data/frames/1/layer_{li}", np.ascontiguousarray(rgba[n]).tobytes())
            zput(z, f"image_data/frames/1/indices_layer_{li}", b"\x00")
    return buf.getvalue()


def make_gpl():
    lines = ["GIMP Palette", f"Name: {SLUG}_{AREA}_scene-palette_{VER}", "Columns: 9", "#"]
    for n, h in PALETTE:
        r, g, b = (int(h[j:j + 2], 16) for j in (0, 2, 4))
        lines.append(f"{r:3d} {g:3d} {b:3d}\t{n}")
    return ("\n".join(lines) + "\n").encode()


# ============================================================================ metrics and checks
V03_FLAT_REL = (f"game/assets/environments/candidates/{V03_RUN}/rpg-2-star-ocean-the-second_wdc-capitol-west_"
                "scene-flat-art_unapproved-v03_20261015-200031-6c309d6a.png")


def metrics(sc, rgba, flat):
    out = {}
    used = set()
    for n in ART_LAYERS:
        a = rgba[n]
        opaque = a[..., 3] == 255
        semi = (a[..., 3] > 0) & (a[..., 3] < 255)
        cols = {tuple(c) for c in a[opaque][:, :3].tolist()} if opaque.any() else set()
        used |= cols
        out[n] = {"opaque_texels": int(opaque.sum()), "semi_alpha_texels": int(semi.sum()),
                  "distinct_colours": len(cols),
                  "colours_outside_art_palette": len(cols - {tuple(RGB[i].tolist()) for i in range(N_ART)})}
    flat_cols = {tuple(c) for c in flat[..., :3].reshape(-1, 3).tolist()}
    idx = flat_index(flat)
    p = np.pad(idx, 1, mode="edge")
    iso = (idx != p[:-2, 1:-1]) & (idx != p[2:, 1:-1]) & (idx != p[1:-1, :-2]) & (idx != p[1:-1, 2:])
    walk = sc.walkable_mask()
    fg = rgba["fg-occlusion"][..., 3] == 255
    spr = heroine_48()
    sm = spr[..., 3] == 255
    sh, sw = sm.shape
    worst, fails, tested = 1.0, 0, 0
    worst_at = None
    for y in range(0, H, 4):
        for x in range(0, W, 4):
            if not walk[y, x]:
                continue
            x0, y0 = x - sw // 2, y - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            cov = fg[y0:y0 + sh, x0:x0 + sw] & sm
            vis = 1 - cov.sum() / sm.sum()
            tested += 1
            if vis < worst:
                worst, worst_at = vis, (x, y)
            if vis < 1 / 3:
                fails += 1
    basin_cols = idx[sc.fountain_basin | sc.fountain_mask]
    out["_summary"] = {
        "art_palette_size": N_ART, "distinct_colours_in_flat": len(flat_cols),
        "distinct_colours_all_art_layers": len(used),
        "isolated_single_texels_in_flat": int(iso.sum()),
        "isolated_single_texel_ratio": round(float(iso.mean()), 5),
        "v03_isolated_single_texel_ratio": 0.0503,
        "walkable_texels": int(walk.sum()),
        "fg_occlusion_over_walkable_ratio": round(float((fg & walk).sum() / walk.sum()), 4),
        "fg_limit_ratio": 0.12,
        "actor_visibility_samples": tested, "actor_visibility_worst": round(float(worst), 3),
        "actor_visibility_worst_at_foot": worst_at, "actor_visibility_below_one_third": fails,
        "heroine_overlay_px": [int(sw), int(sh)],
        "survey_post_height_px": int(np.ptp(np.nonzero(sc.post_mask.any(axis=1))[0]) + 1),
        "water_colour_texels_in_fountain_footprint": int(np.isin(basin_cols, list(WATER)).sum()),
        "fountain_footprint_texels": int((sc.fountain_basin | sc.fountain_mask).sum()),
        "lawn_texels": int(sc.lawn.sum()), "quadrats": len(sc.quadrats), "lawn_shrub_clumps": len(sc.lawn_shrubs),
        "trees": len(sc.tree_list), "trees_dropped_by_visibility_rule": sc.trees_dropped_for_visibility,
        "tall_base_layer_items_registered": len(sc.tall_items),
    }
    return out


def flat_index(flat):
    lut = {tuple(RGB[i].tolist()): i for i in range(len(ALL_PAL))}
    fl = flat[..., :3].reshape(-1, 3)
    keys = fl[:, 0].astype(np.int64) * 65536 + fl[:, 1].astype(np.int64) * 256 + fl[:, 2]
    uk, inv = np.unique(keys, return_inverse=True)
    m = np.array([lut.get(((k >> 16) & 255, (k >> 8) & 255, k & 255), -1) for k in uk.tolist()], np.int32)
    return m[inv].reshape(flat.shape[:2])


def ysort_ground(sc, rgba):
    """Per-texel ground-contact row of each Y-sorted layer (newels: STAIR_BOT; fountain pedestal: its pivot, the
    self-sown tree: its trunk base; survey post: POST y)."""
    g = {}
    for n in YSORT:
        m = rgba[n][..., 3] == 255
        a = np.full((H, W), -1, np.int32)
        a[m] = YSORT[n]
        g[n] = a
    t = sc.fountain_tree_mask & (rgba["fountain-ysort"][..., 3] == 255)
    g["fountain-ysort"][t] = sc.fountain_tree[1]
    return g


def ysort_check(sc, rgba):
    """Representative behind/front stills for each Y-sorted layer: behind -> the sprite covers the actor where they
    overlap; front -> the actor is on top."""
    spr = heroine_48()
    res = {}
    for name, layer in YSORT_CASES:
        foot = actor_cases()[name]
        still = runtime_stack_still(rgba, spr, foot)
        act = np.zeros((H, W, 4), np.uint8)
        paste(act, spr, foot[0], foot[1])
        am = act[..., 3] == 255
        sm = rgba[layer][..., 3] == 255
        overlap = am & sm & ~(rgba["fg-occlusion"][..., 3] == 255)
        walkable = bool(sc.walkable_mask()[foot[1], foot[0]])
        if not overlap.any():
            res[name] = {"foot": list(foot), "layer": layer, "overlap_texels": 0, "foot_walkable": walkable,
                         "ok": False}
            continue
        shows_actor = (still[overlap] == act[overlap]).all(axis=1)
        shows_sprite = (still[overlap] == rgba[layer][overlap]).all(axis=1)
        exp_actor = name.endswith("_front")
        res[name] = {"foot": list(foot), "layer": layer, "pivot_y": YSORT[layer], "foot_walkable": walkable,
                     "overlap_texels": int(overlap.sum()),
                     "actor_on_top_texels": int(shows_actor.sum()), "sprite_on_top_texels": int(shows_sprite.sum()),
                     "ok": walkable and (bool(shows_actor.all()) if exp_actor else bool(shows_sprite.all()))}
    return res


def _feet_near(mask, sh, sw):
    """Feet (fx, fy) whose actor box (rows fy-sh+1..fy, cols fx-sw//2..fx-sw//2+sw-1) can touch `mask`."""
    c = np.pad(mask.astype(np.int32), ((sh, sh), (sw, sw))).cumsum(0).cumsum(1)
    ys = np.arange(H)[:, None]
    xs = np.arange(W)[None, :]
    y0, y1 = ys - sh + 1 + sh, ys + sh + 1
    x0, x1 = xs - sw // 2 + sw, xs - sw // 2 + sw + sw
    s = c[y1 - 1, x1 - 1] - c[y0 - 1, x1 - 1] - c[y1 - 1, x0 - 1] + c[y0 - 1, x0 - 1]
    return s > 0


def depth_audit(sc, rgba):
    """Exhaustive over every walkable foot (1 px steps).
    (a) Y-sorted layers: at runtime the actor is drawn over a sprite iff foot y >= the layer pivot. For each sprite
        texel with ground row g, the correct answer is 'actor over it' iff foot y >= g. Count feet whose 48 px actor
        overlaps a texel where the two disagree (newels, fountain pedestal + self-sown tree, survey post).
    (b) base-layer tall items (props, trunks, rubble, fallen urns...): the actor is always drawn over them, so any
        overlap with a texel whose ground row is south of the foot (g > foot y) is a wrong-order texel.
    (c) deck urns: no walkable foot north of an urn's base may overlap it (they are base-layer)."""
    spr = heroine_48()
    sm_ = spr[..., 3] == 255
    sh, sw = sm_.shape
    walk = sc.walkable_mask()
    res = {}
    yg = ysort_ground(sc, rgba)
    for n in YSORT:
        lm = rgba[n][..., 3] == 255
        G = yg[n]
        piv = YSORT[n]
        cand = _feet_near(lm, sh, sw) & walk
        fys, fxs = np.nonzero(cand)
        overl = wrong_feet = worst = 0
        for fy, fx in zip(fys.tolist(), fxs.tolist()):
            x0, y0 = fx - sw // 2, fy - sh + 1
            if x0 < 0 or y0 < 0 or x0 + sw > W:
                continue
            ov = lm[y0:y0 + sh, x0:x0 + sw] & sm_
            if not ov.any():
                continue
            overl += 1
            gw = G[y0:y0 + sh, x0:x0 + sw][ov]
            actor_over = fy >= piv
            bad = int(((gw > fy) & actor_over).sum() + ((gw <= fy) & (not actor_over)).sum())
            if bad:
                wrong_feet += 1
                worst = max(worst, bad)
        res[n] = {"pivot_y": piv, "overlapping_feet": overl, "feet_with_wrong_order": wrong_feet,
                  "worst_wrong_texels": worst}
    T = sc.tall_mask
    G = sc.tall_ground
    cand = _feet_near(T, sh, sw) & walk
    fys, fxs = np.nonzero(cand)
    overl = wrong_feet = worst = 0
    worst_item = None
    for fy, fx in zip(fys.tolist(), fxs.tolist()):
        x0, y0 = fx - sw // 2, fy - sh + 1
        if x0 < 0 or y0 < 0 or x0 + sw > W:
            continue
        ov = T[y0:y0 + sh, x0:x0 + sw] & sm_
        if not ov.any():
            continue
        overl += 1
        bad = int((G[y0:y0 + sh, x0:x0 + sw][ov] > fy).sum())
        if bad:
            wrong_feet += 1
            if bad > worst:
                worst, worst_item = bad, (fx, fy)
    res["base_layer_tall_items"] = {"items": len(sc.tall_items), "overlapping_feet": overl,
                                    "feet_with_wrong_order": wrong_feet, "worst_wrong_texels": worst,
                                    "worst_foot": worst_item}
    urn_viol = urn_checked = 0
    fixture = np.zeros((H, W), bool)
    for (ux0, uy0, ux1, uy1) in sc.urn_boxes:
        fixture[uy0:uy1 + 1, ux0:ux1 + 1] = True
    fixture &= sc.fixture_mask & (rgba["terrace-walls"][..., 3] == 255)
    for (ux0, uy0, ux1, uy1) in sc.urn_boxes:
        for fy in range(max(0, uy0 - 2), min(H, uy1 + sh)):
            for fx in range(max(0, ux0 - sw), min(W, ux1 + sw)):
                if not walk[fy, fx] or fy >= uy1:
                    continue
                x0, y0 = fx - sw // 2, fy - sh + 1
                if x0 < 0 or y0 < 0 or x0 + sw > W:
                    continue
                urn_checked += 1
                if (fixture[y0:y0 + sh, x0:x0 + sw] & sm_)[max(0, uy0 - y0):, :].any():
                    urn_viol += 1
    res["urns"] = {"urns": len(sc.urn_boxes), "feet_north_of_base_checked": urn_checked,
                   "feet_overlapping_from_behind": urn_viol}
    res["ok"] = all(res[n]["feet_with_wrong_order"] == 0 for n in YSORT) and \
        res["base_layer_tall_items"]["feet_with_wrong_order"] == 0 and urn_viol == 0 and \
        all(res[n]["overlapping_feet"] > 0 for n in YSORT)
    return res


def path_checks(sc):
    """Reachability from the entry over the walkable mask (4-connected flood fill) and over the mask eroded to an
    11 px foot width; minimum clear widths on each stair, on both sides of the fountain and along the axis."""
    walk = sc.walkable_mask()
    feet = walk.copy()
    for k in range(1, 6):
        feet[:, k:] &= walk[:, :-k]
        feet[:, :-k] &= walk[:, k:]
    out = {}
    for label, m in (("raw", walk), ("foot11", feet)):
        im = Image.fromarray((m * 255).astype(np.uint8)).copy()      # copy: a numpy-backed image ignores writes
        ImageDraw.floodfill(im, ENTRY, 128)
        reach = np.array(im) == 128
        out[label] = {k: bool(reach[y, x]) for k, (x, y) in sc.pins().items() if k != "survey_post_pivot"}
    widths = {}
    for si, (sx0, sx1) in enumerate(STAIRS):
        runs = []
        for y in range(EDGE_Y - BAL_H, STAIR_BOT + 1):
            row = walk[y, sx0 - 2:sx1 + 3]
            best = cur = 0
            for v in row:
                cur = cur + 1 if v else 0
                best = max(best, cur)
            runs.append(best)
        widths[f"stair_{'left' if si == 0 else 'right'}_min_clear_px"] = int(min(runs))
    fx, fy = FOUNTAIN
    lw, rw = [], []
    for y in range(fy - FOUNTAIN_HALF[1], fy + FOUNTAIN_HALF[1] + FOUNTAIN_FACE):
        xs = np.nonzero(sc.fountain_mask[y])[0]
        if not len(xs):
            continue
        lw.append(int(walk[y, EXEDRA[0]:xs.min()].sum()))
        rw.append(int(walk[y, xs.max() + 1:EXEDRA[1] + 1].sum()))
    widths["fountain_west_side_min_clear_px"] = min(lw)
    widths["fountain_east_side_min_clear_px"] = min(rw)
    widths["axis_min_clear_px"] = int(min(walk[y, AXIS[0]:AXIS[1] + 1].sum() for y in range(FORE[3] + 1, H)))
    out["widths"] = widths
    out["ok"] = all(out["foot11"].values()) and widths["stair_left_min_clear_px"] >= 40 and \
        widths["stair_right_min_clear_px"] >= 40 and widths["fountain_west_side_min_clear_px"] >= 32 and \
        widths["fountain_east_side_min_clear_px"] >= 32
    return out


def repetition_stats(flat, rows=None, size=16, stride=2, min_colours=4):
    """Share of informative size x size windows (>= min_colours distinct colours, sampled every `stride` px) whose
    exact content recurs elsewhere in the region at least `size` px away (a copy-paste / stamp signature)."""
    idx = flat_index(flat)
    if rows:
        idx = idx[rows[0]:rows[1]]
    idx = (idx + 1).astype(np.uint8)
    win = np.lib.stride_tricks.sliding_window_view(idx, (size, size))[::stride, ::stride]
    gy, gx = win.shape[:2]
    flatw = win.reshape(gy * gx, size * size)
    srt = np.sort(flatw, axis=1)
    ncol = 1 + (np.diff(srt.astype(np.int16), axis=1) != 0).sum(axis=1)
    inf = ncol >= min_colours
    rng = np.random.default_rng(12345)
    w1 = rng.random(size * size); w2 = rng.random(size * size)
    h1 = flatw @ w1; h2 = flatw @ w2
    keys = np.round(h1, 6) * 1e3 + np.round(h2, 6)
    pos_y = np.repeat(np.arange(gy) * stride, gx); pos_x = np.tile(np.arange(gx) * stride, gy)
    order = np.argsort(keys[inf], kind="stable")
    k_ = keys[inf][order]; py_ = pos_y[inf][order]; px_ = pos_x[inf][order]
    rep = np.zeros(len(k_), bool)
    start = 0
    for i in range(1, len(k_) + 1):
        if i == len(k_) or k_[i] != k_[start]:
            if i - start > 1:
                if np.ptp(py_[start:i]) >= size or np.ptp(px_[start:i]) >= size:
                    rep[start:i] = True
            start = i
    return {"windows": int(inf.sum()), "repeated_windows": int(rep.sum()),
            "repeated_share": round(float(rep.mean()) if len(rep) else 0.0, 4)}


def activity_by_window(sc):
    """Ruin and survey items per 640x360 camera quadrant (the v03 review found both concentrated top-right)."""
    ruin_names = ("rubble", "fallen-urn", "uprooted-tree", "lamp-lying", "lamp-head", "deck-debris", "deck-drum",
                  "lamp-stub")
    survey_names = ("crate", "kit", "flag", "beacon", "sensor", "relay", "stake")
    q = {k: {"ruin": 0, "survey": 0} for k in ("top_left", "top_right", "bottom_left", "bottom_right")}

    def quad(x, y):
        return ("top" if y < CAM_H else "bottom") + "_" + ("left" if x < CAM_W else "right")
    for (name, x0, y0, x1, y1) in sc.tall_items:
        n0 = name[0] if isinstance(name, tuple) else name
        cx, cy = (x0 + x1) / 2, y1
        if n0 in ruin_names:
            q[quad(cx, cy)]["ruin"] += 1
        elif n0 in survey_names:
            q[quad(cx, cy)]["survey"] += 1
    q[quad(*POST)]["survey"] += 1
    for (x, y) in sc.quadrats:
        q[quad(x, y)]["survey"] += 1
    q[quad(*FOUNTAIN)]["ruin"] += 1
    q[quad(*FALLEN_TREE[0])]["ruin"] += 0
    q[quad(*sc.sinkhole)]["ruin"] += 1
    q[quad((SLUMP[0] + SLUMP[1]) / 2, EDGE_Y)]["ruin"] += 1
    q[quad((COLLAPSE[0] + COLLAPSE[1]) / 2, EDGE_Y)]["ruin"] += 1
    return q


# ============================================================================ build artefacts
def artefacts():
    sc = Scene().build()
    rgba = {n: to_rgba(sc.L[n]) for n in LAYERS}
    flat = composite_rgba(rgba, ART_LAYERS)
    flat_png = png_bytes(flat)
    files = {"pxo": make_pxo(rgba, flat_png), "ora": make_ora(rgba, flat_png), "flat": flat_png,
             "gpl": make_gpl()}
    return sc, rgba, flat, files


def names():
    return {"pxo": fname("scene-editable-11layer", "pxo"), "ora": fname("scene-editable-11layer", "ora"),
            "flat": fname("scene-flat-art", "png"), "gpl": fname("scene-palette", "gpl"),
            "manifest": fname("scene-manifest", "json"), "walk": fname("scene-walkability", "json")}


def walkability_json(sc):
    wm = sc.walkable_mask()
    cell = 8
    rows = []
    for gy in range(0, H, cell):
        r = ""
        for gx in range(0, W, cell):
            blk = wm[gy:gy + cell, gx:gx + cell]
            r += "." if blk.mean() >= 0.5 else "#"
        rows.append(r)
    px, py = POST
    return {"status": "UNAPPROVED candidate data derived from the guides layer; not runtime-integrated",
            "run": RUN, "canvas": [W, H], "cell_px": cell,
            "grid_legend": {".": "walkable (>=50% of cell)", "#": "blocked"},
            "grid": rows, "pins": {k: list(v) for k, v in sc.pins().items()},
            "survey_post": {"pivot_base_centre": [px, py], "footprint_xyxy": [px - 25, py - 10, px + 24, py],
                            "y_sort_rule": "actor foot y < pivot y -> drawn behind the post; else in front"},
            "stair_lamps_ysort": {
                "layer": "stair-lamps-ysort", "pivot_y": YSORT["stair-lamps-ysort"],
                "newel_boxes_xyxy": [list(map(int, b)) for b in sc.newel_boxes], "lamp_centre_x": list(LAMP_X),
                "y_sort_rule": "one shared pivot row for all four newels (their common ground-contact row)"},
            "fountain_ysort": {
                "layer": "fountain-ysort", "pivot_y": YSORT["fountain-ysort"],
                "basin_centre": list(FOUNTAIN), "basin_half_extents": list(FOUNTAIN_HALF),
                "y_sort_rule": "pedestal + self-sown tree share one pivot; the basin coping and a "
                               f"{FOUNTAIN_COLLAR} px collar are no-walk, so every reachable foot is clearly north "
                               "(behind) or south (in front) of both"},
            "documented_no_walk_collision": {
                "why": "feet level with a newel, hugging a cheek wall, on the deck behind a base-layer urn, inside "
                       "the fountain collar, or north of any base-layer item's ground row within its height (props, "
                       "trunks, rubble, fallen urns) would put the actor at a wrong depth; those texels are blocked",
                "newel_collar_px": NEWEL_COLLAR, "cheek_collar_px": CHEEK_COLLAR, "fountain_collar_px": FOUNTAIN_COLLAR,
                "item_collar_rule": "per item column: rows [top, ground-1], widened 10 px (actor half width) each side",
                "terrace_collar_texels": int(sc.newel_collar.sum()), "item_collar_texels": int(sc.collar.sum()),
                "urn_boxes_xyxy": [list(map(int, b)) for b in sc.urn_boxes],
                "note": "the 8 px grid under-resolves these collars; use the guides layer (red outlines)"},
            "ysort_draw_order": "base layers 1-6 merged -> {stair-lamps-ysort, fountain-ysort, survey-post, actors} "
                                "sorted by pivot row -> fg-occlusion",
            "patrol_route_loop": [list(p) for p in PATROL],
            "cordon_stakes": [list(p) for p in sc.cordon]}


ZOOM3_CROPS = {"facade-central-pavilion": (440, 0, 840, 112), "facade-south-wing": (820, 0, 1280, 112),
               "facade-north-wing": (0, 0, 470, 112), "left-stair-ivy": (370, 100, 560, 330),
               "right-stair-rubble": (740, 100, 960, 330), "exedra-dry-fountain": (500, 96, 780, 320),
               "collapse-south": (900, 110, 1180, 370), "slump-north": (100, 100, 330, 290),
               "post-focal": (340, 330, 600, 560), "lower-right-fallen-tree": (660, 420, 1080, 720),
               "left-belt": (0, 200, 300, 560), "right-belt": (1000, 300, 1280, 720)}


def previews(sc, rgba, flat):
    """QA views, each its own image (no combined collage or side-by-side comparison)."""
    spr = heroine_48()
    out = {}
    scale = flat.copy()
    for k in SCALE_CASES:
        paste(scale, spr, *actor_cases()[k])
    out["preview-heroine48-scale"] = scale
    out["preview-guides-overlay"] = guide_overlay(flat, rgba["guides"])
    for name, foot in actor_cases().items():
        st = runtime_stack_still(rgba, spr, foot)
        tag = name.replace("_", "-")
        out["still-" + tag] = st
        out["cam2x-" + tag] = camera_view(st, foot)
    for qn, (x0, y0) in (("tl", (0, 0)), ("tr", (CAM_W, 0)), ("bl", (0, CAM_H)), ("br", (CAM_W, CAM_H))):
        out["cam2x-quad-" + qn] = zoom(flat[y0:y0 + CAM_H, x0:x0 + CAM_W], 2)
    for name in ("newel_behind", "newel_front", "fountain_behind", "fountain_front"):
        foot = actor_cases()[name]
        st = out["still-" + name.replace("_", "-")]
        x0, y0 = max(0, foot[0] - 80), max(0, foot[1] - 90)
        out["zoom4x-runtime-" + name.replace("_", "-")] = zoom(st[y0:y0 + 130, x0:x0 + 170], 4)
    for k, (x0, y0, x1, y1) in ZOOM3_CROPS.items():
        out[f"zoom3x-{k}"] = zoom(flat[y0:y1, x0:x1], 3)
    v03 = np.array(Image.open(rp(V03_FLAT_REL)).convert("RGBA"))                # read-only reference
    for qn, (x0, y0) in (("tl", (0, 0)), ("tr", (CAM_W, 0)), ("bl", (0, CAM_H)), ("br", (CAM_W, CAM_H))):
        out["v03ref-cam2x-quad-" + qn] = zoom(v03[y0:y0 + CAM_H, x0:x0 + CAM_W], 2)
    return out


def write_new(path, data):
    if os.path.exists(_fs(path)):
        if read_bytes(path) != data:
            raise SystemExit(f"refusing to overwrite a different existing file: {path}")
        return "unchanged"
    with open(_fs(path), "xb") as f:
        f.write(data)
    return "written"


def tree_family_counts(sc):
    c = {}
    for *_, fam in sc.tree_list:
        c[fam] = c.get(fam, 0) + 1
    return c


def manifest(sc, rgba, flat, files, met):
    nm = names()
    return {
        "project": SLUG, "area": "washington-capitol-west-grounds", "run": RUN, "version": "v04",
        "status": "UNAPPROVED exploration-scene candidate (test-only). Not accepted art, not runtime-integrated. "
                  "Acceptance is creator review only; science scene art stays 0/11.",
        "art_approved": False, "runtime_integrated": False, "counters_changed": False,
        "supersedes_nothing": f"v01-v03 are kept untouched; v04 is a parallel candidate. v03 = {V03_RUN}.",
        "authoring_route": {
            "method": "deterministic Python tool authored and run by Claude (Claude Code, claude.ai Max, firstParty); "
                      "writes a native pxo_version 7 .pxo with 11 named layers",
            "pixelorama_gui_paint_pass": False,
            "deviation": "the 2026-10-15 Workstream-B dispatch asked for image edits in the Pixelorama GUI; this "
                         "session had no desktop/computer-use access to the GUI, so v04 is NOT a GUI paint pass. The "
                         "v04 changes are hand-authored placement tables (facade bay states, per-tree list, per-block "
                         "rubble, paving damage, lawn patches, props) rendered with the v03 material painters. A "
                         "creator decision is needed on whether this route is acceptable or a GUI pass must follow.",
            "no_image_generation_model": True, "no_reference_pasted": True},
        "inputs": {"brief": BRIEF_REL, "v04_layer_plan": V04_PLAN_REL, "v03_qa": V03_QA_REL,
                   "previous_tool": V03_TOOL_REL, "spec": SPEC_REL, "site_audit": AUDIT_REL},
        "canvas": {"w": W, "h": H, "texel": "1 authored texel = 1 logical px; nearest-neighbour only",
                   "gameplay_camera": "game/project.godot viewport 640x360 logical, window 1280x720 (integer 2x); "
                                      "camera640x360 previews crop the scene round the heroine and show it at 2x",
                   "camera": "top-down, mild 3/4 front faces; top = east (Capitol west front), bottom = west",
                   "light": "from the upper left; cast shadows fall to the lower right in two opaque steps",
                   "scale_reference": {"file": HEROINE_REL, "logical_height_px": 48}},
        "v04_changes_vs_v03": [
            "vertical re-layout so the architecture fills the upper 640x360 camera windows: facade band 40 -> 60 rows, "
            "terrace wall 42 -> 74 px, deck edge at row 146, stairs to row 300",
            "West Front: main floor with alternating triangular/segmental pediments over a rusticated arcade basement, "
            "belt course and plinth; central pavilion with four PAIRS of columns, loggia openings and five basement "
            "arches (bronze-door centre); wing pavilions with engaged columns; every bay, arch and column condition "
            "hand-assigned (FACADE_BAYS, WING_PAV_*, PAVILION_*), hand-placed spalls/missing blocks and scorch tongues",
            "terrace wall face carries terrace-room windows, each bay with its own condition (WALL_WINDOWS)",
            "TWIN side stairs (two flights + landing each) replace the single central stair; they frame a curved "
            "EXEDRA with three blind niches (centre: dry lion-mask spout with an algae stain) and a DRY octagonal "
            "granite-rimmed fountain planted out with box, grasses and a self-sown tree (new Y-sorted layer)",
            "stairs differ: left mostly intact with joint grass, ivy on the outer cheek, two chipped nosings, one "
            "missing baluster; right with two displaced treads, soot, a rubble spill on its outer third and a fallen "
            "urn on its outer landing pier, keeping a >= 40 px clear lane",
            "four newels with candelabra (states: intact, intact, globe missing, snapped with the head lying by the "
            "stair foot)",
            "ruin and survey spread across the frame: survey post moved to the left lawn panel; narrower collapse on "
            "the right; a second smaller slump with a fallen urn on the left; uprooted oak, toppled walk lamp, "
            "scorched ring and a settled section on the axis, sinkhole on the forecourt in the lower half; survey "
            "transect across the centre; pin flags on the right panel; relay box and strain sensors at the collapse",
            "trees: 24 hand-placed trees (TREES table) instead of a random jittered grid; rubble: 38 hand-listed pieces "
            "(RUBBLE) plus 7 at the slump instead of 74 random; lawn: hand-placed damp hollows / dry crowns, scuffs, "
            "clover, wildflower drifts and shrub clumps",
            "depth: every base-layer item taller than the ground (props, trunks, rubble, fallen urns, fallen tree) is "
            "registered with its ground row and a documented no-walk collar; an exhaustive depth audit is gated",
            "QA: every view is a separate image, incl. 640x360 camera windows at 2x; v03 quadrant crops are written as "
            "separate read-only reference images (no combined comparison image)"],
        "site_fidelity": {
            "source_backed_cues": [
                "twin grand stairs either side of a curved recess with an octagonal granite-rimmed fountain on the lower "
                "west terrace (visitthecapitol.gov architectural-features page, fetched 2026-10-15 for v03; AOC 2024 "
                "West Front photograph cited in the v04 brief). Here drawn DRY and overgrown (no water rule)",
                "bronze urns on balustrade piers (18 urns, Schultz Co., 1890; v03 sources); which piers carry urns is "
                "not measured",
                "terrace walls of marble on a granite rubble foundation (exposed in the collapse and the slump)",
                "rusticated basement arcade with the main floor above, paired columns at the central west front: "
                "arrangement cue only, NOT a measured elevation"],
            "invented_compressions": [
                "stairs drawn perpendicular to the wall so they read top-down (the real grand stairs rise along the "
                "wall); this is a documented invention",
                "terrace wall 74 px (~2.7 m at 27 px/m) against a real ~20 ft; facade shows only two storeys",
                "fountain size, niche count, exedra depth, window counts: arrangement cues, unmeasured",
                "terrace-room windows in the wall face: cue for the Olmsted terrace rooms, positions invented"],
            "deliberately_absent": ["any water", "dome (separate establishing view proposed)", "Summerhouse",
                                    "western road loop", "Reflecting Pool"],
            "game_fiction": ["collapse (right) and slump (left)", "broken wing column and its drum on the deck",
                             "scorch on the south wing", "faded bunting", "storm damage, uprooted oak, toppled lamp",
                             "survey post, kit, transect, flags, sensors, relay, cordon, beacons", "overgrowth"]},
        "layers_bottom_to_top": [
            {"index": i + 1, "name": n, "visible": n != "guides", "locked": n == "guides",
             "runtime_export": {"survey-post": "separate Y-sorted sprite, pivot = base centre " + str(list(POST)),
                                "stair-lamps-ysort": "separate Y-sorted sprite layer (four newels + candelabra), "
                                                     "pivot row y = " + str(YSORT["stair-lamps-ysort"]),
                                "fountain-ysort": "separate Y-sorted sprite layer (pedestal + self-sown tree), pivot "
                                                  "row y = " + str(YSORT["fountain-ysort"]),
                                "fg-occlusion": "separate overlay above actors",
                                "guides": "never exported"}.get(n, "merged into base"),
             **{k: v for k, v in met.get(n, {}).items()}} for i, n in enumerate(LAYERS)],
        "palette": [{"name": n, "hex": "#" + h} for n, h in PALETTE],
        "guide_palette": [{"name": n, "hex": "#" + h} for n, h in GUIDE_PALETTE],
        "metrics": met["_summary"],
        "files_sha256_bytes": {nm[k]: sha(v) for k, v in files.items()},
        "survey_post": {"pivot_base_centre": list(POST), "height_px": met["_summary"]["survey_post_height_px"],
                        "height_vs_actor": round(met["_summary"]["survey_post_height_px"] / 48, 2)},
        "tree_belts": {"trees": len(sc.tree_list), "families": tree_family_counts(sc),
                       "dropped_by_actor_visibility_rule": sc.trees_dropped_for_visibility},
        "tool": {"file": TOOL_REL, "sha256_text_lf_v1": sha_text(read_bytes(os.path.abspath(__file__))),
                 "python": sys.version.split()[0], "pillow": Image.__version__, "numpy": np.__version__},
    }


def build(preview_dir=None):
    sc, rgba, flat, files = artefacts()
    met = metrics(sc, rgba, flat)
    met["_ysort"] = ysort_check(sc, rgba)
    met["_depth"] = depth_audit(sc, rgba)
    met["_paths"] = path_checks(sc)
    met["_repetition"] = {"v04_flat": repetition_stats(flat), "v04_facade_band_rows_0_72": repetition_stats(
        flat, (0, PAV_Y1)),
        "v04_fg_occlusion_layer": repetition_stats(rgba["fg-occlusion"])}
    met["_activity"] = activity_by_window(sc)
    pv = previews(sc, rgba, flat)
    if preview_dir:
        os.makedirs(preview_dir, exist_ok=True)
        Image.fromarray(flat, "RGBA").save(os.path.join(preview_dir, "flat.png"))
        for k, a in pv.items():
            Image.fromarray(a, "RGBA").save(os.path.join(preview_dir, k + ".png"))
        for n in LAYERS:
            Image.fromarray(rgba[n], "RGBA").save(os.path.join(preview_dir, f"layer-{n}.png"))
        print(json.dumps({k: met[k] for k in ("_summary", "_ysort", "_depth", "_paths", "_repetition",
                                              "_activity")}, indent=1, default=str))
        return 0
    sc2, rgba2, flat2, files2 = artefacts()
    if files2 != files:
        raise SystemExit("build is not deterministic")
    cand, out = rp(CAND_REL), rp(OUT_REL)
    os.makedirs(_fs(cand), exist_ok=True)
    os.makedirs(_fs(out), exist_ok=True)
    nm = names()
    for k in ("pxo", "ora", "flat", "gpl"):
        print(write_new(os.path.join(cand, nm[k]), files[k]), nm[k])
    wj = (json.dumps(walkability_json(sc), indent=1) + "\n").encode()
    files["walk"] = wj
    print(write_new(os.path.join(cand, nm["walk"]), wj), nm["walk"])
    man = manifest(sc, rgba, flat, files, met)
    for k in ("_ysort", "_depth", "_paths", "_repetition", "_activity"):
        man[k.strip("_") + "_check"] = met[k]
    man["qa_previews_dir"] = OUT_REL
    print(write_new(os.path.join(cand, nm["manifest"]), (json.dumps(man, indent=2, default=str) + "\n").encode()),
          nm["manifest"])
    for k, a in pv.items():
        print(write_new(os.path.join(out, fname(k, "png")), png_bytes(a)), k)
    return 0


# ============================================================================ Pixelorama gate (isolated APPDATA)
def snapshot_dir(root):
    snap = {}
    if root and os.path.isdir(root):
        for d, _, fs in os.walk(root):
            for f in fs:
                p = os.path.join(d, f)
                try:
                    st = os.stat(p)
                    snap[os.path.relpath(p, root).replace("\\", "/")] = (st.st_size, st.st_mtime_ns)
                except OSError:
                    snap[os.path.relpath(p, root).replace("\\", "/")] = None
    return snap


def run_isolated(exe, args, fake_appdata, real_root):
    """Run Pixelorama headless with APPDATA pointed at a temp dir. Kill-switch: if anything in the real
    %APPDATA%\\pixelorama other than the GUI's own .running heartbeat changes, or .running disappears, kill at once."""
    env = dict(os.environ)
    env["APPDATA"] = fake_appdata
    before = snapshot_dir(real_root)
    t0 = time.time()
    p = subprocess.Popen([exe, "--headless", "--quit", "--"] + args, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    killed, saw_fake_user_dir, marker_missing = False, False, False
    while p.poll() is None:
        now = snapshot_dir(real_root)
        changed = {k for k in set(before) | set(now) if before.get(k) != now.get(k) and k != ".running"}
        if ".running" in before and ".running" not in now:
            marker_missing = True
        if changed or marker_missing:
            p.kill(); killed = True
            break
        if os.path.isdir(os.path.join(fake_appdata, "pixelorama")):
            saw_fake_user_dir = True
        if time.time() - t0 > 240:
            p.kill(); killed = True
            break
        time.sleep(0.01)
    so, se = p.communicate()
    after = snapshot_dir(real_root)
    noise = ("shader_compiler", "custom_samplers", "Condition \"!actions")
    tail = [l for l in so.splitlines() + se.splitlines() if l.strip() and not any(s in l for s in noise)]
    return {"args": [os.path.basename(a) if os.path.isabs(a) else a for a in args], "exit_code": p.returncode,
            "seconds": round(time.time() - t0, 1), "killed_by_guard": killed,
            "fake_user_dir_created": saw_fake_user_dir or os.path.isdir(os.path.join(fake_appdata, "pixelorama")),
            "real_dir_changed_except_running": sorted(k for k in set(before) | set(after)
                                                      if before.get(k) != after.get(k) and k != ".running"),
            "real_running_marker_present_after": ".running" in after, "output_tail": tail[-5:]}


def list_pngs(d):
    return sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))


V03_SHA256 = {  # bytes, recorded in the v03 manifest / v04 plan section 3 and re-hashed before v04 work began
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-editable-10layer_unapproved-v03_20261015-200031-6c309d6a.pxo":
        "1e3e9e9bd0361cdb51f37ec9475b38e162918391acec4b1e145d254e0ab83ffc",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-editable-10layer_unapproved-v03_20261015-200031-6c309d6a.ora":
        "55da5d6b79a2928799bbc8fe250014fa600b77c23bf959137f0e5d2d46a43f6f",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-flat-art_unapproved-v03_20261015-200031-6c309d6a.png":
        "28edf567e3440699879442da045adb9ec0a825dc3dafa6853de55a037955f441",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-palette_unapproved-v03_20261015-200031-6c309d6a.gpl":
        "367b67813c6fbf46cb3d3731fbdeaa26703139bd3b55a99562d18fcf03d7fa04",
    "rpg-2-star-ocean-the-second_wdc-capitol-west_scene-walkability_unapproved-v03_20261015-200031-6c309d6a.json":
        "564ed68d24b7a3a06d902e4b5b6362141eb2a8fc2aad05e191714548c9d90eab",
}
V03_TOOL_SHA256_TEXT_LF = "f1102d7f3be72efeb1b51336e054dda476bebe6f5ead6cf1c6fdf32543dce1d6"


def v03_untouched():
    d = rp(f"game/assets/environments/candidates/{V03_RUN}")
    ok = all(sha(read_bytes(os.path.join(d, n))) == h for n, h in V03_SHA256.items())
    return bool(ok and sha_text(read_bytes(rp(V03_TOOL_REL))) == V03_TOOL_SHA256_TEXT_LF)


def axial_clear(sc, rgba):
    """The axial walk (forecourt foot to the west edge) must stay fully walkable, with no prop, post or canopy
    texel over it (ground-detail overhang tufts and cracks are allowed)."""
    y0 = FORE[3] + 1
    band = np.zeros((H, W), bool)
    band[y0:H, AXIS[0] + 3:AXIS[1] - 2] = True
    walk = sc.walkable_mask()
    over = {n: int(((rgba[n][..., 3] == 255) & band).sum()) for n in ("props-low", "survey-post", "fg-occlusion")}
    return {"band_xyxy": [AXIS[0] + 3, y0, AXIS[1] - 3, H - 1], "walkable_ratio": round(float(walk[band].mean()), 4),
            "texels_over_band": over, "ok": bool(walk[band].all() and not any(over.values()))}


def check(exe, write_report, use_pixelorama, godot=None):
    sc, rgba, flat, files = artefacts()
    nm = names()
    cand = rp(CAND_REL)
    for k in ("pxo", "ora", "flat", "gpl"):
        if read_bytes(os.path.join(cand, nm[k])) != files[k]:
            raise SystemExit(f"{nm[k]} on disk differs from a fresh rebuild")
    met = metrics(sc, rgba, flat)
    ys = ysort_check(sc, rgba)
    dep = depth_audit(sc, rgba)
    pth = path_checks(sc)
    ax = axial_clear(sc, rgba)
    fams = tree_family_counts(sc)
    v03 = np.array(Image.open(rp(V03_FLAT_REL)).convert("RGBA"))
    rep_ = {"v04_flat": repetition_stats(flat), "v03_flat": repetition_stats(v03),
            "v04_facade_band_rows_0_72": repetition_stats(flat, (0, PAV_Y1)),
            "v03_facade_band_rows_0_52": repetition_stats(v03, (0, 52)),
            "v04_fg_occlusion_layer_only": repetition_stats(rgba["fg-occlusion"])}
    rep = {"run": RUN, "gates": {}, "metrics": met["_summary"], "ysort": ys, "depth_audit": dep, "paths": pth,
           "axial_walk": ax, "tree_families": fams, "repetition": rep_, "activity_by_camera_quadrant":
           activity_by_window(sc)}
    s = met["_summary"]
    gates = rep["gates"]
    gates["canvas_1280x720_rgba"] = all(rgba[n].shape == (H, W, 4) for n in LAYERS)
    gates["ground_base_opaque"] = met["ground-base"]["opaque_texels"] == W * H
    gates["binary_alpha_all_layers"] = all(met[n]["semi_alpha_texels"] == 0 for n in ART_LAYERS) and \
        not ((rgba["guides"][..., 3] > 0) & (rgba["guides"][..., 3] < 255)).any()
    gates["art_layers_use_only_palette"] = all(met[n]["colours_outside_art_palette"] == 0 for n in ART_LAYERS)
    gates["palette_38_to_48_in_flat"] = 38 <= s["distinct_colours_in_flat"] <= 48
    gates["fg_occlusion_le_12pct_walkable"] = s["fg_occlusion_over_walkable_ratio"] <= 0.12
    gates["actor_visible_ge_one_third_everywhere"] = s["actor_visibility_below_one_third"] == 0
    gates["ysort_behind_front_stills_all_layers"] = all(v["ok"] for v in ys.values())
    gates["depth_audit_zero_wrong_order"] = dep["ok"]
    gates["paths_entry_to_all_pins_foot11"] = all(pth["foot11"].values())
    gates["stairs_ge_40px_clear_fountain_sides_ge_32px"] = pth["ok"]
    gates["fountain_dry_no_water_colours"] = s["water_colour_texels_in_fountain_footprint"] == 0
    gates["isolated_texels_le_v03"] = s["isolated_single_texel_ratio"] <= 0.0503
    gates["repetition_whole_frame_le_v03"] = rep_["v04_flat"]["repeated_share"] <= rep_["v03_flat"]["repeated_share"]
    gates["repetition_facade_band_le_v03"] = rep_["v04_facade_band_rows_0_72"]["repeated_share"] <= \
        rep_["v03_facade_band_rows_0_52"]["repeated_share"]
    gates["v03_untouched"] = v03_untouched()
    gates["axial_walk_clear_and_walkable"] = ax["ok"]
    gates["tree_shape_families_ge_3"] = len(fams) >= 3
    gates["no_tree_dropped_by_visibility_rule"] = sc.trees_dropped_for_visibility == 0
    gates["survey_post_ge_2x_actor"] = s["survey_post_height_px"] >= 96
    with zipfile.ZipFile(io.BytesIO(files["pxo"])) as z:
        dj = json.loads(z.read("data.json"))
    gates["pxo_layer_stack_is_v04_11_layers"] = [l["name"] for l in dj["layers"]] == LAYERS and \
        [l["visible"] for l in dj["layers"]] == [n != "guides" for n in LAYERS] and len(LAYERS) == 11
    gates["build_deterministic"] = artefacts()[3] == files
    evidence = {}
    if use_pixelorama:
        rep["pixelorama"] = pixelorama_gate(exe, files, rgba, flat)
        gates.update(rep["pixelorama"]["verdicts"])
        fp = rep["pixelorama"].pop("_flat_png", None)
        if fp is not None:
            evidence[fname("pixelorama-pxo-flat-export", "png")] = fp
    if godot:
        rep["godot"], stills = godot_gate(godot, files, rgba)
        gates.update(rep["godot"]["verdicts"])
        for k, b in stills.items():
            evidence[fname("godot-" + k.replace("_", "-"), "png")] = b
    rep["result"] = "PASS" if all(gates.values()) else "FAIL"
    rep["note"] = "Technical gates only. Passing them does not make the art accepted; acceptance is creator review."
    text = json.dumps(rep, indent=2, default=str) + "\n"
    print(text)
    if write_report:
        out = rp(OUT_REL)
        print(write_new(os.path.join(out, fname("technical-check-report", "json")), text.encode()))
        for name, b in evidence.items():
            print(write_new(os.path.join(out, name), b), name)
    return 0 if rep["result"] == "PASS" else 1


GODOT_SCRIPT = r'''extends SceneTree
# Test-only, nonruntime: load the split layer PNGs with Image.load, report size/format/sha256 of the raw RGBA,
# composite runtime-stack stills (base 1-6 -> Y-sorted {sprites, actor} by pivot -> fg-occlusion) with blend_rect,
# then cut the 640x360 logical camera window round the actor and scale it 2x nearest (what the 1280x720 window shows).
func _init():
	var a = OS.get_cmdline_user_args()
	var dir: String = a[0]
	var cases = JSON.parse_string(FileAccess.get_file_as_string(dir + "/cases.json"))
	var names = cases["art_layers"]
	var out = {"layers": {}, "stills": {}}
	var imgs = {}
	for n in names:
		var img = Image.load_from_file(dir + "/" + n + ".png")
		var fmt_in = img.get_format()
		if fmt_in != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		var h = HashingContext.new()
		h.start(HashingContext.HASH_SHA256)
		h.update(img.get_data())
		out["layers"][n] = {"w": img.get_width(), "h": img.get_height(), "format_loaded": fmt_in, "sha256_rgba": h.finish().hex_encode()}
		imgs[n] = img
	var hero = Image.load_from_file(dir + "/heroine48.png")
	hero.convert(Image.FORMAT_RGBA8)
	var sprites = cases["ysort_sprites"]
	for key in cases["feet"].keys():
		var foot = cases["feet"][key]
		var st = imgs[cases["base_layers"][0]].duplicate()
		for i in range(1, cases["base_layers"].size()):
			st.blend_rect(imgs[cases["base_layers"][i]], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		var hp = Vector2i(int(foot[0]) - hero.get_width() / 2, int(foot[1]) - hero.get_height() + 1)
		var placed = false
		for sp in sprites:
			if not placed and int(foot[1]) < int(sp[1]):
				st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
				placed = true
			st.blend_rect(imgs[sp[0]], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		if not placed:
			st.blend_rect(hero, Rect2i(0, 0, hero.get_width(), hero.get_height()), hp)
		st.blend_rect(imgs["fg-occlusion"], Rect2i(0, 0, 1280, 720), Vector2i(0, 0))
		st.save_png(dir + "/still_" + key + ".png")
		var cx = clampi(int(foot[0]), 320, 1280 - 320)
		var cy = clampi(int(foot[1]) - 24, 180, 720 - 180)
		var cam = st.get_region(Rect2i(cx - 320, cy - 180, 640, 360))
		cam.resize(1280, 720, Image.INTERPOLATE_NEAREST)
		cam.save_png(dir + "/cam_" + key + ".png")
		out["stills"][key] = "still_" + key + ".png"
	var f = FileAccess.open(dir + "/godot_report.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("GODOT_GATE_DONE")
	quit()
'''

GODOT_CASES = ("entry", "left_stair_mid", "right_stair_rubble", "recess_front", "recess_side",
               "fountain_behind", "fountain_front", "newel_behind", "newel_front", "post_behind", "post_front",
               "portico", "fallen_tree")


def godot_gate(godot, files, rgba):
    """Test-only, nonruntime: a throwaway Godot project under %LOCALAPPDATA%\\Temp with APPDATA also redirected
    there, so nothing is written to the repo or to the real Godot user dir."""
    tmp = tempfile.mkdtemp(prefix="wb-wdcgodot4-")
    rep = {"godot": godot, "godot_sha256": sha(read_bytes(godot)), "steps": {}}
    stills = {}
    proj_name = f"wdc-scene-gate-v04-{RUN_ID}"
    try:
        proj = os.path.join(tmp, "proj"); os.makedirs(proj)
        data = os.path.join(tmp, "data"); os.makedirs(data)
        fake = os.path.join(tmp, "appdata"); os.makedirs(fake)
        with open(os.path.join(proj, "project.godot"), "w", newline="\n") as f:
            f.write(f'config_version=5\n\n[application]\nconfig/name="{proj_name}"\n')
        with open(os.path.join(proj, "gate.gd"), "w", newline="\n") as f:
            f.write(GODOT_SCRIPT)
        with zipfile.ZipFile(io.BytesIO(files["ora"])) as z:
            for n in ART_LAYERS:
                with open(os.path.join(data, f"{n}.png"), "wb") as f:
                    f.write(z.read(f"data/{n}.png"))
        spr = heroine_48()
        Image.fromarray(spr, "RGBA").save(os.path.join(data, "heroine48.png"))
        feet = {k: list(v) for k, v in actor_cases().items() if k in GODOT_CASES}
        with open(os.path.join(data, "cases.json"), "w") as f:
            json.dump({"art_layers": ART_LAYERS, "base_layers": BASE_LAYERS, "feet": feet,
                       "ysort_sprites": sorted(([k, v] for k, v in YSORT.items()), key=lambda kv: kv[1])}, f)
        env = dict(os.environ); env["APPDATA"] = fake
        p = subprocess.run([godot, "--headless", "--path", proj, "--script", "gate.gd", "--", data],
                           capture_output=True, text=True, timeout=600, env=env, encoding="utf-8", errors="replace")
        rep["exit_code"] = p.returncode
        rep["printed_done"] = "GODOT_GATE_DONE" in p.stdout
        gr = json.load(open(os.path.join(data, "godot_report.json")))
        lay_ok = {}
        for n in ART_LAYERS:
            g = gr["layers"][n]
            lay_ok[n] = g["w"] == W and g["h"] == H and g["sha256_rgba"] == sha(np.ascontiguousarray(rgba[n]).tobytes())
            rep["steps"][n] = {**g, "exact_texels_vs_source": lay_ok[n]}
        st_ok, cam_ok = {}, {}
        for k, foot in feet.items():
            b = read_bytes(os.path.join(data, f"still_{k}.png"))
            got = decode(b)[2]
            exp = runtime_stack_still(rgba, spr, tuple(foot))
            st_ok[k] = bool(got.shape == exp.shape and (got == exp).all())
            cb = read_bytes(os.path.join(data, f"cam_{k}.png"))
            cgot = decode(cb)[2]
            cexp = camera_view(exp, tuple(foot))
            cam_ok[k] = bool(cgot.shape == cexp.shape and (cgot == cexp).all())
            rep["steps"]["still_" + k] = {"foot": foot, "equals_python_runtime_stack": st_ok[k],
                                          "differing_texels": int((got != exp).any(axis=2).sum()),
                                          "camera_rect_xy": list(camera_rect(foot)),
                                          "camera_2x_equals_python": cam_ok[k]}
            stills["still_" + k] = b
            stills["cam2x_" + k] = cb
        rep["verdicts"] = {"godot_loads_layers_exact": all(lay_ok.values()) and rep["exit_code"] == 0,
                           "godot_stills_match_ysort_and_occlusion": all(st_ok.values()),
                           "godot_camera_640x360_2x_match": all(cam_ok.values()),
                           "godot_wrote_nothing_outside_temp": not os.path.isdir(
                               os.path.join(os.environ.get("APPDATA", ""), "Godot", "app_userdata", proj_name))}
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    return rep, stills


def pixelorama_gate(exe, files, rgba, flat):
    real_root = os.path.join(os.environ.get("APPDATA", ""), "pixelorama")
    rep = {"pixelorama": exe, "pixelorama_sha256": sha(read_bytes(exe)),
           "isolation": "APPDATA redirected to a fresh temp dir per run; real %APPDATA%\\pixelorama polled every "
                        "10 ms with a kill-switch", "steps": {}}
    tmp = tempfile.mkdtemp(prefix="wb-wdcscene-")
    try:
        src = {}
        for k in ("pxo", "ora"):
            src[k] = os.path.join(tmp, f"src.{k}")
            with open(src[k], "wb") as f:
                f.write(files[k])
        flats = []
        for label, k, split in (("pxo_flat_1", "pxo", False), ("pxo_flat_2", "pxo", False),
                                ("pxo_split", "pxo", True), ("ora_flat", "ora", False), ("ora_split", "ora", True)):
            d = os.path.join(tmp, label); os.makedirs(d)
            fake = os.path.join(tmp, "appdata_" + label); os.makedirs(fake)
            args = ["--export"] + (["--split-layers"] if split else []) + ["-o", os.path.join(d, "f.png"), src[k]]
            r = run_isolated(exe, args, fake, real_root)
            r["pngs"] = list_pngs(d)
            r["source_copy_unchanged"] = read_bytes(src[k]) == files[k]
            if not split and len(r["pngs"]) == 1:
                b = read_bytes(os.path.join(d, r["pngs"][0]))
                a = decode(b)[2]
                r["png_sha256"] = sha(b)
                r["flat_equals_expected"] = a.shape == flat.shape and bool((a == flat).all())
                r["differing_texels"] = int((a != flat).any(axis=2).sum()) if a.shape == flat.shape else None
                if k == "pxo":
                    flats.append(b)
            if split:
                got = []
                comp = None
                for f in r["pngs"]:
                    a = decode(read_bytes(os.path.join(d, f)))[2]
                    hit = [n for n in LAYERS if a.shape == rgba[n].shape and a.tobytes() == rgba[n].tobytes()]
                    semi = int(((a[..., 3] > 0) & (a[..., 3] < 255)).sum())
                    got.append({"file": f, "exact_layer_match": hit, "semi_alpha": semi})
                r["split"] = got
                matched = [h for g in got for h in g["exact_layer_match"]]
                r["art_layers_all_exact"] = all(n in matched for n in ART_LAYERS)
                r["guides_exported"] = "guides" in matched or any("guides" in g["file"] for g in got)
                # composite of the split art layers (bottom->top) must equal the flattened expectation
                order = {n: i for i, n in enumerate(LAYERS)}
                stack = sorted(((order[g["exact_layer_match"][0]], g["file"]) for g in got
                                if g["exact_layer_match"] and g["exact_layer_match"][0] != "guides"))
                if stack:
                    comp = decode(read_bytes(os.path.join(d, stack[0][1])))[2].copy()
                    for _, f in stack[1:]:
                        a = decode(read_bytes(os.path.join(d, f)))[2]
                        m = a[..., 3] == 255
                        comp[m] = a[m]
                    r["split_composite_equals_flat"] = bool((comp == flat).all())
            rep["steps"][label] = r
        rep["pxo_flat_runs_identical"] = len(flats) == 2 and flats[0] == flats[1]
        if flats:
            rep["_flat_png"] = flats[0]
    finally:
        shutil.rmtree(_fs(tmp), ignore_errors=True)
    st = rep["steps"]
    guard_ok = all(not v["killed_by_guard"] and not v["real_dir_changed_except_running"]
                   and v["real_running_marker_present_after"] for v in st.values())
    rep["verdicts"] = {
        "pixelorama_isolation_held": guard_ok,
        "pixelorama_pxo_flat_exact": all(st[k].get("flat_equals_expected") for k in ("pxo_flat_1", "pxo_flat_2")),
        "pixelorama_pxo_flat_deterministic": rep["pxo_flat_runs_identical"],
        "pixelorama_pxo_split_layers_exact": st["pxo_split"].get("art_layers_all_exact", False),
        "pixelorama_pxo_split_composite_equals_flat": st["pxo_split"].get("split_composite_equals_flat", False),
        "pixelorama_ora_flat_exact": st["ora_flat"].get("flat_equals_expected", False),
        "pixelorama_ora_split_layers_exact": st["ora_split"].get("art_layers_all_exact", False),
        "pixelorama_sources_unchanged": all(v["source_copy_unchanged"] for v in st.values()),
        "pixelorama_split_does_not_export_hidden_guides": not any(st[k].get("guides_exported")
                                                                  for k in ("pxo_split", "ora_split")),
    }
    return rep


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mode", choices=["preview", "build", "check"])
    ap.add_argument("dir", nargs="?")
    ap.add_argument("--pixelorama", default=PIXELORAMA_DEFAULT)
    ap.add_argument("--write-report", action="store_true")
    ap.add_argument("--no-pixelorama", action="store_true")
    ap.add_argument("--godot", default=rp(GODOT_REL))
    ap.add_argument("--no-godot", action="store_true")
    a = ap.parse_args()
    if a.mode == "preview":
        if not a.dir or os.path.abspath(a.dir).startswith(REPO):
            raise SystemExit("preview needs a directory outside the repo")
        return build(a.dir)
    if a.mode == "build":
        return build()
    if not a.no_pixelorama and not os.path.isfile(a.pixelorama):
        raise SystemExit(f"Pixelorama not found: {a.pixelorama}")
    godot = None
    if not a.no_godot:
        if not os.path.isfile(a.godot):
            raise SystemExit(f"Godot not found: {a.godot} (or pass --no-godot)")
        godot = os.path.abspath(a.godot)
    return check(os.path.abspath(a.pixelorama), a.write_report, not a.no_pixelorama, godot)


if __name__ == "__main__":
    sys.exit(main())
